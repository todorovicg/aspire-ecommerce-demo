# Implementation Roadmap

This folder holds the execution plans for the ECommerce Aspire demo. The design is in
[../ARCHITECTURE.md](../ARCHITECTURE.md) and the coding rules in
[../CODING_GUIDELINES.md](../CODING_GUIDELINES.md). Every plan argues from those two
documents; they travel together.

## Documents in this folder

| File | Purpose | Who writes it |
|---|---|---|
| `README.md` | this roadmap: phases, sub-phases, execution protocol | lead, at planning time |
| `0N-<phase>.md` | the detailed plan for one phase, with every file, code block and command | lead, just before the phase starts |
| `STATUS.md` | progress tracking down to task level, plus the exact resume point | lead, after every task review |
| `SUMMARY.md` | dated log of decisions, deviations and surprises during execution | lead, whenever something changes |

Plans are written just in time. Phase 0 and phase 1 are written up front; each later plan
is written after the previous phase is accepted, so it can use what the running system
taught us. This roadmap shows the whole route at sub-phase level from day one.

## Phases

Every phase ends with a runnable increment that can be seen in the dashboard or clicked
in the browser. A phase has sub-phases, each reaching a small verifiable milestone, and
sub-phases have tasks, each ending in a build and a test run.

All six original phases were accepted on 2026-09-12, sub-phase 6.5 the same day after the
owner's browser check. Phases 7 and 8 were added on 2026-09-13 from the owner's feedback and accepted
the same day. Phase 9 was added on 2026-09-14 after the owner's review of the architecture
document. `STATUS.md` holds the per-task states and
`SUMMARY.md` the acceptance records; the root README describes how to run the demo.

| Phase | Plan file | Agents | Delivers | Visible result |
|---|---|---|---|---|
| 0 Foundation | `00-foundation.md` | backend | tooling check, solution skeleton, build props, editorconfig, gitignore, README, ServiceDefaults with the response envelope, AppHost with the four infrastructure resources | dashboard with 4 healthy containers |
| 1 Catalog | `01-catalog.md` | backend | Catalog API with EF Core, migrations, seed data, product endpoints, Scalar, unit tests, AppHost wiring | products JSON from the Catalog URL, Catalog healthy in the dashboard |
| 2 Gateway and frontend shell | `02-gateway-frontend.md` | backend, frontend in parallel | YARP gateway project with service discovery; Angular 22 scaffold, theme, header, footer, products page | browsing products at `https://localhost:7100` |
| 3 Basket | `03-basket.md` | backend, then frontend | Redis basket store, Catalog client, basket endpoints and rules, tests; Angular basket page, basket store, header count | adding, changing and removing items in the browser |
| 4 Checkout and Ordering | `04-checkout-ordering.md` | backend, then frontend | Contracts, Wolverine and RabbitMQ wiring, checkout publishing, Ordering consumer and read endpoints, tests; Angular checkout and orders pages | an order appearing as Submitted after checkout |
| 5 Payment and lifecycle | `05-payment-lifecycle.md` | backend, then frontend | Payment API with test cards, order processor, OrderPaid, Catalog durable inbox and stock decrement, tests; orders polling, out-of-stock UI | the full loop with stock dropping |
| 6 Hardening | `06-hardening.md` | backend | Aspire integration tests, JasperFx dashboard commands, warning cleanup, final README | `dotnet test` buying a product end to end |
| 7 Polish | `07-polish.md` | frontend | orders page shows the order just placed without a refresh, new header, title and footer texts | first order after startup appears on its own |
| 8 Localization | `08-localization.md` | backend and frontend in parallel | Preferences service on Redis, Catalog product translations, Basket names resolved from Catalog per request language, Transloco in the frontend with a language menu, persisted choice, Serbian Latin dictionaries and product content | switching the language translates the UI and the products, survives a refresh |
| 9 API Defaults | `09-api-defaults.md` | backend | `Ecommerce.ApiDefaults` project holding the response envelope, the problem details writer, the registration layers and the buyer identity; ServiceDefaults back to the template; test project renamed | ServiceDefaults reads as the template, `dotnet test` still 154 |

### Sub-phases

**Phase 0 Foundation**
- 0.1 Tooling check and repository skeleton
- 0.2 ServiceDefaults with the API response envelope, and its tests
- 0.3 AppHost with infrastructure resources
- 0.4 Phase acceptance

**Phase 1 Catalog**
- 1.1 Project skeleton and test project
- 1.2 Domain model and persistence, first migration
- 1.3 Seed data and database initializer
- 1.4 Product endpoints
- 1.5 AppHost wiring and phase acceptance

**Phase 2 Gateway and frontend shell**
- 2.1 Gateway project with YARP routes and service discovery
- 2.2 Angular workspace, tooling, theme and layout
- 2.3 Buyer id service, interceptor and response helper
- 2.4 Products page through the gateway
- 2.5 Phase acceptance

**Phase 3 Basket**
- 3.1 Basket domain, Redis store and Catalog client
- 3.2 Basket endpoints and rules
- 3.3 Angular basket store, basket page, header count
- 3.4 Phase acceptance

**Phase 4 Checkout and Ordering**
- 4.1 Contracts project and Wolverine wiring in Basket
- 4.2 Checkout endpoint with validation and inline publish
- 4.3 Ordering project, Mongo store, OrderPlaced handler
- 4.4 Ordering read endpoints
- 4.5 Angular checkout form and orders page
- 4.6 Phase acceptance

**Phase 5 Payment and lifecycle**
- 5.1 Payment API with the test card rule
- 5.2 Order processor: claim, payment call, state transitions
- 5.3 OrderPaid publishing and Catalog durable inbox with stock decrement
- 5.4 Angular orders page polling (out-of-stock rendering was delivered in phase 2)
- 5.5 Phase acceptance

**Phase 6 Hardening**
- 6.1 Integration test project booting the AppHost
- 6.2 JasperFx dashboard commands
- 6.3 Clean startup log and README
- 6.4 Final acceptance
- 6.5 Dashboard URLs, added after the owner's browser check: dev server proxy for `/api` and a regression test

**Phase 7 Polish**
- 7.1 Orders page shows the order just placed
- 7.2 Header, page title and footer texts
- 7.3 Phase acceptance

**Phase 8 Localization**
- 8.1 Preferences service (backend)
- 8.2 Catalog product translations (backend)
- 8.3 Basket names resolved from Catalog per request language (backend)
- 8.4 Frontend localization with Transloco, language menu and persisted choice (frontend, parallel with 8.2 and 8.3)
- 8.5 Phase acceptance

**Phase 9 API Defaults**
- 9.1 Move the shared API code into `Ecommerce.ApiDefaults` (backend)
- 9.2 Documentation (lead)
- 9.3 Phase acceptance

## Execution protocol

**Agents.** Two agent definitions live in `.claude/agents/`: `backend-dev` for all .NET
work and `frontend-dev` for all Angular work. Both run Opus at xhigh effort. At most one
of each exists at a time, and they run in parallel only when a phase has independent
backend and frontend tasks. Within a phase the same agent is continued from task to task
so its context stays consistent. A new phase starts a fresh agent.

**Per task.**

1. The lead sends the agent one task from the plan, verbatim, with the global constraints.
2. The agent works test-first and reports files, commands, output and deviations.
3. The lead reviews without delegating: reads every changed file, builds and runs the
   tests, and checks the work against the plan, the architecture document and the
   guidelines, including the envelope, the log format and the license rule.
4. If anything is off, the lead sends the same agent precise fix instructions and reviews
   again. Only a passing review ticks the task in `STATUS.md`.

**Per phase.** When the last task passes, the lead runs the phase acceptance section with
`aspire run`, checks the dashboard and the UI as written, records the phase in
`SUMMARY.md`, and stops for the owner's review before the next phase.

**Resuming after an interruption.** Read `STATUS.md` first. Its "Current position" block
names the phase, sub-phase and task in progress, which agent had it, what was last
verified, and any half-finished work to look for. Then open the plan file it points to
and continue from that task.

## Global constraints

Copied from the design documents. Every task implicitly includes them.

- .NET SDK 10.0.201 or later 10.0.x, Aspire 13.5.3, Node 24 through nvm, Docker running.
- Only dependencies that are fully open source with no personal or commercial license
  requirement. New ones go into ARCHITECTURE.md section 9 before use.
- No fault injection, chaos switches, simulators or test-only code paths.
- Project names use the `Ecommerce.` prefix; resource names in the AppHost are
  kebab-case as listed in ARCHITECTURE.md section 6.
- Every API response uses the envelope from CODING_GUIDELINES.md section 2.5.
- Every log line uses the format from CODING_GUIDELINES.md section 3.
- No XML documentation, `//` comments only where needed, no em dashes anywhere.
- Default analyzers, warnings allowed but the handed-over build has none.
- No git commands. Tasks end with a build and a test run instead of a commit.
