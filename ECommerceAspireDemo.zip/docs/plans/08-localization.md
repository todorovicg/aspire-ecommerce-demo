# Phase 8 Localization Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** English and Serbian (Latin script) for the whole shop: UI text, statuses, error messages, product names, descriptions and categories, with a language menu in the header and the choice stored per buyer on the server.

**Architecture:** A new `Ecommerce.Preferences.Api` keeps each buyer's language in the shared Redis resource (renamed from `basket-cache` to `redis`) behind `GET` and `PUT /api/preferences`, keyed by the existing `X-Buyer-Id` header and routed through the gateway. Catalog stores translations in a `product_translations` owned collection with English on the product as the fallback and reads the language from the standard `Accept-Language` header through ASP.NET Core request localization. Basket stops storing product names; it names every line from Catalog on each read, forwarding `Accept-Language` with the framework's header propagation, so the basket follows the language and order lines carry the names in the language active at checkout. Ordering is untouched. The frontend uses Transloco with JSON dictionaries under `public/i18n`, a `LanguageStore` that loads the buyer's preference before the first render and persists changes, an interceptor that sends `Accept-Language`, `transloco-locale` pipes for prices and dates, and a language menu before Products.

**Tech Stack:** Aspire.StackExchange.Redis (already present), Microsoft.AspNetCore.HeaderPropagation 10.0.12 (MIT), EF Core owned collections and a new migration, @jsverse/transloco 8.4.0 and @jsverse/transloco-locale 8.4.0 (MIT), Angular 22, Vitest.

**Spec:** `docs/ARCHITECTURE.md` sections 4.1, 4.2, 4.3, 4.7, 4.8, 6 and 9; `docs/CODING_GUIDELINES.md`.

**Agents and ordering:** `backend-dev` runs 8.1.1, then 8.2.1, then 8.3.1 in that order, because Basket's integration test expects Serbian names from Catalog. `frontend-dev` runs 8.4.1 in parallel from the start; its unit tests do not need the backend. Sub-phase 8.5 is the lead's acceptance.

## Global Constraints

- Everything from `docs/plans/README.md` Global constraints applies.
- New packages in this phase, and nothing else: NuGet `Microsoft.AspNetCore.HeaderPropagation` 10.0.12; npm `@jsverse/transloco` 8.4.0 and `@jsverse/transloco-locale` 8.4.0. All MIT.
- Languages are `en` and `sr`. The API receives `Accept-Language: en` or `sr-Latn`; Catalog answers anything else in English. Serbian text is Latin script with diacritics.
- Every full `dotnet test` boots the AppHost, so Docker must be running, Node 24 must be on the PATH (`source "$HOME/.nvm/nvm.sh" && nvm use 24`) and no other AppHost from this repository may run. `dotnet ef` is a global tool; put `$HOME/.dotnet/tools` on the PATH before using it.
- Run every npm command from `src/ecommerce-frontend` with Node 24 from nvm; run `npm run format` before `npm run format:check`.
- Log lines follow `[{Prefix}] ... [{Value}]`; comments only where they explain something the code cannot; no em dashes anywhere, including the dictionaries.
- Nothing under `docs/` is edited by an agent.

---

## Sub-phase 8.1 Preferences service (backend-dev)

### Task 8.1.1: Preferences API on the shared Redis, gateway route, AppHost wiring, integration test

**Files:**
- Create: `src/Ecommerce.Preferences.Api/Ecommerce.Preferences.Api.csproj`
- Create: `src/Ecommerce.Preferences.Api/Properties/launchSettings.json`
- Create: `src/Ecommerce.Preferences.Api/appsettings.json`
- Create: `src/Ecommerce.Preferences.Api/appsettings.Development.json`
- Create: `src/Ecommerce.Preferences.Api/ErrorCodes.cs`
- Create: `src/Ecommerce.Preferences.Api/Domain/Languages.cs`
- Create: `src/Ecommerce.Preferences.Api/Domain/BuyerPreferences.cs`
- Create: `src/Ecommerce.Preferences.Api/Infrastructure/IPreferencesStore.cs`
- Create: `src/Ecommerce.Preferences.Api/Infrastructure/RedisPreferencesStore.cs`
- Create: `src/Ecommerce.Preferences.Api/Features/PreferencesResponse.cs`
- Create: `src/Ecommerce.Preferences.Api/Features/PreferencesService.cs`
- Create: `src/Ecommerce.Preferences.Api/Features/GetPreferences/GetPreferencesEndpoint.cs`
- Create: `src/Ecommerce.Preferences.Api/Features/UpdatePreferences/UpdatePreferencesEndpoint.cs`
- Create: `src/Ecommerce.Preferences.Api/Program.cs`
- Create: `tests/Ecommerce.Preferences.Api.Tests/Ecommerce.Preferences.Api.Tests.csproj`
- Create: `tests/Ecommerce.Preferences.Api.Tests/Fakes/InMemoryPreferencesStore.cs`
- Create: `tests/Ecommerce.Preferences.Api.Tests/Domain/LanguagesTests.cs`
- Create: `tests/Ecommerce.Preferences.Api.Tests/Features/PreferencesServiceTests.cs`
- Create: `tests/Ecommerce.Preferences.Api.Tests/Features/GetPreferencesEndpointTests.cs`
- Create: `tests/Ecommerce.Preferences.Api.Tests/Features/UpdatePreferencesEndpointTests.cs`
- Create: `tests/Ecommerce.IntegrationTests/PreferencesTests.cs`
- Modify: `ECommerceAspireDemo.slnx`
- Modify: `src/Ecommerce.AppHost/Ecommerce.AppHost.csproj`
- Modify: `src/Ecommerce.AppHost/AppHost.cs`
- Modify: `src/Ecommerce.Gateway/appsettings.json`
- Modify: `src/Ecommerce.Basket.Api/Program.cs` (one line: the Redis connection name)

**Interfaces:**
- Consumes: `BuyerId` and `BuyerIdFilter` from ServiceDefaults, `ApiResults`, the shared Redis resource.
- Produces: `GET /api/preferences` returning `{ language }` (English when nothing is stored) and `PUT /api/preferences` with body `{ language }` returning the stored preferences or `400 preferences.unsupported_language`; the AppHost resource `preferences-api` on ports 7150 and 5150; the gateway route `/api/preferences/{**catch-all}`; the Redis resource is now named `redis` and Basket connects to it under that name.

- [ ] **Step 1: Project files, solution entries and the failing tests**

Create `src/Ecommerce.Preferences.Api/Ecommerce.Preferences.Api.csproj`:

```xml
<Project Sdk="Microsoft.NET.Sdk.Web">

  <ItemGroup>
    <PackageReference Include="Aspire.StackExchange.Redis" />
  </ItemGroup>

  <ItemGroup>
    <ProjectReference Include="../Ecommerce.ServiceDefaults/Ecommerce.ServiceDefaults.csproj" />
  </ItemGroup>

</Project>
```

Create `src/Ecommerce.Preferences.Api/Properties/launchSettings.json`:

```json
{
  "$schema": "https://json.schemastore.org/launchsettings.json",
  "profiles": {
    "https": {
      "commandName": "Project",
      "dotnetRunMessages": true,
      "launchBrowser": false,
      "applicationUrl": "https://localhost:7150;http://localhost:5150",
      "environmentVariables": {
        "ASPNETCORE_ENVIRONMENT": "Development"
      }
    },
    "http": {
      "commandName": "Project",
      "dotnetRunMessages": true,
      "launchBrowser": false,
      "applicationUrl": "http://localhost:5150",
      "environmentVariables": {
        "ASPNETCORE_ENVIRONMENT": "Development"
      }
    }
  }
}
```

Create `src/Ecommerce.Preferences.Api/appsettings.json`:

```json
{
  "Logging": {
    "LogLevel": {
      "Default": "Information",
      "Microsoft.AspNetCore": "Warning"
    }
  },
  "AllowedHosts": "*"
}
```

Create `src/Ecommerce.Preferences.Api/appsettings.Development.json`:

```json
{
  "Logging": {
    "LogLevel": {
      "Default": "Information",
      "Microsoft.AspNetCore": "Warning"
    }
  }
}
```

Create `tests/Ecommerce.Preferences.Api.Tests/Ecommerce.Preferences.Api.Tests.csproj`:

```xml
<Project Sdk="Microsoft.NET.Sdk">

  <PropertyGroup>
    <OutputType>Exe</OutputType>
    <IsPackable>false</IsPackable>
    <IsTestProject>true</IsTestProject>
  </PropertyGroup>

  <ItemGroup>
    <PackageReference Include="xunit.v3" />
  </ItemGroup>

  <ItemGroup>
    <Using Include="Xunit" />
  </ItemGroup>

  <ItemGroup>
    <ProjectReference Include="../../src/Ecommerce.Preferences.Api/Ecommerce.Preferences.Api.csproj" />
  </ItemGroup>

</Project>
```

In `ECommerceAspireDemo.slnx` add one line after the Payment project in the `src` folder and one after the Payment tests in the `tests` folder, keeping the alphabetical order:

```xml
    <Project Path="src/Ecommerce.Preferences.Api/Ecommerce.Preferences.Api.csproj" />
```

```xml
    <Project Path="tests/Ecommerce.Preferences.Api.Tests/Ecommerce.Preferences.Api.Tests.csproj" />
```

Create `tests/Ecommerce.Preferences.Api.Tests/Fakes/InMemoryPreferencesStore.cs`:

```csharp
using Ecommerce.Preferences.Api.Domain;
using Ecommerce.Preferences.Api.Infrastructure;

namespace Ecommerce.Preferences.Api.Tests.Fakes;

public sealed class InMemoryPreferencesStore : IPreferencesStore
{
    private readonly Dictionary<Guid, BuyerPreferences> _preferences = [];

    public int SaveCount { get; private set; }

    public Task<BuyerPreferences?> GetAsync(Guid buyerId, CancellationToken cancellationToken) =>
        Task.FromResult(_preferences.GetValueOrDefault(buyerId));

    public Task SaveAsync(Guid buyerId, BuyerPreferences preferences, CancellationToken cancellationToken)
    {
        _preferences[buyerId] = preferences;
        SaveCount++;
        return Task.CompletedTask;
    }
}
```

Create `tests/Ecommerce.Preferences.Api.Tests/Domain/LanguagesTests.cs`:

```csharp
using Ecommerce.Preferences.Api.Domain;

namespace Ecommerce.Preferences.Api.Tests.Domain;

public sealed class LanguagesTests
{
    [Theory]
    [InlineData("en")]
    [InlineData("sr")]
    public void IsSupported_WithAgreedLanguages_ReturnsTrue(string language)
    {
        Assert.True(Languages.IsSupported(language));
    }

    [Theory]
    [InlineData("de")]
    [InlineData("EN")]
    [InlineData("sr-Latn")]
    [InlineData("")]
    [InlineData(null)]
    public void IsSupported_WithAnythingElse_ReturnsFalse(string? language)
    {
        Assert.False(Languages.IsSupported(language));
    }

    [Fact]
    public void Default_IsEnglish()
    {
        Assert.Equal("en", Languages.Default);
        Assert.Equal("en", BuyerPreferences.Default.Language);
    }
}
```

Create `tests/Ecommerce.Preferences.Api.Tests/Features/PreferencesServiceTests.cs`:

```csharp
using Ecommerce.Preferences.Api.Features;
using Ecommerce.Preferences.Api.Tests.Fakes;
using Ecommerce.ServiceDefaults.Api;
using Microsoft.Extensions.Logging.Abstractions;

namespace Ecommerce.Preferences.Api.Tests.Features;

public sealed class PreferencesServiceTests
{
    private static readonly BuyerId Buyer = new(Guid.Parse("b0000000-0000-4000-8000-000000000001"));

    private readonly InMemoryPreferencesStore _store = new();

    private PreferencesService CreateService() => new(_store, NullLogger<PreferencesService>.Instance);

    [Fact]
    public async Task GetAsync_WithoutStoredPreferences_ReturnsEnglish()
    {
        var preferences = await CreateService().GetAsync(Buyer, TestContext.Current.CancellationToken);

        Assert.Equal("en", preferences.Language);
        Assert.Equal(0, _store.SaveCount);
    }

    [Fact]
    public async Task UpdateAsync_WithSupportedLanguage_StoresAndReturnsIt()
    {
        var service = CreateService();

        var result = await service.UpdateAsync(Buyer, "sr", TestContext.Current.CancellationToken);

        var updated = Assert.IsType<UpdatePreferencesResult.Updated>(result);
        Assert.Equal("sr", updated.Preferences.Language);
        Assert.Equal(1, _store.SaveCount);
        Assert.Equal("sr", (await service.GetAsync(Buyer, TestContext.Current.CancellationToken)).Language);
    }

    [Fact]
    public async Task UpdateAsync_WithUnsupportedLanguage_ReturnsUnsupportedWithoutSaving()
    {
        var result = await CreateService().UpdateAsync(Buyer, "de", TestContext.Current.CancellationToken);

        var unsupported = Assert.IsType<UpdatePreferencesResult.UnsupportedLanguage>(result);
        Assert.Equal("de", unsupported.Language);
        Assert.Equal(0, _store.SaveCount);
    }
}
```

Create `tests/Ecommerce.Preferences.Api.Tests/Features/GetPreferencesEndpointTests.cs`:

```csharp
using Ecommerce.Preferences.Api.Features;
using Ecommerce.Preferences.Api.Features.GetPreferences;
using Ecommerce.Preferences.Api.Tests.Fakes;
using Ecommerce.ServiceDefaults.Api;
using Microsoft.Extensions.Logging.Abstractions;

namespace Ecommerce.Preferences.Api.Tests.Features;

public sealed class GetPreferencesEndpointTests
{
    private static readonly BuyerId Buyer = new(Guid.Parse("b0000000-0000-4000-8000-000000000001"));

    [Fact]
    public async Task HandleAsync_WithoutStoredPreferences_ReturnsEnglishEnvelope()
    {
        var service = new PreferencesService(new InMemoryPreferencesStore(), NullLogger<PreferencesService>.Instance);

        var result = await GetPreferencesEndpoint.HandleAsync(Buyer, service, TestContext.Current.CancellationToken);

        Assert.NotNull(result.Value);
        Assert.True(result.Value.Success);
        Assert.Equal("en", result.Value.Data?.Language);
    }
}
```

Create `tests/Ecommerce.Preferences.Api.Tests/Features/UpdatePreferencesEndpointTests.cs`:

```csharp
using Ecommerce.Preferences.Api.Features;
using Ecommerce.Preferences.Api.Features.UpdatePreferences;
using Ecommerce.Preferences.Api.Tests.Fakes;
using Ecommerce.ServiceDefaults.Api;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.Extensions.Logging.Abstractions;

namespace Ecommerce.Preferences.Api.Tests.Features;

public sealed class UpdatePreferencesEndpointTests
{
    private static readonly BuyerId Buyer = new(Guid.Parse("b0000000-0000-4000-8000-000000000001"));

    private readonly PreferencesService _service = new(new InMemoryPreferencesStore(), NullLogger<PreferencesService>.Instance);

    [Fact]
    public async Task HandleAsync_WithSupportedLanguage_ReturnsOkEnvelope()
    {
        var result = await UpdatePreferencesEndpoint.HandleAsync(Buyer, new UpdatePreferencesRequest("sr"), _service, TestContext.Current.CancellationToken);

        var ok = Assert.IsType<Ok<ApiResponse<PreferencesResponse>>>(result.Result);
        Assert.Equal("sr", ok.Value?.Data?.Language);
    }

    [Fact]
    public async Task HandleAsync_WithUnsupportedLanguage_ReturnsBadRequestEnvelope()
    {
        var result = await UpdatePreferencesEndpoint.HandleAsync(Buyer, new UpdatePreferencesRequest("de"), _service, TestContext.Current.CancellationToken);

        var badRequest = Assert.IsType<BadRequest<ApiResponse>>(result.Result);
        Assert.Equal("preferences.unsupported_language", badRequest.Value?.Error?.Code);
        Assert.Equal("Language [de] is not supported", badRequest.Value?.Error?.Message);
    }
}
```

```bash
dotnet build tests/Ecommerce.Preferences.Api.Tests
```

Expected: the build fails because the `Domain`, `Infrastructure` and `Features` types do not exist yet. Note the first error lines for the report.

- [ ] **Step 2: Implement the service**

Create `src/Ecommerce.Preferences.Api/ErrorCodes.cs`:

```csharp
namespace Ecommerce.Preferences.Api;

public static class ErrorCodes
{
    public const string UnsupportedLanguage = "preferences.unsupported_language";
}
```

Create `src/Ecommerce.Preferences.Api/Domain/Languages.cs`:

```csharp
namespace Ecommerce.Preferences.Api.Domain;

public static class Languages
{
    public const string Default = "en";

    public static readonly IReadOnlyList<string> Supported = ["en", "sr"];

    public static bool IsSupported(string? language) =>
        language is not null && Supported.Contains(language, StringComparer.Ordinal);
}
```

Create `src/Ecommerce.Preferences.Api/Domain/BuyerPreferences.cs`:

```csharp
namespace Ecommerce.Preferences.Api.Domain;

public sealed record BuyerPreferences(string Language)
{
    public static readonly BuyerPreferences Default = new(Languages.Default);
}
```

Create `src/Ecommerce.Preferences.Api/Infrastructure/IPreferencesStore.cs`:

```csharp
using Ecommerce.Preferences.Api.Domain;

namespace Ecommerce.Preferences.Api.Infrastructure;

public interface IPreferencesStore
{
    Task<BuyerPreferences?> GetAsync(Guid buyerId, CancellationToken cancellationToken);

    Task SaveAsync(Guid buyerId, BuyerPreferences preferences, CancellationToken cancellationToken);
}
```

Create `src/Ecommerce.Preferences.Api/Infrastructure/RedisPreferencesStore.cs`:

```csharp
using System.Text.Json;
using Ecommerce.Preferences.Api.Domain;
using StackExchange.Redis;

namespace Ecommerce.Preferences.Api.Infrastructure;

// Preferences never expire; a buyer's choice must survive any number of refreshes and restarts
public sealed class RedisPreferencesStore(IConnectionMultiplexer redis) : IPreferencesStore
{
    public async Task<BuyerPreferences?> GetAsync(Guid buyerId, CancellationToken cancellationToken)
    {
        var value = await redis.GetDatabase().StringGetAsync(KeyFor(buyerId));
        return value.IsNullOrEmpty ? null : JsonSerializer.Deserialize<BuyerPreferences>((string)value!, JsonSerializerOptions.Web);
    }

    public Task SaveAsync(Guid buyerId, BuyerPreferences preferences, CancellationToken cancellationToken)
    {
        var json = JsonSerializer.Serialize(preferences, JsonSerializerOptions.Web);
        return redis.GetDatabase().StringSetAsync(KeyFor(buyerId), json);
    }

    private static string KeyFor(Guid buyerId) => $"preferences:{buyerId}";
}
```

Create `src/Ecommerce.Preferences.Api/Features/PreferencesResponse.cs`:

```csharp
using Ecommerce.Preferences.Api.Domain;

namespace Ecommerce.Preferences.Api.Features;

public sealed record PreferencesResponse(string Language)
{
    public static PreferencesResponse From(BuyerPreferences preferences) => new(preferences.Language);
}
```

Create `src/Ecommerce.Preferences.Api/Features/PreferencesService.cs`:

```csharp
using Ecommerce.Preferences.Api.Domain;
using Ecommerce.Preferences.Api.Infrastructure;
using Ecommerce.ServiceDefaults.Api;

namespace Ecommerce.Preferences.Api.Features;

public abstract record UpdatePreferencesResult
{
    public sealed record Updated(BuyerPreferences Preferences) : UpdatePreferencesResult;

    public sealed record UnsupportedLanguage(string Language) : UpdatePreferencesResult;
}

public sealed class PreferencesService(IPreferencesStore store, ILogger<PreferencesService> logger)
{
    public async Task<BuyerPreferences> GetAsync(BuyerId buyerId, CancellationToken cancellationToken) =>
        await store.GetAsync(buyerId.Value, cancellationToken) ?? BuyerPreferences.Default;

    public async Task<UpdatePreferencesResult> UpdateAsync(BuyerId buyerId, string language, CancellationToken cancellationToken)
    {
        if (!Languages.IsSupported(language))
        {
            return new UpdatePreferencesResult.UnsupportedLanguage(language);
        }

        var preferences = new BuyerPreferences(language);
        await store.SaveAsync(buyerId.Value, preferences, cancellationToken);
        logger.LogInformation("[{Prefix}] Set language [{Language}] for buyer [{BuyerId}]", nameof(PreferencesService), language, buyerId.Value);

        return new UpdatePreferencesResult.Updated(preferences);
    }
}
```

Create `src/Ecommerce.Preferences.Api/Features/GetPreferences/GetPreferencesEndpoint.cs`:

```csharp
using Ecommerce.ServiceDefaults.Api;
using Microsoft.AspNetCore.Http.HttpResults;

namespace Ecommerce.Preferences.Api.Features.GetPreferences;

public static class GetPreferencesEndpoint
{
    public static RouteGroupBuilder MapGetPreferences(this RouteGroupBuilder group)
    {
        group.MapGet("/", HandleAsync).WithName("GetPreferences");
        return group;
    }

    public static async Task<Ok<ApiResponse<PreferencesResponse>>> HandleAsync(
        BuyerId buyerId,
        PreferencesService service,
        CancellationToken cancellationToken)
    {
        var preferences = await service.GetAsync(buyerId, cancellationToken);
        return ApiResults.Ok(PreferencesResponse.From(preferences));
    }
}
```

Create `src/Ecommerce.Preferences.Api/Features/UpdatePreferences/UpdatePreferencesEndpoint.cs`:

```csharp
using System.ComponentModel.DataAnnotations;
using Ecommerce.Preferences.Api.Domain;
using Ecommerce.ServiceDefaults.Api;
using Microsoft.AspNetCore.Http.HttpResults;

namespace Ecommerce.Preferences.Api.Features.UpdatePreferences;

public sealed record UpdatePreferencesRequest([property: Required, StringLength(8)] string Language);

public static class UpdatePreferencesEndpoint
{
    public static RouteGroupBuilder MapUpdatePreferences(this RouteGroupBuilder group)
    {
        group.MapPut("/", HandleAsync).WithName("UpdatePreferences");
        return group;
    }

    public static async Task<Results<Ok<ApiResponse<PreferencesResponse>>, BadRequest<ApiResponse>>> HandleAsync(
        BuyerId buyerId,
        UpdatePreferencesRequest request,
        PreferencesService service,
        CancellationToken cancellationToken)
    {
        var result = await service.UpdateAsync(buyerId, request.Language, cancellationToken);

        return result switch
        {
            UpdatePreferencesResult.Updated updated => ApiResults.Ok(PreferencesResponse.From(updated.Preferences)),
            UpdatePreferencesResult.UnsupportedLanguage unsupported => ApiResults.BadRequest(ErrorCodes.UnsupportedLanguage, $"Language [{unsupported.Language}] is not supported", new { Supported = Languages.Supported }),
            _ => throw new InvalidOperationException($"Unhandled result [{result.GetType().Name}]"),
        };
    }
}
```

Create `src/Ecommerce.Preferences.Api/Program.cs`:

```csharp
using Ecommerce.Preferences.Api.Features;
using Ecommerce.Preferences.Api.Features.GetPreferences;
using Ecommerce.Preferences.Api.Features.UpdatePreferences;
using Ecommerce.Preferences.Api.Infrastructure;
using Ecommerce.ServiceDefaults.Api;

var builder = WebApplication.CreateBuilder(args);

builder.AddServiceDefaults();
builder.AddApiDefaults();
builder.Services.AddValidation();
builder.AddRedisClient("redis");
builder.Services.AddSingleton<IPreferencesStore, RedisPreferencesStore>();
builder.Services.AddScoped<PreferencesService>();

var app = builder.Build();

app.UseApiDefaults();

var preferences = app.MapGroup("/api/preferences").WithTags("Preferences").AddEndpointFilter<BuyerIdFilter>();
preferences.MapGetPreferences();
preferences.MapUpdatePreferences();

app.Run();
```

```bash
dotnet test --project tests/Ecommerce.Preferences.Api.Tests
```

Expected: 14 tests passed.

- [ ] **Step 3: Wire the service into the AppHost and the gateway, rename the Redis resource, add the integration test**

In `src/Ecommerce.AppHost/Ecommerce.AppHost.csproj` add one project reference after the Payment one:

```xml
    <ProjectReference Include="../Ecommerce.Preferences.Api/Ecommerce.Preferences.Api.csproj" />
```

Replace `src/Ecommerce.AppHost/AppHost.cs` with:

```csharp
using JasperFx.Aspire;

var builder = DistributedApplication.CreateBuilder(args);

var postgres = builder.AddPostgres("postgres");
var catalogDb = postgres.AddDatabase("catalogdb");
var basketDb = postgres.AddDatabase("basketdb");
var orderingMessagesDb = postgres.AddDatabase("orderingmessages");

var redis = builder.AddRedis("redis");

var rabbitMq = builder.AddRabbitMQ("messaging")
    .WithManagementPlugin();

var mongo = builder.AddMongoDB("mongo");
var orderingDb = mongo.AddDatabase("orderingdb");

var catalogApi = builder.AddProject<Projects.Ecommerce_Catalog_Api>("catalog-api")
    .WithReference(catalogDb)
    .WaitFor(catalogDb)
    .WithReference(rabbitMq)
    .WaitFor(rabbitMq)
    .WithHttpHealthCheck("/health")
    .WithJasperFxCommands();

var paymentApi = builder.AddProject<Projects.Ecommerce_Payment_Api>("payment-api")
    .WithHttpHealthCheck("/health");

var preferencesApi = builder.AddProject<Projects.Ecommerce_Preferences_Api>("preferences-api")
    .WithReference(redis)
    .WaitFor(redis)
    .WithHttpHealthCheck("/health");

var basketApi = builder.AddProject<Projects.Ecommerce_Basket_Api>("basket-api")
    .WithReference(redis)
    .WaitFor(redis)
    .WithReference(basketDb)
    .WaitFor(basketDb)
    .WithReference(rabbitMq)
    .WaitFor(rabbitMq)
    .WithReference(catalogApi)
    .WaitFor(catalogApi)
    .WithHttpHealthCheck("/health")
    .WithJasperFxCommands();

var orderingApi = builder.AddProject<Projects.Ecommerce_Ordering_Api>("ordering-api")
    .WithReference(orderingDb)
    .WaitFor(orderingDb)
    .WithReference(orderingMessagesDb)
    .WaitFor(orderingMessagesDb)
    .WithReference(rabbitMq)
    .WaitFor(rabbitMq)
    .WithReference(paymentApi)
    .WithHttpHealthCheck("/health")
    .WithJasperFxCommands();

var frontend = builder.AddViteApp("frontend", "../ecommerce-frontend");

var gateway = builder.AddProject<Projects.Ecommerce_Gateway>("gateway")
    .WithReference(catalogApi)
    .WaitFor(catalogApi)
    .WithReference(basketApi)
    .WaitFor(basketApi)
    .WithReference(orderingApi)
    .WaitFor(orderingApi)
    .WithReference(preferencesApi)
    .WaitFor(preferencesApi)
    .WithReference(frontend)
    .WithHttpHealthCheck("/health")
    .WithExternalHttpEndpoints();

// The dev server proxies /api to the gateway, so the frontend URL in the dashboard works on its own
frontend.WithReference(gateway);

builder.Build().Run();
```

Replace `src/Ecommerce.Gateway/appsettings.json` with:

```json
{
  "Logging": {
    "LogLevel": {
      "Default": "Information",
      "Microsoft.AspNetCore": "Warning",
      "Yarp": "Warning"
    }
  },
  "AllowedHosts": "*",
  "ReverseProxy": {
    "Routes": {
      "catalog": {
        "ClusterId": "catalog",
        "Order": 0,
        "Match": {
          "Path": "/api/catalog/{**catch-all}"
        }
      },
      "basket": {
        "ClusterId": "basket",
        "Order": 0,
        "Match": {
          "Path": "/api/basket/{**catch-all}"
        }
      },
      "orders": {
        "ClusterId": "ordering",
        "Order": 0,
        "Match": {
          "Path": "/api/orders/{**catch-all}"
        }
      },
      "preferences": {
        "ClusterId": "preferences",
        "Order": 0,
        "Match": {
          "Path": "/api/preferences/{**catch-all}"
        }
      },
      "frontend": {
        "ClusterId": "frontend",
        "Order": 1000,
        "Match": {
          "Path": "/{**catch-all}"
        }
      }
    },
    "Clusters": {
      "catalog": {
        "Destinations": {
          "catalog-api": {
            "Address": "https+http://catalog-api"
          }
        }
      },
      "basket": {
        "Destinations": {
          "basket-api": {
            "Address": "https+http://basket-api"
          }
        }
      },
      "ordering": {
        "Destinations": {
          "ordering-api": {
            "Address": "https+http://ordering-api"
          }
        }
      },
      "preferences": {
        "Destinations": {
          "preferences-api": {
            "Address": "https+http://preferences-api"
          }
        }
      },
      "frontend": {
        "Destinations": {
          "frontend": {
            "Address": "http://frontend"
          }
        }
      }
    }
  }
}
```

In `src/Ecommerce.Basket.Api/Program.cs` change the single line `builder.AddRedisClient("basket-cache");` to:

```csharp
builder.AddRedisClient("redis");
```

Create `tests/Ecommerce.IntegrationTests/PreferencesTests.cs`:

```csharp
using System.Net;
using System.Net.Http.Json;
using System.Text.Json;

namespace Ecommerce.IntegrationTests;

[Collection(AppCollection.Name)]
public sealed class PreferencesTests(AppFixture app)
{
    private static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web);

    [Fact]
    public async Task Language_DefaultsToEnglish_AndSurvivesAnUpdate()
    {
        var cancellationToken = TestContext.Current.CancellationToken;
        var buyerId = Guid.NewGuid();

        Assert.Equal("en", await GetLanguageAsync(buyerId, cancellationToken));

        using var update = await SendAsync(HttpMethod.Put, buyerId, new { language = "sr" }, cancellationToken);
        Assert.Equal(HttpStatusCode.OK, update.StatusCode);

        Assert.Equal("sr", await GetLanguageAsync(buyerId, cancellationToken));
    }

    [Fact]
    public async Task Language_Unsupported_IsRejectedWithTheEnvelopeCode()
    {
        var cancellationToken = TestContext.Current.CancellationToken;

        using var response = await SendAsync(HttpMethod.Put, Guid.NewGuid(), new { language = "de" }, cancellationToken);

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
        using var body = JsonDocument.Parse(await response.Content.ReadAsStringAsync(cancellationToken));
        Assert.Equal("preferences.unsupported_language", body.RootElement.GetProperty("error").GetProperty("code").GetString());
    }

    private async Task<string?> GetLanguageAsync(Guid buyerId, CancellationToken cancellationToken)
    {
        using var response = await SendAsync(HttpMethod.Get, buyerId, null, cancellationToken);
        response.EnsureSuccessStatusCode();
        using var body = JsonDocument.Parse(await response.Content.ReadAsStringAsync(cancellationToken));
        return body.RootElement.GetProperty("data").GetProperty("language").GetString();
    }

    private async Task<HttpResponseMessage> SendAsync(HttpMethod method, Guid buyerId, object? body, CancellationToken cancellationToken)
    {
        using var request = new HttpRequestMessage(method, "/api/preferences");
        request.Headers.Add("X-Buyer-Id", buyerId.ToString());
        if (body is not null)
        {
            request.Content = JsonContent.Create(body, options: Json);
        }

        return await app.Gateway.SendAsync(request, cancellationToken);
    }
}
```

```bash
export PATH="$PATH:$HOME/.dotnet/tools"
source "$HOME/.nvm/nvm.sh" && nvm use 24
dotnet build
dotnet test
```

Expected: `0 Warning(s)`, `0 Error(s)`; 130 tests passed (114 before, 14 unit tests and 2 integration tests new). The integration project boots the AppHost with the new `preferences-api` resource; about 40 s.

## Sub-phase 8.2 Catalog product translations (backend-dev)

### Task 8.2.1: Translations owned by the product, request language from Accept-Language, Serbian seed

**Files:**
- Create: `src/Ecommerce.Catalog.Api/Domain/ProductTranslation.cs`
- Create: `src/Ecommerce.Catalog.Api/Domain/ProductText.cs`
- Modify: `src/Ecommerce.Catalog.Api/Domain/Product.cs`
- Modify: `src/Ecommerce.Catalog.Api/Infrastructure/ProductConfiguration.cs`
- Modify: `src/Ecommerce.Catalog.Api/Infrastructure/CatalogSeedData.cs`
- Modify: `src/Ecommerce.Catalog.Api/Infrastructure/CatalogDbInitializer.cs`
- Create: `src/Ecommerce.Catalog.Api/Features/RequestLanguage.cs`
- Modify: `src/Ecommerce.Catalog.Api/Features/ProductResponse.cs`
- Modify: `src/Ecommerce.Catalog.Api/Features/ListProducts/ListProductsEndpoint.cs`
- Modify: `src/Ecommerce.Catalog.Api/Features/GetProduct/GetProductEndpoint.cs`
- Modify: `src/Ecommerce.Catalog.Api/Program.cs`
- Create (generated): `src/Ecommerce.Catalog.Api/Infrastructure/Migrations/<timestamp>_AddProductTranslations.cs` and its Designer, and the updated `CatalogDbContextModelSnapshot.cs`
- Create: `tests/Ecommerce.Catalog.Api.Tests/Domain/ProductTranslationTests.cs`
- Modify: `tests/Ecommerce.Catalog.Api.Tests/Domain/ProductTests.cs`
- Modify: `tests/Ecommerce.Catalog.Api.Tests/Features/ProductResponseTests.cs`
- Create: `tests/Ecommerce.Catalog.Api.Tests/Features/RequestLanguageTests.cs`
- Modify: `tests/Ecommerce.Catalog.Api.Tests/Features/ListProductsEndpointTests.cs`
- Modify: `tests/Ecommerce.Catalog.Api.Tests/Features/GetProductEndpointTests.cs`
- Modify: `tests/Ecommerce.Catalog.Api.Tests/Infrastructure/CatalogSeedDataTests.cs`
- Modify: `tests/Ecommerce.Catalog.Api.Tests/Infrastructure/CatalogDbContextTests.cs`

**Interfaces:**
- Consumes: `Product`, `CatalogDbContext`, the SQLite test fixture, request localization from ASP.NET Core.
- Produces: `ProductTranslation.Create(language, name, description, category)`; `Product.WithTranslation(...)` (fluent, replaces the same language) and `Product.Localize(language)` returning `ProductText(Name, Description, Category)` with English fallback; `RequestLanguage` bound from the negotiated UI culture (`Code` is `en` or `sr`); `ProductResponse.From(product, language)`; both endpoints take a `RequestLanguage` parameter; the `product_translations` table; `CatalogSeedData.Serbian`; `CatalogDbInitializer.SeedAsync` returns the number of products, not rows.

- [ ] **Step 1: Write the failing tests**

Create `tests/Ecommerce.Catalog.Api.Tests/Domain/ProductTranslationTests.cs`:

```csharp
using Ecommerce.Catalog.Api.Domain;

namespace Ecommerce.Catalog.Api.Tests.Domain;

public sealed class ProductTranslationTests
{
    [Fact]
    public void Create_TrimsTextAndNormalizesTheLanguageCode()
    {
        var translation = ProductTranslation.Create(" SR ", " Šolja ", " Opis ", " Posuđe ");

        Assert.Equal("sr", translation.Language);
        Assert.Equal("Šolja", translation.Name);
        Assert.Equal("Opis", translation.Description);
        Assert.Equal("Posuđe", translation.Category);
    }

    [Fact]
    public void Create_WithBlankLanguage_ThrowsArgumentException()
    {
        Assert.Throws<ArgumentException>(() => ProductTranslation.Create(" ", "Šolja", "Opis", "Posuđe"));
    }

    [Fact]
    public void Create_WithBlankName_ThrowsArgumentException()
    {
        Assert.Throws<ArgumentException>(() => ProductTranslation.Create("sr", " ", "Opis", "Posuđe"));
    }
}
```

Replace `tests/Ecommerce.Catalog.Api.Tests/Domain/ProductTests.cs` with:

```csharp
using Ecommerce.Catalog.Api.Domain;

namespace Ecommerce.Catalog.Api.Tests.Domain;

public sealed class ProductTests
{
    private static readonly Guid ValidId = Guid.Parse("a0000000-0000-4000-8000-000000000001");

    [Fact]
    public void Create_WithValidValues_SetsAllProperties()
    {
        var product = Product.Create(ValidId, "Aspire Ceramic Mug", "A mug", "Drinkware", 12.50m, 25, "mug");

        Assert.Equal(ValidId, product.Id);
        Assert.Equal("Aspire Ceramic Mug", product.Name);
        Assert.Equal("A mug", product.Description);
        Assert.Equal("Drinkware", product.Category);
        Assert.Equal(12.50m, product.Price);
        Assert.Equal(25, product.AvailableStock);
        Assert.Equal("mug", product.ImageKey);
    }

    [Fact]
    public void Create_TrimsTextFields()
    {
        var product = Product.Create(ValidId, "  Mug ", " A mug ", " Drinkware ", 1m, 1, " mug ");

        Assert.Equal("Mug", product.Name);
        Assert.Equal("A mug", product.Description);
        Assert.Equal("Drinkware", product.Category);
        Assert.Equal("mug", product.ImageKey);
    }

    [Fact]
    public void Create_WithZeroStock_IsAllowed()
    {
        var product = Product.Create(ValidId, "Mug", "A mug", "Drinkware", 1m, 0, "mug");

        Assert.Equal(0, product.AvailableStock);
    }

    [Fact]
    public void Create_WithEmptyId_ThrowsArgumentException()
    {
        Assert.Throws<ArgumentException>(() => Product.Create(Guid.Empty, "Mug", "A mug", "Drinkware", 1m, 1, "mug"));
    }

    [Fact]
    public void Create_WithBlankName_ThrowsArgumentException()
    {
        Assert.Throws<ArgumentException>(() => Product.Create(ValidId, " ", "A mug", "Drinkware", 1m, 1, "mug"));
    }

    [Fact]
    public void Create_WithZeroPrice_ThrowsArgumentOutOfRangeException()
    {
        Assert.Throws<ArgumentOutOfRangeException>(() => Product.Create(ValidId, "Mug", "A mug", "Drinkware", 0m, 1, "mug"));
    }

    [Fact]
    public void Create_WithNegativeStock_ThrowsArgumentOutOfRangeException()
    {
        Assert.Throws<ArgumentOutOfRangeException>(() => Product.Create(ValidId, "Mug", "A mug", "Drinkware", 1m, -1, "mug"));
    }

    [Fact]
    public void WithTranslation_AddsOnePerLanguageAndReplacesTheSameLanguage()
    {
        var product = Product.Create(ValidId, "Mug", "A mug", "Drinkware", 1m, 1, "mug")
            .WithTranslation("sr", "Šolja", "Jedna šolja", "Posuđe")
            .WithTranslation("sr", "Keramička šolja", "Jedna šolja", "Posuđe");

        var translation = Assert.Single(product.Translations);
        Assert.Equal("Keramička šolja", translation.Name);
    }

    [Fact]
    public void Localize_WithTranslation_ReturnsTheTranslatedText()
    {
        var product = Product.Create(ValidId, "Mug", "A mug", "Drinkware", 1m, 1, "mug")
            .WithTranslation("sr", "Šolja", "Jedna šolja", "Posuđe");

        var text = product.Localize("sr");

        Assert.Equal(new ProductText("Šolja", "Jedna šolja", "Posuđe"), text);
    }

    [Fact]
    public void Localize_WithoutTranslation_FallsBackToTheProductText()
    {
        var product = Product.Create(ValidId, "Mug", "A mug", "Drinkware", 1m, 1, "mug")
            .WithTranslation("sr", "Šolja", "Jedna šolja", "Posuđe");

        Assert.Equal(new ProductText("Mug", "A mug", "Drinkware"), product.Localize("en"));
        Assert.Equal(new ProductText("Mug", "A mug", "Drinkware"), product.Localize("de"));
    }
}
```

Replace `tests/Ecommerce.Catalog.Api.Tests/Features/ProductResponseTests.cs` with:

```csharp
using Ecommerce.Catalog.Api.Domain;
using Ecommerce.Catalog.Api.Features;

namespace Ecommerce.Catalog.Api.Tests.Features;

public sealed class ProductResponseTests
{
    private static readonly Guid Id = Guid.Parse("a0000000-0000-4000-8000-000000000001");

    private static Product CreateMug() =>
        Product.Create(Id, "Aspire Ceramic Mug", "A mug", "Drinkware", 12.50m, 25, "mug")
            .WithTranslation("sr", "Aspire keramička šolja", "Jedna šolja", "Posuđe za piće");

    [Fact]
    public void From_WithEnglish_MapsEveryField()
    {
        var response = ProductResponse.From(CreateMug(), "en");

        Assert.Equal(Id, response.Id);
        Assert.Equal("Aspire Ceramic Mug", response.Name);
        Assert.Equal("A mug", response.Description);
        Assert.Equal("Drinkware", response.Category);
        Assert.Equal(12.50m, response.Price);
        Assert.Equal(25, response.AvailableStock);
        Assert.Equal("mug", response.ImageKey);
    }

    [Fact]
    public void From_WithTranslatedLanguage_MapsTheTranslatedTextAndKeepsTheRest()
    {
        var response = ProductResponse.From(CreateMug(), "sr");

        Assert.Equal("Aspire keramička šolja", response.Name);
        Assert.Equal("Jedna šolja", response.Description);
        Assert.Equal("Posuđe za piće", response.Category);
        Assert.Equal(12.50m, response.Price);
        Assert.Equal("mug", response.ImageKey);
    }
}
```

Create `tests/Ecommerce.Catalog.Api.Tests/Features/RequestLanguageTests.cs`:

```csharp
using Ecommerce.Catalog.Api.Features;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Localization;

namespace Ecommerce.Catalog.Api.Tests.Features;

public sealed class RequestLanguageTests
{
    [Fact]
    public async Task BindAsync_WithoutNegotiatedCulture_IsEnglish()
    {
        var language = await RequestLanguage.BindAsync(new DefaultHttpContext());

        Assert.Equal("en", language?.Code);
    }

    [Theory]
    [InlineData("sr-Latn", "sr")]
    [InlineData("sr", "sr")]
    [InlineData("en", "en")]
    public async Task BindAsync_WithNegotiatedCulture_UsesItsTwoLetterCode(string culture, string expected)
    {
        var context = new DefaultHttpContext();
        context.Features.Set<IRequestCultureFeature>(new RequestCultureFeature(new RequestCulture(culture), null));

        var language = await RequestLanguage.BindAsync(context);

        Assert.Equal(expected, language?.Code);
    }
}
```

Replace `tests/Ecommerce.Catalog.Api.Tests/Features/ListProductsEndpointTests.cs` with:

```csharp
using Ecommerce.Catalog.Api.Features;
using Ecommerce.Catalog.Api.Features.ListProducts;
using Ecommerce.Catalog.Api.Infrastructure;

namespace Ecommerce.Catalog.Api.Tests.Features;

public sealed class ListProductsEndpointTests
{
    private static readonly Guid MugId = Guid.Parse("a0000000-0000-4000-8000-000000000001");
    private static readonly Guid CapId = Guid.Parse("a0000000-0000-4000-8000-000000000007");

    [Fact]
    public async Task HandleAsync_WithoutIds_ReturnsAllProductsOrderedByName()
    {
        using var db = new SqliteCatalogDb();
        await CatalogDbInitializer.SeedAsync(db.Context, TestContext.Current.CancellationToken);

        var result = await ListProductsEndpoint.HandleAsync(null, RequestLanguage.English, db.Context, TestContext.Current.CancellationToken);

        Assert.NotNull(result.Value);
        Assert.True(result.Value.Success);
        var products = result.Value.Data;
        Assert.NotNull(products);
        Assert.Equal(12, products.Count);
        Assert.Equal(products.OrderBy(p => p.Name, StringComparer.Ordinal).Select(p => p.Id), products.Select(p => p.Id));
    }

    [Fact]
    public async Task HandleAsync_WithIds_ReturnsOnlyMatchingProducts()
    {
        using var db = new SqliteCatalogDb();
        await CatalogDbInitializer.SeedAsync(db.Context, TestContext.Current.CancellationToken);

        var result = await ListProductsEndpoint.HandleAsync([MugId, CapId], RequestLanguage.English, db.Context, TestContext.Current.CancellationToken);

        var products = result.Value?.Data;
        Assert.NotNull(products);
        Assert.Equal(2, products.Count);
        Assert.Contains(products, p => p.Id == MugId);
        Assert.Contains(products, p => p.Id == CapId);
    }

    [Fact]
    public async Task HandleAsync_WithUnknownIds_ReturnsEmptyList()
    {
        using var db = new SqliteCatalogDb();
        await CatalogDbInitializer.SeedAsync(db.Context, TestContext.Current.CancellationToken);

        var result = await ListProductsEndpoint.HandleAsync([Guid.NewGuid()], RequestLanguage.English, db.Context, TestContext.Current.CancellationToken);

        var products = result.Value?.Data;
        Assert.NotNull(products);
        Assert.Empty(products);
    }

    [Fact]
    public async Task HandleAsync_WithSerbian_ReturnsTranslatedTextOrderedByTranslatedName()
    {
        using var db = new SqliteCatalogDb();
        await CatalogDbInitializer.SeedAsync(db.Context, TestContext.Current.CancellationToken);

        var result = await ListProductsEndpoint.HandleAsync(null, new RequestLanguage("sr"), db.Context, TestContext.Current.CancellationToken);

        var products = result.Value?.Data;
        Assert.NotNull(products);
        Assert.Equal(12, products.Count);
        Assert.Equal("Aspire keramička šolja", products.Single(p => p.Id == MugId).Name);
        Assert.Equal(["Dodaci", "Knjige", "Odeća", "Posuđe za piće"], products.Select(p => p.Category).Distinct(StringComparer.Ordinal).Order(StringComparer.Ordinal));
        Assert.Equal(products.OrderBy(p => p.Name, StringComparer.Ordinal).Select(p => p.Id), products.Select(p => p.Id));
    }
}
```

Replace `tests/Ecommerce.Catalog.Api.Tests/Features/GetProductEndpointTests.cs` with:

```csharp
using Ecommerce.Catalog.Api.Features;
using Ecommerce.Catalog.Api.Features.GetProduct;
using Ecommerce.Catalog.Api.Infrastructure;
using Ecommerce.ServiceDefaults.Api;
using Microsoft.AspNetCore.Http.HttpResults;

namespace Ecommerce.Catalog.Api.Tests.Features;

public sealed class GetProductEndpointTests
{
    private static readonly Guid MugId = Guid.Parse("a0000000-0000-4000-8000-000000000001");

    [Fact]
    public async Task HandleAsync_WithExistingId_ReturnsProduct()
    {
        using var db = new SqliteCatalogDb();
        await CatalogDbInitializer.SeedAsync(db.Context, TestContext.Current.CancellationToken);

        var result = await GetProductEndpoint.HandleAsync(MugId, RequestLanguage.English, db.Context, TestContext.Current.CancellationToken);

        var ok = Assert.IsType<Ok<ApiResponse<ProductResponse>>>(result.Result);
        Assert.NotNull(ok.Value?.Data);
        Assert.Equal(MugId, ok.Value.Data.Id);
        Assert.Equal("Aspire Ceramic Mug", ok.Value.Data.Name);
    }

    [Fact]
    public async Task HandleAsync_WithUnknownId_ReturnsNotFoundEnvelope()
    {
        using var db = new SqliteCatalogDb();
        var unknownId = Guid.Parse("a0000000-0000-4000-8000-0000000000ff");

        var result = await GetProductEndpoint.HandleAsync(unknownId, RequestLanguage.English, db.Context, TestContext.Current.CancellationToken);

        var notFound = Assert.IsType<NotFound<ApiResponse>>(result.Result);
        Assert.NotNull(notFound.Value?.Error);
        Assert.False(notFound.Value.Success);
        Assert.Equal("catalog.product_not_found", notFound.Value.Error.Code);
        Assert.Equal($"Product [{unknownId}] not found", notFound.Value.Error.Message);
    }

    [Fact]
    public async Task HandleAsync_WithSerbian_ReturnsTranslatedProduct()
    {
        using var db = new SqliteCatalogDb();
        await CatalogDbInitializer.SeedAsync(db.Context, TestContext.Current.CancellationToken);

        var result = await GetProductEndpoint.HandleAsync(MugId, new RequestLanguage("sr"), db.Context, TestContext.Current.CancellationToken);

        var ok = Assert.IsType<Ok<ApiResponse<ProductResponse>>>(result.Result);
        Assert.Equal("Aspire keramička šolja", ok.Value?.Data?.Name);
        Assert.Equal("Posuđe za piće", ok.Value?.Data?.Category);
    }

    [Fact]
    public async Task HandleAsync_WithUnknownLanguage_FallsBackToEnglish()
    {
        using var db = new SqliteCatalogDb();
        await CatalogDbInitializer.SeedAsync(db.Context, TestContext.Current.CancellationToken);

        var result = await GetProductEndpoint.HandleAsync(MugId, new RequestLanguage("de"), db.Context, TestContext.Current.CancellationToken);

        var ok = Assert.IsType<Ok<ApiResponse<ProductResponse>>>(result.Result);
        Assert.Equal("Aspire Ceramic Mug", ok.Value?.Data?.Name);
    }
}
```

Replace `tests/Ecommerce.Catalog.Api.Tests/Infrastructure/CatalogSeedDataTests.cs` with:

```csharp
using Ecommerce.Catalog.Api.Infrastructure;

namespace Ecommerce.Catalog.Api.Tests.Infrastructure;

public sealed class CatalogSeedDataTests
{
    [Fact]
    public void CreateProducts_ReturnsTwelveProducts()
    {
        var products = CatalogSeedData.CreateProducts();

        Assert.Equal(12, products.Count);
    }

    [Fact]
    public void CreateProducts_HaveUniqueIdsAndNames()
    {
        var products = CatalogSeedData.CreateProducts();

        Assert.Equal(products.Count, products.Select(p => p.Id).Distinct().Count());
        Assert.Equal(products.Count, products.Select(p => p.Name).Distinct(StringComparer.Ordinal).Count());
    }

    [Fact]
    public void CreateProducts_ContainsExactlyOneOutOfStockProduct()
    {
        var products = CatalogSeedData.CreateProducts();

        Assert.Single(products, p => p.AvailableStock == 0);
    }

    [Fact]
    public void CreateProducts_ContainsExactlyOneProductWithStockOfTwo()
    {
        var products = CatalogSeedData.CreateProducts();

        Assert.Single(products, p => p.AvailableStock == 2);
    }

    [Fact]
    public void CreateProducts_ReturnsFreshInstancesOnEveryCall()
    {
        var first = CatalogSeedData.CreateProducts();
        var second = CatalogSeedData.CreateProducts();

        Assert.NotSame(first[0], second[0]);
        Assert.Equal(first[0].Id, second[0].Id);
    }

    [Fact]
    public void CreateProducts_UsesTheFourAgreedCategories()
    {
        var categories = CatalogSeedData.CreateProducts().Select(p => p.Category).Distinct(StringComparer.Ordinal).Order().ToList();

        Assert.Equal(["Accessories", "Apparel", "Books", "Drinkware"], categories);
    }

    [Fact]
    public void CreateProducts_EveryProductHasASerbianTranslation()
    {
        var products = CatalogSeedData.CreateProducts();

        Assert.All(products, product => Assert.Single(product.Translations, t => t.Language == CatalogSeedData.Serbian));
        Assert.Equal(products.Count, products.Select(p => p.Localize(CatalogSeedData.Serbian).Name).Distinct(StringComparer.Ordinal).Count());
    }

    [Fact]
    public void CreateProducts_TranslatesTheFourCategoriesIntoSerbian()
    {
        var categories = CatalogSeedData.CreateProducts().Select(p => p.Localize(CatalogSeedData.Serbian).Category).Distinct(StringComparer.Ordinal).Order(StringComparer.Ordinal).ToList();

        Assert.Equal(["Dodaci", "Knjige", "Odeća", "Posuđe za piće"], categories);
    }
}
```

Replace `tests/Ecommerce.Catalog.Api.Tests/Infrastructure/CatalogDbContextTests.cs` with:

```csharp
using Ecommerce.Catalog.Api.Domain;
using Microsoft.EntityFrameworkCore;

namespace Ecommerce.Catalog.Api.Tests.Infrastructure;

public sealed class CatalogDbContextTests
{
    [Fact]
    public async Task SaveChanges_ThenQuery_RoundTripsProduct()
    {
        using var db = new SqliteCatalogDb();
        var id = Guid.Parse("a0000000-0000-4000-8000-000000000099");
        db.Context.Products.Add(Product.Create(id, "Aspire Ceramic Mug", "A mug", "Drinkware", 12.50m, 25, "mug"));
        await db.Context.SaveChangesAsync(TestContext.Current.CancellationToken);
        db.Context.ChangeTracker.Clear();

        var loaded = await db.Context.Products.SingleAsync(p => p.Id == id, TestContext.Current.CancellationToken);

        Assert.Equal("Aspire Ceramic Mug", loaded.Name);
        Assert.Equal("Drinkware", loaded.Category);
        Assert.Equal(12.50m, loaded.Price);
        Assert.Equal(25, loaded.AvailableStock);
        Assert.Equal("mug", loaded.ImageKey);
    }

    [Fact]
    public async Task SaveChanges_ThenQuery_RoundTripsTranslations()
    {
        using var db = new SqliteCatalogDb();
        var id = Guid.Parse("a0000000-0000-4000-8000-000000000098");
        db.Context.Products.Add(Product.Create(id, "Aspire Ceramic Mug", "A mug", "Drinkware", 12.50m, 25, "mug")
            .WithTranslation("sr", "Aspire keramička šolja", "Jedna šolja", "Posuđe za piće"));
        await db.Context.SaveChangesAsync(TestContext.Current.CancellationToken);
        db.Context.ChangeTracker.Clear();

        var loaded = await db.Context.Products.SingleAsync(p => p.Id == id, TestContext.Current.CancellationToken);

        var translation = Assert.Single(loaded.Translations);
        Assert.Equal("sr", translation.Language);
        Assert.Equal("Aspire keramička šolja", translation.Name);
        Assert.Equal("Aspire keramička šolja", loaded.Localize("sr").Name);
    }
}
```

```bash
dotnet build tests/Ecommerce.Catalog.Api.Tests
```

Expected: the build fails on `ProductTranslation`, `ProductText`, `WithTranslation`, `Localize`, `RequestLanguage` and the new `From` and `HandleAsync` signatures. Note the first error lines for the report.

- [ ] **Step 2: Implement the domain, the mapping, the language binding, the endpoints and the seed**

Create `src/Ecommerce.Catalog.Api/Domain/ProductTranslation.cs`:

```csharp
namespace Ecommerce.Catalog.Api.Domain;

public sealed class ProductTranslation
{
    public const int LanguageMaxLength = 8;

    // EF Core materializes entities through this constructor
    private ProductTranslation()
    {
    }

    private ProductTranslation(string language, string name, string description, string category)
    {
        Language = language;
        Name = name;
        Description = description;
        Category = category;
    }

    public string Language { get; private set; } = string.Empty;

    public string Name { get; private set; } = string.Empty;

    public string Description { get; private set; } = string.Empty;

    public string Category { get; private set; } = string.Empty;

    public static ProductTranslation Create(string language, string name, string description, string category)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(language);
        ArgumentException.ThrowIfNullOrWhiteSpace(name);
        ArgumentNullException.ThrowIfNull(description);
        ArgumentException.ThrowIfNullOrWhiteSpace(category);

        return new ProductTranslation(language.Trim().ToLowerInvariant(), name.Trim(), description.Trim(), category.Trim());
    }
}
```

Create `src/Ecommerce.Catalog.Api/Domain/ProductText.cs`:

```csharp
namespace Ecommerce.Catalog.Api.Domain;

public sealed record ProductText(string Name, string Description, string Category);
```

Replace `src/Ecommerce.Catalog.Api/Domain/Product.cs` with:

```csharp
namespace Ecommerce.Catalog.Api.Domain;

public sealed class Product
{
    public const int NameMaxLength = 200;
    public const int DescriptionMaxLength = 2000;
    public const int CategoryMaxLength = 100;
    public const int ImageKeyMaxLength = 50;

    private readonly List<ProductTranslation> _translations = [];

    // EF Core materializes entities through this constructor
    private Product()
    {
    }

    private Product(Guid id, string name, string description, string category, decimal price, int availableStock, string imageKey)
    {
        Id = id;
        Name = name;
        Description = description;
        Category = category;
        Price = price;
        AvailableStock = availableStock;
        ImageKey = imageKey;
    }

    public Guid Id { get; private set; }

    public string Name { get; private set; } = string.Empty;

    public string Description { get; private set; } = string.Empty;

    public string Category { get; private set; } = string.Empty;

    public decimal Price { get; private set; }

    public int AvailableStock { get; private set; }

    public string ImageKey { get; private set; } = string.Empty;

    public IReadOnlyList<ProductTranslation> Translations => _translations;

    public static Product Create(Guid id, string name, string description, string category, decimal price, int availableStock, string imageKey)
    {
        if (id == Guid.Empty)
        {
            throw new ArgumentException("Product id must not be empty", nameof(id));
        }

        ArgumentException.ThrowIfNullOrWhiteSpace(name);
        ArgumentNullException.ThrowIfNull(description);
        ArgumentException.ThrowIfNullOrWhiteSpace(category);
        ArgumentException.ThrowIfNullOrWhiteSpace(imageKey);
        ArgumentOutOfRangeException.ThrowIfNegativeOrZero(price);
        ArgumentOutOfRangeException.ThrowIfNegative(availableStock);

        return new Product(id, name.Trim(), description.Trim(), category.Trim(), price, availableStock, imageKey.Trim());
    }

    // Adds or replaces the translation for a language; the product's own text is English and the fallback
    public Product WithTranslation(string language, string name, string description, string category)
    {
        var translation = ProductTranslation.Create(language, name, description, category);
        _translations.RemoveAll(existing => existing.Language == translation.Language);
        _translations.Add(translation);
        return this;
    }

    public ProductText Localize(string language)
    {
        var translation = _translations.Find(existing => existing.Language == language);
        return translation is null
            ? new ProductText(Name, Description, Category)
            : new ProductText(translation.Name, translation.Description, translation.Category);
    }
}
```

Replace `src/Ecommerce.Catalog.Api/Infrastructure/ProductConfiguration.cs` with:

```csharp
using Ecommerce.Catalog.Api.Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Ecommerce.Catalog.Api.Infrastructure;

public sealed class ProductConfiguration : IEntityTypeConfiguration<Product>
{
    public void Configure(EntityTypeBuilder<Product> builder)
    {
        builder.ToTable("products");

        builder.HasKey(p => p.Id);
        builder.Property(p => p.Id).ValueGeneratedNever();

        builder.Property(p => p.Name).HasMaxLength(Product.NameMaxLength).IsRequired();
        builder.Property(p => p.Description).HasMaxLength(Product.DescriptionMaxLength).IsRequired();
        builder.Property(p => p.Category).HasMaxLength(Product.CategoryMaxLength).IsRequired();
        builder.Property(p => p.Price).HasPrecision(10, 2);
        builder.Property(p => p.AvailableStock).IsRequired();
        builder.Property(p => p.ImageKey).HasMaxLength(Product.ImageKeyMaxLength).IsRequired();

        builder.HasIndex(p => p.Name);

        builder.OwnsMany(p => p.Translations, translations =>
        {
            translations.ToTable("product_translations");
            translations.WithOwner().HasForeignKey("ProductId");
            translations.HasKey("ProductId", nameof(ProductTranslation.Language));
            translations.Property(t => t.Language).HasMaxLength(ProductTranslation.LanguageMaxLength).IsRequired();
            translations.Property(t => t.Name).HasMaxLength(Product.NameMaxLength).IsRequired();
            translations.Property(t => t.Description).HasMaxLength(Product.DescriptionMaxLength).IsRequired();
            translations.Property(t => t.Category).HasMaxLength(Product.CategoryMaxLength).IsRequired();
        });
        builder.Navigation(p => p.Translations).HasField("_translations").UsePropertyAccessMode(PropertyAccessMode.Field);
    }
}
```

Replace `src/Ecommerce.Catalog.Api/Infrastructure/CatalogSeedData.cs` with:

```csharp
using Ecommerce.Catalog.Api.Domain;

namespace Ecommerce.Catalog.Api.Infrastructure;

public static class CatalogSeedData
{
    public const string Serbian = "sr";

    public static IReadOnlyList<Product> CreateProducts() =>
    [
        Product.Create(Guid.Parse("a0000000-0000-4000-8000-000000000001"), "Aspire Ceramic Mug", "Glossy 350 ml ceramic mug with the Aspire logo", "Drinkware", 12.50m, 25, "mug")
            .WithTranslation(Serbian, "Aspire keramička šolja", "Sjajna keramička šolja od 350 ml sa Aspire logom", "Posuđe za piće"),
        Product.Create(Guid.Parse("a0000000-0000-4000-8000-000000000002"), "Aspire Travel Tumbler", "Insulated 450 ml tumbler that keeps coffee hot through a long deploy", "Drinkware", 24.00m, 15, "tumbler")
            .WithTranslation(Serbian, "Aspire putna čaša", "Termo čaša od 450 ml koja drži kafu toplom tokom dugog deploja", "Posuđe za piće"),
        Product.Create(Guid.Parse("a0000000-0000-4000-8000-000000000003"), "Aspire Water Bottle", "750 ml stainless steel bottle with a leak-proof cap", "Drinkware", 18.90m, 20, "bottle")
            .WithTranslation(Serbian, "Aspire flaša za vodu", "Flaša od nerđajućeg čelika od 750 ml sa čepom koji ne curi", "Posuđe za piće"),
        Product.Create(Guid.Parse("a0000000-0000-4000-8000-000000000004"), "Aspire Logo T-Shirt", "Soft cotton t-shirt with a small chest logo", "Apparel", 22.00m, 30, "tshirt")
            .WithTranslation(Serbian, "Aspire majica sa logom", "Mekana pamučna majica sa malim logom na grudima", "Odeća"),
        Product.Create(Guid.Parse("a0000000-0000-4000-8000-000000000005"), "Aspire Zip Hoodie", "Heavyweight zip hoodie with an embroidered logo", "Apparel", 49.00m, 12, "hoodie")
            .WithTranslation(Serbian, "Aspire duks sa rajsferšlusom", "Teški duks sa rajsferšlusom i izvezenim logom", "Odeća"),
        Product.Create(Guid.Parse("a0000000-0000-4000-8000-000000000006"), "Aspire Limited Edition Hoodie", "Numbered launch edition hoodie, sold out", "Apparel", 59.00m, 0, "hoodie-limited")
            .WithTranslation(Serbian, "Aspire duks limitirano izdanje", "Numerisano izdanje duksa sa lansiranja, rasprodato", "Odeća"),
        Product.Create(Guid.Parse("a0000000-0000-4000-8000-000000000007"), "Aspire Dad Cap", "Unstructured cotton cap with an adjustable strap", "Apparel", 19.50m, 18, "cap")
            .WithTranslation(Serbian, "Aspire kačket", "Pamučni kačket bez strukture sa podesivim kaišem", "Odeća"),
        Product.Create(Guid.Parse("a0000000-0000-4000-8000-000000000008"), "Aspire Sticker Pack", "Ten die-cut vinyl stickers for laptops and notebooks", "Accessories", 6.00m, 100, "stickers")
            .WithTranslation(Serbian, "Aspire paket nalepnica", "Deset vinil nalepnica za laptopove i sveske", "Dodaci"),
        Product.Create(Guid.Parse("a0000000-0000-4000-8000-000000000009"), "Aspire Laptop Sleeve", "Padded sleeve for 13 to 14 inch laptops", "Accessories", 34.00m, 10, "sleeve")
            .WithTranslation(Serbian, "Aspire futrola za laptop", "Podstavljena futrola za laptopove od 13 do 14 inča", "Dodaci"),
        Product.Create(Guid.Parse("a0000000-0000-4000-8000-000000000010"), "Aspire Launch Poster", "A2 poster from the launch event, only two left", "Accessories", 15.00m, 2, "poster")
            .WithTranslation(Serbian, "Aspire poster sa lansiranja", "A2 poster sa događaja lansiranja, ostala su samo dva", "Dodaci"),
        Product.Create(Guid.Parse("a0000000-0000-4000-8000-000000000011"), "Cloud-Native .NET Handbook", "Practical guide to building distributed .NET systems", "Books", 39.00m, 8, "book")
            .WithTranslation(Serbian, "Priručnik za cloud-native .NET", "Praktičan vodič za izgradnju distribuiranih .NET sistema", "Knjige"),
        Product.Create(Guid.Parse("a0000000-0000-4000-8000-000000000012"), "Distributed Tracing Field Guide", "Short guide to reading traces, spans and metrics", "Books", 29.00m, 6, "book-tracing")
            .WithTranslation(Serbian, "Terenski vodič za distribuirano praćenje", "Kratak vodič za čitanje trejsova, spanova i metrika", "Knjige"),
    ];
}
```

Replace `src/Ecommerce.Catalog.Api/Infrastructure/CatalogDbInitializer.cs` with:

```csharp
using System.Diagnostics;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Ecommerce.Catalog.Api.Infrastructure;

// Runs before the server starts listening, so the health check only passes on a migrated and seeded database
public sealed class CatalogDbInitializer(IServiceProvider services, ILogger<CatalogDbInitializer> logger) : IHostedService
{
    private static readonly ActivitySource ActivitySource = new("Ecommerce.Catalog.Api");

    public async Task StartAsync(CancellationToken cancellationToken)
    {
        using var activity = ActivitySource.StartActivity("Initialize catalog database", ActivityKind.Client);
        await using var scope = services.CreateAsyncScope();
        var db = scope.ServiceProvider.GetRequiredService<CatalogDbContext>();

        // The Npgsql migrator reads the history table before creating it and logs that read as a failed command on a fresh database; creating the table first keeps the startup log clean
        await db.Database.ExecuteSqlRawAsync(db.GetService<IHistoryRepository>().GetCreateIfNotExistsScript(), cancellationToken);
        await db.Database.MigrateAsync(cancellationToken);
        logger.LogInformation("[{Prefix}] Applied pending migrations", nameof(CatalogDbInitializer));

        var inserted = await SeedAsync(db, cancellationToken);
        if (inserted == 0)
        {
            logger.LogInformation("[{Prefix}] Catalog already seeded, skipping", nameof(CatalogDbInitializer));
            return;
        }

        logger.LogInformation("[{Prefix}] Seeded [{Count}] products", nameof(CatalogDbInitializer), inserted);
    }

    public Task StopAsync(CancellationToken cancellationToken) => Task.CompletedTask;

    public static async Task<int> SeedAsync(CatalogDbContext db, CancellationToken cancellationToken)
    {
        if (await db.Products.AnyAsync(cancellationToken))
        {
            return 0;
        }

        var products = CatalogSeedData.CreateProducts();
        db.Products.AddRange(products);
        await db.SaveChangesAsync(cancellationToken);
        return products.Count;
    }
}
```

Create `src/Ecommerce.Catalog.Api/Features/RequestLanguage.cs`:

```csharp
using Microsoft.AspNetCore.Localization;

namespace Ecommerce.Catalog.Api.Features;

// Bound from the culture that request localization negotiated from Accept-Language; English when nothing supported was asked for
public sealed record RequestLanguage(string Code)
{
    public const string Default = "en";

    public static readonly RequestLanguage English = new(Default);

    public static ValueTask<RequestLanguage?> BindAsync(HttpContext context)
    {
        var culture = context.Features.Get<IRequestCultureFeature>()?.RequestCulture.UICulture;
        var language = culture is null ? Default : culture.TwoLetterISOLanguageName;
        return ValueTask.FromResult<RequestLanguage?>(new RequestLanguage(language));
    }
}
```

Replace `src/Ecommerce.Catalog.Api/Features/ProductResponse.cs` with:

```csharp
using Ecommerce.Catalog.Api.Domain;

namespace Ecommerce.Catalog.Api.Features;

public sealed record ProductResponse(
    Guid Id,
    string Name,
    string Description,
    string Category,
    decimal Price,
    int AvailableStock,
    string ImageKey)
{
    public static ProductResponse From(Product product, string language)
    {
        var text = product.Localize(language);
        return new(product.Id, text.Name, text.Description, text.Category, product.Price, product.AvailableStock, product.ImageKey);
    }
}
```

Replace `src/Ecommerce.Catalog.Api/Features/ListProducts/ListProductsEndpoint.cs` with:

```csharp
using Ecommerce.Catalog.Api.Infrastructure;
using Ecommerce.ServiceDefaults.Api;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.EntityFrameworkCore;

namespace Ecommerce.Catalog.Api.Features.ListProducts;

public static class ListProductsEndpoint
{
    public static RouteGroupBuilder MapListProducts(this RouteGroupBuilder group)
    {
        group.MapGet("/products", HandleAsync).WithName("ListProducts");
        return group;
    }

    public static async Task<Ok<ApiResponse<IReadOnlyList<ProductResponse>>>> HandleAsync(
        Guid[]? ids,
        RequestLanguage language,
        CatalogDbContext db,
        CancellationToken cancellationToken)
    {
        var query = db.Products.AsNoTracking();
        if (ids is { Length: > 0 })
        {
            query = query.Where(p => ids.Contains(p.Id));
        }

        var products = await query.ToListAsync(cancellationToken);
        IReadOnlyList<ProductResponse> response = products
            .Select(product => ProductResponse.From(product, language.Code))
            .OrderBy(product => product.Name, StringComparer.Ordinal)
            .ToList();

        return ApiResults.Ok(response);
    }
}
```

Replace `src/Ecommerce.Catalog.Api/Features/GetProduct/GetProductEndpoint.cs` with:

```csharp
using Ecommerce.Catalog.Api.Infrastructure;
using Ecommerce.ServiceDefaults.Api;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.EntityFrameworkCore;

namespace Ecommerce.Catalog.Api.Features.GetProduct;

public static class GetProductEndpoint
{
    public static RouteGroupBuilder MapGetProduct(this RouteGroupBuilder group)
    {
        group.MapGet("/products/{id:guid}", HandleAsync).WithName("GetProduct");
        return group;
    }

    public static async Task<Results<Ok<ApiResponse<ProductResponse>>, NotFound<ApiResponse>>> HandleAsync(
        Guid id,
        RequestLanguage language,
        CatalogDbContext db,
        CancellationToken cancellationToken)
    {
        var product = await db.Products.AsNoTracking().SingleOrDefaultAsync(p => p.Id == id, cancellationToken);
        if (product is null)
        {
            return ApiResults.NotFound(ErrorCodes.ProductNotFound, $"Product [{id}] not found");
        }

        return ApiResults.Ok(ProductResponse.From(product, language.Code));
    }
}
```

Replace `src/Ecommerce.Catalog.Api/Program.cs` with:

```csharp
using Ecommerce.Catalog.Api.Features;
using Ecommerce.Catalog.Api.Features.GetProduct;
using Ecommerce.Catalog.Api.Features.ListProducts;
using Ecommerce.Catalog.Api.Infrastructure;
using Ecommerce.ServiceDefaults.Api;
using JasperFx;
using Microsoft.AspNetCore.Localization;
using Wolverine;
using Wolverine.EntityFrameworkCore;
using Wolverine.Postgresql;
using Wolverine.RabbitMQ;

var builder = WebApplication.CreateBuilder(args);

builder.AddServiceDefaults();
builder.AddApiDefaults();
builder.Services.AddValidation();
// Wolverine opens an explicit transaction around each handler, which EF Core forbids under the retrying execution strategy
builder.AddNpgsqlDbContext<CatalogDbContext>("catalogdb", settings => settings.DisableRetry = true);
builder.Services.AddHostedService<CatalogDbInitializer>();
// Product text follows the Accept-Language header; anything outside the supported set falls back to English
builder.Services.AddRequestLocalization(options =>
{
    options.SetDefaultCulture(RequestLanguage.Default)
        .AddSupportedCultures(RequestLanguage.Default, "sr", "sr-Latn")
        .AddSupportedUICultures(RequestLanguage.Default, "sr", "sr-Latn");
    options.RequestCultureProviders = [new AcceptLanguageHeaderRequestCultureProvider()];
});

builder.UseWolverine(options =>
{
    // Incoming OrderPaid events are tracked in a durable inbox in the catalog database, so a redelivery never decrements twice
    options.PersistMessagesWithPostgresql(builder.Configuration.GetConnectionString("catalogdb")!, "wolverine");
    options.UseEntityFrameworkCoreTransactions();
    options.Policies.AutoApplyTransactions();
    options.Policies.UseDurableInboxOnAllListeners();
    options.UseRabbitMqUsingNamedConnection("messaging")
        .AutoProvision()
        .DeclareExchange("order-paid", exchange => exchange.BindQueue("catalog.order-paid"));
    options.ListenToRabbitQueue("catalog.order-paid");
});

var app = builder.Build();

app.UseApiDefaults();
app.UseRequestLocalization();

var catalog = app.MapGroup("/api/catalog").WithTags("Catalog");
catalog.MapListProducts();
catalog.MapGetProduct();

return await app.RunJasperFxCommands(args);
```

- [ ] **Step 3: Add the migration**

```bash
export PATH="$PATH:$HOME/.dotnet/tools"
dotnet ef migrations add AddProductTranslations --project src/Ecommerce.Catalog.Api --output-dir Infrastructure/Migrations
```

Expected: `Done.` and three changed or new files under `src/Ecommerce.Catalog.Api/Infrastructure/Migrations`. The new migration's `Up` must create the table `product_translations` with columns `Language` (character varying(8)), `ProductId` (uuid), `Name` (200), `Description` (2000), `Category` (100), the primary key `(ProductId, Language)` and a foreign key to `products` with `ReferentialAction.Cascade`. If it looks different, stop and report it.

- [ ] **Step 4: Run the tests**

```bash
export PATH="$PATH:$HOME/.dotnet/tools"
source "$HOME/.nvm/nvm.sh" && nvm use 24
dotnet test --project tests/Ecommerce.Catalog.Api.Tests
dotnet build
dotnet test
```

Expected: 42 Catalog tests passed (25 before); `0 Warning(s)`; 147 tests passed in total (130 after task 8.1.1 plus 17). The integration run applies the new migration on a fresh database.

## Sub-phase 8.3 Basket names resolved from Catalog per request language (backend-dev)

### Task 8.3.1: Nameless basket lines, one catalog lookup per read, Accept-Language propagation

**Files:**
- Modify: `src/Ecommerce.Basket.Api/Domain/BasketItem.cs`
- Modify: `src/Ecommerce.Basket.Api/Domain/ShoppingBasket.cs`
- Modify: `src/Ecommerce.Basket.Api/Infrastructure/ICatalogClient.cs`
- Modify: `src/Ecommerce.Basket.Api/Infrastructure/CatalogClient.cs`
- Create: `src/Ecommerce.Basket.Api/Features/NamedBasket.cs`
- Modify: `src/Ecommerce.Basket.Api/Features/BasketResponse.cs`
- Modify: `src/Ecommerce.Basket.Api/Features/BasketService.cs`
- Modify: `src/Ecommerce.Basket.Api/Features/GetBasket/GetBasketEndpoint.cs`
- Modify: `src/Ecommerce.Basket.Api/Features/RemoveItem/RemoveItemEndpoint.cs`
- Modify: `src/Ecommerce.Basket.Api/Features/Checkout/CheckoutService.cs`
- Modify: `src/Ecommerce.Basket.Api/Program.cs`
- Modify: `src/Ecommerce.Basket.Api/Ecommerce.Basket.Api.csproj`
- Modify: `Directory.Packages.props`
- Modify: `tests/Ecommerce.Basket.Api.Tests/Fakes/FakeCatalogClient.cs`
- Modify: `tests/Ecommerce.Basket.Api.Tests/Domain/ShoppingBasketTests.cs`
- Modify: `tests/Ecommerce.Basket.Api.Tests/Features/BasketServiceTests.cs`
- Create: `tests/Ecommerce.Basket.Api.Tests/Features/GetBasketEndpointTests.cs`
- Create: `tests/Ecommerce.Basket.Api.Tests/Features/RemoveItemEndpointTests.cs`
- Modify: `tests/Ecommerce.Basket.Api.Tests/Features/CheckoutServiceTests.cs`
- Modify: `tests/Ecommerce.Basket.Api.Tests/Features/CheckoutEndpointTests.cs`
- Create: `tests/Ecommerce.IntegrationTests/LocalizationTests.cs`

`UpsertItemEndpoint.cs` and `UpsertItemEndpointTests.cs` do not change; `BasketResponse.From` keeps working for them through the new `NamedBasket`.

**Interfaces:**
- Consumes: Catalog's `GET /api/catalog/products?ids=...` answering in the language of `Accept-Language` (task 8.2.1), the resilience handler already on the Catalog `HttpClient`.
- Produces: `BasketItem(ProductId, UnitPrice, Quantity)`; `ShoppingBasket.UpsertItem(productId, unitPrice, requestedQuantity, availableStock)`; `ICatalogClient` with `GetProductsAsync` only; `NamedBasket(Basket, ProductNames)`; `BasketResult.Success(NamedBasket)` and `BasketResult.CatalogUnavailable`; `UpsertItemResult.Success(NamedBasket, ...)`; `BasketResponse.From(NamedBasket)`; `GET /api/basket` and `DELETE /api/basket/items/{id}` answer `503 basket.catalog_unavailable` when Catalog is down; `Accept-Language` propagates to Catalog.

- [ ] **Step 1: Write the failing tests**

Replace `tests/Ecommerce.Basket.Api.Tests/Fakes/FakeCatalogClient.cs` with:

```csharp
using Ecommerce.Basket.Api.Infrastructure;

namespace Ecommerce.Basket.Api.Tests.Fakes;

public sealed class FakeCatalogClient : ICatalogClient
{
    private readonly Dictionary<Guid, CatalogProduct> _products = [];

    public bool Unavailable { get; set; }

    public int LookupCount { get; private set; }

    public FakeCatalogClient With(CatalogProduct product)
    {
        _products[product.Id] = product;
        return this;
    }

    public Task<IReadOnlyList<CatalogProduct>> GetProductsAsync(IReadOnlyCollection<Guid> productIds, CancellationToken cancellationToken)
    {
        LookupCount++;
        if (Unavailable)
        {
            throw new CatalogUnavailableException(new HttpRequestException("Catalog unreachable"));
        }

        IReadOnlyList<CatalogProduct> found = productIds.Where(_products.ContainsKey).Select(id => _products[id]).ToList();
        return Task.FromResult(found);
    }
}
```

Replace `tests/Ecommerce.Basket.Api.Tests/Domain/ShoppingBasketTests.cs` with:

```csharp
using Ecommerce.Basket.Api.Domain;

namespace Ecommerce.Basket.Api.Tests.Domain;

public sealed class ShoppingBasketTests
{
    private static readonly Guid BuyerId = Guid.Parse("b0000000-0000-4000-8000-000000000001");
    private static readonly Guid MugId = Guid.Parse("a0000000-0000-4000-8000-000000000001");
    private static readonly Guid CapId = Guid.Parse("a0000000-0000-4000-8000-000000000007");

    [Fact]
    public void UpsertItem_AddsLineWithRequestedQuantity()
    {
        var basket = new ShoppingBasket(BuyerId);

        var applied = basket.UpsertItem(MugId, 12.50m, 2, 25);

        Assert.Equal(2, applied);
        var item = Assert.Single(basket.Items);
        Assert.Equal(MugId, item.ProductId);
        Assert.Equal(25.00m, item.LineTotal);
    }

    [Fact]
    public void UpsertItem_CapsAtAvailableStock()
    {
        var basket = new ShoppingBasket(BuyerId);

        var applied = basket.UpsertItem(MugId, 12.50m, 10, 3);

        Assert.Equal(3, applied);
        Assert.Equal(3, Assert.Single(basket.Items).Quantity);
    }

    [Fact]
    public void UpsertItem_CapsAtMaxQuantityPerLine()
    {
        var basket = new ShoppingBasket(BuyerId);

        var applied = basket.UpsertItem(MugId, 12.50m, 99, 500);

        Assert.Equal(ShoppingBasket.MaxQuantityPerLine, applied);
    }

    [Fact]
    public void UpsertItem_ReplacesExistingLineInsteadOfAdding()
    {
        var basket = new ShoppingBasket(BuyerId);
        basket.UpsertItem(MugId, 12.50m, 2, 25);

        basket.UpsertItem(MugId, 12.50m, 5, 25);

        Assert.Equal(5, Assert.Single(basket.Items).Quantity);
    }

    [Fact]
    public void ItemCountAndTotal_SumAcrossLines()
    {
        var basket = new ShoppingBasket(BuyerId);
        basket.UpsertItem(MugId, 12.50m, 2, 25);
        basket.UpsertItem(CapId, 19.50m, 1, 18);

        Assert.Equal(3, basket.ItemCount);
        Assert.Equal(44.50m, basket.Total);
    }

    [Fact]
    public void RemoveItem_ReturnsWhetherALineWasRemoved()
    {
        var basket = new ShoppingBasket(BuyerId);
        basket.UpsertItem(MugId, 12.50m, 2, 25);

        Assert.True(basket.RemoveItem(MugId));
        Assert.False(basket.RemoveItem(MugId));
        Assert.Empty(basket.Items);
    }

    [Fact]
    public void UpsertItem_WithZeroQuantity_Throws()
    {
        var basket = new ShoppingBasket(BuyerId);

        Assert.Throws<ArgumentOutOfRangeException>(() => basket.UpsertItem(MugId, 12.50m, 0, 25));
    }
}
```

Replace `tests/Ecommerce.Basket.Api.Tests/Features/BasketServiceTests.cs` with:

```csharp
using Ecommerce.Basket.Api.Domain;
using Ecommerce.Basket.Api.Features;
using Ecommerce.Basket.Api.Infrastructure;
using Ecommerce.Basket.Api.Tests.Fakes;
using Ecommerce.ServiceDefaults.Api;
using Microsoft.Extensions.Logging.Abstractions;

namespace Ecommerce.Basket.Api.Tests.Features;

public sealed class BasketServiceTests
{
    private static readonly BuyerId Buyer = new(Guid.Parse("b0000000-0000-4000-8000-000000000001"));
    private static readonly CatalogProduct Mug = new(Guid.Parse("a0000000-0000-4000-8000-000000000001"), "Aspire Ceramic Mug", 12.50m, 25);
    private static readonly CatalogProduct Poster = new(Guid.Parse("a0000000-0000-4000-8000-000000000010"), "Aspire Launch Poster", 15.00m, 2);
    private static readonly CatalogProduct LimitedHoodie = new(Guid.Parse("a0000000-0000-4000-8000-000000000006"), "Aspire Limited Edition Hoodie", 59.00m, 0);

    private readonly InMemoryBasketStore _store = new();
    private readonly FakeCatalogClient _catalog = new FakeCatalogClient().With(Mug).With(Poster).With(LimitedHoodie);

    private BasketService CreateService() => new(_store, _catalog, NullLogger<BasketService>.Instance);

    private async Task SeedBasketAsync(params (CatalogProduct Product, int Quantity)[] lines)
    {
        var basket = new ShoppingBasket(Buyer.Value);
        foreach (var (product, quantity) in lines)
        {
            basket.UpsertItem(product.Id, product.Price, quantity, 99);
        }

        await _store.SaveAsync(basket, TestContext.Current.CancellationToken);
    }

    [Fact]
    public async Task GetAsync_WithoutStoredBasket_ReturnsEmptyBasketWithoutAskingTheCatalog()
    {
        var result = await CreateService().GetAsync(Buyer, TestContext.Current.CancellationToken);

        var success = Assert.IsType<BasketResult.Success>(result);
        Assert.Equal(Buyer.Value, success.Basket.Basket.BuyerId);
        Assert.Empty(success.Basket.Basket.Items);
        Assert.Equal(0, _catalog.LookupCount);
        Assert.Equal(0, _store.SaveCount);
    }

    [Fact]
    public async Task GetAsync_WithLines_NamesThemFromTheCatalogInOneCall()
    {
        await SeedBasketAsync((Mug, 2), (Poster, 1));

        var result = await CreateService().GetAsync(Buyer, TestContext.Current.CancellationToken);

        var success = Assert.IsType<BasketResult.Success>(result);
        Assert.Equal("Aspire Ceramic Mug", success.Basket.ProductNames[Mug.Id]);
        Assert.Equal("Aspire Launch Poster", success.Basket.ProductNames[Poster.Id]);
        Assert.Equal(1, _catalog.LookupCount);
    }

    [Fact]
    public async Task GetAsync_WhenCatalogUnavailable_ReturnsCatalogUnavailable()
    {
        await SeedBasketAsync((Mug, 1));
        _catalog.Unavailable = true;

        var result = await CreateService().GetAsync(Buyer, TestContext.Current.CancellationToken);

        Assert.IsType<BasketResult.CatalogUnavailable>(result);
    }

    [Fact]
    public async Task UpsertItemAsync_WithKnownProduct_StoresLineWithCatalogPriceAndNamesEveryLine()
    {
        await SeedBasketAsync((Poster, 1));

        var result = await CreateService().UpsertItemAsync(Buyer, Mug.Id, 2, TestContext.Current.CancellationToken);

        var success = Assert.IsType<UpsertItemResult.Success>(result);
        Assert.False(success.Capped);
        Assert.Equal(2, success.AppliedQuantity);
        var line = success.Basket.Basket.Items.Single(item => item.ProductId == Mug.Id);
        Assert.Equal(12.50m, line.UnitPrice);
        Assert.Equal("Aspire Ceramic Mug", success.Basket.ProductNames[Mug.Id]);
        Assert.Equal("Aspire Launch Poster", success.Basket.ProductNames[Poster.Id]);
        Assert.Equal(1, _catalog.LookupCount);
        Assert.Equal(2, _store.SaveCount);
    }

    [Fact]
    public async Task UpsertItemAsync_BeyondStock_CapsAndFlags()
    {
        var result = await CreateService().UpsertItemAsync(Buyer, Poster.Id, 5, TestContext.Current.CancellationToken);

        var success = Assert.IsType<UpsertItemResult.Success>(result);
        Assert.True(success.Capped);
        Assert.Equal(5, success.RequestedQuantity);
        Assert.Equal(2, success.AppliedQuantity);
    }

    [Fact]
    public async Task UpsertItemAsync_WithUnknownProduct_ReturnsProductNotFound()
    {
        var unknown = Guid.Parse("a0000000-0000-4000-8000-0000000000ff");

        var result = await CreateService().UpsertItemAsync(Buyer, unknown, 1, TestContext.Current.CancellationToken);

        var notFound = Assert.IsType<UpsertItemResult.ProductNotFound>(result);
        Assert.Equal(unknown, notFound.ProductId);
        Assert.Equal(0, _store.SaveCount);
    }

    [Fact]
    public async Task UpsertItemAsync_WithOutOfStockProduct_ReturnsOutOfStock()
    {
        var result = await CreateService().UpsertItemAsync(Buyer, LimitedHoodie.Id, 1, TestContext.Current.CancellationToken);

        var outOfStock = Assert.IsType<UpsertItemResult.OutOfStock>(result);
        Assert.Equal("Aspire Limited Edition Hoodie", outOfStock.ProductName);
        Assert.Equal(0, _store.SaveCount);
    }

    [Fact]
    public async Task UpsertItemAsync_WhenCatalogUnavailable_ReturnsCatalogUnavailable()
    {
        _catalog.Unavailable = true;

        var result = await CreateService().UpsertItemAsync(Buyer, Mug.Id, 1, TestContext.Current.CancellationToken);

        Assert.IsType<UpsertItemResult.CatalogUnavailable>(result);
        Assert.Equal(0, _store.SaveCount);
    }

    [Fact]
    public async Task RemoveItemAsync_RemovesLineSavesAndNamesTheRest()
    {
        await SeedBasketAsync((Mug, 2), (Poster, 1));

        var result = await CreateService().RemoveItemAsync(Buyer, Mug.Id, TestContext.Current.CancellationToken);

        var success = Assert.IsType<BasketResult.Success>(result);
        var remaining = Assert.Single(success.Basket.Basket.Items);
        Assert.Equal(Poster.Id, remaining.ProductId);
        Assert.Equal("Aspire Launch Poster", success.Basket.ProductNames[Poster.Id]);
        Assert.Equal(2, _store.SaveCount);
    }

    [Fact]
    public async Task RemoveItemAsync_WithUnknownLine_ReturnsBasketWithoutSaving()
    {
        var result = await CreateService().RemoveItemAsync(Buyer, Mug.Id, TestContext.Current.CancellationToken);

        var success = Assert.IsType<BasketResult.Success>(result);
        Assert.Empty(success.Basket.Basket.Items);
        Assert.Equal(0, _store.SaveCount);
    }
}
```

Create `tests/Ecommerce.Basket.Api.Tests/Features/GetBasketEndpointTests.cs`:

```csharp
using Ecommerce.Basket.Api.Domain;
using Ecommerce.Basket.Api.Features;
using Ecommerce.Basket.Api.Features.GetBasket;
using Ecommerce.Basket.Api.Infrastructure;
using Ecommerce.Basket.Api.Tests.Fakes;
using Ecommerce.ServiceDefaults.Api;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.Extensions.Logging.Abstractions;

namespace Ecommerce.Basket.Api.Tests.Features;

public sealed class GetBasketEndpointTests
{
    private static readonly BuyerId Buyer = new(Guid.Parse("b0000000-0000-4000-8000-000000000001"));
    private static readonly CatalogProduct Mug = new(Guid.Parse("a0000000-0000-4000-8000-000000000001"), "Aspire keramička šolja", 12.50m, 25);

    private readonly InMemoryBasketStore _store = new();
    private readonly FakeCatalogClient _catalog = new FakeCatalogClient().With(Mug);

    private BasketService CreateService() => new(_store, _catalog, NullLogger<BasketService>.Instance);

    private async Task SeedMugAsync()
    {
        var basket = new ShoppingBasket(Buyer.Value);
        basket.UpsertItem(Mug.Id, Mug.Price, 2, 25);
        await _store.SaveAsync(basket, TestContext.Current.CancellationToken);
    }

    [Fact]
    public async Task HandleAsync_NamesLinesAsTheCatalogReturnsThem()
    {
        await SeedMugAsync();

        var result = await GetBasketEndpoint.HandleAsync(Buyer, CreateService(), TestContext.Current.CancellationToken);

        var ok = Assert.IsType<Ok<ApiResponse<BasketResponse>>>(result.Result);
        var item = Assert.Single(ok.Value?.Data?.Items ?? []);
        Assert.Equal("Aspire keramička šolja", item.ProductName);
        Assert.Equal(25.00m, item.LineTotal);
    }

    [Fact]
    public async Task HandleAsync_WhenCatalogUnavailable_ReturnsServiceUnavailableEnvelope()
    {
        await SeedMugAsync();
        _catalog.Unavailable = true;

        var result = await GetBasketEndpoint.HandleAsync(Buyer, CreateService(), TestContext.Current.CancellationToken);

        var unavailable = Assert.IsType<JsonHttpResult<ApiResponse>>(result.Result);
        Assert.Equal(StatusCodes.Status503ServiceUnavailable, unavailable.StatusCode);
        Assert.Equal("basket.catalog_unavailable", unavailable.Value?.Error?.Code);
    }
}
```

Create `tests/Ecommerce.Basket.Api.Tests/Features/RemoveItemEndpointTests.cs`:

```csharp
using Ecommerce.Basket.Api.Domain;
using Ecommerce.Basket.Api.Features;
using Ecommerce.Basket.Api.Features.RemoveItem;
using Ecommerce.Basket.Api.Infrastructure;
using Ecommerce.Basket.Api.Tests.Fakes;
using Ecommerce.ServiceDefaults.Api;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.Extensions.Logging.Abstractions;

namespace Ecommerce.Basket.Api.Tests.Features;

public sealed class RemoveItemEndpointTests
{
    private static readonly BuyerId Buyer = new(Guid.Parse("b0000000-0000-4000-8000-000000000001"));
    private static readonly CatalogProduct Mug = new(Guid.Parse("a0000000-0000-4000-8000-000000000001"), "Aspire Ceramic Mug", 12.50m, 25);
    private static readonly CatalogProduct Poster = new(Guid.Parse("a0000000-0000-4000-8000-000000000010"), "Aspire Launch Poster", 15.00m, 2);

    [Fact]
    public async Task HandleAsync_RemovesTheLineAndReturnsTheNamedRest()
    {
        var store = new InMemoryBasketStore();
        var basket = new ShoppingBasket(Buyer.Value);
        basket.UpsertItem(Mug.Id, Mug.Price, 1, 25);
        basket.UpsertItem(Poster.Id, Poster.Price, 1, 2);
        await store.SaveAsync(basket, TestContext.Current.CancellationToken);
        var service = new BasketService(store, new FakeCatalogClient().With(Mug).With(Poster), NullLogger<BasketService>.Instance);

        var result = await RemoveItemEndpoint.HandleAsync(Buyer, Mug.Id, service, TestContext.Current.CancellationToken);

        var ok = Assert.IsType<Ok<ApiResponse<BasketResponse>>>(result.Result);
        var item = Assert.Single(ok.Value?.Data?.Items ?? []);
        Assert.Equal("Aspire Launch Poster", item.ProductName);
    }
}
```

Replace `tests/Ecommerce.Basket.Api.Tests/Features/CheckoutServiceTests.cs` with:

```csharp
using Ecommerce.Basket.Api.Domain;
using Ecommerce.Basket.Api.Features.Checkout;
using Ecommerce.Basket.Api.Infrastructure;
using Ecommerce.Basket.Api.Tests.Fakes;
using Ecommerce.Contracts;
using Ecommerce.ServiceDefaults.Api;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Extensions.Time.Testing;

namespace Ecommerce.Basket.Api.Tests.Features;

public sealed class CheckoutServiceTests
{
    private static readonly BuyerId Buyer = new(Guid.Parse("b0000000-0000-4000-8000-000000000001"));
    private static readonly CatalogProduct Mug = new(Guid.Parse("a0000000-0000-4000-8000-000000000001"), "Aspire Ceramic Mug", 12.50m, 25);
    private static readonly CatalogProduct Poster = new(Guid.Parse("a0000000-0000-4000-8000-000000000010"), "Aspire Launch Poster", 15.00m, 2);
    private static readonly CheckoutDetails Details = new(
        new OrderBuyer("Goran", "goran@example.com"),
        new OrderAddress("Main Street 1", "Belgrade", "11000", "Serbia"),
        new OrderCard("4242424242424242", "Goran"));
    private static readonly DateTimeOffset Now = new(2026, 9, 12, 12, 0, 0, TimeSpan.Zero);

    private readonly InMemoryBasketStore _store = new();
    private readonly FakeCatalogClient _catalog = new FakeCatalogClient().With(Mug).With(Poster);
    private readonly FakeOrderPlacedPublisher _publisher = new();

    private CheckoutService CreateService() =>
        new(_store, _catalog, _publisher, new FakeTimeProvider(Now), NullLogger<CheckoutService>.Instance);

    private async Task SeedBasketAsync(params (CatalogProduct Product, int Quantity, decimal StoredPrice)[] lines)
    {
        var basket = new ShoppingBasket(Buyer.Value);
        foreach (var (product, quantity, storedPrice) in lines)
        {
            basket.UpsertItem(product.Id, storedPrice, quantity, 99);
        }

        await _store.SaveAsync(basket, TestContext.Current.CancellationToken);
    }

    [Fact]
    public async Task CheckoutAsync_WithoutBasket_ReturnsEmptyBasket()
    {
        var result = await CreateService().CheckoutAsync(Buyer, Details, TestContext.Current.CancellationToken);

        Assert.IsType<CheckoutResult.EmptyBasket>(result);
        Assert.Empty(_publisher.Published);
    }

    [Fact]
    public async Task CheckoutAsync_PublishesOrderWithCurrentCatalogPricesAndClearsBasket()
    {
        await SeedBasketAsync((Mug, 2, 10.00m), (Poster, 1, 15.00m));

        var result = await CreateService().CheckoutAsync(Buyer, Details, TestContext.Current.CancellationToken);

        var placed = Assert.IsType<CheckoutResult.Placed>(result);
        var message = Assert.Single(_publisher.Published);
        Assert.Equal(placed.OrderId, message.OrderId);
        Assert.Equal(Buyer.Value, message.BuyerId);
        Assert.Equal(40.00m, placed.Total);
        Assert.Equal(40.00m, message.Total);
        Assert.Equal("EUR", message.Currency);
        Assert.Equal(Now, message.PlacedAt);
        Assert.Equal(12.50m, message.Lines.Single(line => line.ProductId == Mug.Id).UnitPrice);
        Assert.Equal("4242424242424242", message.Card.Number);
        Assert.Null(await _store.GetAsync(Buyer.Value, TestContext.Current.CancellationToken));
    }

    [Fact]
    public async Task CheckoutAsync_WithLineBeyondStock_ReturnsOutOfStockAndKeepsBasket()
    {
        await SeedBasketAsync((Mug, 1, 12.50m), (Poster, 3, 15.00m));

        var result = await CreateService().CheckoutAsync(Buyer, Details, TestContext.Current.CancellationToken);

        var outOfStock = Assert.IsType<CheckoutResult.OutOfStock>(result);
        var line = Assert.Single(outOfStock.Lines);
        Assert.Equal(Poster.Id, line.ProductId);
        Assert.Equal(3, line.Requested);
        Assert.Equal(2, line.Available);
        Assert.Empty(_publisher.Published);
        Assert.NotNull(await _store.GetAsync(Buyer.Value, TestContext.Current.CancellationToken));
    }

    [Fact]
    public async Task CheckoutAsync_WithProductNoLongerInCatalog_ReportsItWithZeroAvailable()
    {
        var vanished = new CatalogProduct(Guid.Parse("a0000000-0000-4000-8000-0000000000ee"), "Vanished", 1m, 1);
        await SeedBasketAsync((vanished, 1, 1m));

        var result = await CreateService().CheckoutAsync(Buyer, Details, TestContext.Current.CancellationToken);

        var outOfStock = Assert.IsType<CheckoutResult.OutOfStock>(result);
        Assert.Equal(0, Assert.Single(outOfStock.Lines).Available);
    }

    [Fact]
    public async Task CheckoutAsync_WhenCatalogUnavailable_ReturnsCatalogUnavailable()
    {
        await SeedBasketAsync((Mug, 1, 12.50m));
        _catalog.Unavailable = true;

        var result = await CreateService().CheckoutAsync(Buyer, Details, TestContext.Current.CancellationToken);

        Assert.IsType<CheckoutResult.CatalogUnavailable>(result);
        Assert.NotNull(await _store.GetAsync(Buyer.Value, TestContext.Current.CancellationToken));
    }

    [Fact]
    public async Task CheckoutAsync_WhenOutboxUnavailable_ReturnsOutboxUnavailableAndKeepsBasket()
    {
        await SeedBasketAsync((Mug, 1, 12.50m));
        _publisher.Unavailable = true;

        var result = await CreateService().CheckoutAsync(Buyer, Details, TestContext.Current.CancellationToken);

        Assert.IsType<CheckoutResult.OutboxUnavailable>(result);
        Assert.NotNull(await _store.GetAsync(Buyer.Value, TestContext.Current.CancellationToken));
    }
}
```

Replace `tests/Ecommerce.Basket.Api.Tests/Features/CheckoutEndpointTests.cs` with:

```csharp
using Ecommerce.Basket.Api.Domain;
using Ecommerce.Basket.Api.Features.Checkout;
using Ecommerce.Basket.Api.Infrastructure;
using Ecommerce.Basket.Api.Tests.Fakes;
using Ecommerce.ServiceDefaults.Api;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Extensions.Time.Testing;

namespace Ecommerce.Basket.Api.Tests.Features;

public sealed class CheckoutEndpointTests
{
    private static readonly BuyerId Buyer = new(Guid.Parse("b0000000-0000-4000-8000-000000000001"));
    private static readonly CatalogProduct Mug = new(Guid.Parse("a0000000-0000-4000-8000-000000000001"), "Aspire Ceramic Mug", 12.50m, 25);
    private static readonly CheckoutRequest Request = new(
        new CheckoutBuyer("Goran", "goran@example.com"),
        new CheckoutAddress("Main Street 1", "Belgrade", "11000", "Serbia"),
        new CheckoutCard("4242424242424242", "Goran"));

    private readonly InMemoryBasketStore _store = new();
    private readonly FakeOrderPlacedPublisher _publisher = new();

    private CheckoutService CreateService() =>
        new(_store, new FakeCatalogClient().With(Mug), _publisher, new FakeTimeProvider(), NullLogger<CheckoutService>.Instance);

    [Fact]
    public async Task HandleAsync_WithEmptyBasket_ReturnsBadRequestEnvelope()
    {
        var result = await CheckoutEndpoint.HandleAsync(Buyer, Request, CreateService(), TestContext.Current.CancellationToken);

        var badRequest = Assert.IsType<BadRequest<ApiResponse>>(result.Result);
        Assert.Equal("basket.checkout_empty", badRequest.Value?.Error?.Code);
    }

    [Fact]
    public async Task HandleAsync_WithItems_ReturnsAcceptedWithOrderId()
    {
        var basket = new ShoppingBasket(Buyer.Value);
        basket.UpsertItem(Mug.Id, Mug.Price, 2, Mug.AvailableStock);
        await _store.SaveAsync(basket, TestContext.Current.CancellationToken);

        var result = await CheckoutEndpoint.HandleAsync(Buyer, Request, CreateService(), TestContext.Current.CancellationToken);

        var accepted = Assert.IsType<Accepted<ApiResponse<CheckoutResponse>>>(result.Result);
        Assert.Equal(StatusCodes.Status202Accepted, accepted.StatusCode);
        Assert.NotNull(accepted.Value?.Data);
        Assert.Equal(25.00m, accepted.Value.Data.Total);
        Assert.Equal("EUR", accepted.Value.Data.Currency);
        Assert.Equal(accepted.Value.Data.OrderId, Assert.Single(_publisher.Published).OrderId);
    }

    [Fact]
    public async Task HandleAsync_WhenOutboxUnavailable_ReturnsServiceUnavailableEnvelope()
    {
        var basket = new ShoppingBasket(Buyer.Value);
        basket.UpsertItem(Mug.Id, Mug.Price, 1, Mug.AvailableStock);
        await _store.SaveAsync(basket, TestContext.Current.CancellationToken);
        _publisher.Unavailable = true;

        var result = await CheckoutEndpoint.HandleAsync(Buyer, Request, CreateService(), TestContext.Current.CancellationToken);

        var unavailable = Assert.IsType<JsonHttpResult<ApiResponse>>(result.Result);
        Assert.Equal(StatusCodes.Status503ServiceUnavailable, unavailable.StatusCode);
        Assert.Equal("basket.outbox_unavailable", unavailable.Value?.Error?.Code);
    }
}
```

```bash
dotnet build tests/Ecommerce.Basket.Api.Tests
```

Expected: the build fails on `UpsertItem` taking four arguments, `NamedBasket`, `BasketResult`, `LookupCount` and the removed `GetProductAsync`. Note the first error lines for the report.

- [ ] **Step 2: Implement**

Replace `src/Ecommerce.Basket.Api/Domain/BasketItem.cs` with:

```csharp
namespace Ecommerce.Basket.Api.Domain;

// Product names are not stored; Catalog names every line in the request's language when the basket is read
public sealed record BasketItem(Guid ProductId, decimal UnitPrice, int Quantity)
{
    public decimal LineTotal => UnitPrice * Quantity;
}
```

Replace `src/Ecommerce.Basket.Api/Domain/ShoppingBasket.cs` with:

```csharp
namespace Ecommerce.Basket.Api.Domain;

public sealed class ShoppingBasket
{
    public const int MaxQuantityPerLine = 99;

    private readonly List<BasketItem> _items;

    public ShoppingBasket(Guid buyerId)
        : this(buyerId, [])
    {
    }

    public ShoppingBasket(Guid buyerId, IEnumerable<BasketItem> items)
    {
        BuyerId = buyerId;
        _items = [.. items];
    }

    public Guid BuyerId { get; }

    public IReadOnlyList<BasketItem> Items => _items;

    public int ItemCount => _items.Sum(item => item.Quantity);

    public decimal Total => _items.Sum(item => item.LineTotal);

    // Sets the line quantity, capped at the available stock, and returns the quantity applied
    public int UpsertItem(Guid productId, decimal unitPrice, int requestedQuantity, int availableStock)
    {
        ArgumentOutOfRangeException.ThrowIfNegativeOrZero(requestedQuantity);
        ArgumentOutOfRangeException.ThrowIfNegativeOrZero(availableStock);

        var applied = Math.Min(Math.Min(requestedQuantity, availableStock), MaxQuantityPerLine);
        var item = new BasketItem(productId, unitPrice, applied);
        var index = _items.FindIndex(existing => existing.ProductId == productId);
        if (index >= 0)
        {
            _items[index] = item;
        }
        else
        {
            _items.Add(item);
        }

        return applied;
    }

    public bool RemoveItem(Guid productId) => _items.RemoveAll(item => item.ProductId == productId) > 0;
}
```

Replace `src/Ecommerce.Basket.Api/Infrastructure/ICatalogClient.cs` with:

```csharp
namespace Ecommerce.Basket.Api.Infrastructure;

public sealed record CatalogProduct(Guid Id, string Name, decimal Price, int AvailableStock);

// Thrown when the catalog cannot be reached after the resilience handler gave up
public sealed class CatalogUnavailableException(Exception inner) : Exception("The catalog service is unavailable", inner);

public interface ICatalogClient
{
    // Returns only the products the catalog knows, named in the request's language; throws CatalogUnavailableException when the catalog cannot be reached
    Task<IReadOnlyList<CatalogProduct>> GetProductsAsync(IReadOnlyCollection<Guid> productIds, CancellationToken cancellationToken);
}
```

Replace `src/Ecommerce.Basket.Api/Infrastructure/CatalogClient.cs` with:

```csharp
using System.Net.Http.Json;
using Ecommerce.ServiceDefaults.Api;
using Polly.CircuitBreaker;
using Polly.Timeout;

namespace Ecommerce.Basket.Api.Infrastructure;

// The Accept-Language header of the current request travels along through header propagation, so names come back in the buyer's language
public sealed class CatalogClient(HttpClient httpClient) : ICatalogClient
{
    public async Task<IReadOnlyList<CatalogProduct>> GetProductsAsync(IReadOnlyCollection<Guid> productIds, CancellationToken cancellationToken)
    {
        if (productIds.Count == 0)
        {
            return [];
        }

        var query = string.Join("&", productIds.Select(id => $"ids={id}"));
        try
        {
            var envelope = await httpClient.GetFromJsonAsync<ApiResponse<List<CatalogProduct>>>($"/api/catalog/products?{query}", cancellationToken);
            return envelope?.Data ?? [];
        }
        catch (Exception exception) when (IsTransport(exception))
        {
            throw new CatalogUnavailableException(exception);
        }
    }

    private static bool IsTransport(Exception exception) =>
        exception is HttpRequestException or TimeoutRejectedException or BrokenCircuitException;
}
```

Create `src/Ecommerce.Basket.Api/Features/NamedBasket.cs`:

```csharp
using Ecommerce.Basket.Api.Domain;

namespace Ecommerce.Basket.Api.Features;

// A basket together with the product names Catalog returned for its lines in the request's language
public sealed record NamedBasket(ShoppingBasket Basket, IReadOnlyDictionary<Guid, string> ProductNames);
```

Replace `src/Ecommerce.Basket.Api/Features/BasketResponse.cs` with:

```csharp
namespace Ecommerce.Basket.Api.Features;

public sealed record BasketItemResponse(Guid ProductId, string ProductName, decimal UnitPrice, int Quantity, decimal LineTotal);

public sealed record BasketResponse(Guid BuyerId, IReadOnlyList<BasketItemResponse> Items, int ItemCount, decimal Total)
{
    // A product the catalog no longer knows is shown by its id
    public static BasketResponse From(NamedBasket named) =>
        new(
            named.Basket.BuyerId,
            named.Basket.Items
                .Select(item => new BasketItemResponse(
                    item.ProductId,
                    named.ProductNames.GetValueOrDefault(item.ProductId, item.ProductId.ToString()),
                    item.UnitPrice,
                    item.Quantity,
                    item.LineTotal))
                .ToList(),
            named.Basket.ItemCount,
            named.Basket.Total);
}
```

Replace `src/Ecommerce.Basket.Api/Features/BasketService.cs` with:

```csharp
using Ecommerce.Basket.Api.Domain;
using Ecommerce.Basket.Api.Infrastructure;
using Ecommerce.ServiceDefaults.Api;

namespace Ecommerce.Basket.Api.Features;

public abstract record BasketResult
{
    public sealed record Success(NamedBasket Basket) : BasketResult;

    public sealed record CatalogUnavailable : BasketResult;
}

public abstract record UpsertItemResult
{
    public sealed record Success(NamedBasket Basket, int RequestedQuantity, int AppliedQuantity) : UpsertItemResult
    {
        public bool Capped => AppliedQuantity < RequestedQuantity;
    }

    public sealed record ProductNotFound(Guid ProductId) : UpsertItemResult;

    public sealed record OutOfStock(Guid ProductId, string ProductName) : UpsertItemResult;

    public sealed record CatalogUnavailable : UpsertItemResult;
}

public sealed class BasketService(IBasketStore store, ICatalogClient catalog, ILogger<BasketService> logger)
{
    public async Task<BasketResult> GetAsync(BuyerId buyerId, CancellationToken cancellationToken)
    {
        var basket = await LoadAsync(buyerId, cancellationToken);
        return await NameAsync(basket, cancellationToken);
    }

    public async Task<UpsertItemResult> UpsertItemAsync(BuyerId buyerId, Guid productId, int quantity, CancellationToken cancellationToken)
    {
        var basket = await LoadAsync(buyerId, cancellationToken);

        // One catalog call checks the requested product and names every line of the response
        IReadOnlyList<CatalogProduct> products;
        try
        {
            products = await catalog.GetProductsAsync(basket.Items.Select(item => item.ProductId).Append(productId).Distinct().ToList(), cancellationToken);
        }
        catch (CatalogUnavailableException exception)
        {
            logger.LogWarning(exception, "[{Prefix}] Catalog unavailable while adding product [{ProductId}] for buyer [{BuyerId}]", nameof(BasketService), productId, buyerId.Value);
            return new UpsertItemResult.CatalogUnavailable();
        }

        var product = products.FirstOrDefault(candidate => candidate.Id == productId);
        if (product is null)
        {
            return new UpsertItemResult.ProductNotFound(productId);
        }

        if (product.AvailableStock == 0)
        {
            return new UpsertItemResult.OutOfStock(product.Id, product.Name);
        }

        var applied = basket.UpsertItem(product.Id, product.Price, quantity, product.AvailableStock);
        await store.SaveAsync(basket, cancellationToken);

        if (applied < quantity)
        {
            logger.LogWarning("[{Prefix}] Capped product [{ProductId}] at [{Applied}] of requested [{Requested}] for buyer [{BuyerId}]", nameof(BasketService), product.Id, applied, quantity, buyerId.Value);
        }
        else
        {
            logger.LogInformation("[{Prefix}] Set product [{ProductId}] quantity [{Quantity}] for buyer [{BuyerId}]", nameof(BasketService), product.Id, applied, buyerId.Value);
        }

        return new UpsertItemResult.Success(new NamedBasket(basket, NamesOf(products)), quantity, applied);
    }

    public async Task<BasketResult> RemoveItemAsync(BuyerId buyerId, Guid productId, CancellationToken cancellationToken)
    {
        var basket = await LoadAsync(buyerId, cancellationToken);
        if (basket.RemoveItem(productId))
        {
            await store.SaveAsync(basket, cancellationToken);
            logger.LogInformation("[{Prefix}] Removed product [{ProductId}] for buyer [{BuyerId}]", nameof(BasketService), productId, buyerId.Value);
        }

        return await NameAsync(basket, cancellationToken);
    }

    private async Task<ShoppingBasket> LoadAsync(BuyerId buyerId, CancellationToken cancellationToken) =>
        await store.GetAsync(buyerId.Value, cancellationToken) ?? new ShoppingBasket(buyerId.Value);

    // An empty basket needs no catalog call
    private async Task<BasketResult> NameAsync(ShoppingBasket basket, CancellationToken cancellationToken)
    {
        if (basket.Items.Count == 0)
        {
            return new BasketResult.Success(new NamedBasket(basket, new Dictionary<Guid, string>()));
        }

        try
        {
            var products = await catalog.GetProductsAsync(basket.Items.Select(item => item.ProductId).ToList(), cancellationToken);
            return new BasketResult.Success(new NamedBasket(basket, NamesOf(products)));
        }
        catch (CatalogUnavailableException exception)
        {
            logger.LogWarning(exception, "[{Prefix}] Catalog unavailable while naming the basket of buyer [{BuyerId}]", nameof(BasketService), basket.BuyerId);
            return new BasketResult.CatalogUnavailable();
        }
    }

    private static Dictionary<Guid, string> NamesOf(IReadOnlyList<CatalogProduct> products) =>
        products.ToDictionary(product => product.Id, product => product.Name);
}
```

Replace `src/Ecommerce.Basket.Api/Features/GetBasket/GetBasketEndpoint.cs` with:

```csharp
using Ecommerce.ServiceDefaults.Api;
using Microsoft.AspNetCore.Http.HttpResults;

namespace Ecommerce.Basket.Api.Features.GetBasket;

public static class GetBasketEndpoint
{
    public static RouteGroupBuilder MapGetBasket(this RouteGroupBuilder group)
    {
        group.MapGet("/", HandleAsync).WithName("GetBasket");
        return group;
    }

    public static async Task<Results<Ok<ApiResponse<BasketResponse>>, JsonHttpResult<ApiResponse>>> HandleAsync(
        BuyerId buyerId,
        BasketService service,
        CancellationToken cancellationToken)
    {
        var result = await service.GetAsync(buyerId, cancellationToken);

        return result switch
        {
            BasketResult.Success success => ApiResults.Ok(BasketResponse.From(success.Basket)),
            BasketResult.CatalogUnavailable => ApiResults.ServiceUnavailable(ErrorCodes.CatalogUnavailable, "The catalog service is unavailable"),
            _ => throw new InvalidOperationException($"Unhandled result [{result.GetType().Name}]"),
        };
    }
}
```

Replace `src/Ecommerce.Basket.Api/Features/RemoveItem/RemoveItemEndpoint.cs` with:

```csharp
using Ecommerce.ServiceDefaults.Api;
using Microsoft.AspNetCore.Http.HttpResults;

namespace Ecommerce.Basket.Api.Features.RemoveItem;

public static class RemoveItemEndpoint
{
    public static RouteGroupBuilder MapRemoveItem(this RouteGroupBuilder group)
    {
        group.MapDelete("/items/{productId:guid}", HandleAsync).WithName("RemoveBasketItem");
        return group;
    }

    public static async Task<Results<Ok<ApiResponse<BasketResponse>>, JsonHttpResult<ApiResponse>>> HandleAsync(
        BuyerId buyerId,
        Guid productId,
        BasketService service,
        CancellationToken cancellationToken)
    {
        var result = await service.RemoveItemAsync(buyerId, productId, cancellationToken);

        return result switch
        {
            BasketResult.Success success => ApiResults.Ok(BasketResponse.From(success.Basket)),
            BasketResult.CatalogUnavailable => ApiResults.ServiceUnavailable(ErrorCodes.CatalogUnavailable, "The catalog service is unavailable"),
            _ => throw new InvalidOperationException($"Unhandled result [{result.GetType().Name}]"),
        };
    }
}
```

Replace `src/Ecommerce.Basket.Api/Features/Checkout/CheckoutService.cs` with:

```csharp
using Ecommerce.Basket.Api.Domain;
using Ecommerce.Basket.Api.Infrastructure;
using Ecommerce.Contracts;
using Ecommerce.ServiceDefaults.Api;

namespace Ecommerce.Basket.Api.Features.Checkout;

public sealed record CheckoutDetails(OrderBuyer Buyer, OrderAddress ShippingAddress, OrderCard Card);

public sealed record UnavailableLine(Guid ProductId, string ProductName, int Requested, int Available);

public abstract record CheckoutResult
{
    public sealed record Placed(Guid OrderId, decimal Total) : CheckoutResult;

    public sealed record EmptyBasket : CheckoutResult;

    public sealed record OutOfStock(IReadOnlyList<UnavailableLine> Lines) : CheckoutResult;

    public sealed record CatalogUnavailable : CheckoutResult;

    public sealed record OutboxUnavailable : CheckoutResult;
}

public sealed class CheckoutService(
    IBasketStore store,
    ICatalogClient catalog,
    IOrderPlacedPublisher publisher,
    TimeProvider timeProvider,
    ILogger<CheckoutService> logger)
{
    public const string Currency = "EUR";

    public async Task<CheckoutResult> CheckoutAsync(BuyerId buyerId, CheckoutDetails details, CancellationToken cancellationToken)
    {
        var basket = await store.GetAsync(buyerId.Value, cancellationToken);
        if (basket is null || basket.Items.Count == 0)
        {
            return new CheckoutResult.EmptyBasket();
        }

        IReadOnlyList<CatalogProduct> products;
        try
        {
            products = await catalog.GetProductsAsync(basket.Items.Select(item => item.ProductId).ToList(), cancellationToken);
        }
        catch (CatalogUnavailableException exception)
        {
            logger.LogWarning(exception, "[{Prefix}] Catalog unavailable during checkout for buyer [{BuyerId}]", nameof(CheckoutService), buyerId.Value);
            return new CheckoutResult.CatalogUnavailable();
        }

        var byId = products.ToDictionary(product => product.Id);
        var unavailable = basket.Items
            .Select(item => byId.TryGetValue(item.ProductId, out var product)
                ? new UnavailableLine(item.ProductId, product.Name, item.Quantity, product.AvailableStock)
                : new UnavailableLine(item.ProductId, item.ProductId.ToString(), item.Quantity, 0))
            .Where(line => line.Available < line.Requested)
            .ToList();
        if (unavailable.Count > 0)
        {
            logger.LogWarning("[{Prefix}] Checkout blocked for buyer [{BuyerId}], [{Count}] lines exceed stock", nameof(CheckoutService), buyerId.Value, unavailable.Count);
            return new CheckoutResult.OutOfStock(unavailable);
        }

        var lines = basket.Items
            .Select(item => new OrderLine(item.ProductId, byId[item.ProductId].Name, byId[item.ProductId].Price, item.Quantity))
            .ToList();
        var orderPlaced = new OrderPlaced(
            Guid.CreateVersion7(),
            buyerId.Value,
            details.Buyer,
            details.ShippingAddress,
            details.Card,
            lines,
            lines.Sum(line => line.UnitPrice * line.Quantity),
            Currency,
            timeProvider.GetUtcNow());

        try
        {
            await publisher.PublishAsync(orderPlaced, cancellationToken);
        }
        catch (OutboxUnavailableException exception)
        {
            logger.LogWarning(exception, "[{Prefix}] Outbox unavailable, order [{OrderId}] for buyer [{BuyerId}] not placed, basket kept", nameof(CheckoutService), orderPlaced.OrderId, buyerId.Value);
            return new CheckoutResult.OutboxUnavailable();
        }

        await store.DeleteAsync(buyerId.Value, cancellationToken);
        logger.LogInformation("[{Prefix}] Published OrderPlaced for order [{OrderId}] buyer [{BuyerId}] total [{Total}]", nameof(CheckoutService), orderPlaced.OrderId, buyerId.Value, orderPlaced.Total);
        return new CheckoutResult.Placed(orderPlaced.OrderId, orderPlaced.Total);
    }
}
```

Replace `src/Ecommerce.Basket.Api/Program.cs` with:

```csharp
using Ecommerce.Basket.Api.Features;
using Ecommerce.Basket.Api.Features.Checkout;
using Ecommerce.Basket.Api.Features.GetBasket;
using Ecommerce.Basket.Api.Features.RemoveItem;
using Ecommerce.Basket.Api.Features.UpsertItem;
using Ecommerce.Basket.Api.Infrastructure;
using Ecommerce.Contracts;
using Ecommerce.ServiceDefaults.Api;
using JasperFx;
using Wolverine;
using Wolverine.Postgresql;
using Wolverine.RabbitMQ;

var builder = WebApplication.CreateBuilder(args);

builder.AddServiceDefaults();
builder.AddApiDefaults();
builder.Services.AddValidation();
builder.AddRedisClient("redis");
builder.Services.AddSingleton<IBasketStore, RedisBasketStore>();
// The buyer's Accept-Language travels to Catalog on every call, so product names come back in the buyer's language
builder.Services.AddHeaderPropagation(options => options.Headers.Add("Accept-Language"));
builder.Services.AddHttpClient<ICatalogClient, CatalogClient>(client => client.BaseAddress = new Uri("https+http://catalog-api"))
    .AddHeaderPropagation();
builder.Services.AddSingleton(TimeProvider.System);
builder.Services.AddScoped<IOrderPlacedPublisher, WolverineOrderPlacedPublisher>();
builder.Services.AddScoped<BasketService>();
builder.Services.AddScoped<CheckoutService>();

builder.UseWolverine(options =>
{
    // The outbox tables live in the basket's own database; a message is persisted there before PublishAsync returns
    options.PersistMessagesWithPostgresql(builder.Configuration.GetConnectionString("basketdb")!, "wolverine");
    options.UseRabbitMqUsingNamedConnection("messaging").AutoProvision();
    options.PublishMessage<OrderPlaced>().ToRabbitExchange("order-placed").UseDurableOutbox();
});

var app = builder.Build();

app.UseApiDefaults();
app.UseHeaderPropagation();

var basket = app.MapGroup("/api/basket").WithTags("Basket").AddEndpointFilter<BuyerIdFilter>();
basket.MapGetBasket();
basket.MapUpsertItem();
basket.MapRemoveItem();
basket.MapCheckout();

return await app.RunJasperFxCommands(args);
```

Replace `src/Ecommerce.Basket.Api/Ecommerce.Basket.Api.csproj` with:

```xml
<Project Sdk="Microsoft.NET.Sdk.Web">

  <ItemGroup>
    <PackageReference Include="Aspire.StackExchange.Redis" />
    <PackageReference Include="Microsoft.AspNetCore.HeaderPropagation" />
    <PackageReference Include="WolverineFx" />
    <PackageReference Include="WolverineFx.RabbitMQ" />
    <PackageReference Include="WolverineFx.RuntimeCompilation" />
    <PackageReference Include="WolverineFx.Postgresql" />
  </ItemGroup>

  <ItemGroup>
    <ProjectReference Include="../Ecommerce.Contracts/Ecommerce.Contracts.csproj" />
    <ProjectReference Include="../Ecommerce.ServiceDefaults/Ecommerce.ServiceDefaults.csproj" />
  </ItemGroup>

</Project>
```

In `Directory.Packages.props` add one line to the `Basket` group after the Redis one:

```xml
    <PackageVersion Include="Microsoft.AspNetCore.HeaderPropagation" Version="10.0.12" />
```

```bash
dotnet test --project tests/Ecommerce.Basket.Api.Tests
```

Expected: 33 tests passed (28 before).

- [ ] **Step 3: Integration test and the full run**

Create `tests/Ecommerce.IntegrationTests/LocalizationTests.cs`:

```csharp
using System.Net.Http.Json;
using System.Text.Json;

namespace Ecommerce.IntegrationTests;

[Collection(AppCollection.Name)]
public sealed class LocalizationTests(AppFixture app)
{
    private static readonly Guid Mug = Guid.Parse("a0000000-0000-4000-8000-000000000001");
    private static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web);

    [Fact]
    public async Task Product_FollowsAcceptLanguage_AndFallsBackToEnglish()
    {
        var cancellationToken = TestContext.Current.CancellationToken;

        Assert.Equal("Aspire keramička šolja", await GetProductNameAsync("sr-Latn", cancellationToken));
        Assert.Equal("Aspire Ceramic Mug", await GetProductNameAsync("en", cancellationToken));
        Assert.Equal("Aspire Ceramic Mug", await GetProductNameAsync("de", cancellationToken));
    }

    [Fact]
    public async Task BasketLines_AreNamedInTheLanguageOfEachRead()
    {
        var cancellationToken = TestContext.Current.CancellationToken;
        var buyerId = Guid.NewGuid();
        await new ShopClient(app.Gateway, buyerId).AddToBasketAsync(Mug, 1, cancellationToken);

        Assert.Equal("Aspire keramička šolja", await GetBasketLineNameAsync(buyerId, "sr-Latn", cancellationToken));
        Assert.Equal("Aspire Ceramic Mug", await GetBasketLineNameAsync(buyerId, "en", cancellationToken));
    }

    private async Task<string?> GetProductNameAsync(string language, CancellationToken cancellationToken)
    {
        using var request = new HttpRequestMessage(HttpMethod.Get, $"/api/catalog/products/{Mug}");
        request.Headers.Add("Accept-Language", language);
        using var response = await app.Gateway.SendAsync(request, cancellationToken);
        response.EnsureSuccessStatusCode();
        using var body = JsonDocument.Parse(await response.Content.ReadAsStringAsync(cancellationToken));
        return body.RootElement.GetProperty("data").GetProperty("name").GetString();
    }

    private async Task<string?> GetBasketLineNameAsync(Guid buyerId, string language, CancellationToken cancellationToken)
    {
        using var request = new HttpRequestMessage(HttpMethod.Get, "/api/basket");
        request.Headers.Add("X-Buyer-Id", buyerId.ToString());
        request.Headers.Add("Accept-Language", language);
        using var response = await app.Gateway.SendAsync(request, cancellationToken);
        response.EnsureSuccessStatusCode();
        using var body = JsonDocument.Parse(await response.Content.ReadAsStringAsync(cancellationToken));
        return body.RootElement.GetProperty("data").GetProperty("items")[0].GetProperty("productName").GetString();
    }
}
```

```bash
export PATH="$PATH:$HOME/.dotnet/tools"
source "$HOME/.nvm/nvm.sh" && nvm use 24
dotnet build
dotnet test
```

Expected: `0 Warning(s)`; 154 tests passed (147 after task 8.2.1 plus 5 Basket tests and 2 integration tests).

## Sub-phase 8.4 Frontend localization with Transloco, language menu and persisted choice (frontend-dev)

### Task 8.4.1: Dictionaries, language store, menu, interceptor, translated pages

**Files:**
- Modify: `src/ecommerce-frontend/package.json` (through `npm install`), `package-lock.json`
- Modify: `src/ecommerce-frontend/tsconfig.json`
- Modify: `src/ecommerce-frontend/angular.json`
- Create: `src/ecommerce-frontend/public/i18n/en.json`
- Create: `src/ecommerce-frontend/public/i18n/sr.json`
- Create: `src/ecommerce-frontend/src/app/core/i18n/languages.ts`
- Create: `src/ecommerce-frontend/src/app/core/i18n/transloco-loader.ts`
- Create: `src/ecommerce-frontend/src/app/core/i18n/translate-known.ts`
- Create: `src/ecommerce-frontend/src/app/core/i18n/translate-known.spec.ts`
- Create: `src/ecommerce-frontend/src/app/core/i18n/transloco-testing.ts`
- Create: `src/ecommerce-frontend/src/app/shared/models/preferences.ts`
- Create: `src/ecommerce-frontend/src/app/core/api/preferences-api.ts`
- Create: `src/ecommerce-frontend/src/app/core/language-store.ts`
- Create: `src/ecommerce-frontend/src/app/core/language-store.spec.ts`
- Create: `src/ecommerce-frontend/src/app/core/language-interceptor.ts`
- Create: `src/ecommerce-frontend/src/app/core/language-interceptor.spec.ts`
- Create: `src/ecommerce-frontend/src/app/core/layout/language-menu.ts`, `.html`, `.scss`, `.spec.ts`
- Modify: `src/ecommerce-frontend/src/app/app.config.ts`
- Modify: `src/ecommerce-frontend/src/app/app.ts`
- Modify: `src/ecommerce-frontend/src/app/app.spec.ts`
- Modify: `src/ecommerce-frontend/src/app/core/layout/site-header.ts`, `.html`
- Modify: `src/ecommerce-frontend/src/app/core/api/catalog-api.ts`
- Modify: `src/ecommerce-frontend/src/app/features/products/product-list.ts`, `.html`
- Modify: `src/ecommerce-frontend/src/app/features/basket/basket-page.ts`, `.html`
- Modify: `src/ecommerce-frontend/src/app/features/checkout/checkout-page.ts`, `.html`, `.spec.ts`
- Modify: `src/ecommerce-frontend/src/app/features/orders/orders-page.ts`, `.html`, `.spec.ts`

**Interfaces:**
- Consumes: `GET` and `PUT /api/preferences` returning `{ language }` (task 8.1.1); Catalog and Basket answering `Accept-Language` (tasks 8.2.1 and 8.3.1); the existing `BasketStore`, `PendingOrder`, `ApiFailure`.
- Produces: `LanguageStore` (`language`, `acceptLanguage`, `initialize()`, `select(language)`); `languageInterceptor`; `LanguageMenu` (`app-language-menu`); `translateKnown` and `failureMessage`; `provideTranslocoTesting()` for specs; every visible string comes from `public/i18n/*.json`; prices and dates format per language; the products list reloads on a language change and the root component reloads the basket.

- [ ] **Step 1: Install the two packages**

```bash
npm install @jsverse/transloco@8.4.0 @jsverse/transloco-locale@8.4.0
```

Expected: `package.json` gains `"@jsverse/transloco": "^8.4.0"` and `"@jsverse/transloco-locale": "^8.4.0"` under `dependencies`, alphabetically after the Angular packages. Ignore the `npm warn install-scripts` lines.

- [ ] **Step 2: Dictionaries, JSON imports, testing helper and the failing specs**

Create `src/ecommerce-frontend/public/i18n/en.json`:

```json
{
  "nav": {
    "products": "Products",
    "basket": "Basket",
    "orders": "Orders",
    "language": "Language"
  },
  "language": {
    "saveFailed": "Your language could not be saved"
  },
  "common": {
    "retry": "Retry",
    "dismiss": "Dismiss",
    "browse": "Browse products",
    "total": "Total"
  },
  "products": {
    "title": "Products",
    "loading": "Loading products",
    "inStock": "In stock: {{count}}",
    "outOfStock": "Out of stock",
    "add": "Add to basket",
    "empty": "No products available",
    "added": "Added {{name}} to your basket",
    "capped": "Only {{count}} of {{name}} available, quantity set to {{count}}"
  },
  "basket": {
    "title": "Your basket",
    "empty": "Your basket is empty.",
    "each": "{{price}} each",
    "quantityOf": "Quantity of {{name}}",
    "decrease": "Decrease quantity",
    "increase": "Increase quantity",
    "remove": "Remove",
    "checkout": "Proceed to checkout",
    "removed": "Removed {{name}} from your basket",
    "capped": "Only {{count}} of {{name}} available"
  },
  "checkout": {
    "title": "Checkout",
    "empty": "Your basket is empty, there is nothing to check out.",
    "details": "Delivery and payment",
    "name": "Full name",
    "email": "Email",
    "street": "Street",
    "city": "City",
    "postalCode": "Postal code",
    "country": "Country",
    "cardNumber": "Card number",
    "cardHint": "Test cards: 4242 4242 4242 4242 is approved, any number ending in 0002 is declined",
    "cardHolder": "Card holder",
    "back": "Back to basket",
    "place": "Place order",
    "summary": "Order summary",
    "placed": "Order placed, total {{total}}"
  },
  "orders": {
    "title": "Your orders",
    "loading": "Loading orders",
    "watching": "Watching for status changes",
    "placing": "Your order is being placed and will appear here in a moment.",
    "empty": "You have not placed any orders yet.",
    "order": "Order {{id}}",
    "cardAndCity": "Card ending {{last4}}, shipping to {{city}}"
  },
  "status": {
    "Submitted": "Submitted",
    "Paid": "Paid",
    "Shipped": "Shipped",
    "PaymentFailed": "Payment failed"
  },
  "reasons": {
    "card_declined": "The card was declined",
    "declined": "The payment was declined"
  },
  "errors": {
    "basket": {
      "product_not_found": "That product no longer exists",
      "product_out_of_stock": "That product is out of stock",
      "catalog_unavailable": "The catalog is unavailable right now, please try again",
      "checkout_empty": "Your basket is empty",
      "checkout_out_of_stock": "Some items exceed the available stock",
      "outbox_unavailable": "The order could not be submitted, your basket was kept"
    },
    "catalog": {
      "product_not_found": "That product no longer exists"
    },
    "common": {
      "upstream_unavailable": "A service is unavailable right now, please try again"
    },
    "client": {
      "network_error": "The server could not be reached"
    }
  }
}
```

Create `src/ecommerce-frontend/public/i18n/sr.json`:

```json
{
  "nav": {
    "products": "Proizvodi",
    "basket": "Korpa",
    "orders": "Porudžbine",
    "language": "Jezik"
  },
  "language": {
    "saveFailed": "Vaš jezik nije mogao da bude sačuvan"
  },
  "common": {
    "retry": "Pokušaj ponovo",
    "dismiss": "Zatvori",
    "browse": "Pogledaj proizvode",
    "total": "Ukupno"
  },
  "products": {
    "title": "Proizvodi",
    "loading": "Učitavanje proizvoda",
    "inStock": "Na stanju: {{count}}",
    "outOfStock": "Nema na stanju",
    "add": "Dodaj u korpu",
    "empty": "Nema dostupnih proizvoda",
    "added": "{{name}} je dodat u korpu",
    "capped": "Dostupno je samo {{count}} kom. proizvoda {{name}}, količina je postavljena na {{count}}"
  },
  "basket": {
    "title": "Vaša korpa",
    "empty": "Vaša korpa je prazna.",
    "each": "{{price}} po komadu",
    "quantityOf": "Količina za {{name}}",
    "decrease": "Smanji količinu",
    "increase": "Povećaj količinu",
    "remove": "Ukloni",
    "checkout": "Nastavi na plaćanje",
    "removed": "{{name}} je uklonjen iz korpe",
    "capped": "Dostupno je samo {{count}} kom. proizvoda {{name}}"
  },
  "checkout": {
    "title": "Plaćanje",
    "empty": "Vaša korpa je prazna, nema šta da se plati.",
    "details": "Isporuka i plaćanje",
    "name": "Ime i prezime",
    "email": "Imejl",
    "street": "Ulica",
    "city": "Grad",
    "postalCode": "Poštanski broj",
    "country": "Država",
    "cardNumber": "Broj kartice",
    "cardHint": "Test kartice: 4242 4242 4242 4242 se odobrava, svaki broj koji se završava na 0002 se odbija",
    "cardHolder": "Vlasnik kartice",
    "back": "Nazad na korpu",
    "place": "Poruči",
    "summary": "Pregled porudžbine",
    "placed": "Porudžbina je primljena, ukupno {{total}}"
  },
  "orders": {
    "title": "Vaše porudžbine",
    "loading": "Učitavanje porudžbina",
    "watching": "Pratimo promene statusa",
    "placing": "Vaša porudžbina se obrađuje i pojaviće se ovde za koji trenutak.",
    "empty": "Još uvek niste ništa poručili.",
    "order": "Porudžbina {{id}}",
    "cardAndCity": "Kartica se završava na {{last4}}, isporuka u {{city}}"
  },
  "status": {
    "Submitted": "Primljena",
    "Paid": "Plaćena",
    "Shipped": "Poslata",
    "PaymentFailed": "Plaćanje nije uspelo"
  },
  "reasons": {
    "card_declined": "Kartica je odbijena",
    "declined": "Plaćanje je odbijeno"
  },
  "errors": {
    "basket": {
      "product_not_found": "Taj proizvod više ne postoji",
      "product_out_of_stock": "Tog proizvoda nema na stanju",
      "catalog_unavailable": "Katalog trenutno nije dostupan, pokušajte ponovo",
      "checkout_empty": "Vaša korpa je prazna",
      "checkout_out_of_stock": "Neke stavke premašuju dostupne količine",
      "outbox_unavailable": "Porudžbina nije mogla da bude poslata, korpa je sačuvana"
    },
    "catalog": {
      "product_not_found": "Taj proizvod više ne postoji"
    },
    "common": {
      "upstream_unavailable": "Neki servis trenutno nije dostupan, pokušajte ponovo"
    },
    "client": {
      "network_error": "Server nije dostupan"
    }
  }
}
```

In `src/ecommerce-frontend/tsconfig.json` add one line to `compilerOptions` after `"importHelpers": true,`:

```json
    "resolveJsonModule": true,
```

In `src/ecommerce-frontend/angular.json`, in the production budgets, change the `initial` budget's `"maximumWarning": "500kB"` to `"maximumWarning": "600kB"`; Transloco adds about 17 kB to the initial bundle.

Create `src/ecommerce-frontend/src/app/core/i18n/languages.ts`:

```ts
export const languages = ['en', 'sr'] as const;

export type Language = (typeof languages)[number];

export const defaultLanguage: Language = 'en';

// Shown in the language menu, each name in its own language
export const languageNames: Record<Language, string> = { en: 'English', sr: 'Srpski' };

// What the API receives in Accept-Language; Serbian is served in the Latin script
export const acceptLanguages: Record<Language, string> = { en: 'en', sr: 'sr-Latn' };

// Locales for number and date formatting
export const locales: Record<Language, string> = { en: 'en-US', sr: 'sr-Latn-RS' };

export function isLanguage(value: unknown): value is Language {
  return typeof value === 'string' && (languages as readonly string[]).includes(value);
}
```

Create `src/ecommerce-frontend/src/app/core/i18n/transloco-testing.ts`:

```ts
import { importProvidersFrom } from '@angular/core';
import { TranslocoTestingModule } from '@jsverse/transloco';
import { provideTranslocoLocale } from '@jsverse/transloco-locale';

import en from '../../../../public/i18n/en.json';
import sr from '../../../../public/i18n/sr.json';
import { defaultLanguage, languages, locales } from './languages';

// Specs render with the real dictionaries, so text assertions read English by default
export function provideTranslocoTesting() {
  return [
    importProvidersFrom(
      TranslocoTestingModule.forRoot({
        langs: { en, sr },
        translocoConfig: {
          availableLangs: [...languages],
          defaultLang: defaultLanguage,
          reRenderOnLangChange: true,
        },
        preloadLangs: true,
      }),
    ),
    provideTranslocoLocale({ langToLocaleMapping: locales }),
  ];
}
```

Create `src/ecommerce-frontend/src/app/core/i18n/translate-known.spec.ts`:

```ts
import { TestBed } from '@angular/core/testing';
import { TranslocoService } from '@jsverse/transloco';

import { ApiFailure } from '../api/api-response';
import { failureMessage, translateKnown } from './translate-known';
import { provideTranslocoTesting } from './transloco-testing';

describe('translateKnown', () => {
  let transloco: TranslocoService;

  beforeEach(() => {
    TestBed.configureTestingModule({ providers: [provideTranslocoTesting()] });
    transloco = TestBed.inject(TranslocoService);
  });

  it('translates a known key in the active language', () => {
    expect(translateKnown(transloco, 'reasons.card_declined', 'raw')).toBe('The card was declined');

    transloco.setActiveLang('sr');
    expect(translateKnown(transloco, 'reasons.card_declined', 'raw')).toBe('Kartica je odbijena');
  });

  it('returns the fallback for an unknown key', () => {
    expect(translateKnown(transloco, 'reasons.something_else', 'raw')).toBe('raw');
  });

  it('maps a known API error code and keeps the server message otherwise', () => {
    const known = new ApiFailure(
      'basket.product_out_of_stock',
      'Product [x] has [0] units available',
    );
    const unknown = new ApiFailure('basket.brand_new_code', 'Something specific');

    expect(failureMessage(transloco, known)).toBe('That product is out of stock');
    expect(failureMessage(transloco, unknown)).toBe('Something specific');
  });
});
```

Create `src/ecommerce-frontend/src/app/core/language-store.spec.ts`:

```ts
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { TranslocoService } from '@jsverse/transloco';

import { provideTranslocoTesting } from './i18n/transloco-testing';
import { LanguageStore } from './language-store';

describe('LanguageStore', () => {
  let store: LanguageStore;
  let controller: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting(), provideTranslocoTesting()],
    });
    store = TestBed.inject(LanguageStore);
    controller = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    controller.verify();
    document.documentElement.lang = 'en';
  });

  it('starts in English', () => {
    expect(store.language()).toBe('en');
    expect(store.acceptLanguage()).toBe('en');
  });

  it('applies the stored preference before the first render', async () => {
    const initialized = store.initialize();
    controller
      .expectOne('/api/preferences')
      .flush({ success: true, data: { language: 'sr' }, error: null });
    await initialized;

    expect(store.language()).toBe('sr');
    expect(store.acceptLanguage()).toBe('sr-Latn');
    expect(TestBed.inject(TranslocoService).getActiveLang()).toBe('sr');
    expect(document.documentElement.lang).toBe('sr');
  });

  it('keeps English when the preference cannot be read', async () => {
    const initialized = store.initialize();
    controller
      .expectOne('/api/preferences')
      .flush(null, { status: 503, statusText: 'Service Unavailable' });
    await initialized;

    expect(store.language()).toBe('en');
    expect(document.documentElement.lang).toBe('en');
  });

  it('switches at once and stores the choice', async () => {
    const selected = store.select('sr');
    await new Promise((resolve) => setTimeout(resolve));

    expect(store.language()).toBe('sr');
    const request = controller.expectOne(
      (candidate) => candidate.method === 'PUT' && candidate.url === '/api/preferences',
    );
    expect(request.request.body).toEqual({ language: 'sr' });
    request.flush({ success: true, data: { language: 'sr' }, error: null });
    await selected;
  });

  it('does nothing when the language is already active', async () => {
    await store.select('en');

    expect(store.language()).toBe('en');
  });
});
```

Create `src/ecommerce-frontend/src/app/core/language-interceptor.spec.ts`:

```ts
import { HttpClient, provideHttpClient, withInterceptors } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';

import { provideTranslocoTesting } from './i18n/transloco-testing';
import { languageInterceptor } from './language-interceptor';

describe('languageInterceptor', () => {
  let http: HttpClient;
  let controller: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        provideHttpClient(withInterceptors([languageInterceptor])),
        provideHttpClientTesting(),
        provideTranslocoTesting(),
      ],
    });
    http = TestBed.inject(HttpClient);
    controller = TestBed.inject(HttpTestingController);
  });

  afterEach(() => controller.verify());

  it('adds the active language to API requests', () => {
    http.get('/api/basket').subscribe();

    const request = controller.expectOne('/api/basket');
    expect(request.request.headers.get('Accept-Language')).toBe('en');
    request.flush({ success: true, data: null, error: null });
  });

  it('keeps a header the caller set', () => {
    http.get('/api/catalog/products', { headers: { 'Accept-Language': 'sr-Latn' } }).subscribe();

    const request = controller.expectOne('/api/catalog/products');
    expect(request.request.headers.get('Accept-Language')).toBe('sr-Latn');
    request.flush({ success: true, data: [], error: null });
  });

  it('leaves non-API requests untouched', () => {
    http.get('/i18n/en.json').subscribe();

    const request = controller.expectOne('/i18n/en.json');
    expect(request.request.headers.has('Accept-Language')).toBe(false);
    request.flush({});
  });
});
```

Create `src/ecommerce-frontend/src/app/core/layout/language-menu.spec.ts`:

```ts
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';

import { Language } from '../i18n/languages';
import { provideTranslocoTesting } from '../i18n/transloco-testing';
import { LanguageStore } from '../language-store';
import { LanguageMenu } from './language-menu';

interface MenuOwner {
  select(language: Language): Promise<void>;
}

describe('LanguageMenu', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [LanguageMenu],
      providers: [provideHttpClient(), provideHttpClientTesting(), provideTranslocoTesting()],
    }).compileComponents();
  });

  afterEach(() => {
    TestBed.inject(HttpTestingController).verify();
    document.documentElement.lang = 'en';
  });

  it('shows the active language on the trigger', () => {
    const fixture = TestBed.createComponent(LanguageMenu);
    fixture.detectChanges();

    expect((fixture.nativeElement as HTMLElement).textContent).toContain('English');
  });

  it('selecting a language switches the store and stores the choice', async () => {
    const fixture = TestBed.createComponent(LanguageMenu);
    fixture.detectChanges();
    const controller = TestBed.inject(HttpTestingController);

    const selected = (fixture.componentInstance as unknown as MenuOwner).select('sr');
    await new Promise((resolve) => setTimeout(resolve));
    controller
      .expectOne((request) => request.method === 'PUT' && request.url === '/api/preferences')
      .flush({ success: true, data: { language: 'sr' }, error: null });
    await selected;
    fixture.detectChanges();

    expect(TestBed.inject(LanguageStore).language()).toBe('sr');
    expect((fixture.nativeElement as HTMLElement).textContent).toContain('Srpski');
  });
});
```

Replace `src/ecommerce-frontend/src/app/app.spec.ts` with:

```ts
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';

import { App } from './app';
import { provideTranslocoTesting } from './core/i18n/transloco-testing';

describe('App', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [App],
      providers: [
        provideRouter([]),
        provideHttpClient(),
        provideHttpClientTesting(),
        provideTranslocoTesting(),
      ],
    }).compileComponents();
  });

  it('renders the header, the language menu and the footer credit and loads the basket', async () => {
    const fixture = TestBed.createComponent(App);
    fixture.detectChanges();
    const controller = TestBed.inject(HttpTestingController);
    controller.expectOne('/api/basket').flush({
      success: true,
      data: { buyerId: 'b', items: [], itemCount: 0, total: 0 },
      error: null,
    });
    await fixture.whenStable();

    const text = (fixture.nativeElement as HTMLElement).textContent ?? '';
    expect(text).toContain('E-Commerce Aspire Demo');
    expect(text).toContain('English');
    expect(text).toContain('Products');
    expect(text).toContain('Basket');
    expect(text).toContain('Orders');
    expect(text).toContain('Goran Todorovic 2026 - Master');
    controller.verify();
  });
});
```

Replace `src/ecommerce-frontend/src/app/features/checkout/checkout-page.spec.ts` with:

```ts
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';

import { provideTranslocoTesting } from '../../core/i18n/transloco-testing';
import { PendingOrder } from '../../core/pending-order';
import { CheckoutRequest } from '../../shared/models/order';
import { CheckoutPage } from './checkout-page';

interface FormOwner {
  form: CheckoutPage['form'];
  toRequest(): CheckoutRequest;
  submit(): Promise<void>;
}

describe('CheckoutPage', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CheckoutPage],
      providers: [
        provideRouter([]),
        provideHttpClient(),
        provideHttpClientTesting(),
        provideTranslocoTesting(),
      ],
    }).compileComponents();
  });

  function create(): FormOwner {
    return TestBed.createComponent(CheckoutPage).componentInstance as unknown as FormOwner;
  }

  it('starts with the approving test card and an otherwise invalid form', () => {
    const page = create();

    expect(page.form.controls.cardNumber.value).toBe('4242 4242 4242 4242');
    expect(page.form.valid).toBe(false);
  });

  it('becomes valid with complete details and strips spaces from the card number', () => {
    const page = create();
    page.form.setValue({
      name: 'Goran',
      email: 'goran@example.com',
      street: 'Main Street 1',
      city: 'Belgrade',
      postalCode: '11000',
      country: 'Serbia',
      cardNumber: '4242 4242 4242 4242',
      cardHolder: 'Goran',
    });

    expect(page.form.valid).toBe(true);
    expect(page.toRequest()).toEqual({
      buyer: { name: 'Goran', email: 'goran@example.com' },
      shippingAddress: {
        street: 'Main Street 1',
        city: 'Belgrade',
        postalCode: '11000',
        country: 'Serbia',
      },
      card: { number: '4242424242424242', holderName: 'Goran' },
    });
  });

  it('rejects a card number that is not 16 digits', () => {
    const page = create();
    page.form.controls.cardNumber.setValue('1234');

    expect(page.form.controls.cardNumber.valid).toBe(false);
  });
});

describe('CheckoutPage after placing an order', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CheckoutPage],
      providers: [
        provideRouter([{ path: 'orders', component: CheckoutPage }]),
        provideHttpClient(),
        provideHttpClientTesting(),
        provideTranslocoTesting(),
      ],
    }).compileComponents();
  });

  it('remembers the placed order id for the orders page', async () => {
    const page = TestBed.createComponent(CheckoutPage).componentInstance as unknown as FormOwner;
    page.form.setValue({
      name: 'Goran',
      email: 'goran@example.com',
      street: 'Main Street 1',
      city: 'Belgrade',
      postalCode: '11000',
      country: 'Serbia',
      cardNumber: '4242 4242 4242 4242',
      cardHolder: 'Goran',
    });
    const controller = TestBed.inject(HttpTestingController);

    const submitted = page.submit();
    controller.expectOne('/api/basket/checkout').flush({
      success: true,
      data: { orderId: 'o-1', total: 12.5, currency: 'EUR' },
      error: null,
    });
    await submitted;

    expect(TestBed.inject(PendingOrder).orderId()).toBe('o-1');
    controller.verify();
  });
});
```

Replace `src/ecommerce-frontend/src/app/features/orders/orders-page.spec.ts` with:

```ts
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';

import { provideTranslocoTesting } from '../../core/i18n/transloco-testing';
import { PendingOrder } from '../../core/pending-order';
import { Order } from '../../shared/models/order';
import { OrdersPage } from './orders-page';

function order(id: string, status: Order['status']): Order {
  return {
    id,
    status,
    total: 10,
    currency: 'EUR',
    createdAt: '2026-09-12T12:00:00Z',
    paidAt: null,
    shippedAt: null,
    failureReason: null,
    cardLast4: '4242',
    buyer: { name: 'Goran', email: 'goran@example.com' },
    shippingAddress: {
      street: 'Main Street 1',
      city: 'Belgrade',
      postalCode: '11000',
      country: 'Serbia',
    },
    lines: [],
  };
}

describe('OrdersPage', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [OrdersPage],
      providers: [
        provideRouter([]),
        provideHttpClient(),
        provideHttpClientTesting(),
        provideTranslocoTesting(),
      ],
    }).compileComponents();
  });

  async function render(orders: Order[]): Promise<HTMLElement> {
    const fixture = TestBed.createComponent(OrdersPage);
    fixture.detectChanges();
    const controller = TestBed.inject(HttpTestingController);
    controller.expectOne('/api/orders').flush({ success: true, data: orders, error: null });
    await fixture.whenStable();
    fixture.detectChanges();
    controller.verify();
    return fixture.nativeElement as HTMLElement;
  }

  it('shows the waiting notice instead of the empty state while the placed order is missing', async () => {
    TestBed.inject(PendingOrder).placed('o-1');

    const element = await render([]);

    expect(element.textContent).toContain('Your order is being placed');
    expect(element.textContent).not.toContain('You have not placed any orders yet');
    expect(element.textContent).toContain('Watching for status changes');
  });

  it('forgets the placed order once the list contains it', async () => {
    const pending = TestBed.inject(PendingOrder);
    pending.placed('o-1');

    const element = await render([order('o-1', 'Shipped')]);

    expect(pending.orderId()).toBeNull();
    expect(element.textContent).not.toContain('Your order is being placed');
    expect(element.textContent).not.toContain('Watching for status changes');
  });

  it('shows the empty state when nothing is pending', async () => {
    const element = await render([]);

    expect(element.textContent).toContain('You have not placed any orders yet');
    expect(element.textContent).not.toContain('Watching for status changes');
  });
});
```

```bash
npm test
```

Expected: the run fails to build the specs because `translate-known`, `language-store`, `language-interceptor` and `language-menu` do not exist yet. Note the summary for the report.

- [ ] **Step 3: Implement**

Create `src/ecommerce-frontend/src/app/core/i18n/transloco-loader.ts`:

```ts
import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Translation, TranslocoLoader } from '@jsverse/transloco';

@Injectable({ providedIn: 'root' })
export class TranslocoHttpLoader implements TranslocoLoader {
  private readonly http = inject(HttpClient);

  getTranslation(language: string) {
    return this.http.get<Translation>(`/i18n/${language}.json`);
  }
}
```

Create `src/ecommerce-frontend/src/app/core/i18n/translate-known.ts`:

```ts
import { TranslocoService } from '@jsverse/transloco';

import { ApiFailure } from '../api/api-response';

// Translates a key only when the active dictionary has it, otherwise returns the fallback text
export function translateKnown(transloco: TranslocoService, key: string, fallback: string): string {
  const table = transloco.getTranslation(transloco.getActiveLang());
  return key in table ? transloco.translate(key) : fallback;
}

// Known API error codes read naturally in the active language; anything else shows what the server said
export function failureMessage(transloco: TranslocoService, failure: ApiFailure): string {
  return translateKnown(transloco, `errors.${failure.code}`, failure.message);
}
```

Create `src/ecommerce-frontend/src/app/shared/models/preferences.ts`:

```ts
export interface Preferences {
  language: string;
}
```

Create `src/ecommerce-frontend/src/app/core/api/preferences-api.ts`:

```ts
import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable, firstValueFrom } from 'rxjs';

import { Preferences } from '../../shared/models/preferences';
import { ApiResponse, toApiFailure, unwrap } from './api-response';

@Injectable({ providedIn: 'root' })
export class PreferencesApi {
  private readonly http = inject(HttpClient);

  get(): Promise<Preferences> {
    return this.request(this.http.get<ApiResponse<Preferences>>('/api/preferences'));
  }

  update(language: string): Promise<Preferences> {
    return this.request(this.http.put<ApiResponse<Preferences>>('/api/preferences', { language }));
  }

  private async request<T>(call: Observable<ApiResponse<T>>): Promise<T> {
    try {
      return unwrap(await firstValueFrom(call));
    } catch (error) {
      throw toApiFailure(error);
    }
  }
}
```

Create `src/ecommerce-frontend/src/app/core/language-store.ts`:

```ts
import { DOCUMENT, Injectable, computed, inject, signal } from '@angular/core';
import { TranslocoService } from '@jsverse/transloco';
import { firstValueFrom } from 'rxjs';

import { PreferencesApi } from './api/preferences-api';
import { Language, acceptLanguages, defaultLanguage, isLanguage } from './i18n/languages';

// The active language: read from the buyer's server-side preference before the first render, stored on every change
@Injectable({ providedIn: 'root' })
export class LanguageStore {
  private readonly transloco = inject(TranslocoService);
  private readonly preferences = inject(PreferencesApi);
  private readonly document = inject(DOCUMENT);
  private readonly languageState = signal<Language>(defaultLanguage);

  readonly language = this.languageState.asReadonly();
  readonly acceptLanguage = computed(() => acceptLanguages[this.languageState()]);

  async initialize(): Promise<void> {
    let language = defaultLanguage;
    try {
      const stored = await this.preferences.get();
      if (isLanguage(stored.language)) {
        language = stored.language;
      }
    } catch {
      // The shop opens even when the preference service is down; English is the default
    }
    await this.apply(language);
  }

  // The language switches at once; a failed store leaves it active for this visit and is reported by the caller
  async select(language: Language): Promise<void> {
    if (language === this.languageState()) {
      return;
    }
    await this.apply(language);
    await this.preferences.update(language);
  }

  private async apply(language: Language): Promise<void> {
    await firstValueFrom(this.transloco.load(language));
    this.transloco.setActiveLang(language);
    this.languageState.set(language);
    this.document.documentElement.lang = language;
  }
}
```

Create `src/ecommerce-frontend/src/app/core/language-interceptor.ts`:

```ts
import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';

import { LanguageStore } from './language-store';

// Every API call carries the active language unless the caller set the header itself
export const languageInterceptor: HttpInterceptorFn = (request, next) => {
  if (!request.url.startsWith('/api/') || request.headers.has('Accept-Language')) {
    return next(request);
  }
  const language = inject(LanguageStore);
  return next(request.clone({ setHeaders: { 'Accept-Language': language.acceptLanguage() } }));
};
```

Create `src/ecommerce-frontend/src/app/core/layout/language-menu.ts`:

```ts
import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatMenuModule } from '@angular/material/menu';
import { MatSnackBar } from '@angular/material/snack-bar';
import { TranslocoPipe, TranslocoService } from '@jsverse/transloco';

import { Language, languageNames, languages } from '../i18n/languages';
import { LanguageStore } from '../language-store';

@Component({
  selector: 'app-language-menu',
  imports: [MatButtonModule, MatMenuModule, TranslocoPipe],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './language-menu.html',
  styleUrl: './language-menu.scss',
})
export class LanguageMenu {
  private readonly snackBar = inject(MatSnackBar);
  private readonly transloco = inject(TranslocoService);

  protected readonly store = inject(LanguageStore);
  protected readonly languages = languages;
  protected readonly names = languageNames;

  protected async select(language: Language): Promise<void> {
    try {
      await this.store.select(language);
    } catch {
      this.snackBar.open(
        this.transloco.translate('language.saveFailed'),
        this.transloco.translate('common.dismiss'),
        { duration: 5000 },
      );
    }
  }
}
```

Create `src/ecommerce-frontend/src/app/core/layout/language-menu.html`:

```html
<button
  mat-button
  class="trigger"
  [matMenuTriggerFor]="menu"
  [attr.aria-label]="'nav.language' | transloco"
>
  {{ names[store.language()] }} <span aria-hidden="true">&#9662;</span>
</button>
<mat-menu #menu="matMenu">
  @for (language of languages; track language) {
    <button mat-menu-item (click)="select(language)" [disabled]="language === store.language()">
      {{ names[language] }}
    </button>
  }
</mat-menu>
```

Create `src/ecommerce-frontend/src/app/core/layout/language-menu.scss`:

```scss
.trigger {
  margin-inline-end: 0.5rem;
}
```

Replace `src/ecommerce-frontend/src/app/app.config.ts` with:

```ts
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import {
  ApplicationConfig,
  inject,
  isDevMode,
  provideAppInitializer,
  provideBrowserGlobalErrorListeners,
} from '@angular/core';
import { provideRouter } from '@angular/router';
import { provideTransloco } from '@jsverse/transloco';
import { provideTranslocoLocale } from '@jsverse/transloco-locale';

import { routes } from './app.routes';
import { buyerIdInterceptor } from './core/buyer-id-interceptor';
import { defaultLanguage, languages, locales } from './core/i18n/languages';
import { TranslocoHttpLoader } from './core/i18n/transloco-loader';
import { languageInterceptor } from './core/language-interceptor';
import { LanguageStore } from './core/language-store';

export const appConfig: ApplicationConfig = {
  providers: [
    provideBrowserGlobalErrorListeners(),
    provideRouter(routes),
    provideHttpClient(withInterceptors([buyerIdInterceptor, languageInterceptor])),
    provideTransloco({
      config: {
        availableLangs: [...languages],
        defaultLang: defaultLanguage,
        fallbackLang: defaultLanguage,
        reRenderOnLangChange: true,
        prodMode: !isDevMode(),
      },
      loader: TranslocoHttpLoader,
    }),
    provideTranslocoLocale({ langToLocaleMapping: locales }),
    // The buyer's language is known before the first render, so nothing flashes in English
    provideAppInitializer(() => inject(LanguageStore).initialize()),
  ],
};
```

Replace `src/ecommerce-frontend/src/app/app.ts` with:

```ts
import { ChangeDetectionStrategy, Component, effect, inject } from '@angular/core';
import { RouterOutlet } from '@angular/router';

import { BasketStore } from './core/basket-store';
import { LanguageStore } from './core/language-store';
import { SiteFooter } from './core/layout/site-footer';
import { SiteHeader } from './core/layout/site-header';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, SiteHeader, SiteFooter],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './app.html',
  styleUrl: './app.scss',
})
export class App {
  private readonly basket = inject(BasketStore);
  private readonly language = inject(LanguageStore);

  constructor() {
    // Loaded at startup and again on every language change, because line names come from Catalog in that language
    effect(() => {
      this.language.language();
      void this.basket.load();
    });
  }
}
```

Replace `src/ecommerce-frontend/src/app/core/layout/site-header.ts` with:

```ts
import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { MatBadgeModule } from '@angular/material/badge';
import { MatButtonModule } from '@angular/material/button';
import { MatToolbarModule } from '@angular/material/toolbar';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { TranslocoPipe } from '@jsverse/transloco';

import { BasketStore } from '../basket-store';
import { LanguageMenu } from './language-menu';

@Component({
  selector: 'app-site-header',
  imports: [
    MatToolbarModule,
    MatButtonModule,
    MatBadgeModule,
    RouterLink,
    RouterLinkActive,
    TranslocoPipe,
    LanguageMenu,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './site-header.html',
  styleUrl: './site-header.scss',
})
export class SiteHeader {
  protected readonly basket = inject(BasketStore);
}
```

Replace `src/ecommerce-frontend/src/app/core/layout/site-header.html` with:

```html
<mat-toolbar class="header">
  <a class="brand" routerLink="/products">E-Commerce Aspire Demo</a>
  <nav class="nav" aria-label="Main">
    <app-language-menu />
    <a mat-button routerLink="/products" routerLinkActive="active">{{
      'nav.products' | transloco
    }}</a>
    <a
      mat-button
      routerLink="/basket"
      routerLinkActive="active"
      [matBadge]="basket.count()"
      [matBadgeHidden]="basket.count() === 0"
      matBadgeSize="small"
      [attr.aria-label]="'nav.basket' | transloco"
    >
      {{ 'nav.basket' | transloco }}
    </a>
    <a mat-button routerLink="/orders" routerLinkActive="active">{{ 'nav.orders' | transloco }}</a>
  </nav>
</mat-toolbar>
```

Replace `src/ecommerce-frontend/src/app/core/api/catalog-api.ts` with:

```ts
import { httpResource } from '@angular/common/http';
import { Injectable, Injector, inject } from '@angular/core';

import { Product } from '../../shared/models/product';
import { LanguageStore } from '../language-store';
import { ApiResponse, unwrap } from './api-response';

@Injectable({ providedIn: 'root' })
export class CatalogApi {
  private readonly injector = inject(Injector);
  private readonly language = inject(LanguageStore);

  // The header is part of the request, so the list reloads when the language changes
  listProducts() {
    return httpResource<Product[]>(
      () => ({
        url: '/api/catalog/products',
        headers: { 'Accept-Language': this.language.acceptLanguage() },
      }),
      {
        injector: this.injector,
        parse: (raw) => unwrap(raw as ApiResponse<Product[]>),
      },
    );
  }
}
```

Replace `src/ecommerce-frontend/src/app/features/products/product-list.ts` with:

```ts
import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSnackBar } from '@angular/material/snack-bar';
import { TranslocoPipe, TranslocoService } from '@jsverse/transloco';
import { TranslocoCurrencyPipe } from '@jsverse/transloco-locale';

import { toApiFailure } from '../../core/api/api-response';
import { CatalogApi } from '../../core/api/catalog-api';
import { BasketStore } from '../../core/basket-store';
import { failureMessage } from '../../core/i18n/translate-known';
import { LanguageStore } from '../../core/language-store';
import { Product } from '../../shared/models/product';
import { ProductImage } from '../../shared/product-image/product-image';

@Component({
  selector: 'app-product-list',
  imports: [
    MatCardModule,
    MatButtonModule,
    MatProgressBarModule,
    ProductImage,
    TranslocoPipe,
    TranslocoCurrencyPipe,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './product-list.html',
  styleUrl: './product-list.scss',
})
export class ProductList {
  private readonly catalog = inject(CatalogApi);
  private readonly snackBar = inject(MatSnackBar);
  private readonly transloco = inject(TranslocoService);
  private readonly language = inject(LanguageStore);

  protected readonly basket = inject(BasketStore);
  protected readonly products = this.catalog.listProducts();
  protected readonly failure = computed(() => {
    const error = this.products.error();
    return error ? toApiFailure(error) : null;
  });
  // Reads the language so the text follows a switch
  protected readonly failureText = computed(() => {
    this.language.language();
    const failure = this.failure();
    return failure ? failureMessage(this.transloco, failure) : null;
  });

  protected reload(): void {
    this.products.reload();
  }

  protected async add(product: Product): Promise<void> {
    try {
      const result = await this.basket.add(product.id);
      const message = result.capped
        ? this.transloco.translate('products.capped', {
            count: result.appliedQuantity,
            name: product.name,
          })
        : this.transloco.translate('products.added', { name: product.name });
      this.snackBar.open(message, undefined, { duration: 3000 });
    } catch (error) {
      this.snackBar.open(
        failureMessage(this.transloco, toApiFailure(error)),
        this.transloco.translate('common.dismiss'),
        { duration: 5000 },
      );
    }
  }
}
```

Replace `src/ecommerce-frontend/src/app/features/products/product-list.html` with:

```html
<h1 class="title">{{ 'products.title' | transloco }}</h1>

@if (products.isLoading()) {
  <mat-progress-bar mode="indeterminate" [attr.aria-label]="'products.loading' | transloco" />
}

@if (failure(); as failure) {
  <mat-card class="notice" appearance="outlined">
    <mat-card-content>
      <p>{{ failureText() }}</p>
      <p class="code">[{{ failure.code }}]</p>
    </mat-card-content>
    <mat-card-actions>
      <button mat-button (click)="reload()">{{ 'common.retry' | transloco }}</button>
    </mat-card-actions>
  </mat-card>
} @else if (products.value(); as items) {
  <div class="grid">
    @for (product of items; track product.id) {
      <mat-card
        class="product"
        [class.sold-out]="product.availableStock === 0"
        appearance="outlined"
      >
        <app-product-image [imageKey]="product.imageKey" [name]="product.name" />
        <mat-card-header>
          <mat-card-title>{{ product.name }}</mat-card-title>
          <mat-card-subtitle>{{ product.category }}</mat-card-subtitle>
        </mat-card-header>
        <mat-card-content>
          <p class="description">{{ product.description }}</p>
          <p class="price">{{ product.price | translocoCurrency: 'symbol' : {} : 'EUR' }}</p>
          @if (product.availableStock > 0) {
            <p class="stock">
              {{ 'products.inStock' | transloco: { count: product.availableStock } }}
            </p>
          } @else {
            <p class="stock out">{{ 'products.outOfStock' | transloco }}</p>
          }
        </mat-card-content>
        <mat-card-actions align="end">
          <button
            mat-flat-button
            (click)="add(product)"
            [disabled]="product.availableStock === 0 || basket.busy()"
          >
            {{ 'products.add' | transloco }}
          </button>
        </mat-card-actions>
      </mat-card>
    } @empty {
      <p>{{ 'products.empty' | transloco }}</p>
    }
  </div>
}
```

Replace `src/ecommerce-frontend/src/app/features/basket/basket-page.ts` with:

```ts
import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatSnackBar } from '@angular/material/snack-bar';
import { RouterLink } from '@angular/router';
import { TranslocoPipe, TranslocoService } from '@jsverse/transloco';
import { TranslocoCurrencyPipe } from '@jsverse/transloco-locale';

import { toApiFailure } from '../../core/api/api-response';
import { BasketStore } from '../../core/basket-store';
import { failureMessage } from '../../core/i18n/translate-known';
import { LanguageStore } from '../../core/language-store';
import { BasketItem } from '../../shared/models/basket';

@Component({
  selector: 'app-basket-page',
  imports: [MatCardModule, MatButtonModule, RouterLink, TranslocoPipe, TranslocoCurrencyPipe],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './basket-page.html',
  styleUrl: './basket-page.scss',
})
export class BasketPage {
  private readonly snackBar = inject(MatSnackBar);
  private readonly transloco = inject(TranslocoService);
  private readonly language = inject(LanguageStore);

  protected readonly store = inject(BasketStore);
  // Reads the language so the text follows a switch
  protected readonly failureText = computed(() => {
    this.language.language();
    const failure = this.store.failure();
    return failure ? failureMessage(this.transloco, failure) : null;
  });

  protected increase(item: BasketItem): Promise<void> {
    return this.change(item, item.quantity + 1);
  }

  protected decrease(item: BasketItem): Promise<void> {
    return item.quantity === 1 ? this.remove(item) : this.change(item, item.quantity - 1);
  }

  protected async remove(item: BasketItem): Promise<void> {
    try {
      await this.store.remove(item.productId);
      this.snackBar.open(
        this.transloco.translate('basket.removed', { name: item.productName }),
        undefined,
        { duration: 3000 },
      );
    } catch (error) {
      this.notify(error);
    }
  }

  private async change(item: BasketItem, quantity: number): Promise<void> {
    try {
      const result = await this.store.setQuantity(item.productId, quantity);
      if (result.capped) {
        this.snackBar.open(
          this.transloco.translate('basket.capped', {
            count: result.appliedQuantity,
            name: item.productName,
          }),
          undefined,
          { duration: 4000 },
        );
      }
    } catch (error) {
      this.notify(error);
    }
  }

  private notify(error: unknown): void {
    this.snackBar.open(
      failureMessage(this.transloco, toApiFailure(error)),
      this.transloco.translate('common.dismiss'),
      { duration: 5000 },
    );
  }
}
```

Replace `src/ecommerce-frontend/src/app/features/basket/basket-page.html` with:

```html
<h1 class="title">{{ 'basket.title' | transloco }}</h1>

@if (store.failure(); as failure) {
  <mat-card class="notice" appearance="outlined">
    <mat-card-content>
      <p>{{ failureText() }}</p>
      <p class="code">[{{ failure.code }}]</p>
    </mat-card-content>
    <mat-card-actions>
      <button mat-button (click)="store.load()">{{ 'common.retry' | transloco }}</button>
    </mat-card-actions>
  </mat-card>
} @else if (store.items().length === 0) {
  <mat-card class="notice" appearance="outlined">
    <mat-card-content>
      <p>{{ 'basket.empty' | transloco }}</p>
    </mat-card-content>
    <mat-card-actions>
      <a mat-flat-button routerLink="/products">{{ 'common.browse' | transloco }}</a>
    </mat-card-actions>
  </mat-card>
} @else {
  <mat-card appearance="outlined">
    <mat-card-content>
      <ul class="lines">
        @for (item of store.items(); track item.productId) {
          <li class="line">
            <div class="name">
              <span>{{ item.productName }}</span>
              <small>{{
                'basket.each'
                  | transloco
                    : { price: (item.unitPrice | translocoCurrency: 'symbol' : {} : 'EUR') }
              }}</small>
            </div>
            <div
              class="quantity"
              role="group"
              [attr.aria-label]="'basket.quantityOf' | transloco: { name: item.productName }"
            >
              <button
                mat-stroked-button
                (click)="decrease(item)"
                [disabled]="store.busy()"
                [attr.aria-label]="'basket.decrease' | transloco"
              >
                -
              </button>
              <span class="value">{{ item.quantity }}</span>
              <button
                mat-stroked-button
                (click)="increase(item)"
                [disabled]="store.busy()"
                [attr.aria-label]="'basket.increase' | transloco"
              >
                +
              </button>
            </div>
            <div class="line-total">
              {{ item.lineTotal | translocoCurrency: 'symbol' : {} : 'EUR' }}
            </div>
            <button mat-button (click)="remove(item)" [disabled]="store.busy()">
              {{ 'basket.remove' | transloco }}
            </button>
          </li>
        }
      </ul>
      <div class="summary">
        <span>{{ 'common.total' | transloco }}</span>
        <span class="total">{{ store.total() | translocoCurrency: 'symbol' : {} : 'EUR' }}</span>
      </div>
    </mat-card-content>
    <mat-card-actions align="end">
      <a mat-flat-button routerLink="/checkout" [class.disabled]="store.busy()">{{
        'basket.checkout' | transloco
      }}</a>
    </mat-card-actions>
  </mat-card>
}
```

Replace `src/ecommerce-frontend/src/app/features/checkout/checkout-page.ts` with:

```ts
import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router, RouterLink } from '@angular/router';
import { TranslocoPipe, TranslocoService } from '@jsverse/transloco';
import { TranslocoCurrencyPipe, TranslocoLocaleService } from '@jsverse/transloco-locale';

import { toApiFailure } from '../../core/api/api-response';
import { BasketStore } from '../../core/basket-store';
import { failureMessage } from '../../core/i18n/translate-known';
import { PendingOrder } from '../../core/pending-order';
import { CheckoutRequest } from '../../shared/models/order';

export const approvingTestCard = '4242 4242 4242 4242';

@Component({
  selector: 'app-checkout-page',
  imports: [
    ReactiveFormsModule,
    MatCardModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    RouterLink,
    TranslocoPipe,
    TranslocoCurrencyPipe,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './checkout-page.html',
  styleUrl: './checkout-page.scss',
})
export class CheckoutPage {
  private readonly formBuilder = inject(FormBuilder).nonNullable;
  private readonly router = inject(Router);
  private readonly snackBar = inject(MatSnackBar);
  private readonly pending = inject(PendingOrder);
  private readonly transloco = inject(TranslocoService);
  private readonly locale = inject(TranslocoLocaleService);

  protected readonly store = inject(BasketStore);
  protected readonly submitting = signal(false);

  protected readonly form = this.formBuilder.group({
    name: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(100)]],
    email: ['', [Validators.required, Validators.email, Validators.maxLength(200)]],
    street: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(200)]],
    city: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(100)]],
    postalCode: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(20)]],
    country: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(100)]],
    cardNumber: [approvingTestCard, [Validators.required, Validators.pattern(/^(\d\s*){16}$/)]],
    cardHolder: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(100)]],
  });

  protected toRequest(): CheckoutRequest {
    const value = this.form.getRawValue();
    return {
      buyer: { name: value.name.trim(), email: value.email.trim() },
      shippingAddress: {
        street: value.street.trim(),
        city: value.city.trim(),
        postalCode: value.postalCode.trim(),
        country: value.country.trim(),
      },
      card: { number: value.cardNumber.replace(/\s+/g, ''), holderName: value.cardHolder.trim() },
    };
  }

  protected async submit(): Promise<void> {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    this.submitting.set(true);
    try {
      const response = await this.store.checkout(this.toRequest());
      this.pending.placed(response.orderId);
      const total = this.locale.localizeNumber(response.total, 'currency', undefined, {
        currency: response.currency,
      });
      this.snackBar.open(this.transloco.translate('checkout.placed', { total }), undefined, {
        duration: 4000,
      });
      await this.router.navigate(['/orders']);
    } catch (error) {
      this.snackBar.open(
        failureMessage(this.transloco, toApiFailure(error)),
        this.transloco.translate('common.dismiss'),
        { duration: 6000 },
      );
    } finally {
      this.submitting.set(false);
    }
  }
}
```

Replace `src/ecommerce-frontend/src/app/features/checkout/checkout-page.html` with:

```html
<h1 class="title">{{ 'checkout.title' | transloco }}</h1>

@if (store.items().length === 0) {
  <mat-card class="notice" appearance="outlined">
    <mat-card-content>
      <p>{{ 'checkout.empty' | transloco }}</p>
    </mat-card-content>
    <mat-card-actions>
      <a mat-flat-button routerLink="/products">{{ 'common.browse' | transloco }}</a>
    </mat-card-actions>
  </mat-card>
} @else {
  <div class="layout">
    <mat-card appearance="outlined">
      <mat-card-header>
        <mat-card-title>{{ 'checkout.details' | transloco }}</mat-card-title>
      </mat-card-header>
      <mat-card-content>
        <form [formGroup]="form" (ngSubmit)="submit()" class="form">
          <mat-form-field>
            <mat-label>{{ 'checkout.name' | transloco }}</mat-label>
            <input matInput formControlName="name" autocomplete="name" />
          </mat-form-field>
          <mat-form-field>
            <mat-label>{{ 'checkout.email' | transloco }}</mat-label>
            <input matInput formControlName="email" type="email" autocomplete="email" />
          </mat-form-field>
          <mat-form-field class="wide">
            <mat-label>{{ 'checkout.street' | transloco }}</mat-label>
            <input matInput formControlName="street" autocomplete="street-address" />
          </mat-form-field>
          <mat-form-field>
            <mat-label>{{ 'checkout.city' | transloco }}</mat-label>
            <input matInput formControlName="city" autocomplete="address-level2" />
          </mat-form-field>
          <mat-form-field>
            <mat-label>{{ 'checkout.postalCode' | transloco }}</mat-label>
            <input matInput formControlName="postalCode" autocomplete="postal-code" />
          </mat-form-field>
          <mat-form-field>
            <mat-label>{{ 'checkout.country' | transloco }}</mat-label>
            <input matInput formControlName="country" autocomplete="country-name" />
          </mat-form-field>
          <mat-form-field class="wide">
            <mat-label>{{ 'checkout.cardNumber' | transloco }}</mat-label>
            <input matInput formControlName="cardNumber" inputmode="numeric" autocomplete="off" />
            <mat-hint>{{ 'checkout.cardHint' | transloco }}</mat-hint>
          </mat-form-field>
          <mat-form-field class="wide">
            <mat-label>{{ 'checkout.cardHolder' | transloco }}</mat-label>
            <input matInput formControlName="cardHolder" autocomplete="cc-name" />
          </mat-form-field>
          <div class="actions">
            <a mat-button routerLink="/basket">{{ 'checkout.back' | transloco }}</a>
            <button mat-flat-button type="submit" [disabled]="submitting() || store.busy()">
              {{ 'checkout.place' | transloco }}
            </button>
          </div>
        </form>
      </mat-card-content>
    </mat-card>

    <mat-card appearance="outlined" class="summary">
      <mat-card-header>
        <mat-card-title>{{ 'checkout.summary' | transloco }}</mat-card-title>
      </mat-card-header>
      <mat-card-content>
        <ul class="lines">
          @for (item of store.items(); track item.productId) {
            <li>
              <span>{{ item.quantity }} x {{ item.productName }}</span>
              <span>{{ item.lineTotal | translocoCurrency: 'symbol' : {} : 'EUR' }}</span>
            </li>
          }
        </ul>
        <div class="total">
          <span>{{ 'common.total' | transloco }}</span>
          <span>{{ store.total() | translocoCurrency: 'symbol' : {} : 'EUR' }}</span>
        </div>
      </mat-card-content>
    </mat-card>
  </div>
}
```

Replace `src/ecommerce-frontend/src/app/features/orders/orders-page.ts` with:

```ts
import {
  ChangeDetectionStrategy,
  Component,
  DestroyRef,
  computed,
  effect,
  inject,
} from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { RouterLink } from '@angular/router';
import { TranslocoPipe, TranslocoService } from '@jsverse/transloco';
import { TranslocoCurrencyPipe, TranslocoDatePipe } from '@jsverse/transloco-locale';

import { toApiFailure } from '../../core/api/api-response';
import { OrdersApi } from '../../core/api/orders-api';
import { failureMessage, translateKnown } from '../../core/i18n/translate-known';
import { LanguageStore } from '../../core/language-store';
import { PendingOrder } from '../../core/pending-order';
import { ordersPollIntervalMs, shouldPollOrders } from './orders-polling';

@Component({
  selector: 'app-orders-page',
  imports: [
    MatCardModule,
    MatButtonModule,
    MatProgressBarModule,
    RouterLink,
    TranslocoPipe,
    TranslocoCurrencyPipe,
    TranslocoDatePipe,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './orders-page.html',
  styleUrl: './orders-page.scss',
})
export class OrdersPage {
  private readonly api = inject(OrdersApi);
  private readonly pending = inject(PendingOrder);
  private readonly destroyRef = inject(DestroyRef);
  private readonly transloco = inject(TranslocoService);
  private readonly language = inject(LanguageStore);

  protected readonly orders = this.api.listOrders();
  protected readonly failure = computed(() => {
    const error = this.orders.error();
    return error ? toApiFailure(error) : null;
  });
  // Reads the language so the text follows a switch
  protected readonly failureText = computed(() => {
    this.language.language();
    const failure = this.failure();
    return failure ? failureMessage(this.transloco, failure) : null;
  });
  protected readonly polling = computed(() =>
    shouldPollOrders(this.orders.value(), this.pending.orderId()),
  );
  protected readonly waitingForOrder = computed(() => {
    const pendingId = this.pending.orderId();
    return pendingId !== null && !this.orders.value()?.some((order) => order.id === pendingId);
  });

  constructor() {
    // Refreshes only while an order is still moving or expected, so the dashboard is not flooded with idle requests
    const timer = setInterval(() => {
      if (this.polling() && this.orders.status() === 'resolved') {
        this.orders.reload();
      }
    }, ordersPollIntervalMs);
    this.destroyRef.onDestroy(() => clearInterval(timer));

    effect(() => {
      const pendingId = this.pending.orderId();
      if (pendingId !== null && this.orders.value()?.some((order) => order.id === pendingId)) {
        this.pending.seen(pendingId);
      }
    });
  }

  protected reload(): void {
    this.orders.reload();
  }

  // A known reason reads naturally in the active language; anything else is shown as the server sent it
  protected reason(failureReason: string): string {
    return translateKnown(this.transloco, `reasons.${failureReason}`, failureReason);
  }
}
```

Replace `src/ecommerce-frontend/src/app/features/orders/orders-page.html` with:

```html
<h1 class="title">{{ 'orders.title' | transloco }}</h1>

@if (orders.status() === 'loading') {
  <mat-progress-bar mode="indeterminate" [attr.aria-label]="'orders.loading' | transloco" />
}
@if (polling()) {
  <p class="hint">{{ 'orders.watching' | transloco }}</p>
}

@if (failure(); as failure) {
  <mat-card class="notice" appearance="outlined">
    <mat-card-content>
      <p>{{ failureText() }}</p>
      <p class="code">[{{ failure.code }}]</p>
    </mat-card-content>
    <mat-card-actions>
      <button mat-button (click)="reload()">{{ 'common.retry' | transloco }}</button>
    </mat-card-actions>
  </mat-card>
} @else if (orders.value(); as items) {
  @if (items.length === 0) {
    <mat-card class="notice" appearance="outlined">
      <mat-card-content>
        @if (waitingForOrder()) {
          <p>{{ 'orders.placing' | transloco }}</p>
        } @else {
          <p>{{ 'orders.empty' | transloco }}</p>
        }
      </mat-card-content>
      <mat-card-actions>
        <a mat-flat-button routerLink="/products">{{ 'common.browse' | transloco }}</a>
      </mat-card-actions>
    </mat-card>
  }
  <div class="list">
    @for (order of items; track order.id) {
      <mat-card appearance="outlined" class="order">
        <mat-card-header>
          <mat-card-title>{{
            'orders.order' | transloco: { id: order.id.slice(0, 8) }
          }}</mat-card-title>
          <mat-card-subtitle>{{
            order.createdAt | translocoDate: { dateStyle: 'medium', timeStyle: 'short' }
          }}</mat-card-subtitle>
          <span class="status" [class]="'status ' + order.status.toLowerCase()">{{
            'status.' + order.status | transloco
          }}</span>
        </mat-card-header>
        <mat-card-content>
          <ul class="lines">
            @for (line of order.lines; track line.productId) {
              <li>
                <span>{{ line.quantity }} x {{ line.productName }}</span>
                <span>{{
                  line.lineTotal | translocoCurrency: 'symbol' : {} : order.currency
                }}</span>
              </li>
            }
          </ul>
          <div class="footer">
            <span>{{
              'orders.cardAndCity'
                | transloco: { last4: order.cardLast4, city: order.shippingAddress.city }
            }}</span>
            <span class="total">{{
              order.total | translocoCurrency: 'symbol' : {} : order.currency
            }}</span>
          </div>
          @if (order.failureReason) {
            <p class="reason">{{ reason(order.failureReason) }}</p>
          }
        </mat-card-content>
      </mat-card>
    }
  </div>
}
```

- [ ] **Step 4: Run the checks**

```bash
npm run format
npm test
npm run lint
npm run format:check
npm run build
```

Expected: 49 tests passed across 14 files (36 before); `All files pass linting.`; `All matched files use Prettier code style!`; the build completes without a budget warning and `dist/ecommerce-frontend/browser/i18n` holds `en.json` and `sr.json`.

## Sub-phase 8.5 Acceptance

Run by the lead after every task above is reviewed.

```bash
export PATH="$PATH:$HOME/.dotnet/tools"
source "$HOME/.nvm/nvm.sh" && nvm use 24
dotnet build
dotnet test
cd src/ecommerce-frontend && npm run lint && npm test && npm run format:check && npm run build && cd ../..
AH=src/Ecommerce.AppHost/Ecommerce.AppHost.csproj
aspire start --apphost $AH --non-interactive --format Json
for r in catalog-api basket-api ordering-api payment-api preferences-api frontend gateway; do aspire wait $r --status healthy --timeout 300 --apphost $AH --non-interactive; done
G=http://localhost:5100; B="X-Buyer-Id: b0000000-0000-4000-8000-000000000091"; MUG=a0000000-0000-4000-8000-000000000001
curl -s -H "$B" $G/api/preferences                                                       # language en
curl -s -H "$B" -H "content-type: application/json" -X PUT -d '{"language":"sr"}' $G/api/preferences   # language sr
curl -s -H "Accept-Language: sr-Latn" $G/api/catalog/products/$MUG | grep -o '"name":"[^"]*"'         # Aspire keramička šolja
curl -s -H "$B" -H "content-type: application/json" -X PUT -d "{\"productId\":\"$MUG\",\"quantity\":1}" -o /dev/null $G/api/basket/items
curl -s -H "$B" -H "Accept-Language: sr-Latn" $G/api/basket | grep -o '"productName":"[^"]*"'         # Serbian line name
curl -s -H "$B" -H "Accept-Language: en" $G/api/basket | grep -o '"productName":"[^"]*"'              # English line name
FE=$(aspire describe frontend --apphost $AH --non-interactive --format Json | grep -o '"url": "http://localhost:[0-9]*"' | head -1 | cut -d'"' -f4)
curl -s -o /dev/null -w "%{http_code} %{content_type}\n" $FE/i18n/sr.json                            # 200 application/json
curl -s -o /dev/null -w "%{http_code} %{content_type}\n" $G/i18n/sr.json                             # 200 application/json
for r in catalog-api basket-api ordering-api payment-api preferences-api gateway frontend; do aspire logs $r --apphost $AH --non-interactive | sed 's/\x1b\[[0-9;]*m//g' | grep -E "warn:|fail:" | sed "s/^/$r: /"; done
aspire stop --apphost $AH --non-interactive
```

Expected: `0 Warning(s)`, 154 .NET tests, 49 frontend tests, lint, format and build clean, seven healthy, the preference round trip, Serbian and English names as commented, both dictionary URLs served, the sweep empty. Owner's browser check: open the shop, switch to Srpski in the header menu; navigation, product names, categories, descriptions, buttons, prices and the basket switch to Serbian; refresh and it stays Serbian; add to basket, check out and watch the order statuses in Serbian; switch back to English.
