# Phase 1 Catalog Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** A Catalog API that owns products in PostgreSQL through EF Core, migrates and seeds itself at startup, serves the two product endpoints in the response envelope, and runs healthy under the AppHost.

**Architecture:** One project `Ecommerce.Catalog.Api` with a `Domain` folder (the `Product` entity), an `Infrastructure` folder (DbContext, EF configuration, design-time factory, migrations, seed data, hosted initializer) and a `Features` folder with one static endpoint class per feature. Requests hit `/api/catalog/...`. The AppHost registers the project with a reference to `catalogdb` and waits for the database to be healthy. Unit tests run the endpoint handlers against SQLite in-memory through the real EF Core provider.

**Tech Stack:** Aspire.Npgsql.EntityFrameworkCore.PostgreSQL 13.5.3, EF Core 10.0.12 with Npgsql, Microsoft.EntityFrameworkCore.Sqlite 10.0.12 for tests, dotnet-ef 10.x, xUnit v3 4.0.0.

**Spec:** `docs/ARCHITECTURE.md` sections 4.2, 6, 7 and 8; `docs/CODING_GUIDELINES.md` sections 2, 3 and 5.

**Agent:** `backend-dev` for every task. No frontend work in this phase.

## Global Constraints

- Everything from `docs/plans/README.md` Global constraints and from the phase 0 plan applies.
- New packages in this phase, all MIT unless noted: `Aspire.Npgsql.EntityFrameworkCore.PostgreSQL` 13.5.3, `Microsoft.EntityFrameworkCore.Design` 10.0.12, `Microsoft.EntityFrameworkCore.Sqlite` 10.0.12 (tests only). `Npgsql.EntityFrameworkCore.PostgreSQL` (PostgreSQL license) arrives transitively. Add nothing else.
- Endpoint classes are static and do not log. Logging happens in hosted services and application classes with `ILogger<T>`.
- Every response uses the envelope. Business errors use codes from the service's `ErrorCodes` class.
- Money is `decimal`, currency is EUR.
- Product ids are the fixed GUIDs listed in task 1.3.1; do not generate new ones.

---

## Sub-phase 1.1 Project skeleton and test project

### Task 1.1.1: Catalog API project

**Files:**
- Modify: `Directory.Packages.props`
- Create: `src/Ecommerce.Catalog.Api/` from the `web` template
- Modify: `src/Ecommerce.Catalog.Api/Ecommerce.Catalog.Api.csproj`
- Modify: `src/Ecommerce.Catalog.Api/Program.cs`
- Modify: `src/Ecommerce.Catalog.Api/appsettings.json`
- Modify: `src/Ecommerce.Catalog.Api/Properties/launchSettings.json`
- Keep as generated: `src/Ecommerce.Catalog.Api/appsettings.Development.json`

**Interfaces:**
- Consumes: `AddServiceDefaults()`, `AddApiDefaults()`, `UseApiDefaults()` from phase 0.
- Produces: a running empty API on `https://localhost:7110` and `http://localhost:5110` that already returns the envelope for unmatched routes.

- [ ] **Step 1: Add the package versions**

In `Directory.Packages.props`, add a new group after the `Service defaults` group and one line to the `Tests` group:

```xml
  <ItemGroup Label="Catalog">
    <PackageVersion Include="Aspire.Npgsql.EntityFrameworkCore.PostgreSQL" Version="13.5.3" />
    <PackageVersion Include="Microsoft.EntityFrameworkCore.Design" Version="10.0.12" />
  </ItemGroup>
```

```xml
    <PackageVersion Include="Microsoft.EntityFrameworkCore.Sqlite" Version="10.0.12" />
```

- [ ] **Step 2: Scaffold and add to the solution**

```bash
dotnet new web -n Ecommerce.Catalog.Api -o src/Ecommerce.Catalog.Api
dotnet sln add src/Ecommerce.Catalog.Api
```

- [ ] **Step 3: Replace the project file**

`src/Ecommerce.Catalog.Api/Ecommerce.Catalog.Api.csproj`:

```xml
<Project Sdk="Microsoft.NET.Sdk.Web">

  <ItemGroup>
    <PackageReference Include="Aspire.Npgsql.EntityFrameworkCore.PostgreSQL" />
    <PackageReference Include="Microsoft.EntityFrameworkCore.Design">
      <PrivateAssets>all</PrivateAssets>
      <IncludeAssets>runtime; build; native; contentfiles; analyzers; buildtransitive</IncludeAssets>
    </PackageReference>
  </ItemGroup>

  <ItemGroup>
    <ProjectReference Include="../Ecommerce.ServiceDefaults/Ecommerce.ServiceDefaults.csproj" />
  </ItemGroup>

</Project>
```

- [ ] **Step 4: Replace `Program.cs` with the minimal composition root**

```csharp
using Ecommerce.ServiceDefaults.Api;

var builder = WebApplication.CreateBuilder(args);

builder.AddServiceDefaults();
builder.AddApiDefaults();
builder.Services.AddValidation();

var app = builder.Build();

app.UseApiDefaults();

app.Run();
```

- [ ] **Step 5: Replace `appsettings.json`**

```json
{
  "Logging": {
    "LogLevel": {
      "Default": "Information",
      "Microsoft.AspNetCore": "Warning"
    }
  },
  "AllowedHosts": "*"
}
```

- [ ] **Step 6: Replace `Properties/launchSettings.json` with fixed ports**

The `https` profile is first because the AppHost picks the profile matching its own, and both are fixed so the demo URL never changes.

```json
{
  "$schema": "https://json.schemastore.org/launchsettings.json",
  "profiles": {
    "https": {
      "commandName": "Project",
      "dotnetRunMessages": true,
      "launchBrowser": false,
      "applicationUrl": "https://localhost:7110;http://localhost:5110",
      "environmentVariables": {
        "ASPNETCORE_ENVIRONMENT": "Development"
      }
    },
    "http": {
      "commandName": "Project",
      "dotnetRunMessages": true,
      "launchBrowser": false,
      "applicationUrl": "http://localhost:5110",
      "environmentVariables": {
        "ASPNETCORE_ENVIRONMENT": "Development"
      }
    }
  }
}
```

- [ ] **Step 7: Build and smoke test standalone**

The API has no database yet, so it can run on its own for this check.

```bash
dotnet build
dotnet run --project src/Ecommerce.Catalog.Api --launch-profile http --no-build > /tmp/catalog-smoke.log 2>&1 &
CATALOG_PID=$!
curl -s --retry 30 --retry-delay 1 --retry-connrefused -w ' [%{http_code}]\n' http://localhost:5110/alive
curl -s -w ' [%{http_code}]\n' http://localhost:5110/api/nope
curl -s -o /dev/null -w '%{http_code}\n' http://localhost:5110/scalar/
kill $CATALOG_PID
```

Expected, in order: `Healthy [200]`; a JSON envelope with `"success":false` and `"code":"common.not_found"` and `[404]`; `200`. The build reports no warnings.

### Task 1.1.2: Catalog test project

**Files:**
- Create: `tests/Ecommerce.Catalog.Api.Tests/Ecommerce.Catalog.Api.Tests.csproj`

**Interfaces:**
- Consumes: `Ecommerce.Catalog.Api` project.
- Produces: the test project every later task in this phase adds tests to.

- [ ] **Step 1: Create the project file**

```xml
<Project Sdk="Microsoft.NET.Sdk">

  <PropertyGroup>
    <OutputType>Exe</OutputType>
    <IsPackable>false</IsPackable>
    <IsTestProject>true</IsTestProject>
  </PropertyGroup>

  <ItemGroup>
    <PackageReference Include="xunit.v3" />
    <PackageReference Include="Microsoft.EntityFrameworkCore.Sqlite" />
  </ItemGroup>

  <ItemGroup>
    <Using Include="Xunit" />
  </ItemGroup>

  <ItemGroup>
    <ProjectReference Include="../../src/Ecommerce.Catalog.Api/Ecommerce.Catalog.Api.csproj" />
  </ItemGroup>

</Project>
```

- [ ] **Step 2: Add to the solution and build**

```bash
dotnet sln add tests/Ecommerce.Catalog.Api.Tests
dotnet build
```

Expected: `Build succeeded.` with `0 Warning(s)`. The test project has no tests yet; `dotnet test` is not required for this task.

---

## Sub-phase 1.2 Domain model and persistence

### Task 1.2.1: Product entity, test-first

**Files:**
- Create: `tests/Ecommerce.Catalog.Api.Tests/Domain/ProductTests.cs`
- Create: `src/Ecommerce.Catalog.Api/Domain/Product.cs`

**Interfaces:**
- Consumes: nothing.
- Produces: `sealed class Product` in `Ecommerce.Catalog.Api.Domain` with read-only properties `Id`, `Name`, `Description`, `Category`, `Price`, `AvailableStock`, `ImageKey`, constants `NameMaxLength`, `DescriptionMaxLength`, `CategoryMaxLength`, `ImageKeyMaxLength`, and the factory `static Product Create(Guid id, string name, string description, string category, decimal price, int availableStock, string imageKey)`.

- [ ] **Step 1: Write the failing tests**

`tests/Ecommerce.Catalog.Api.Tests/Domain/ProductTests.cs`:

```csharp
using Ecommerce.Catalog.Api.Domain;

namespace Ecommerce.Catalog.Api.Tests.Domain;

public sealed class ProductTests
{
    private static readonly Guid ValidId = Guid.Parse("a0000000-0000-4000-8000-000000000001");

    [Fact]
    public void Create_WithValidValues_SetsAllProperties()
    {
        var product = Product.Create(ValidId, "Aspire Ceramic Mug", "A mug", "Drinkware", 12.50m, 25, "mug");

        Assert.Equal(ValidId, product.Id);
        Assert.Equal("Aspire Ceramic Mug", product.Name);
        Assert.Equal("A mug", product.Description);
        Assert.Equal("Drinkware", product.Category);
        Assert.Equal(12.50m, product.Price);
        Assert.Equal(25, product.AvailableStock);
        Assert.Equal("mug", product.ImageKey);
    }

    [Fact]
    public void Create_TrimsTextFields()
    {
        var product = Product.Create(ValidId, "  Mug ", " A mug ", " Drinkware ", 1m, 1, " mug ");

        Assert.Equal("Mug", product.Name);
        Assert.Equal("A mug", product.Description);
        Assert.Equal("Drinkware", product.Category);
        Assert.Equal("mug", product.ImageKey);
    }

    [Fact]
    public void Create_WithZeroStock_IsAllowed()
    {
        var product = Product.Create(ValidId, "Mug", "A mug", "Drinkware", 1m, 0, "mug");

        Assert.Equal(0, product.AvailableStock);
    }

    [Fact]
    public void Create_WithEmptyId_ThrowsArgumentException()
    {
        Assert.Throws<ArgumentException>(() => Product.Create(Guid.Empty, "Mug", "A mug", "Drinkware", 1m, 1, "mug"));
    }

    [Fact]
    public void Create_WithBlankName_ThrowsArgumentException()
    {
        Assert.Throws<ArgumentException>(() => Product.Create(ValidId, " ", "A mug", "Drinkware", 1m, 1, "mug"));
    }

    [Fact]
    public void Create_WithZeroPrice_ThrowsArgumentOutOfRangeException()
    {
        Assert.Throws<ArgumentOutOfRangeException>(() => Product.Create(ValidId, "Mug", "A mug", "Drinkware", 0m, 1, "mug"));
    }

    [Fact]
    public void Create_WithNegativeStock_ThrowsArgumentOutOfRangeException()
    {
        Assert.Throws<ArgumentOutOfRangeException>(() => Product.Create(ValidId, "Mug", "A mug", "Drinkware", 1m, -1, "mug"));
    }
}
```

- [ ] **Step 2: Run the tests and confirm they fail to compile**

```bash
dotnet test --project tests/Ecommerce.Catalog.Api.Tests
```

Expected: build errors naming `Product` as missing.

- [ ] **Step 3: Implement the entity**

`src/Ecommerce.Catalog.Api/Domain/Product.cs`:

```csharp
namespace Ecommerce.Catalog.Api.Domain;

public sealed class Product
{
    public const int NameMaxLength = 200;
    public const int DescriptionMaxLength = 2000;
    public const int CategoryMaxLength = 100;
    public const int ImageKeyMaxLength = 50;

    // EF Core materializes entities through this constructor
    private Product()
    {
    }

    private Product(Guid id, string name, string description, string category, decimal price, int availableStock, string imageKey)
    {
        Id = id;
        Name = name;
        Description = description;
        Category = category;
        Price = price;
        AvailableStock = availableStock;
        ImageKey = imageKey;
    }

    public Guid Id { get; private set; }

    public string Name { get; private set; } = string.Empty;

    public string Description { get; private set; } = string.Empty;

    public string Category { get; private set; } = string.Empty;

    public decimal Price { get; private set; }

    public int AvailableStock { get; private set; }

    public string ImageKey { get; private set; } = string.Empty;

    public static Product Create(Guid id, string name, string description, string category, decimal price, int availableStock, string imageKey)
    {
        if (id == Guid.Empty)
        {
            throw new ArgumentException("Product id must not be empty", nameof(id));
        }

        ArgumentException.ThrowIfNullOrWhiteSpace(name);
        ArgumentNullException.ThrowIfNull(description);
        ArgumentException.ThrowIfNullOrWhiteSpace(category);
        ArgumentException.ThrowIfNullOrWhiteSpace(imageKey);
        ArgumentOutOfRangeException.ThrowIfNegativeOrZero(price);
        ArgumentOutOfRangeException.ThrowIfNegative(availableStock);

        return new Product(id, name.Trim(), description.Trim(), category.Trim(), price, availableStock, imageKey.Trim());
    }
}
```

- [ ] **Step 4: Run the tests and confirm they pass**

```bash
dotnet test --project tests/Ecommerce.Catalog.Api.Tests
```

Expected: `Passed!` with 7 succeeded, no warnings.

### Task 1.2.2: CatalogDbContext, configuration, design-time factory, SQLite test fixture

**Files:**
- Create: `src/Ecommerce.Catalog.Api/Infrastructure/CatalogDbContext.cs`
- Create: `src/Ecommerce.Catalog.Api/Infrastructure/ProductConfiguration.cs`
- Create: `src/Ecommerce.Catalog.Api/Infrastructure/CatalogDbContextDesignTimeFactory.cs`
- Create: `tests/Ecommerce.Catalog.Api.Tests/SqliteCatalogDb.cs`
- Create: `tests/Ecommerce.Catalog.Api.Tests/Infrastructure/CatalogDbContextTests.cs`

**Interfaces:**
- Consumes: `Product`.
- Produces:
  - `sealed class CatalogDbContext(DbContextOptions<CatalogDbContext> options) : DbContext` with `DbSet<Product> Products`.
  - `sealed class SqliteCatalogDb : IDisposable` in the test project with a `Context` property, one fresh in-memory database per instance, schema created from the model.

- [ ] **Step 1: Write the failing test and the fixture**

`tests/Ecommerce.Catalog.Api.Tests/SqliteCatalogDb.cs`:

```csharp
using Ecommerce.Catalog.Api.Infrastructure;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;

namespace Ecommerce.Catalog.Api.Tests;

// A real EF Core provider on a private in-memory SQLite database, one per test
public sealed class SqliteCatalogDb : IDisposable
{
    private readonly SqliteConnection _connection;

    public SqliteCatalogDb()
    {
        _connection = new SqliteConnection("DataSource=:memory:");
        _connection.Open();

        var options = new DbContextOptionsBuilder<CatalogDbContext>()
            .UseSqlite(_connection)
            .Options;

        Context = new CatalogDbContext(options);
        Context.Database.EnsureCreated();
    }

    public CatalogDbContext Context { get; }

    public void Dispose()
    {
        Context.Dispose();
        _connection.Dispose();
    }
}
```

`tests/Ecommerce.Catalog.Api.Tests/Infrastructure/CatalogDbContextTests.cs`:

```csharp
using Ecommerce.Catalog.Api.Domain;
using Microsoft.EntityFrameworkCore;

namespace Ecommerce.Catalog.Api.Tests.Infrastructure;

public sealed class CatalogDbContextTests
{
    [Fact]
    public async Task SaveChanges_ThenQuery_RoundTripsProduct()
    {
        using var db = new SqliteCatalogDb();
        var id = Guid.Parse("a0000000-0000-4000-8000-000000000099");
        db.Context.Products.Add(Product.Create(id, "Aspire Ceramic Mug", "A mug", "Drinkware", 12.50m, 25, "mug"));
        await db.Context.SaveChangesAsync(TestContext.Current.CancellationToken);
        db.Context.ChangeTracker.Clear();

        var loaded = await db.Context.Products.SingleAsync(p => p.Id == id, TestContext.Current.CancellationToken);

        Assert.Equal("Aspire Ceramic Mug", loaded.Name);
        Assert.Equal("Drinkware", loaded.Category);
        Assert.Equal(12.50m, loaded.Price);
        Assert.Equal(25, loaded.AvailableStock);
        Assert.Equal("mug", loaded.ImageKey);
    }
}
```

- [ ] **Step 2: Run the tests and confirm they fail to compile**

```bash
dotnet test --project tests/Ecommerce.Catalog.Api.Tests
```

Expected: build errors naming `CatalogDbContext` as missing.

- [ ] **Step 3: Implement the DbContext and configuration**

`src/Ecommerce.Catalog.Api/Infrastructure/CatalogDbContext.cs`:

```csharp
using Ecommerce.Catalog.Api.Domain;
using Microsoft.EntityFrameworkCore;

namespace Ecommerce.Catalog.Api.Infrastructure;

public sealed class CatalogDbContext(DbContextOptions<CatalogDbContext> options) : DbContext(options)
{
    public DbSet<Product> Products => Set<Product>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(CatalogDbContext).Assembly);
    }
}
```

`src/Ecommerce.Catalog.Api/Infrastructure/ProductConfiguration.cs`:

```csharp
using Ecommerce.Catalog.Api.Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Ecommerce.Catalog.Api.Infrastructure;

public sealed class ProductConfiguration : IEntityTypeConfiguration<Product>
{
    public void Configure(EntityTypeBuilder<Product> builder)
    {
        builder.ToTable("products");

        builder.HasKey(p => p.Id);
        builder.Property(p => p.Id).ValueGeneratedNever();

        builder.Property(p => p.Name).HasMaxLength(Product.NameMaxLength).IsRequired();
        builder.Property(p => p.Description).HasMaxLength(Product.DescriptionMaxLength).IsRequired();
        builder.Property(p => p.Category).HasMaxLength(Product.CategoryMaxLength).IsRequired();
        builder.Property(p => p.Price).HasPrecision(10, 2);
        builder.Property(p => p.AvailableStock).IsRequired();
        builder.Property(p => p.ImageKey).HasMaxLength(Product.ImageKeyMaxLength).IsRequired();

        builder.HasIndex(p => p.Name);
    }
}
```

- [ ] **Step 4: Implement the design-time factory**

`dotnet ef` needs a context without the Aspire-injected connection string. The factory is used only by the tools; at run time the connection string comes from the AppHost.

`src/Ecommerce.Catalog.Api/Infrastructure/CatalogDbContextDesignTimeFactory.cs`:

```csharp
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;

namespace Ecommerce.Catalog.Api.Infrastructure;

// Used only by dotnet ef at design time; the connection string is never used to connect
public sealed class CatalogDbContextDesignTimeFactory : IDesignTimeDbContextFactory<CatalogDbContext>
{
    public CatalogDbContext CreateDbContext(string[] args)
    {
        var options = new DbContextOptionsBuilder<CatalogDbContext>()
            .UseNpgsql("Host=localhost;Database=catalogdb;Username=postgres;Password=postgres")
            .Options;

        return new CatalogDbContext(options);
    }
}
```

- [ ] **Step 5: Run the tests and confirm they pass**

```bash
dotnet test --project tests/Ecommerce.Catalog.Api.Tests
```

Expected: `Passed!` with 8 succeeded, no warnings.

### Task 1.2.3: InitialCreate migration

**Files:**
- Create: `src/Ecommerce.Catalog.Api/Infrastructure/Migrations/<timestamp>_InitialCreate.cs` (generated)
- Create: `src/Ecommerce.Catalog.Api/Infrastructure/Migrations/<timestamp>_InitialCreate.Designer.cs` (generated)
- Create: `src/Ecommerce.Catalog.Api/Infrastructure/Migrations/CatalogDbContextModelSnapshot.cs` (generated)

**Interfaces:**
- Consumes: `CatalogDbContext` and the design-time factory.
- Produces: the migration the hosted initializer applies at startup.

- [ ] **Step 1: Bring the EF tool to the package version**

```bash
dotnet tool update -g dotnet-ef
dotnet ef --version
```

Expected: version 10.0.12 or later 10.0.x. If the update fails for lack of network, continue with the installed 10.x tool; the tools print a version mismatch warning that does not affect the result.

- [ ] **Step 2: Generate the migration**

```bash
dotnet ef migrations add InitialCreate --project src/Ecommerce.Catalog.Api --output-dir Infrastructure/Migrations
ls src/Ecommerce.Catalog.Api/Infrastructure/Migrations
```

Expected: three files as listed above. Open the `_InitialCreate.cs` file and confirm it creates table `products` with columns `Id`, `Name` (max 200), `Description` (max 2000), `Category` (max 100), `Price` (`numeric(10,2)`), `AvailableStock`, `ImageKey` (max 50), and an index on `Name`. Generated migration files keep their generated style, including their `<inheritdoc />` comments; they are the one exception to the comment rules.

- [ ] **Step 3: Build and run the tests**

```bash
dotnet build
dotnet test --project tests/Ecommerce.Catalog.Api.Tests
```

Expected: no warnings, 8 tests passed.

---

## Sub-phase 1.3 Seed data and database initializer

### Task 1.3.1: Seed data, test-first

**Files:**
- Create: `tests/Ecommerce.Catalog.Api.Tests/Infrastructure/CatalogSeedDataTests.cs`
- Create: `src/Ecommerce.Catalog.Api/Infrastructure/CatalogSeedData.cs`

**Interfaces:**
- Consumes: `Product.Create`.
- Produces: `static class CatalogSeedData` with `static IReadOnlyList<Product> CreateProducts()` returning fresh instances on every call, so two DbContexts never track the same object. Ids are fixed and later phases and the frontend may rely on them.

- [ ] **Step 1: Write the failing tests**

`tests/Ecommerce.Catalog.Api.Tests/Infrastructure/CatalogSeedDataTests.cs`:

```csharp
using Ecommerce.Catalog.Api.Infrastructure;

namespace Ecommerce.Catalog.Api.Tests.Infrastructure;

public sealed class CatalogSeedDataTests
{
    [Fact]
    public void CreateProducts_ReturnsTwelveProducts()
    {
        var products = CatalogSeedData.CreateProducts();

        Assert.Equal(12, products.Count);
    }

    [Fact]
    public void CreateProducts_HaveUniqueIdsAndNames()
    {
        var products = CatalogSeedData.CreateProducts();

        Assert.Equal(products.Count, products.Select(p => p.Id).Distinct().Count());
        Assert.Equal(products.Count, products.Select(p => p.Name).Distinct(StringComparer.Ordinal).Count());
    }

    [Fact]
    public void CreateProducts_ContainsExactlyOneOutOfStockProduct()
    {
        var products = CatalogSeedData.CreateProducts();

        Assert.Single(products, p => p.AvailableStock == 0);
    }

    [Fact]
    public void CreateProducts_ContainsExactlyOneProductWithStockOfTwo()
    {
        var products = CatalogSeedData.CreateProducts();

        Assert.Single(products, p => p.AvailableStock == 2);
    }

    [Fact]
    public void CreateProducts_ReturnsFreshInstancesOnEveryCall()
    {
        var first = CatalogSeedData.CreateProducts();
        var second = CatalogSeedData.CreateProducts();

        Assert.NotSame(first[0], second[0]);
        Assert.Equal(first[0].Id, second[0].Id);
    }

    [Fact]
    public void CreateProducts_UsesTheFourAgreedCategories()
    {
        var categories = CatalogSeedData.CreateProducts().Select(p => p.Category).Distinct(StringComparer.Ordinal).Order().ToList();

        Assert.Equal(["Accessories", "Apparel", "Books", "Drinkware"], categories);
    }
}
```

- [ ] **Step 2: Run the tests and confirm they fail to compile**

```bash
dotnet test --project tests/Ecommerce.Catalog.Api.Tests
```

Expected: build errors naming `CatalogSeedData` as missing.

- [ ] **Step 3: Implement the seed data**

`src/Ecommerce.Catalog.Api/Infrastructure/CatalogSeedData.cs`:

```csharp
using Ecommerce.Catalog.Api.Domain;

namespace Ecommerce.Catalog.Api.Infrastructure;

public static class CatalogSeedData
{
    public static IReadOnlyList<Product> CreateProducts() =>
    [
        Product.Create(Guid.Parse("a0000000-0000-4000-8000-000000000001"), "Aspire Ceramic Mug", "Glossy 350 ml ceramic mug with the Aspire logo", "Drinkware", 12.50m, 25, "mug"),
        Product.Create(Guid.Parse("a0000000-0000-4000-8000-000000000002"), "Aspire Travel Tumbler", "Insulated 450 ml tumbler that keeps coffee hot through a long deploy", "Drinkware", 24.00m, 15, "tumbler"),
        Product.Create(Guid.Parse("a0000000-0000-4000-8000-000000000003"), "Aspire Water Bottle", "750 ml stainless steel bottle with a leak-proof cap", "Drinkware", 18.90m, 20, "bottle"),
        Product.Create(Guid.Parse("a0000000-0000-4000-8000-000000000004"), "Aspire Logo T-Shirt", "Soft cotton t-shirt with a small chest logo", "Apparel", 22.00m, 30, "tshirt"),
        Product.Create(Guid.Parse("a0000000-0000-4000-8000-000000000005"), "Aspire Zip Hoodie", "Heavyweight zip hoodie with an embroidered logo", "Apparel", 49.00m, 12, "hoodie"),
        Product.Create(Guid.Parse("a0000000-0000-4000-8000-000000000006"), "Aspire Limited Edition Hoodie", "Numbered launch edition hoodie, sold out", "Apparel", 59.00m, 0, "hoodie-limited"),
        Product.Create(Guid.Parse("a0000000-0000-4000-8000-000000000007"), "Aspire Dad Cap", "Unstructured cotton cap with an adjustable strap", "Apparel", 19.50m, 18, "cap"),
        Product.Create(Guid.Parse("a0000000-0000-4000-8000-000000000008"), "Aspire Sticker Pack", "Ten die-cut vinyl stickers for laptops and notebooks", "Accessories", 6.00m, 100, "stickers"),
        Product.Create(Guid.Parse("a0000000-0000-4000-8000-000000000009"), "Aspire Laptop Sleeve", "Padded sleeve for 13 to 14 inch laptops", "Accessories", 34.00m, 10, "sleeve"),
        Product.Create(Guid.Parse("a0000000-0000-4000-8000-000000000010"), "Aspire Launch Poster", "A2 poster from the launch event, only two left", "Accessories", 15.00m, 2, "poster"),
        Product.Create(Guid.Parse("a0000000-0000-4000-8000-000000000011"), "Cloud-Native .NET Handbook", "Practical guide to building distributed .NET systems", "Books", 39.00m, 8, "book"),
        Product.Create(Guid.Parse("a0000000-0000-4000-8000-000000000012"), "Distributed Tracing Field Guide", "Short guide to reading traces, spans and metrics", "Books", 29.00m, 6, "book-tracing"),
    ];
}
```

- [ ] **Step 4: Run the tests and confirm they pass**

```bash
dotnet test --project tests/Ecommerce.Catalog.Api.Tests
```

Expected: `Passed!` with 14 succeeded, no warnings.

### Task 1.3.2: CatalogDbInitializer hosted service, test-first

**Files:**
- Create: `tests/Ecommerce.Catalog.Api.Tests/Infrastructure/CatalogDbInitializerTests.cs`
- Create: `src/Ecommerce.Catalog.Api/Infrastructure/CatalogDbInitializer.cs`

**Interfaces:**
- Consumes: `CatalogDbContext`, `CatalogSeedData`.
- Produces: `sealed class CatalogDbInitializer : IHostedService` that migrates then seeds before the server starts listening, and `static Task<int> SeedAsync(CatalogDbContext db, CancellationToken cancellationToken)` returning the number of inserted products, zero when already seeded.

- [ ] **Step 1: Write the failing tests**

`tests/Ecommerce.Catalog.Api.Tests/Infrastructure/CatalogDbInitializerTests.cs`:

```csharp
using Ecommerce.Catalog.Api.Infrastructure;
using Microsoft.EntityFrameworkCore;

namespace Ecommerce.Catalog.Api.Tests.Infrastructure;

public sealed class CatalogDbInitializerTests
{
    [Fact]
    public async Task SeedAsync_OnEmptyDatabase_InsertsAllProducts()
    {
        using var db = new SqliteCatalogDb();

        var inserted = await CatalogDbInitializer.SeedAsync(db.Context, TestContext.Current.CancellationToken);

        Assert.Equal(12, inserted);
        Assert.Equal(12, await db.Context.Products.CountAsync(TestContext.Current.CancellationToken));
    }

    [Fact]
    public async Task SeedAsync_WhenAlreadySeeded_InsertsNothing()
    {
        using var db = new SqliteCatalogDb();
        await CatalogDbInitializer.SeedAsync(db.Context, TestContext.Current.CancellationToken);

        var inserted = await CatalogDbInitializer.SeedAsync(db.Context, TestContext.Current.CancellationToken);

        Assert.Equal(0, inserted);
        Assert.Equal(12, await db.Context.Products.CountAsync(TestContext.Current.CancellationToken));
    }
}
```

- [ ] **Step 2: Run the tests and confirm they fail to compile**

```bash
dotnet test --project tests/Ecommerce.Catalog.Api.Tests
```

Expected: build errors naming `CatalogDbInitializer` as missing.

- [ ] **Step 3: Implement the initializer**

The `ActivitySource` name equals the application name, which ServiceDefaults already subscribes to, so the migration shows up as a span in the dashboard.

`src/Ecommerce.Catalog.Api/Infrastructure/CatalogDbInitializer.cs`:

```csharp
using System.Diagnostics;
using Microsoft.EntityFrameworkCore;

namespace Ecommerce.Catalog.Api.Infrastructure;

// Runs before the server starts listening, so the health check only passes on a migrated and seeded database
public sealed class CatalogDbInitializer(IServiceProvider services, ILogger<CatalogDbInitializer> logger) : IHostedService
{
    private static readonly ActivitySource ActivitySource = new("Ecommerce.Catalog.Api");

    public async Task StartAsync(CancellationToken cancellationToken)
    {
        using var activity = ActivitySource.StartActivity("Initialize catalog database", ActivityKind.Client);
        await using var scope = services.CreateAsyncScope();
        var db = scope.ServiceProvider.GetRequiredService<CatalogDbContext>();

        await db.Database.MigrateAsync(cancellationToken);
        logger.LogInformation("[{Prefix}] Applied pending migrations", nameof(CatalogDbInitializer));

        var inserted = await SeedAsync(db, cancellationToken);
        if (inserted == 0)
        {
            logger.LogInformation("[{Prefix}] Catalog already seeded, skipping", nameof(CatalogDbInitializer));
            return;
        }

        logger.LogInformation("[{Prefix}] Seeded [{Count}] products", nameof(CatalogDbInitializer), inserted);
    }

    public Task StopAsync(CancellationToken cancellationToken) => Task.CompletedTask;

    public static async Task<int> SeedAsync(CatalogDbContext db, CancellationToken cancellationToken)
    {
        if (await db.Products.AnyAsync(cancellationToken))
        {
            return 0;
        }

        db.Products.AddRange(CatalogSeedData.CreateProducts());
        return await db.SaveChangesAsync(cancellationToken);
    }
}
```

- [ ] **Step 4: Run the tests and confirm they pass**

```bash
dotnet test --project tests/Ecommerce.Catalog.Api.Tests
```

Expected: `Passed!` with 16 succeeded, no warnings.

---

## Sub-phase 1.4 Product endpoints

### Task 1.4.1: ProductResponse and ErrorCodes, test-first

**Files:**
- Create: `tests/Ecommerce.Catalog.Api.Tests/Features/ProductResponseTests.cs`
- Create: `src/Ecommerce.Catalog.Api/Features/ProductResponse.cs`
- Create: `src/Ecommerce.Catalog.Api/ErrorCodes.cs`

**Interfaces:**
- Consumes: `Product`.
- Produces:
  - `sealed record ProductResponse(Guid Id, string Name, string Description, string Category, decimal Price, int AvailableStock, string ImageKey)` in `Ecommerce.Catalog.Api.Features` with `static ProductResponse From(Product product)`.
  - `static class ErrorCodes` in `Ecommerce.Catalog.Api` with `ProductNotFound = "catalog.product_not_found"`.

- [ ] **Step 1: Write the failing test**

`tests/Ecommerce.Catalog.Api.Tests/Features/ProductResponseTests.cs`:

```csharp
using Ecommerce.Catalog.Api.Domain;
using Ecommerce.Catalog.Api.Features;

namespace Ecommerce.Catalog.Api.Tests.Features;

public sealed class ProductResponseTests
{
    [Fact]
    public void From_MapsEveryField()
    {
        var id = Guid.Parse("a0000000-0000-4000-8000-000000000001");
        var product = Product.Create(id, "Aspire Ceramic Mug", "A mug", "Drinkware", 12.50m, 25, "mug");

        var response = ProductResponse.From(product);

        Assert.Equal(id, response.Id);
        Assert.Equal("Aspire Ceramic Mug", response.Name);
        Assert.Equal("A mug", response.Description);
        Assert.Equal("Drinkware", response.Category);
        Assert.Equal(12.50m, response.Price);
        Assert.Equal(25, response.AvailableStock);
        Assert.Equal("mug", response.ImageKey);
    }
}
```

- [ ] **Step 2: Run the tests and confirm they fail to compile**

```bash
dotnet test --project tests/Ecommerce.Catalog.Api.Tests
```

Expected: build errors naming `ProductResponse` as missing.

- [ ] **Step 3: Implement the response record and the error codes**

`src/Ecommerce.Catalog.Api/Features/ProductResponse.cs`:

```csharp
using Ecommerce.Catalog.Api.Domain;

namespace Ecommerce.Catalog.Api.Features;

public sealed record ProductResponse(
    Guid Id,
    string Name,
    string Description,
    string Category,
    decimal Price,
    int AvailableStock,
    string ImageKey)
{
    public static ProductResponse From(Product product) =>
        new(product.Id, product.Name, product.Description, product.Category, product.Price, product.AvailableStock, product.ImageKey);
}
```

`src/Ecommerce.Catalog.Api/ErrorCodes.cs`:

```csharp
namespace Ecommerce.Catalog.Api;

public static class ErrorCodes
{
    public const string ProductNotFound = "catalog.product_not_found";
}
```

- [ ] **Step 4: Run the tests and confirm they pass**

```bash
dotnet test --project tests/Ecommerce.Catalog.Api.Tests
```

Expected: `Passed!` with 17 succeeded, no warnings.

### Task 1.4.2: ListProducts endpoint, test-first

**Files:**
- Create: `tests/Ecommerce.Catalog.Api.Tests/Features/ListProductsEndpointTests.cs`
- Create: `src/Ecommerce.Catalog.Api/Features/ListProducts/ListProductsEndpoint.cs`

**Interfaces:**
- Consumes: `CatalogDbContext`, `ProductResponse`, `ApiResults`, `ApiResponse<T>`.
- Produces: `static class ListProductsEndpoint` with `RouteGroupBuilder MapListProducts(this RouteGroupBuilder group)` mapping `GET /products`, and `static Task<Ok<ApiResponse<IReadOnlyList<ProductResponse>>>> HandleAsync(Guid[]? ids, CatalogDbContext db, CancellationToken cancellationToken)`. The `ids` query parameter repeats, as in `?ids=<guid>&ids=<guid>`; when absent every product is returned. Results are ordered by name.

- [ ] **Step 1: Write the failing tests**

`tests/Ecommerce.Catalog.Api.Tests/Features/ListProductsEndpointTests.cs`:

```csharp
using Ecommerce.Catalog.Api.Features.ListProducts;
using Ecommerce.Catalog.Api.Infrastructure;

namespace Ecommerce.Catalog.Api.Tests.Features;

public sealed class ListProductsEndpointTests
{
    private static readonly Guid MugId = Guid.Parse("a0000000-0000-4000-8000-000000000001");
    private static readonly Guid CapId = Guid.Parse("a0000000-0000-4000-8000-000000000007");

    [Fact]
    public async Task HandleAsync_WithoutIds_ReturnsAllProductsOrderedByName()
    {
        using var db = new SqliteCatalogDb();
        await CatalogDbInitializer.SeedAsync(db.Context, TestContext.Current.CancellationToken);

        var result = await ListProductsEndpoint.HandleAsync(null, db.Context, TestContext.Current.CancellationToken);

        Assert.NotNull(result.Value);
        Assert.True(result.Value.Success);
        var products = result.Value.Data;
        Assert.NotNull(products);
        Assert.Equal(12, products.Count);
        Assert.Equal(products.OrderBy(p => p.Name, StringComparer.Ordinal).Select(p => p.Id), products.Select(p => p.Id));
    }

    [Fact]
    public async Task HandleAsync_WithIds_ReturnsOnlyMatchingProducts()
    {
        using var db = new SqliteCatalogDb();
        await CatalogDbInitializer.SeedAsync(db.Context, TestContext.Current.CancellationToken);

        var result = await ListProductsEndpoint.HandleAsync([MugId, CapId], db.Context, TestContext.Current.CancellationToken);

        var products = result.Value?.Data;
        Assert.NotNull(products);
        Assert.Equal(2, products.Count);
        Assert.Contains(products, p => p.Id == MugId);
        Assert.Contains(products, p => p.Id == CapId);
    }

    [Fact]
    public async Task HandleAsync_WithUnknownIds_ReturnsEmptyList()
    {
        using var db = new SqliteCatalogDb();
        await CatalogDbInitializer.SeedAsync(db.Context, TestContext.Current.CancellationToken);

        var result = await ListProductsEndpoint.HandleAsync([Guid.NewGuid()], db.Context, TestContext.Current.CancellationToken);

        var products = result.Value?.Data;
        Assert.NotNull(products);
        Assert.Empty(products);
    }
}
```

- [ ] **Step 2: Run the tests and confirm they fail to compile**

```bash
dotnet test --project tests/Ecommerce.Catalog.Api.Tests
```

Expected: build errors naming `ListProductsEndpoint` as missing.

- [ ] **Step 3: Implement the endpoint**

`src/Ecommerce.Catalog.Api/Features/ListProducts/ListProductsEndpoint.cs`:

```csharp
using Ecommerce.Catalog.Api.Infrastructure;
using Ecommerce.ServiceDefaults.Api;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.EntityFrameworkCore;

namespace Ecommerce.Catalog.Api.Features.ListProducts;

public static class ListProductsEndpoint
{
    public static RouteGroupBuilder MapListProducts(this RouteGroupBuilder group)
    {
        group.MapGet("/products", HandleAsync).WithName("ListProducts");
        return group;
    }

    public static async Task<Ok<ApiResponse<IReadOnlyList<ProductResponse>>>> HandleAsync(
        Guid[]? ids,
        CatalogDbContext db,
        CancellationToken cancellationToken)
    {
        var query = db.Products.AsNoTracking();
        if (ids is { Length: > 0 })
        {
            query = query.Where(p => ids.Contains(p.Id));
        }

        var products = await query.OrderBy(p => p.Name).ToListAsync(cancellationToken);
        IReadOnlyList<ProductResponse> response = products.Select(ProductResponse.From).ToList();

        return ApiResults.Ok(response);
    }
}
```

- [ ] **Step 4: Run the tests and confirm they pass**

```bash
dotnet test --project tests/Ecommerce.Catalog.Api.Tests
```

Expected: `Passed!` with 20 succeeded, no warnings.

### Task 1.4.3: GetProduct endpoint, test-first

**Files:**
- Create: `tests/Ecommerce.Catalog.Api.Tests/Features/GetProductEndpointTests.cs`
- Create: `src/Ecommerce.Catalog.Api/Features/GetProduct/GetProductEndpoint.cs`

**Interfaces:**
- Consumes: `CatalogDbContext`, `ProductResponse`, `ErrorCodes`, `ApiResults`.
- Produces: `static class GetProductEndpoint` with `RouteGroupBuilder MapGetProduct(this RouteGroupBuilder group)` mapping `GET /products/{id:guid}`, and `static Task<Results<Ok<ApiResponse<ProductResponse>>, NotFound<ApiResponse>>> HandleAsync(Guid id, CatalogDbContext db, CancellationToken cancellationToken)`.

- [ ] **Step 1: Write the failing tests**

`tests/Ecommerce.Catalog.Api.Tests/Features/GetProductEndpointTests.cs`:

```csharp
using Ecommerce.Catalog.Api.Features;
using Ecommerce.Catalog.Api.Features.GetProduct;
using Ecommerce.Catalog.Api.Infrastructure;
using Ecommerce.ServiceDefaults.Api;
using Microsoft.AspNetCore.Http.HttpResults;

namespace Ecommerce.Catalog.Api.Tests.Features;

public sealed class GetProductEndpointTests
{
    private static readonly Guid MugId = Guid.Parse("a0000000-0000-4000-8000-000000000001");

    [Fact]
    public async Task HandleAsync_WithExistingId_ReturnsProduct()
    {
        using var db = new SqliteCatalogDb();
        await CatalogDbInitializer.SeedAsync(db.Context, TestContext.Current.CancellationToken);

        var result = await GetProductEndpoint.HandleAsync(MugId, db.Context, TestContext.Current.CancellationToken);

        var ok = Assert.IsType<Ok<ApiResponse<ProductResponse>>>(result.Result);
        Assert.NotNull(ok.Value?.Data);
        Assert.Equal(MugId, ok.Value.Data.Id);
        Assert.Equal("Aspire Ceramic Mug", ok.Value.Data.Name);
    }

    [Fact]
    public async Task HandleAsync_WithUnknownId_ReturnsNotFoundEnvelope()
    {
        using var db = new SqliteCatalogDb();
        var unknownId = Guid.Parse("a0000000-0000-4000-8000-0000000000ff");

        var result = await GetProductEndpoint.HandleAsync(unknownId, db.Context, TestContext.Current.CancellationToken);

        var notFound = Assert.IsType<NotFound<ApiResponse>>(result.Result);
        Assert.NotNull(notFound.Value?.Error);
        Assert.False(notFound.Value.Success);
        Assert.Equal("catalog.product_not_found", notFound.Value.Error.Code);
        Assert.Equal($"Product [{unknownId}] not found", notFound.Value.Error.Message);
    }
}
```

- [ ] **Step 2: Run the tests and confirm they fail to compile**

```bash
dotnet test --project tests/Ecommerce.Catalog.Api.Tests
```

Expected: build errors naming `GetProductEndpoint` as missing.

- [ ] **Step 3: Implement the endpoint**

`src/Ecommerce.Catalog.Api/Features/GetProduct/GetProductEndpoint.cs`:

```csharp
using Ecommerce.Catalog.Api.Infrastructure;
using Ecommerce.ServiceDefaults.Api;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.EntityFrameworkCore;

namespace Ecommerce.Catalog.Api.Features.GetProduct;

public static class GetProductEndpoint
{
    public static RouteGroupBuilder MapGetProduct(this RouteGroupBuilder group)
    {
        group.MapGet("/products/{id:guid}", HandleAsync).WithName("GetProduct");
        return group;
    }

    public static async Task<Results<Ok<ApiResponse<ProductResponse>>, NotFound<ApiResponse>>> HandleAsync(
        Guid id,
        CatalogDbContext db,
        CancellationToken cancellationToken)
    {
        var product = await db.Products.AsNoTracking().SingleOrDefaultAsync(p => p.Id == id, cancellationToken);
        if (product is null)
        {
            return ApiResults.NotFound(ErrorCodes.ProductNotFound, $"Product [{id}] not found");
        }

        return ApiResults.Ok(ProductResponse.From(product));
    }
}
```

- [ ] **Step 4: Run the tests and confirm they pass**

```bash
dotnet test --project tests/Ecommerce.Catalog.Api.Tests
```

Expected: `Passed!` with 22 succeeded, no warnings.

### Task 1.4.4: Program.cs composition

**Files:**
- Modify: `src/Ecommerce.Catalog.Api/Program.cs`

**Interfaces:**
- Consumes: everything above, plus `AddNpgsqlDbContext<TContext>(string connectionName)` from the Aspire Npgsql EF Core integration, which registers the context, its health check, tracing, metrics and connection retries from the `catalogdb` connection string the AppHost injects.
- Produces: the finished Catalog service. It cannot run standalone any more because the connection string only exists under the AppHost.

- [ ] **Step 1: Replace `Program.cs`**

```csharp
using Ecommerce.Catalog.Api.Features.GetProduct;
using Ecommerce.Catalog.Api.Features.ListProducts;
using Ecommerce.Catalog.Api.Infrastructure;
using Ecommerce.ServiceDefaults.Api;

var builder = WebApplication.CreateBuilder(args);

builder.AddServiceDefaults();
builder.AddApiDefaults();
builder.Services.AddValidation();
builder.AddNpgsqlDbContext<CatalogDbContext>("catalogdb");
builder.Services.AddHostedService<CatalogDbInitializer>();

var app = builder.Build();

app.UseApiDefaults();

var catalog = app.MapGroup("/api/catalog").WithTags("Catalog");
catalog.MapListProducts();
catalog.MapGetProduct();

app.Run();
```

- [ ] **Step 2: Build and run every test**

```bash
dotnet build
dotnet test
```

Expected: no warnings; 22 ServiceDefaults tests and 22 Catalog tests pass.

---

## Sub-phase 1.5 AppHost wiring and phase acceptance

### Task 1.5.1: Register catalog-api in the AppHost

**Files:**
- Modify: `src/Ecommerce.AppHost/Ecommerce.AppHost.csproj`
- Modify: `src/Ecommerce.AppHost/AppHost.cs`

**Interfaces:**
- Consumes: the `catalogDb` resource variable from phase 0.
- Produces: the `catalog-api` resource. Phase 2 will assign it to a `catalogApi` variable for the gateway to reference.

- [ ] **Step 1: Add the project reference**

In `src/Ecommerce.AppHost/Ecommerce.AppHost.csproj`, add after the package item group:

```xml
  <ItemGroup>
    <ProjectReference Include="../Ecommerce.Catalog.Api/Ecommerce.Catalog.Api.csproj" />
  </ItemGroup>
```

- [ ] **Step 2: Register the project**

In `src/Ecommerce.AppHost/AppHost.cs`, insert before `builder.Build().Run();`:

```csharp
builder.AddProject<Projects.Ecommerce_Catalog_Api>("catalog-api")
    .WithReference(catalogDb)
    .WaitFor(catalogDb)
    .WithHttpHealthCheck("/health");
```

`WithHttpHealthCheck` is required: without it Aspire reports the project as having no
health checks, the dashboard never shows the healthy mark, and a later `WaitFor` on
`catalog-api` would only wait for the process to start, not for the database to be
migrated and seeded.

- [ ] **Step 3: Build**

```bash
dotnet build
```

Expected: `Build succeeded.` with `0 Warning(s)`. The `Projects.Ecommerce_Catalog_Api` type is generated by the AppHost SDK from the project reference.

### Task 1.5.2: Phase acceptance

Run by the lead after every task above is reviewed and ticked.

- [ ] **Step 1: Clean build and full test run**

```bash
dotnet build
dotnet test
```

Expected: `0 Warning(s)`, 44 tests passed.

- [ ] **Step 2: Start the AppHost**

```bash
export PATH="$PATH:$HOME/.dotnet/tools"
aspire run --apphost src/Ecommerce.AppHost/Ecommerce.AppHost.csproj
```

Before the first interactive run, trust the Aspire developer certificate once with
`aspire certs trust`; macOS asks for authorization and the prompt must be approved.
Without that trust the HTTPS endpoints fail certificate validation in curl and the
browser. The lead's non-interactive equivalent of this acceptance is
`aspire start --non-interactive`, `aspire wait catalog-api --status healthy`,
`aspire describe`, `aspire logs catalog-api --search CatalogDbInitializer`, the curl
checks below over `http://localhost:5110` instead of the HTTPS port, and `aspire stop`,
all with `--apphost src/Ecommerce.AppHost/Ecommerce.AppHost.csproj`.

- [ ] **Step 3: Check the dashboard**

Resources: `catalog-api` shows Waiting until `catalogdb` is healthy, then Running with a healthy check mark. Its endpoints list `https://localhost:7110`. Structured logs filtered to `catalog-api` contain `[CatalogDbInitializer] Applied pending migrations` and `[CatalogDbInitializer] Seeded [12] products`. Traces contain a trace whose root span is `Initialize catalog database` with EF Core and Npgsql child spans beneath it.

One error-level log line appears on the very first run against an empty database:
`Failed executing DbCommand ... FROM "__EFMigrationsHistory"`. That is EF Core probing
the migrations history table before creating it. It is expected and does not appear on
later runs against the same database.

- [ ] **Step 4: Exercise the endpoints**

```bash
curl -s https://localhost:7110/api/catalog/products | python3 -c 'import sys,json; d=json.load(sys.stdin); print(d["success"], len(d["data"]), d["data"][0]["name"])'
# Expected: True 12 Aspire Ceramic Mug

curl -s "https://localhost:7110/api/catalog/products?ids=a0000000-0000-4000-8000-000000000001&ids=a0000000-0000-4000-8000-000000000007" | python3 -c 'import sys,json; d=json.load(sys.stdin); print([p["name"] for p in d["data"]])'
# Expected: ['Aspire Ceramic Mug', 'Aspire Dad Cap']

curl -s -w ' [%{http_code}]\n' https://localhost:7110/api/catalog/products/a0000000-0000-4000-8000-000000000006
# Expected: envelope with "availableStock":0 and [200]

curl -s -w ' [%{http_code}]\n' https://localhost:7110/api/catalog/products/a0000000-0000-4000-8000-0000000000ff
# Expected: envelope with "code":"catalog.product_not_found" and [404]

curl -s -w ' [%{http_code}]\n' https://localhost:7110/api/catalog/products/not-a-guid
# Expected: envelope with "code":"common.not_found" and [404], because the route constraint does not match

curl -s -w ' [%{http_code}]\n' https://localhost:7110/health
# Expected: Healthy [200]

curl -s -o /dev/null -w '%{http_code}\n' https://localhost:7110/scalar/
# Expected: 200
```

If curl rejects the certificate, the Aspire developer certificate trust prompt from step 2 was declined; stop the AppHost, start it again and approve the prompt rather than adding `-k`.

- [ ] **Step 5: Restart and confirm idempotent seeding**

In the dashboard, restart `catalog-api` from its resource actions. Its logs now contain `[CatalogDbInitializer] Catalog already seeded, skipping` and the product count is still 12.

- [ ] **Step 6: Stop and record**

Press Ctrl+C. The lead ticks phase 1 in `STATUS.md`, writes the phase entry in `SUMMARY.md`, and waits for the owner's review before writing the phase 2 plan.
