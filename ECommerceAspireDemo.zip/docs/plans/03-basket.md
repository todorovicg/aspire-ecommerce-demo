# Phase 3 Basket Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** A working shopping basket. The Basket service keeps one basket per buyer in Redis, validates every line against the Catalog through a discovered, resilient HttpClient, and exposes get, upsert and remove endpoints; the gateway routes to it; the frontend shows the basket count in the header, adds products from the products page with feedback, and offers a basket page with quantity controls and removal.

**Architecture:** `Ecommerce.Basket.Api` has a `Domain` folder (`ShoppingBasket`, `BasketItem`, `BuyerId`), an `Infrastructure` folder (`IBasketStore` with `RedisBasketStore`, `ICatalogClient` with `CatalogClient` and `CatalogUnavailableException`), and a `Features` folder with `BasketService` holding the rules, `BasketResponse`, a `BuyerIdFilter` on the route group and one static endpoint class per feature. The buyer comes from the `X-Buyer-Id` header, bound through `BuyerId.BindAsync` and rejected once by the filter. Transport failures toward the Catalog are translated into a single domain exception by the client so the service maps them to a 503 envelope. The frontend adds `BasketApi`, a signal-based `BasketStore` that always holds the server's copy, a badge in the header, a basket page, and the add action on the products page with snack bar feedback.

**Tech Stack:** Aspire.StackExchange.Redis 13.5.3 (StackExchange.Redis 2.x, MIT), Polly exception types already present through Microsoft.Extensions.Http.Resilience, Angular Material badge and snack bar (already installed).

**Spec:** `docs/ARCHITECTURE.md` sections 4.1, 4.3, 4.7 and 6; `docs/CODING_GUIDELINES.md` sections 2, 3, 5 and 6.

**Agents and ordering:** `backend-dev` runs sub-phases 3.1 and 3.2, `frontend-dev` runs sub-phase 3.3. They run in parallel with no dependency between them; the frontend tests mock every HTTP call. Sub-phase 3.4 is the lead's acceptance and needs both halves.

## Global Constraints

- Everything from `docs/plans/README.md` Global constraints applies.
- New NuGet package in this phase: `Aspire.StackExchange.Redis` 13.5.3 (MIT). No new npm packages. Add nothing else.
- The aggregate is named `ShoppingBasket`, not `Basket`: inside the `Ecommerce.Basket.Api` namespaces the identifier `Basket` resolves to the namespace segment and would not compile as a type.
- Endpoint classes are static and do not log; `BasketService` logs with `ILogger<BasketService>` in the `[{Prefix}]` format.
- Every response uses the envelope. Business errors use `ErrorCodes` from the service; header problems use `CommonErrorCodes.BuyerIdInvalid`.
- Frontend commands run inside `src/ecommerce-frontend` after `source "$HOME/.nvm/nvm.sh" && nvm use`, and every frontend task ends with `npm test`, `npm run build`, `npm run lint` and `npm run format:check` passing.
- The basket page has no checkout button yet; checkout arrives in phase 4.

---

## Sub-phase 3.1 Basket domain, store and Catalog client (backend-dev)

### Task 3.1.1: Basket API project and test project

**Files:**
- Modify: `Directory.Packages.props`
- Create: `src/Ecommerce.Basket.Api/Ecommerce.Basket.Api.csproj`
- Create: `src/Ecommerce.Basket.Api/Program.cs` (intermediate version, replaced in task 3.2.2)
- Create: `src/Ecommerce.Basket.Api/appsettings.json`
- Create: `src/Ecommerce.Basket.Api/appsettings.Development.json`
- Create: `src/Ecommerce.Basket.Api/Properties/launchSettings.json`
- Create: `src/Ecommerce.Basket.Api/ErrorCodes.cs`
- Create: `tests/Ecommerce.Basket.Api.Tests/Ecommerce.Basket.Api.Tests.csproj`

**Interfaces:**
- Consumes: `AddServiceDefaults()`, `AddApiDefaults()`, `UseApiDefaults()`.
- Produces: an empty Basket API on `https://localhost:7120` and `http://localhost:5120`, the `ErrorCodes` constants `ProductNotFound = "basket.product_not_found"`, `ProductOutOfStock = "basket.product_out_of_stock"`, `CatalogUnavailable = "basket.catalog_unavailable"`, and the test project every later task adds tests to.

- [ ] **Step 1: Add the package version**

In `Directory.Packages.props`, add a new group directly before the `Catalog` group:

```xml
  <ItemGroup Label="Basket">
    <PackageVersion Include="Aspire.StackExchange.Redis" Version="13.5.3" />
  </ItemGroup>
```

- [ ] **Step 2: Create the project files by hand**

Create the folders `src/Ecommerce.Basket.Api`, `src/Ecommerce.Basket.Api/Properties` and `tests/Ecommerce.Basket.Api.Tests`.

`src/Ecommerce.Basket.Api/Ecommerce.Basket.Api.csproj`:

```xml
<Project Sdk="Microsoft.NET.Sdk.Web">

  <ItemGroup>
    <PackageReference Include="Aspire.StackExchange.Redis" />
  </ItemGroup>

  <ItemGroup>
    <ProjectReference Include="../Ecommerce.ServiceDefaults/Ecommerce.ServiceDefaults.csproj" />
  </ItemGroup>

</Project>
```

`src/Ecommerce.Basket.Api/Program.cs`, the intermediate composition root:

```csharp
using Ecommerce.ServiceDefaults.Api;

var builder = WebApplication.CreateBuilder(args);

builder.AddServiceDefaults();
builder.AddApiDefaults();
builder.Services.AddValidation();

var app = builder.Build();

app.UseApiDefaults();

app.Run();
```

`src/Ecommerce.Basket.Api/appsettings.json`:

```json
{
  "Logging": {
    "LogLevel": {
      "Default": "Information",
      "Microsoft.AspNetCore": "Warning"
    }
  },
  "AllowedHosts": "*"
}
```

`src/Ecommerce.Basket.Api/appsettings.Development.json`:

```json
{
  "Logging": {
    "LogLevel": {
      "Default": "Information",
      "Microsoft.AspNetCore": "Warning"
    }
  }
}
```

`src/Ecommerce.Basket.Api/Properties/launchSettings.json`:

```json
{
  "$schema": "https://json.schemastore.org/launchsettings.json",
  "profiles": {
    "https": {
      "commandName": "Project",
      "dotnetRunMessages": true,
      "launchBrowser": false,
      "applicationUrl": "https://localhost:7120;http://localhost:5120",
      "environmentVariables": {
        "ASPNETCORE_ENVIRONMENT": "Development"
      }
    },
    "http": {
      "commandName": "Project",
      "dotnetRunMessages": true,
      "launchBrowser": false,
      "applicationUrl": "http://localhost:5120",
      "environmentVariables": {
        "ASPNETCORE_ENVIRONMENT": "Development"
      }
    }
  }
}
```

`src/Ecommerce.Basket.Api/ErrorCodes.cs`:

```csharp
namespace Ecommerce.Basket.Api;

public static class ErrorCodes
{
    public const string ProductNotFound = "basket.product_not_found";
    public const string ProductOutOfStock = "basket.product_out_of_stock";
    public const string CatalogUnavailable = "basket.catalog_unavailable";
}
```

`tests/Ecommerce.Basket.Api.Tests/Ecommerce.Basket.Api.Tests.csproj`:

```xml
<Project Sdk="Microsoft.NET.Sdk">

  <PropertyGroup>
    <OutputType>Exe</OutputType>
    <IsPackable>false</IsPackable>
    <IsTestProject>true</IsTestProject>
  </PropertyGroup>

  <ItemGroup>
    <PackageReference Include="xunit.v3" />
  </ItemGroup>

  <ItemGroup>
    <Using Include="Xunit" />
  </ItemGroup>

  <ItemGroup>
    <ProjectReference Include="../../src/Ecommerce.Basket.Api/Ecommerce.Basket.Api.csproj" />
  </ItemGroup>

</Project>
```

- [ ] **Step 3: Add both projects to the solution and build**

```bash
dotnet sln add src/Ecommerce.Basket.Api tests/Ecommerce.Basket.Api.Tests
dotnet build
```

Expected: `Build succeeded.` with `0 Warning(s)`.

- [ ] **Step 4: Smoke test standalone**

```bash
dotnet run --project src/Ecommerce.Basket.Api --launch-profile http --no-build > /tmp/basket-smoke.log 2>&1 &
BASKET_PID=$!
curl -s --retry 30 --retry-delay 1 --retry-connrefused -w ' [%{http_code}]\n' http://localhost:5120/alive
curl -s -w ' [%{http_code}]\n' http://localhost:5120/api/nope
kill $BASKET_PID
```

Expected: `Healthy [200]`, then a 404 envelope with `"code":"common.not_found"`. Confirm with `pgrep -fl Ecommerce.Basket.Api` that nothing is left running.

### Task 3.1.2: ShoppingBasket, BasketItem and BuyerId, test-first

**Files:**
- Create: `tests/Ecommerce.Basket.Api.Tests/Domain/ShoppingBasketTests.cs`
- Create: `tests/Ecommerce.Basket.Api.Tests/Domain/BuyerIdTests.cs`
- Create: `src/Ecommerce.Basket.Api/Domain/BasketItem.cs`
- Create: `src/Ecommerce.Basket.Api/Domain/ShoppingBasket.cs`
- Create: `src/Ecommerce.Basket.Api/Domain/BuyerId.cs`

**Interfaces:**
- Consumes: nothing.
- Produces, in `Ecommerce.Basket.Api.Domain`:
  - `sealed record BasketItem(Guid ProductId, string ProductName, decimal UnitPrice, int Quantity)` with `LineTotal`.
  - `sealed class ShoppingBasket` with `MaxQuantityPerLine = 99`, constructors `(Guid buyerId)` and `(Guid buyerId, IEnumerable<BasketItem> items)`, properties `BuyerId`, `Items`, `ItemCount`, `Total`, method `int UpsertItem(Guid productId, string productName, decimal unitPrice, int requestedQuantity, int availableStock)` returning the applied quantity capped at the stock and at 99, and `bool RemoveItem(Guid productId)`.
  - `sealed record BuyerId(Guid Value)` with `HeaderName = "X-Buyer-Id"`, `Invalid`, `IsValid`, and `static ValueTask<BuyerId?> BindAsync(HttpContext context)` which never fails binding: a missing, malformed or empty header yields `Invalid` so the filter in task 3.2.2 can answer 400 with the right code.

- [ ] **Step 1: Write the failing tests**

`tests/Ecommerce.Basket.Api.Tests/Domain/ShoppingBasketTests.cs`:

```csharp
using Ecommerce.Basket.Api.Domain;

namespace Ecommerce.Basket.Api.Tests.Domain;

public sealed class ShoppingBasketTests
{
    private static readonly Guid BuyerId = Guid.Parse("b0000000-0000-4000-8000-000000000001");
    private static readonly Guid MugId = Guid.Parse("a0000000-0000-4000-8000-000000000001");
    private static readonly Guid CapId = Guid.Parse("a0000000-0000-4000-8000-000000000007");

    [Fact]
    public void UpsertItem_AddsLineWithRequestedQuantity()
    {
        var basket = new ShoppingBasket(BuyerId);

        var applied = basket.UpsertItem(MugId, "Aspire Ceramic Mug", 12.50m, 2, 25);

        Assert.Equal(2, applied);
        var item = Assert.Single(basket.Items);
        Assert.Equal(MugId, item.ProductId);
        Assert.Equal(25.00m, item.LineTotal);
    }

    [Fact]
    public void UpsertItem_CapsAtAvailableStock()
    {
        var basket = new ShoppingBasket(BuyerId);

        var applied = basket.UpsertItem(MugId, "Aspire Ceramic Mug", 12.50m, 10, 3);

        Assert.Equal(3, applied);
        Assert.Equal(3, Assert.Single(basket.Items).Quantity);
    }

    [Fact]
    public void UpsertItem_CapsAtMaxQuantityPerLine()
    {
        var basket = new ShoppingBasket(BuyerId);

        var applied = basket.UpsertItem(MugId, "Aspire Ceramic Mug", 12.50m, 99, 500);

        Assert.Equal(ShoppingBasket.MaxQuantityPerLine, applied);
    }

    [Fact]
    public void UpsertItem_ReplacesExistingLineInsteadOfAdding()
    {
        var basket = new ShoppingBasket(BuyerId);
        basket.UpsertItem(MugId, "Aspire Ceramic Mug", 12.50m, 2, 25);

        basket.UpsertItem(MugId, "Aspire Ceramic Mug", 12.50m, 5, 25);

        Assert.Equal(5, Assert.Single(basket.Items).Quantity);
    }

    [Fact]
    public void ItemCountAndTotal_SumAcrossLines()
    {
        var basket = new ShoppingBasket(BuyerId);
        basket.UpsertItem(MugId, "Aspire Ceramic Mug", 12.50m, 2, 25);
        basket.UpsertItem(CapId, "Aspire Dad Cap", 19.50m, 1, 18);

        Assert.Equal(3, basket.ItemCount);
        Assert.Equal(44.50m, basket.Total);
    }

    [Fact]
    public void RemoveItem_ReturnsWhetherALineWasRemoved()
    {
        var basket = new ShoppingBasket(BuyerId);
        basket.UpsertItem(MugId, "Aspire Ceramic Mug", 12.50m, 2, 25);

        Assert.True(basket.RemoveItem(MugId));
        Assert.False(basket.RemoveItem(MugId));
        Assert.Empty(basket.Items);
    }

    [Fact]
    public void UpsertItem_WithZeroQuantity_Throws()
    {
        var basket = new ShoppingBasket(BuyerId);

        Assert.Throws<ArgumentOutOfRangeException>(() => basket.UpsertItem(MugId, "Aspire Ceramic Mug", 12.50m, 0, 25));
    }
}
```

`tests/Ecommerce.Basket.Api.Tests/Domain/BuyerIdTests.cs`:

```csharp
using Ecommerce.Basket.Api.Domain;
using Microsoft.AspNetCore.Http;

namespace Ecommerce.Basket.Api.Tests.Domain;

public sealed class BuyerIdTests
{
    [Fact]
    public async Task BindAsync_WithValidHeader_ReturnsBuyerId()
    {
        var context = new DefaultHttpContext();
        context.Request.Headers[BuyerId.HeaderName] = "b0000000-0000-4000-8000-000000000001";

        var buyerId = await BuyerId.BindAsync(context);

        Assert.NotNull(buyerId);
        Assert.True(buyerId.IsValid);
        Assert.Equal(Guid.Parse("b0000000-0000-4000-8000-000000000001"), buyerId.Value);
    }

    [Fact]
    public async Task BindAsync_WithoutHeader_ReturnsInvalid()
    {
        var buyerId = await BuyerId.BindAsync(new DefaultHttpContext());

        Assert.NotNull(buyerId);
        Assert.False(buyerId.IsValid);
    }

    [Theory]
    [InlineData("not-a-guid")]
    [InlineData("00000000-0000-0000-0000-000000000000")]
    public async Task BindAsync_WithMalformedOrEmptyHeader_ReturnsInvalid(string header)
    {
        var context = new DefaultHttpContext();
        context.Request.Headers[BuyerId.HeaderName] = header;

        var buyerId = await BuyerId.BindAsync(context);

        Assert.NotNull(buyerId);
        Assert.False(buyerId.IsValid);
    }
}
```

- [ ] **Step 2: Run the tests and confirm they fail to compile**

```bash
dotnet test --project tests/Ecommerce.Basket.Api.Tests
```

Expected: compile errors naming the `Ecommerce.Basket.Api.Domain` namespace or `ShoppingBasket` and `BuyerId` as missing.

- [ ] **Step 3: Implement the domain**

`src/Ecommerce.Basket.Api/Domain/BasketItem.cs`:

```csharp
namespace Ecommerce.Basket.Api.Domain;

public sealed record BasketItem(Guid ProductId, string ProductName, decimal UnitPrice, int Quantity)
{
    public decimal LineTotal => UnitPrice * Quantity;
}
```

`src/Ecommerce.Basket.Api/Domain/ShoppingBasket.cs`:

```csharp
namespace Ecommerce.Basket.Api.Domain;

public sealed class ShoppingBasket
{
    public const int MaxQuantityPerLine = 99;

    private readonly List<BasketItem> _items;

    public ShoppingBasket(Guid buyerId)
        : this(buyerId, [])
    {
    }

    public ShoppingBasket(Guid buyerId, IEnumerable<BasketItem> items)
    {
        BuyerId = buyerId;
        _items = [.. items];
    }

    public Guid BuyerId { get; }

    public IReadOnlyList<BasketItem> Items => _items;

    public int ItemCount => _items.Sum(item => item.Quantity);

    public decimal Total => _items.Sum(item => item.LineTotal);

    // Sets the line quantity, capped at the available stock, and returns the quantity applied
    public int UpsertItem(Guid productId, string productName, decimal unitPrice, int requestedQuantity, int availableStock)
    {
        ArgumentOutOfRangeException.ThrowIfNegativeOrZero(requestedQuantity);
        ArgumentOutOfRangeException.ThrowIfNegativeOrZero(availableStock);

        var applied = Math.Min(Math.Min(requestedQuantity, availableStock), MaxQuantityPerLine);
        var item = new BasketItem(productId, productName, unitPrice, applied);
        var index = _items.FindIndex(existing => existing.ProductId == productId);
        if (index >= 0)
        {
            _items[index] = item;
        }
        else
        {
            _items.Add(item);
        }

        return applied;
    }

    public bool RemoveItem(Guid productId) => _items.RemoveAll(item => item.ProductId == productId) > 0;
}
```

`src/Ecommerce.Basket.Api/Domain/BuyerId.cs`:

```csharp
namespace Ecommerce.Basket.Api.Domain;

// Bound from the X-Buyer-Id header; an invalid or missing header yields Invalid so BuyerIdFilter can answer 400
public sealed record BuyerId(Guid Value)
{
    public const string HeaderName = "X-Buyer-Id";

    public static readonly BuyerId Invalid = new(Guid.Empty);

    public bool IsValid => Value != Guid.Empty;

    public static ValueTask<BuyerId?> BindAsync(HttpContext context)
    {
        var header = context.Request.Headers[HeaderName].ToString();
        var buyerId = Guid.TryParse(header, out var value) && value != Guid.Empty ? new BuyerId(value) : Invalid;
        return ValueTask.FromResult<BuyerId?>(buyerId);
    }
}
```

- [ ] **Step 4: Run the tests and confirm they pass**

```bash
dotnet test --project tests/Ecommerce.Basket.Api.Tests
```

Expected: `Passed!` with 11 succeeded (7 basket tests, 4 buyer id cases), no warnings.

### Task 3.1.3: Basket store, Catalog client and test fakes

**Files:**
- Create: `src/Ecommerce.Basket.Api/Infrastructure/IBasketStore.cs`
- Create: `src/Ecommerce.Basket.Api/Infrastructure/RedisBasketStore.cs`
- Create: `src/Ecommerce.Basket.Api/Infrastructure/ICatalogClient.cs`
- Create: `src/Ecommerce.Basket.Api/Infrastructure/CatalogClient.cs`
- Create: `tests/Ecommerce.Basket.Api.Tests/Fakes/InMemoryBasketStore.cs`
- Create: `tests/Ecommerce.Basket.Api.Tests/Fakes/FakeCatalogClient.cs`

**Interfaces:**
- Consumes: `ShoppingBasket`, `BasketItem`, `ApiResponse<T>` from ServiceDefaults, `IConnectionMultiplexer` from StackExchange.Redis.
- Produces:
  - `IBasketStore` with `GetAsync(Guid buyerId, ct)` returning null when absent, `SaveAsync(ShoppingBasket, ct)` and `DeleteAsync(Guid buyerId, ct)`; `RedisBasketStore` keeps key `basket:<buyerId>` as JSON with a 7-day expiry refreshed on every save.
  - `CatalogProduct(Guid Id, string Name, decimal Price, int AvailableStock)`, `CatalogUnavailableException`, `ICatalogClient.GetProductAsync(Guid productId, ct)` returning null on 404 and throwing `CatalogUnavailableException` when the resilience handler gives up. The client wraps `HttpRequestException`, Polly's `TimeoutRejectedException` and `BrokenCircuitException`; all three occur in practice when the Catalog is down.
  - Test fakes `InMemoryBasketStore` (with `SaveCount`) and `FakeCatalogClient` (with `With(product)` and `Unavailable`).

These types have no unit tests of their own: the Redis store and the HTTP client are exercised by the phase acceptance against real Redis and Catalog, and the fakes are exercised by the service tests in task 3.2.1.

- [ ] **Step 1: Write the infrastructure**

`src/Ecommerce.Basket.Api/Infrastructure/IBasketStore.cs`:

```csharp
using Ecommerce.Basket.Api.Domain;

namespace Ecommerce.Basket.Api.Infrastructure;

public interface IBasketStore
{
    Task<ShoppingBasket?> GetAsync(Guid buyerId, CancellationToken cancellationToken);

    Task SaveAsync(ShoppingBasket basket, CancellationToken cancellationToken);

    Task DeleteAsync(Guid buyerId, CancellationToken cancellationToken);
}
```

`src/Ecommerce.Basket.Api/Infrastructure/RedisBasketStore.cs`:

```csharp
using System.Text.Json;
using Ecommerce.Basket.Api.Domain;
using StackExchange.Redis;

namespace Ecommerce.Basket.Api.Infrastructure;

public sealed class RedisBasketStore(IConnectionMultiplexer redis) : IBasketStore
{
    private static readonly TimeSpan Expiry = TimeSpan.FromDays(7);

    public async Task<ShoppingBasket?> GetAsync(Guid buyerId, CancellationToken cancellationToken)
    {
        var value = await redis.GetDatabase().StringGetAsync(KeyFor(buyerId));
        if (value.IsNullOrEmpty)
        {
            return null;
        }

        var stored = JsonSerializer.Deserialize<StoredBasket>((string)value!, JsonSerializerOptions.Web);
        return stored is null ? null : new ShoppingBasket(stored.BuyerId, stored.Items);
    }

    public Task SaveAsync(ShoppingBasket basket, CancellationToken cancellationToken)
    {
        var stored = new StoredBasket(basket.BuyerId, basket.Items);
        var json = JsonSerializer.Serialize(stored, JsonSerializerOptions.Web);
        return redis.GetDatabase().StringSetAsync(KeyFor(basket.BuyerId), json, Expiry);
    }

    public Task DeleteAsync(Guid buyerId, CancellationToken cancellationToken) =>
        redis.GetDatabase().KeyDeleteAsync(KeyFor(buyerId));

    private static string KeyFor(Guid buyerId) => $"basket:{buyerId}";

    private sealed record StoredBasket(Guid BuyerId, IReadOnlyList<BasketItem> Items);
}
```

`src/Ecommerce.Basket.Api/Infrastructure/ICatalogClient.cs`:

```csharp
namespace Ecommerce.Basket.Api.Infrastructure;

public sealed record CatalogProduct(Guid Id, string Name, decimal Price, int AvailableStock);

// Thrown when the catalog cannot be reached after the resilience handler gave up
public sealed class CatalogUnavailableException(Exception inner) : Exception("The catalog service is unavailable", inner);

public interface ICatalogClient
{
    // Returns null when the catalog has no such product; throws CatalogUnavailableException when the catalog cannot be reached
    Task<CatalogProduct?> GetProductAsync(Guid productId, CancellationToken cancellationToken);
}
```

`src/Ecommerce.Basket.Api/Infrastructure/CatalogClient.cs`:

```csharp
using System.Net;
using System.Net.Http.Json;
using Ecommerce.ServiceDefaults.Api;
using Polly.CircuitBreaker;
using Polly.Timeout;

namespace Ecommerce.Basket.Api.Infrastructure;

public sealed class CatalogClient(HttpClient httpClient) : ICatalogClient
{
    public async Task<CatalogProduct?> GetProductAsync(Guid productId, CancellationToken cancellationToken)
    {
        try
        {
            using var response = await httpClient.GetAsync($"/api/catalog/products/{productId}", cancellationToken);
            if (response.StatusCode == HttpStatusCode.NotFound)
            {
                return null;
            }

            response.EnsureSuccessStatusCode();
            var envelope = await response.Content.ReadFromJsonAsync<ApiResponse<CatalogProduct>>(cancellationToken);
            return envelope?.Data;
        }
        catch (Exception exception) when (exception is HttpRequestException or TimeoutRejectedException or BrokenCircuitException)
        {
            throw new CatalogUnavailableException(exception);
        }
    }
}
```

- [ ] **Step 2: Write the fakes**

`tests/Ecommerce.Basket.Api.Tests/Fakes/InMemoryBasketStore.cs`:

```csharp
using Ecommerce.Basket.Api.Domain;
using Ecommerce.Basket.Api.Infrastructure;

namespace Ecommerce.Basket.Api.Tests.Fakes;

public sealed class InMemoryBasketStore : IBasketStore
{
    private readonly Dictionary<Guid, ShoppingBasket> _baskets = [];

    public int SaveCount { get; private set; }

    public Task<ShoppingBasket?> GetAsync(Guid buyerId, CancellationToken cancellationToken) =>
        Task.FromResult(_baskets.TryGetValue(buyerId, out var basket) ? new ShoppingBasket(basket.BuyerId, basket.Items) : null);

    public Task SaveAsync(ShoppingBasket basket, CancellationToken cancellationToken)
    {
        _baskets[basket.BuyerId] = new ShoppingBasket(basket.BuyerId, basket.Items);
        SaveCount++;
        return Task.CompletedTask;
    }

    public Task DeleteAsync(Guid buyerId, CancellationToken cancellationToken)
    {
        _baskets.Remove(buyerId);
        return Task.CompletedTask;
    }
}
```

`tests/Ecommerce.Basket.Api.Tests/Fakes/FakeCatalogClient.cs`:

```csharp
using Ecommerce.Basket.Api.Infrastructure;

namespace Ecommerce.Basket.Api.Tests.Fakes;

public sealed class FakeCatalogClient : ICatalogClient
{
    private readonly Dictionary<Guid, CatalogProduct> _products = [];

    public bool Unavailable { get; set; }

    public FakeCatalogClient With(CatalogProduct product)
    {
        _products[product.Id] = product;
        return this;
    }

    public Task<CatalogProduct?> GetProductAsync(Guid productId, CancellationToken cancellationToken)
    {
        if (Unavailable)
        {
            throw new CatalogUnavailableException(new HttpRequestException("Catalog unreachable"));
        }

        return Task.FromResult(_products.GetValueOrDefault(productId));
    }
}
```

- [ ] **Step 3: Build and run the tests**

```bash
dotnet build
dotnet test --project tests/Ecommerce.Basket.Api.Tests
```

Expected: `0 Warning(s)`, 11 tests still passing.

---

## Sub-phase 3.2 Basket endpoints and rules (backend-dev)

### Task 3.2.1: BasketResponse and BasketService, test-first

**Files:**
- Create: `tests/Ecommerce.Basket.Api.Tests/Features/BasketServiceTests.cs`
- Create: `src/Ecommerce.Basket.Api/Features/BasketResponse.cs`
- Create: `src/Ecommerce.Basket.Api/Features/BasketService.cs`

**Interfaces:**
- Consumes: the domain, `IBasketStore`, `ICatalogClient`, the fakes.
- Produces, in `Ecommerce.Basket.Api.Features`:
  - `BasketItemResponse(ProductId, ProductName, UnitPrice, Quantity, LineTotal)` and `BasketResponse(BuyerId, Items, ItemCount, Total)` with `From(ShoppingBasket)`.
  - `UpsertItemResult` with the cases `Success(Basket, RequestedQuantity, AppliedQuantity)` exposing `Capped`, `ProductNotFound(ProductId)`, `OutOfStock(ProductId, ProductName)` and `CatalogUnavailable`.
  - `BasketService(IBasketStore, ICatalogClient, ILogger<BasketService>)` with `GetAsync(BuyerId, ct)` returning an empty basket when none is stored, `UpsertItemAsync(BuyerId, Guid productId, int quantity, ct)` and `RemoveItemAsync(BuyerId, Guid productId, ct)`. Logs one line per successful change, a warning when a quantity is capped, and a warning with the exception when the Catalog is unavailable.

- [ ] **Step 1: Write the failing tests**

`tests/Ecommerce.Basket.Api.Tests/Features/BasketServiceTests.cs`:

```csharp
using Ecommerce.Basket.Api.Domain;
using Ecommerce.Basket.Api.Features;
using Ecommerce.Basket.Api.Infrastructure;
using Ecommerce.Basket.Api.Tests.Fakes;
using Microsoft.Extensions.Logging.Abstractions;

namespace Ecommerce.Basket.Api.Tests.Features;

public sealed class BasketServiceTests
{
    private static readonly BuyerId Buyer = new(Guid.Parse("b0000000-0000-4000-8000-000000000001"));
    private static readonly CatalogProduct Mug = new(Guid.Parse("a0000000-0000-4000-8000-000000000001"), "Aspire Ceramic Mug", 12.50m, 25);
    private static readonly CatalogProduct Poster = new(Guid.Parse("a0000000-0000-4000-8000-000000000010"), "Aspire Launch Poster", 15.00m, 2);
    private static readonly CatalogProduct LimitedHoodie = new(Guid.Parse("a0000000-0000-4000-8000-000000000006"), "Aspire Limited Edition Hoodie", 59.00m, 0);

    private readonly InMemoryBasketStore _store = new();
    private readonly FakeCatalogClient _catalog = new FakeCatalogClient().With(Mug).With(Poster).With(LimitedHoodie);

    private BasketService CreateService() => new(_store, _catalog, NullLogger<BasketService>.Instance);

    [Fact]
    public async Task GetAsync_WithoutStoredBasket_ReturnsEmptyBasketForBuyer()
    {
        var basket = await CreateService().GetAsync(Buyer, TestContext.Current.CancellationToken);

        Assert.Equal(Buyer.Value, basket.BuyerId);
        Assert.Empty(basket.Items);
        Assert.Equal(0, _store.SaveCount);
    }

    [Fact]
    public async Task UpsertItemAsync_WithKnownProduct_StoresLineWithCatalogPrice()
    {
        var result = await CreateService().UpsertItemAsync(Buyer, Mug.Id, 2, TestContext.Current.CancellationToken);

        var success = Assert.IsType<UpsertItemResult.Success>(result);
        Assert.False(success.Capped);
        Assert.Equal(2, success.AppliedQuantity);
        var item = Assert.Single(success.Basket.Items);
        Assert.Equal(12.50m, item.UnitPrice);
        Assert.Equal("Aspire Ceramic Mug", item.ProductName);
        Assert.Equal(1, _store.SaveCount);
    }

    [Fact]
    public async Task UpsertItemAsync_BeyondStock_CapsAndFlags()
    {
        var result = await CreateService().UpsertItemAsync(Buyer, Poster.Id, 5, TestContext.Current.CancellationToken);

        var success = Assert.IsType<UpsertItemResult.Success>(result);
        Assert.True(success.Capped);
        Assert.Equal(5, success.RequestedQuantity);
        Assert.Equal(2, success.AppliedQuantity);
    }

    [Fact]
    public async Task UpsertItemAsync_WithUnknownProduct_ReturnsProductNotFound()
    {
        var unknown = Guid.Parse("a0000000-0000-4000-8000-0000000000ff");

        var result = await CreateService().UpsertItemAsync(Buyer, unknown, 1, TestContext.Current.CancellationToken);

        var notFound = Assert.IsType<UpsertItemResult.ProductNotFound>(result);
        Assert.Equal(unknown, notFound.ProductId);
        Assert.Equal(0, _store.SaveCount);
    }

    [Fact]
    public async Task UpsertItemAsync_WithOutOfStockProduct_ReturnsOutOfStock()
    {
        var result = await CreateService().UpsertItemAsync(Buyer, LimitedHoodie.Id, 1, TestContext.Current.CancellationToken);

        var outOfStock = Assert.IsType<UpsertItemResult.OutOfStock>(result);
        Assert.Equal("Aspire Limited Edition Hoodie", outOfStock.ProductName);
        Assert.Equal(0, _store.SaveCount);
    }

    [Fact]
    public async Task UpsertItemAsync_WhenCatalogUnavailable_ReturnsCatalogUnavailable()
    {
        _catalog.Unavailable = true;

        var result = await CreateService().UpsertItemAsync(Buyer, Mug.Id, 1, TestContext.Current.CancellationToken);

        Assert.IsType<UpsertItemResult.CatalogUnavailable>(result);
        Assert.Equal(0, _store.SaveCount);
    }

    [Fact]
    public async Task RemoveItemAsync_RemovesLineAndSaves()
    {
        var service = CreateService();
        await service.UpsertItemAsync(Buyer, Mug.Id, 2, TestContext.Current.CancellationToken);

        var basket = await service.RemoveItemAsync(Buyer, Mug.Id, TestContext.Current.CancellationToken);

        Assert.Empty(basket.Items);
        Assert.Equal(2, _store.SaveCount);
    }

    [Fact]
    public async Task RemoveItemAsync_WithUnknownLine_ReturnsBasketWithoutSaving()
    {
        var basket = await CreateService().RemoveItemAsync(Buyer, Mug.Id, TestContext.Current.CancellationToken);

        Assert.Empty(basket.Items);
        Assert.Equal(0, _store.SaveCount);
    }
}
```

- [ ] **Step 2: Run the tests and confirm they fail to compile**

```bash
dotnet test --project tests/Ecommerce.Basket.Api.Tests
```

Expected: compile errors naming the `Ecommerce.Basket.Api.Features` namespace or `BasketService` as missing.

- [ ] **Step 3: Implement**

`src/Ecommerce.Basket.Api/Features/BasketResponse.cs`:

```csharp
using Ecommerce.Basket.Api.Domain;

namespace Ecommerce.Basket.Api.Features;

public sealed record BasketItemResponse(Guid ProductId, string ProductName, decimal UnitPrice, int Quantity, decimal LineTotal);

public sealed record BasketResponse(Guid BuyerId, IReadOnlyList<BasketItemResponse> Items, int ItemCount, decimal Total)
{
    public static BasketResponse From(ShoppingBasket basket) =>
        new(
            basket.BuyerId,
            basket.Items.Select(item => new BasketItemResponse(item.ProductId, item.ProductName, item.UnitPrice, item.Quantity, item.LineTotal)).ToList(),
            basket.ItemCount,
            basket.Total);
}
```

`src/Ecommerce.Basket.Api/Features/BasketService.cs`:

```csharp
using Ecommerce.Basket.Api.Domain;
using Ecommerce.Basket.Api.Infrastructure;

namespace Ecommerce.Basket.Api.Features;

public abstract record UpsertItemResult
{
    public sealed record Success(ShoppingBasket Basket, int RequestedQuantity, int AppliedQuantity) : UpsertItemResult
    {
        public bool Capped => AppliedQuantity < RequestedQuantity;
    }

    public sealed record ProductNotFound(Guid ProductId) : UpsertItemResult;

    public sealed record OutOfStock(Guid ProductId, string ProductName) : UpsertItemResult;

    public sealed record CatalogUnavailable : UpsertItemResult;
}

public sealed class BasketService(IBasketStore store, ICatalogClient catalog, ILogger<BasketService> logger)
{
    public async Task<ShoppingBasket> GetAsync(BuyerId buyerId, CancellationToken cancellationToken) =>
        await store.GetAsync(buyerId.Value, cancellationToken) ?? new ShoppingBasket(buyerId.Value);

    public async Task<UpsertItemResult> UpsertItemAsync(BuyerId buyerId, Guid productId, int quantity, CancellationToken cancellationToken)
    {
        CatalogProduct? product;
        try
        {
            product = await catalog.GetProductAsync(productId, cancellationToken);
        }
        catch (CatalogUnavailableException exception)
        {
            logger.LogWarning(exception, "[{Prefix}] Catalog unavailable while adding product [{ProductId}] for buyer [{BuyerId}]", nameof(BasketService), productId, buyerId.Value);
            return new UpsertItemResult.CatalogUnavailable();
        }

        if (product is null)
        {
            return new UpsertItemResult.ProductNotFound(productId);
        }

        if (product.AvailableStock == 0)
        {
            return new UpsertItemResult.OutOfStock(product.Id, product.Name);
        }

        var basket = await GetAsync(buyerId, cancellationToken);
        var applied = basket.UpsertItem(product.Id, product.Name, product.Price, quantity, product.AvailableStock);
        await store.SaveAsync(basket, cancellationToken);

        if (applied < quantity)
        {
            logger.LogWarning("[{Prefix}] Capped product [{ProductId}] at [{Applied}] of requested [{Requested}] for buyer [{BuyerId}]", nameof(BasketService), product.Id, applied, quantity, buyerId.Value);
        }
        else
        {
            logger.LogInformation("[{Prefix}] Set product [{ProductId}] quantity [{Quantity}] for buyer [{BuyerId}]", nameof(BasketService), product.Id, applied, buyerId.Value);
        }

        return new UpsertItemResult.Success(basket, quantity, applied);
    }

    public async Task<ShoppingBasket> RemoveItemAsync(BuyerId buyerId, Guid productId, CancellationToken cancellationToken)
    {
        var basket = await GetAsync(buyerId, cancellationToken);
        if (basket.RemoveItem(productId))
        {
            await store.SaveAsync(basket, cancellationToken);
            logger.LogInformation("[{Prefix}] Removed product [{ProductId}] for buyer [{BuyerId}]", nameof(BasketService), productId, buyerId.Value);
        }

        return basket;
    }
}
```

- [ ] **Step 4: Run the tests and confirm they pass**

```bash
dotnet test --project tests/Ecommerce.Basket.Api.Tests
```

Expected: `Passed!` with 19 succeeded, no warnings.

### Task 3.2.2: BuyerIdFilter, the three endpoints and the composition root, test-first

**Files:**
- Create: `tests/Ecommerce.Basket.Api.Tests/Features/BuyerIdFilterTests.cs`
- Create: `tests/Ecommerce.Basket.Api.Tests/Features/UpsertItemEndpointTests.cs`
- Create: `src/Ecommerce.Basket.Api/Features/BuyerIdFilter.cs`
- Create: `src/Ecommerce.Basket.Api/Features/GetBasket/GetBasketEndpoint.cs`
- Create: `src/Ecommerce.Basket.Api/Features/UpsertItem/UpsertItemEndpoint.cs`
- Create: `src/Ecommerce.Basket.Api/Features/RemoveItem/RemoveItemEndpoint.cs`
- Modify: `src/Ecommerce.Basket.Api/Program.cs`

**Interfaces:**
- Consumes: `BasketService`, `ApiResults`, `CommonErrorCodes`.
- Produces:
  - `BuyerIdFilter : IEndpointFilter` returning the 400 envelope `common.buyer_id_invalid` when the bound `BuyerId` argument is invalid.
  - `GET /api/basket` returning `BasketResponse`; `PUT /api/basket/items` with body `UpsertItemRequest(Guid ProductId, int Quantity)` where quantity is validated to 1..99, returning `UpsertItemResponse(Basket, RequestedQuantity, AppliedQuantity, Capped)` or the 404, 409 and 503 envelopes; `DELETE /api/basket/items/{productId}` returning the updated `BasketResponse` even when the line did not exist.
  - The final `Program.cs` registering the Redis client for `basket-cache`, the store, the typed `CatalogClient` with base address `https+http://catalog-api`, `BasketService`, and the route group with the filter.

- [ ] **Step 1: Write the failing tests**

`tests/Ecommerce.Basket.Api.Tests/Features/BuyerIdFilterTests.cs`:

```csharp
using Ecommerce.Basket.Api.Domain;
using Ecommerce.Basket.Api.Features;
using Ecommerce.ServiceDefaults.Api;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;

namespace Ecommerce.Basket.Api.Tests.Features;

public sealed class BuyerIdFilterTests
{
    [Fact]
    public async Task InvokeAsync_WithInvalidBuyerId_ReturnsBadRequestEnvelope()
    {
        var context = new DefaultEndpointFilterInvocationContext(new DefaultHttpContext(), BuyerId.Invalid);
        var filter = new BuyerIdFilter();

        var result = await filter.InvokeAsync(context, _ => ValueTask.FromResult<object?>("next"));

        var badRequest = Assert.IsType<BadRequest<ApiResponse>>(result);
        Assert.NotNull(badRequest.Value?.Error);
        Assert.Equal("common.buyer_id_invalid", badRequest.Value.Error.Code);
    }

    [Fact]
    public async Task InvokeAsync_WithValidBuyerId_CallsNext()
    {
        var context = new DefaultEndpointFilterInvocationContext(new DefaultHttpContext(), new BuyerId(Guid.NewGuid()));
        var filter = new BuyerIdFilter();

        var result = await filter.InvokeAsync(context, _ => ValueTask.FromResult<object?>("next"));

        Assert.Equal("next", result);
    }
}
```

`tests/Ecommerce.Basket.Api.Tests/Features/UpsertItemEndpointTests.cs`:

```csharp
using Ecommerce.Basket.Api.Domain;
using Ecommerce.Basket.Api.Features;
using Ecommerce.Basket.Api.Features.UpsertItem;
using Ecommerce.Basket.Api.Infrastructure;
using Ecommerce.Basket.Api.Tests.Fakes;
using Ecommerce.ServiceDefaults.Api;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.Extensions.Logging.Abstractions;

namespace Ecommerce.Basket.Api.Tests.Features;

public sealed class UpsertItemEndpointTests
{
    private static readonly BuyerId Buyer = new(Guid.Parse("b0000000-0000-4000-8000-000000000001"));
    private static readonly CatalogProduct Mug = new(Guid.Parse("a0000000-0000-4000-8000-000000000001"), "Aspire Ceramic Mug", 12.50m, 25);
    private static readonly CatalogProduct LimitedHoodie = new(Guid.Parse("a0000000-0000-4000-8000-000000000006"), "Aspire Limited Edition Hoodie", 59.00m, 0);

    private readonly FakeCatalogClient _catalog = new FakeCatalogClient().With(Mug).With(LimitedHoodie);

    private BasketService CreateService() => new(new InMemoryBasketStore(), _catalog, NullLogger<BasketService>.Instance);

    [Fact]
    public async Task HandleAsync_WithKnownProduct_ReturnsOkWithBasket()
    {
        var result = await UpsertItemEndpoint.HandleAsync(Buyer, new UpsertItemRequest(Mug.Id, 3), CreateService(), TestContext.Current.CancellationToken);

        var ok = Assert.IsType<Ok<ApiResponse<UpsertItemResponse>>>(result.Result);
        Assert.NotNull(ok.Value?.Data);
        Assert.Equal(3, ok.Value.Data.AppliedQuantity);
        Assert.Equal(3, ok.Value.Data.Basket.ItemCount);
        Assert.Equal(37.50m, ok.Value.Data.Basket.Total);
    }

    [Fact]
    public async Task HandleAsync_WithUnknownProduct_ReturnsNotFoundEnvelope()
    {
        var result = await UpsertItemEndpoint.HandleAsync(Buyer, new UpsertItemRequest(Guid.NewGuid(), 1), CreateService(), TestContext.Current.CancellationToken);

        var notFound = Assert.IsType<NotFound<ApiResponse>>(result.Result);
        Assert.Equal("basket.product_not_found", notFound.Value?.Error?.Code);
    }

    [Fact]
    public async Task HandleAsync_WithOutOfStockProduct_ReturnsConflictEnvelope()
    {
        var result = await UpsertItemEndpoint.HandleAsync(Buyer, new UpsertItemRequest(LimitedHoodie.Id, 1), CreateService(), TestContext.Current.CancellationToken);

        var conflict = Assert.IsType<Conflict<ApiResponse>>(result.Result);
        Assert.Equal("basket.product_out_of_stock", conflict.Value?.Error?.Code);
    }

    [Fact]
    public async Task HandleAsync_WhenCatalogUnavailable_ReturnsServiceUnavailableEnvelope()
    {
        _catalog.Unavailable = true;

        var result = await UpsertItemEndpoint.HandleAsync(Buyer, new UpsertItemRequest(Mug.Id, 1), CreateService(), TestContext.Current.CancellationToken);

        var unavailable = Assert.IsType<JsonHttpResult<ApiResponse>>(result.Result);
        Assert.Equal(StatusCodes.Status503ServiceUnavailable, unavailable.StatusCode);
        Assert.Equal("basket.catalog_unavailable", unavailable.Value?.Error?.Code);
    }
}
```

- [ ] **Step 2: Run the tests and confirm they fail to compile**

```bash
dotnet test --project tests/Ecommerce.Basket.Api.Tests
```

Expected: a compile error naming the `Ecommerce.Basket.Api.Features.UpsertItem` namespace as missing. The compiler stops at that failed using directive, so the missing `BuyerIdFilter` type is not reported separately.

- [ ] **Step 3: Implement the filter and the endpoints**

`src/Ecommerce.Basket.Api/Features/BuyerIdFilter.cs`:

```csharp
using Ecommerce.Basket.Api.Domain;
using Ecommerce.ServiceDefaults.Api;

namespace Ecommerce.Basket.Api.Features;

// Answers 400 once for every endpoint in the group when the X-Buyer-Id header is missing or malformed
public sealed class BuyerIdFilter : IEndpointFilter
{
    public ValueTask<object?> InvokeAsync(EndpointFilterInvocationContext context, EndpointFilterDelegate next)
    {
        var buyerId = context.Arguments.OfType<BuyerId>().FirstOrDefault();
        if (buyerId is { IsValid: false })
        {
            return ValueTask.FromResult<object?>(ApiResults.BadRequest(
                CommonErrorCodes.BuyerIdInvalid,
                $"Header [{BuyerId.HeaderName}] must carry a valid buyer id"));
        }

        return next(context);
    }
}
```

`src/Ecommerce.Basket.Api/Features/GetBasket/GetBasketEndpoint.cs`:

```csharp
using Ecommerce.Basket.Api.Domain;
using Ecommerce.ServiceDefaults.Api;
using Microsoft.AspNetCore.Http.HttpResults;

namespace Ecommerce.Basket.Api.Features.GetBasket;

public static class GetBasketEndpoint
{
    public static RouteGroupBuilder MapGetBasket(this RouteGroupBuilder group)
    {
        group.MapGet("/", HandleAsync).WithName("GetBasket");
        return group;
    }

    public static async Task<Ok<ApiResponse<BasketResponse>>> HandleAsync(
        BuyerId buyerId,
        BasketService service,
        CancellationToken cancellationToken)
    {
        var basket = await service.GetAsync(buyerId, cancellationToken);
        return ApiResults.Ok(BasketResponse.From(basket));
    }
}
```

`src/Ecommerce.Basket.Api/Features/UpsertItem/UpsertItemEndpoint.cs`:

```csharp
using System.ComponentModel.DataAnnotations;
using Ecommerce.Basket.Api.Domain;
using Ecommerce.ServiceDefaults.Api;
using Microsoft.AspNetCore.Http.HttpResults;

namespace Ecommerce.Basket.Api.Features.UpsertItem;

public sealed record UpsertItemRequest(Guid ProductId, [Range(1, ShoppingBasket.MaxQuantityPerLine)] int Quantity);

public sealed record UpsertItemResponse(BasketResponse Basket, int RequestedQuantity, int AppliedQuantity, bool Capped);

public static class UpsertItemEndpoint
{
    public static RouteGroupBuilder MapUpsertItem(this RouteGroupBuilder group)
    {
        group.MapPut("/items", HandleAsync).WithName("UpsertBasketItem");
        return group;
    }

    public static async Task<Results<Ok<ApiResponse<UpsertItemResponse>>, NotFound<ApiResponse>, Conflict<ApiResponse>, JsonHttpResult<ApiResponse>>> HandleAsync(
        BuyerId buyerId,
        UpsertItemRequest request,
        BasketService service,
        CancellationToken cancellationToken)
    {
        var result = await service.UpsertItemAsync(buyerId, request.ProductId, request.Quantity, cancellationToken);

        return result switch
        {
            UpsertItemResult.Success success => ApiResults.Ok(new UpsertItemResponse(BasketResponse.From(success.Basket), success.RequestedQuantity, success.AppliedQuantity, success.Capped)),
            UpsertItemResult.ProductNotFound notFound => ApiResults.NotFound(ErrorCodes.ProductNotFound, $"Product [{notFound.ProductId}] not found"),
            UpsertItemResult.OutOfStock outOfStock => ApiResults.Conflict(ErrorCodes.ProductOutOfStock, $"Product [{outOfStock.ProductName}] has [0] units available", new { outOfStock.ProductId }),
            UpsertItemResult.CatalogUnavailable => ApiResults.ServiceUnavailable(ErrorCodes.CatalogUnavailable, "The catalog service is unavailable"),
            _ => throw new InvalidOperationException($"Unhandled result [{result.GetType().Name}]"),
        };
    }
}
```

`src/Ecommerce.Basket.Api/Features/RemoveItem/RemoveItemEndpoint.cs`:

```csharp
using Ecommerce.Basket.Api.Domain;
using Ecommerce.ServiceDefaults.Api;
using Microsoft.AspNetCore.Http.HttpResults;

namespace Ecommerce.Basket.Api.Features.RemoveItem;

public static class RemoveItemEndpoint
{
    public static RouteGroupBuilder MapRemoveItem(this RouteGroupBuilder group)
    {
        group.MapDelete("/items/{productId:guid}", HandleAsync).WithName("RemoveBasketItem");
        return group;
    }

    public static async Task<Ok<ApiResponse<BasketResponse>>> HandleAsync(
        BuyerId buyerId,
        Guid productId,
        BasketService service,
        CancellationToken cancellationToken)
    {
        var basket = await service.RemoveItemAsync(buyerId, productId, cancellationToken);
        return ApiResults.Ok(BasketResponse.From(basket));
    }
}
```

- [ ] **Step 4: Replace `Program.cs` with the final composition root**

```csharp
using Ecommerce.Basket.Api.Features;
using Ecommerce.Basket.Api.Features.GetBasket;
using Ecommerce.Basket.Api.Features.RemoveItem;
using Ecommerce.Basket.Api.Features.UpsertItem;
using Ecommerce.Basket.Api.Infrastructure;
using Ecommerce.ServiceDefaults.Api;

var builder = WebApplication.CreateBuilder(args);

builder.AddServiceDefaults();
builder.AddApiDefaults();
builder.Services.AddValidation();
builder.AddRedisClient("basket-cache");
builder.Services.AddSingleton<IBasketStore, RedisBasketStore>();
builder.Services.AddHttpClient<ICatalogClient, CatalogClient>(client => client.BaseAddress = new Uri("https+http://catalog-api"));
builder.Services.AddScoped<BasketService>();

var app = builder.Build();

app.UseApiDefaults();

var basket = app.MapGroup("/api/basket").WithTags("Basket").AddEndpointFilter<BuyerIdFilter>();
basket.MapGetBasket();
basket.MapUpsertItem();
basket.MapRemoveItem();

app.Run();
```

- [ ] **Step 5: Run every test and build**

```bash
dotnet test
dotnet build
```

Expected: 25 Basket tests, 26 ServiceDefaults tests and 22 Catalog tests pass, 73 in total, with `0 Warning(s)`. The Basket API can no longer run standalone because the Redis connection string only exists under the AppHost.

### Task 3.2.3: Gateway route and AppHost wiring

**Files:**
- Modify: `src/Ecommerce.Gateway/appsettings.json`
- Modify: `src/Ecommerce.AppHost/Ecommerce.AppHost.csproj`
- Modify: `src/Ecommerce.AppHost/AppHost.cs`

**Interfaces:**
- Consumes: the `redis` and `catalogApi` variables and the gateway registration from earlier phases.
- Produces: the `basket-api` resource waiting for `basket-cache` and `catalog-api`, referenced by the gateway; the gateway route `basket` (order 0) to cluster `basket` at `https+http://basket-api`.

- [ ] **Step 1: Replace the gateway configuration**

`src/Ecommerce.Gateway/appsettings.json`:

```json
{
  "Logging": {
    "LogLevel": {
      "Default": "Information",
      "Microsoft.AspNetCore": "Warning",
      "Yarp": "Warning"
    }
  },
  "AllowedHosts": "*",
  "ReverseProxy": {
    "Routes": {
      "catalog": {
        "ClusterId": "catalog",
        "Order": 0,
        "Match": {
          "Path": "/api/catalog/{**catch-all}"
        }
      },
      "basket": {
        "ClusterId": "basket",
        "Order": 0,
        "Match": {
          "Path": "/api/basket/{**catch-all}"
        }
      },
      "frontend": {
        "ClusterId": "frontend",
        "Order": 1000,
        "Match": {
          "Path": "/{**catch-all}"
        }
      }
    },
    "Clusters": {
      "catalog": {
        "Destinations": {
          "catalog-api": {
            "Address": "https+http://catalog-api"
          }
        }
      },
      "basket": {
        "Destinations": {
          "basket-api": {
            "Address": "https+http://basket-api"
          }
        }
      },
      "frontend": {
        "Destinations": {
          "frontend": {
            "Address": "http://frontend"
          }
        }
      }
    }
  }
}
```

- [ ] **Step 2: Replace the AppHost project file**

```xml
<Project Sdk="Aspire.AppHost.Sdk/13.5.3">

  <PropertyGroup>
    <OutputType>Exe</OutputType>
    <AspireUseCliBundle>true</AspireUseCliBundle>
    <UserSecretsId>ecommerce-aspire-demo-apphost</UserSecretsId>
  </PropertyGroup>

  <ItemGroup>
    <PackageReference Include="Aspire.Hosting.PostgreSQL" />
    <PackageReference Include="Aspire.Hosting.Redis" />
    <PackageReference Include="Aspire.Hosting.RabbitMQ" />
    <PackageReference Include="Aspire.Hosting.MongoDB" />
    <PackageReference Include="Aspire.Hosting.JavaScript" />
  </ItemGroup>

  <ItemGroup>
    <ProjectReference Include="../Ecommerce.Catalog.Api/Ecommerce.Catalog.Api.csproj" />
    <ProjectReference Include="../Ecommerce.Basket.Api/Ecommerce.Basket.Api.csproj" />
    <ProjectReference Include="../Ecommerce.Gateway/Ecommerce.Gateway.csproj" />
  </ItemGroup>

</Project>
```

- [ ] **Step 3: Replace `AppHost.cs`**

```csharp
var builder = DistributedApplication.CreateBuilder(args);

var postgres = builder.AddPostgres("postgres");
var catalogDb = postgres.AddDatabase("catalogdb");

var redis = builder.AddRedis("basket-cache");

var rabbitMq = builder.AddRabbitMQ("messaging")
    .WithManagementPlugin();

var mongo = builder.AddMongoDB("mongo");
var orderingDb = mongo.AddDatabase("orderingdb");

var catalogApi = builder.AddProject<Projects.Ecommerce_Catalog_Api>("catalog-api")
    .WithReference(catalogDb)
    .WaitFor(catalogDb)
    .WithHttpHealthCheck("/health");

var basketApi = builder.AddProject<Projects.Ecommerce_Basket_Api>("basket-api")
    .WithReference(redis)
    .WaitFor(redis)
    .WithReference(catalogApi)
    .WaitFor(catalogApi)
    .WithHttpHealthCheck("/health");

var frontend = builder.AddViteApp("frontend", "../ecommerce-frontend");

builder.AddProject<Projects.Ecommerce_Gateway>("gateway")
    .WithReference(catalogApi)
    .WaitFor(catalogApi)
    .WithReference(basketApi)
    .WaitFor(basketApi)
    .WithReference(frontend)
    .WithHttpHealthCheck("/health")
    .WithExternalHttpEndpoints();

builder.Build().Run();
```

- [ ] **Step 4: Build**

```bash
dotnet build
```

Expected: `Build succeeded.` with `0 Warning(s)`. Do not run the AppHost; the lead runs phase acceptance.

---

## Sub-phase 3.3 Basket store, header count, basket page and add action (frontend-dev)

### Task 3.3.1: Basket models, BasketApi and BasketStore, test-first

**Files:**
- Create: `src/ecommerce-frontend/src/app/core/basket-store.spec.ts`
- Create: `src/ecommerce-frontend/src/app/shared/models/basket.ts`
- Create: `src/ecommerce-frontend/src/app/core/api/basket-api.ts`
- Create: `src/ecommerce-frontend/src/app/core/basket-store.ts`

**Interfaces:**
- Consumes: `unwrap`, `toApiFailure`, `ApiResponse`, `HttpClient`.
- Produces:
  - `Basket`, `BasketItem` and `UpsertItemResult` interfaces mirroring the Basket API responses in camelCase.
  - `BasketApi` with `get()`, `upsertItem(productId, quantity)` and `removeItem(productId)`, each returning a promise of the unwrapped data and rejecting with `ApiFailure`.
  - `BasketStore` with readonly signals `basket`, `busy`, `failure`, computed `items`, `count`, `total`, and methods `load()` (records failures instead of throwing), `add(productId)` (requests the current line quantity plus one), `setQuantity(productId, quantity)` and `remove(productId)` (both replace the basket with the server's copy and rethrow `ApiFailure`).

- [ ] **Step 1: Write the failing spec**

`src/app/core/basket-store.spec.ts`:

```typescript
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';

import { Basket } from '../shared/models/basket';
import { ApiFailure } from './api/api-response';
import { BasketStore } from './basket-store';

const buyerId = 'b0000000-0000-4000-8000-000000000001';
const mugId = 'a0000000-0000-4000-8000-000000000001';

function basketWith(quantity: number): Basket {
  const items =
    quantity === 0
      ? []
      : [
          {
            productId: mugId,
            productName: 'Aspire Ceramic Mug',
            unitPrice: 12.5,
            quantity,
            lineTotal: 12.5 * quantity,
          },
        ];
  return { buyerId, items, itemCount: quantity, total: 12.5 * quantity };
}

describe('BasketStore', () => {
  let store: BasketStore;
  let controller: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting()],
    });
    store = TestBed.inject(BasketStore);
    controller = TestBed.inject(HttpTestingController);
  });

  afterEach(() => controller.verify());

  it('load fills the basket and the count', async () => {
    const loading = store.load();
    controller.expectOne('/api/basket').flush({ success: true, data: basketWith(2), error: null });
    await loading;

    expect(store.count()).toBe(2);
    expect(store.total()).toBe(25);
    expect(store.failure()).toBeNull();
  });

  it('load records a failure instead of throwing', async () => {
    const loading = store.load();
    controller.expectOne('/api/basket').flush(
      {
        success: false,
        data: null,
        error: {
          code: 'common.upstream_unavailable',
          message: 'An upstream service is unavailable',
          details: null,
          traceId: null,
        },
      },
      { status: 504, statusText: 'Gateway Timeout' },
    );
    await loading;

    expect(store.count()).toBe(0);
    expect(store.failure()?.code).toBe('common.upstream_unavailable');
  });

  it('setQuantity sends the line and replaces the basket with the result', async () => {
    const changing = store.setQuantity(mugId, 3);
    const request = controller.expectOne('/api/basket/items');
    expect(request.request.method).toBe('PUT');
    expect(request.request.body).toEqual({ productId: mugId, quantity: 3 });
    request.flush({
      success: true,
      data: { basket: basketWith(3), requestedQuantity: 3, appliedQuantity: 3, capped: false },
      error: null,
    });

    const result = await changing;

    expect(result.capped).toBe(false);
    expect(store.count()).toBe(3);
  });

  it('add requests one more than the current line quantity', async () => {
    const loading = store.load();
    controller.expectOne('/api/basket').flush({ success: true, data: basketWith(2), error: null });
    await loading;

    const adding = store.add(mugId);
    const request = controller.expectOne('/api/basket/items');
    expect(request.request.body).toEqual({ productId: mugId, quantity: 3 });
    request.flush({
      success: true,
      data: { basket: basketWith(3), requestedQuantity: 3, appliedQuantity: 3, capped: false },
      error: null,
    });
    await adding;

    expect(store.count()).toBe(3);
  });

  it('setQuantity throws an ApiFailure carrying the envelope code', async () => {
    const changing = store.setQuantity(mugId, 1);
    controller.expectOne('/api/basket/items').flush(
      {
        success: false,
        data: null,
        error: {
          code: 'basket.product_out_of_stock',
          message: 'Product [Mug] has [0] units available',
          details: null,
          traceId: null,
        },
      },
      { status: 409, statusText: 'Conflict' },
    );

    await expect(changing).rejects.toMatchObject({ code: 'basket.product_out_of_stock' });
    await expect(changing).rejects.toBeInstanceOf(ApiFailure);
    expect(store.busy()).toBe(false);
  });

  it('remove sends a DELETE and replaces the basket', async () => {
    const removing = store.remove(mugId);
    const request = controller.expectOne(`/api/basket/items/${mugId}`);
    expect(request.request.method).toBe('DELETE');
    request.flush({ success: true, data: basketWith(0), error: null });
    await removing;

    expect(store.count()).toBe(0);
    expect(store.items()).toEqual([]);
  });
});
```

- [ ] **Step 2: Run the tests and confirm they fail**

```bash
npm test
```

Expected: the run fails to resolve `./basket-store`.

- [ ] **Step 3: Implement**

`src/app/shared/models/basket.ts`:

```typescript
export interface BasketItem {
  productId: string;
  productName: string;
  unitPrice: number;
  quantity: number;
  lineTotal: number;
}

export interface Basket {
  buyerId: string;
  items: BasketItem[];
  itemCount: number;
  total: number;
}

export interface UpsertItemResult {
  basket: Basket;
  requestedQuantity: number;
  appliedQuantity: number;
  capped: boolean;
}
```

`src/app/core/api/basket-api.ts`:

```typescript
import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable, firstValueFrom } from 'rxjs';

import { Basket, UpsertItemResult } from '../../shared/models/basket';
import { ApiResponse, toApiFailure, unwrap } from './api-response';

@Injectable({ providedIn: 'root' })
export class BasketApi {
  private readonly http = inject(HttpClient);

  get(): Promise<Basket> {
    return this.request(this.http.get<ApiResponse<Basket>>('/api/basket'));
  }

  upsertItem(productId: string, quantity: number): Promise<UpsertItemResult> {
    return this.request(
      this.http.put<ApiResponse<UpsertItemResult>>('/api/basket/items', { productId, quantity }),
    );
  }

  removeItem(productId: string): Promise<Basket> {
    return this.request(this.http.delete<ApiResponse<Basket>>(`/api/basket/items/${productId}`));
  }

  private async request<T>(call: Observable<ApiResponse<T>>): Promise<T> {
    try {
      return unwrap(await firstValueFrom(call));
    } catch (error) {
      throw toApiFailure(error);
    }
  }
}
```

`src/app/core/basket-store.ts`:

```typescript
import { Injectable, computed, inject, signal } from '@angular/core';

import { Basket, UpsertItemResult } from '../shared/models/basket';
import { ApiFailure, toApiFailure } from './api/api-response';
import { BasketApi } from './api/basket-api';

// The single source of truth for the basket in the browser; every mutation replaces it with the server's copy
@Injectable({ providedIn: 'root' })
export class BasketStore {
  private readonly api = inject(BasketApi);
  private readonly basketState = signal<Basket | null>(null);
  private readonly busyState = signal(false);
  private readonly failureState = signal<ApiFailure | null>(null);

  readonly basket = this.basketState.asReadonly();
  readonly busy = this.busyState.asReadonly();
  readonly failure = this.failureState.asReadonly();
  readonly items = computed(() => this.basketState()?.items ?? []);
  readonly count = computed(() => this.basketState()?.itemCount ?? 0);
  readonly total = computed(() => this.basketState()?.total ?? 0);

  async load(): Promise<void> {
    this.busyState.set(true);
    try {
      this.basketState.set(await this.api.get());
      this.failureState.set(null);
    } catch (error) {
      this.failureState.set(toApiFailure(error));
    } finally {
      this.busyState.set(false);
    }
  }

  add(productId: string): Promise<UpsertItemResult> {
    const existing = this.items().find((item) => item.productId === productId);
    return this.setQuantity(productId, (existing?.quantity ?? 0) + 1);
  }

  async setQuantity(productId: string, quantity: number): Promise<UpsertItemResult> {
    this.busyState.set(true);
    try {
      const result = await this.api.upsertItem(productId, quantity);
      this.basketState.set(result.basket);
      return result;
    } finally {
      this.busyState.set(false);
    }
  }

  async remove(productId: string): Promise<void> {
    this.busyState.set(true);
    try {
      this.basketState.set(await this.api.removeItem(productId));
    } finally {
      this.busyState.set(false);
    }
  }
}
```

- [ ] **Step 4: Run the tests, then the full check**

```bash
npm test
npm run build
npm run lint
npm run format:check
```

Expected: `Test Files  6 passed (6)` and `Tests  22 passed (22)`; build, lint and format check clean.

### Task 3.3.2: Header badge, basket page, add action and routes, test-first

**Files:**
- Modify: `src/ecommerce-frontend/src/app/app.spec.ts`
- Modify: `src/ecommerce-frontend/src/app/app.ts`
- Modify: `src/ecommerce-frontend/src/app/app.routes.ts`
- Modify: `src/ecommerce-frontend/src/app/core/layout/site-header.ts`
- Modify: `src/ecommerce-frontend/src/app/core/layout/site-header.html`
- Create: `src/ecommerce-frontend/src/app/features/basket/basket-page.ts`, `basket-page.html`, `basket-page.scss`
- Modify: `src/ecommerce-frontend/src/app/features/products/product-list.ts`
- Modify: `src/ecommerce-frontend/src/app/features/products/product-list.html`

**Interfaces:**
- Consumes: `BasketStore`, Material badge and snack bar.
- Produces: `App` loading the basket once at startup; `SiteHeader` with a Basket link carrying a badge that hides at zero; `BasketPage` at `/basket` with empty, error and list states, plus and minus controls, removal, total, and snack bar feedback; `ProductList` whose add-to-basket button calls the store and reports "Added ... to your basket", the capped quantity, or the failure message.

- [ ] **Step 1: Write the failing spec**

Replace `src/app/app.spec.ts` with:

```typescript
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';

import { App } from './app';

describe('App', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [App],
      providers: [provideRouter([]), provideHttpClient(), provideHttpClientTesting()],
    }).compileComponents();
  });

  it('renders the header label and the footer credit and loads the basket', async () => {
    const fixture = TestBed.createComponent(App);
    const controller = TestBed.inject(HttpTestingController);
    controller.expectOne('/api/basket').flush({
      success: true,
      data: { buyerId: 'b', items: [], itemCount: 0, total: 0 },
      error: null,
    });
    await fixture.whenStable();

    const text = (fixture.nativeElement as HTMLElement).textContent ?? '';
    expect(text).toContain('ECommerce Demo');
    expect(text).toContain('Basket');
    expect(text).toContain('Developed by Goran Todorovic 2026');
    controller.verify();
  });
});
```

- [ ] **Step 2: Run the tests and confirm they fail**

```bash
npm test
```

Expected: the App spec fails because no request to `/api/basket` is made and the header has no Basket link yet; the other 21 tests pass.

- [ ] **Step 3: Implement**

`src/app/app.ts`:

```typescript
import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { RouterOutlet } from '@angular/router';

import { BasketStore } from './core/basket-store';
import { SiteFooter } from './core/layout/site-footer';
import { SiteHeader } from './core/layout/site-header';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, SiteHeader, SiteFooter],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './app.html',
  styleUrl: './app.scss',
})
export class App {
  private readonly basket = inject(BasketStore);

  constructor() {
    void this.basket.load();
  }
}
```

`src/app/app.routes.ts`:

```typescript
import { Routes } from '@angular/router';

export const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'products' },
  {
    path: 'products',
    loadComponent: () => import('./features/products/product-list').then((m) => m.ProductList),
  },
  {
    path: 'basket',
    loadComponent: () => import('./features/basket/basket-page').then((m) => m.BasketPage),
  },
  { path: '**', redirectTo: 'products' },
];
```

`src/app/core/layout/site-header.ts`:

```typescript
import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { MatBadgeModule } from '@angular/material/badge';
import { MatButtonModule } from '@angular/material/button';
import { MatToolbarModule } from '@angular/material/toolbar';
import { RouterLink, RouterLinkActive } from '@angular/router';

import { BasketStore } from '../basket-store';

@Component({
  selector: 'app-site-header',
  imports: [MatToolbarModule, MatButtonModule, MatBadgeModule, RouterLink, RouterLinkActive],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './site-header.html',
  styleUrl: './site-header.scss',
})
export class SiteHeader {
  protected readonly basket = inject(BasketStore);
}
```

`src/app/core/layout/site-header.html`:

```html
<mat-toolbar class="header">
  <a class="brand" routerLink="/products">ECommerce Demo</a>
  <nav class="nav" aria-label="Main">
    <a mat-button routerLink="/products" routerLinkActive="active">Products</a>
    <a
      mat-button
      routerLink="/basket"
      routerLinkActive="active"
      [matBadge]="basket.count()"
      [matBadgeHidden]="basket.count() === 0"
      matBadgeSize="small"
      aria-label="Basket"
    >
      Basket
    </a>
  </nav>
</mat-toolbar>
```

`src/app/features/basket/basket-page.ts`:

```typescript
import { CurrencyPipe } from '@angular/common';
import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatSnackBar } from '@angular/material/snack-bar';
import { RouterLink } from '@angular/router';

import { toApiFailure } from '../../core/api/api-response';
import { BasketStore } from '../../core/basket-store';
import { BasketItem } from '../../shared/models/basket';

@Component({
  selector: 'app-basket-page',
  imports: [CurrencyPipe, MatCardModule, MatButtonModule, RouterLink],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './basket-page.html',
  styleUrl: './basket-page.scss',
})
export class BasketPage {
  protected readonly store = inject(BasketStore);
  private readonly snackBar = inject(MatSnackBar);

  protected increase(item: BasketItem): Promise<void> {
    return this.change(item, item.quantity + 1);
  }

  protected decrease(item: BasketItem): Promise<void> {
    return item.quantity === 1 ? this.remove(item) : this.change(item, item.quantity - 1);
  }

  protected async remove(item: BasketItem): Promise<void> {
    try {
      await this.store.remove(item.productId);
      this.snackBar.open(`Removed ${item.productName} from your basket`, undefined, {
        duration: 3000,
      });
    } catch (error) {
      this.snackBar.open(toApiFailure(error).message, 'Dismiss', { duration: 5000 });
    }
  }

  private async change(item: BasketItem, quantity: number): Promise<void> {
    try {
      const result = await this.store.setQuantity(item.productId, quantity);
      if (result.capped) {
        this.snackBar.open(
          `Only ${result.appliedQuantity} of ${item.productName} available`,
          undefined,
          {
            duration: 4000,
          },
        );
      }
    } catch (error) {
      this.snackBar.open(toApiFailure(error).message, 'Dismiss', { duration: 5000 });
    }
  }
}
```

`src/app/features/basket/basket-page.html`:

```html
<h1 class="title">Your basket</h1>

@if (store.failure(); as failure) {
  <mat-card class="notice" appearance="outlined">
    <mat-card-content>
      <p>{{ failure.message }}</p>
      <p class="code">[{{ failure.code }}]</p>
    </mat-card-content>
    <mat-card-actions>
      <button mat-button (click)="store.load()">Retry</button>
    </mat-card-actions>
  </mat-card>
} @else if (store.items().length === 0) {
  <mat-card class="notice" appearance="outlined">
    <mat-card-content>
      <p>Your basket is empty.</p>
    </mat-card-content>
    <mat-card-actions>
      <a mat-flat-button routerLink="/products">Browse products</a>
    </mat-card-actions>
  </mat-card>
} @else {
  <mat-card appearance="outlined">
    <mat-card-content>
      <ul class="lines">
        @for (item of store.items(); track item.productId) {
          <li class="line">
            <div class="name">
              <span>{{ item.productName }}</span>
              <small>{{ item.unitPrice | currency: 'EUR' }} each</small>
            </div>
            <div
              class="quantity"
              role="group"
              [attr.aria-label]="'Quantity of ' + item.productName"
            >
              <button
                mat-stroked-button
                (click)="decrease(item)"
                [disabled]="store.busy()"
                aria-label="Decrease quantity"
              >
                -
              </button>
              <span class="value">{{ item.quantity }}</span>
              <button
                mat-stroked-button
                (click)="increase(item)"
                [disabled]="store.busy()"
                aria-label="Increase quantity"
              >
                +
              </button>
            </div>
            <div class="line-total">{{ item.lineTotal | currency: 'EUR' }}</div>
            <button mat-button (click)="remove(item)" [disabled]="store.busy()">Remove</button>
          </li>
        }
      </ul>
      <div class="summary">
        <span>Total</span>
        <span class="total">{{ store.total() | currency: 'EUR' }}</span>
      </div>
    </mat-card-content>
  </mat-card>
}
```

`src/app/features/basket/basket-page.scss`:

```scss
.title {
  font: var(--mat-sys-headline-medium);
  margin: 0 0 1rem;
}

.lines {
  list-style: none;
  margin: 0;
  padding: 0;
}

.line {
  display: grid;
  grid-template-columns: 1fr auto auto auto;
  align-items: center;
  gap: 1rem;
  padding: 0.75rem 0;
  border-bottom: 1px solid var(--mat-sys-outline-variant);
}

.name {
  display: flex;
  flex-direction: column;
}

.name small {
  color: var(--mat-sys-on-surface-variant);
}

.quantity {
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

.quantity .value {
  min-width: 2ch;
  text-align: center;
  font: var(--mat-sys-title-medium);
}

.line-total {
  min-width: 6rem;
  text-align: right;
  font: var(--mat-sys-title-medium);
}

.summary {
  display: flex;
  justify-content: space-between;
  padding-top: 1rem;
  font: var(--mat-sys-title-large);
}

.notice .code {
  font: var(--mat-sys-label-medium);
  color: var(--mat-sys-on-surface-variant);
}

@media (max-width: 600px) {
  .line {
    grid-template-columns: 1fr auto;
  }
}
```

`src/app/features/products/product-list.ts`:

```typescript
import { CurrencyPipe } from '@angular/common';
import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSnackBar } from '@angular/material/snack-bar';

import { toApiFailure } from '../../core/api/api-response';
import { CatalogApi } from '../../core/api/catalog-api';
import { BasketStore } from '../../core/basket-store';
import { Product } from '../../shared/models/product';
import { ProductImage } from '../../shared/product-image/product-image';

@Component({
  selector: 'app-product-list',
  imports: [CurrencyPipe, MatCardModule, MatButtonModule, MatProgressBarModule, ProductImage],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './product-list.html',
  styleUrl: './product-list.scss',
})
export class ProductList {
  private readonly catalog = inject(CatalogApi);
  private readonly snackBar = inject(MatSnackBar);

  protected readonly basket = inject(BasketStore);
  protected readonly products = this.catalog.listProducts();
  protected readonly failure = computed(() => {
    const error = this.products.error();
    return error ? toApiFailure(error) : null;
  });

  protected reload(): void {
    this.products.reload();
  }

  protected async add(product: Product): Promise<void> {
    try {
      const result = await this.basket.add(product.id);
      const message = result.capped
        ? `Only ${result.appliedQuantity} of ${product.name} available, quantity set to ${result.appliedQuantity}`
        : `Added ${product.name} to your basket`;
      this.snackBar.open(message, undefined, { duration: 3000 });
    } catch (error) {
      this.snackBar.open(toApiFailure(error).message, 'Dismiss', { duration: 5000 });
    }
  }
}
```

`src/app/features/products/product-list.html`:

```html
<h1 class="title">Products</h1>

@if (products.isLoading()) {
  <mat-progress-bar mode="indeterminate" aria-label="Loading products" />
}

@if (failure(); as failure) {
  <mat-card class="notice" appearance="outlined">
    <mat-card-content>
      <p>{{ failure.message }}</p>
      <p class="code">[{{ failure.code }}]</p>
    </mat-card-content>
    <mat-card-actions>
      <button mat-button (click)="reload()">Retry</button>
    </mat-card-actions>
  </mat-card>
} @else if (products.value(); as items) {
  <div class="grid">
    @for (product of items; track product.id) {
      <mat-card
        class="product"
        [class.sold-out]="product.availableStock === 0"
        appearance="outlined"
      >
        <app-product-image [imageKey]="product.imageKey" [name]="product.name" />
        <mat-card-header>
          <mat-card-title>{{ product.name }}</mat-card-title>
          <mat-card-subtitle>{{ product.category }}</mat-card-subtitle>
        </mat-card-header>
        <mat-card-content>
          <p class="description">{{ product.description }}</p>
          <p class="price">{{ product.price | currency: 'EUR' }}</p>
          @if (product.availableStock > 0) {
            <p class="stock">In stock: {{ product.availableStock }}</p>
          } @else {
            <p class="stock out">Out of stock</p>
          }
        </mat-card-content>
        <mat-card-actions align="end">
          <button
            mat-flat-button
            (click)="add(product)"
            [disabled]="product.availableStock === 0 || basket.busy()"
          >
            Add to basket
          </button>
        </mat-card-actions>
      </mat-card>
    } @empty {
      <p>No products available</p>
    }
  </div>
}
```

- [ ] **Step 4: Run the tests, then the full check**

```bash
npm test
npm run build
npm run lint
npm run format:check
```

Expected: `Test Files  6 passed (6)` and `Tests  22 passed (22)`; the build lists lazy chunks named `product-list` and `basket-page`; lint and format check clean.

---

## Sub-phase 3.4 Phase acceptance

Run by the lead after every task above is reviewed and ticked.

- [ ] **Step 1: Clean build and full test runs**

```bash
dotnet build
dotnet test
cd src/ecommerce-frontend && source "$HOME/.nvm/nvm.sh" && nvm use && npm run lint && npm test && cd ../..
```

Expected: `0 Warning(s)`, 73 .NET tests, 22 frontend tests, lint clean.

- [ ] **Step 2: Start the AppHost and wait**

```bash
export PATH="$PATH:$HOME/.dotnet/tools"
source "$HOME/.nvm/nvm.sh" && nvm use 24
AH=src/Ecommerce.AppHost/Ecommerce.AppHost.csproj
aspire start --apphost $AH --non-interactive --format Json
for r in catalog-api basket-api frontend gateway; do aspire wait $r --status healthy --timeout 300 --apphost $AH --non-interactive; done
```

Expected: all four healthy; `basket-api` starts only after `basket-cache` and `catalog-api` are healthy. The `nvm use` line matters: the AppHost starts the Angular dev server with whatever `node` and `npm` are on the PATH of the shell that launched it, and without them the `frontend` and `frontend-installer` resources go straight to FailedToStart.

- [ ] **Step 3: Exercise the basket through the gateway**

Every call below carries the buyer header except the first two. Expected results are in the comments.

```bash
G=http://localhost:5100/api/basket
BUYER="X-Buyer-Id: b0000000-0000-4000-8000-000000000001"
curl -s -w ' [%{http_code}]\n' $G                                  # common.buyer_id_invalid [400]
curl -s -H "X-Buyer-Id: nope" -w ' [%{http_code}]\n' $G            # common.buyer_id_invalid [400]
curl -s -H "$BUYER" -w ' [%{http_code}]\n' $G                      # success, itemCount 0 [200]
curl -s -H "$BUYER" -H "content-type: application/json" -X PUT -d '{"productId":"a0000000-0000-4000-8000-000000000001","quantity":2}' -w ' [%{http_code}]\n' $G/items
# success, appliedQuantity 2, capped false, basket.itemCount 2 [200]
curl -s -H "$BUYER" -H "content-type: application/json" -X PUT -d '{"productId":"a0000000-0000-4000-8000-000000000010","quantity":5}' -w ' [%{http_code}]\n' $G/items
# success, appliedQuantity 2, capped true, basket.itemCount 4, basket.total 55 [200]
curl -s -H "$BUYER" -H "content-type: application/json" -X PUT -d '{"productId":"a0000000-0000-4000-8000-000000000006","quantity":1}' -w ' [%{http_code}]\n' $G/items
# basket.product_out_of_stock [409]
curl -s -H "$BUYER" -H "content-type: application/json" -X PUT -d '{"productId":"a0000000-0000-4000-8000-0000000000ff","quantity":1}' -w ' [%{http_code}]\n' $G/items
# basket.product_not_found [404]
curl -s -H "$BUYER" -H "content-type: application/json" -X PUT -d '{"productId":"a0000000-0000-4000-8000-000000000001","quantity":0}' -w ' [%{http_code}]\n' $G/items
# common.validation_failed with details.Quantity [400]
curl -s -H "$BUYER" $G                                              # two lines, total 55
aspire resource basket-api restart --apphost $AH --non-interactive
aspire wait basket-api --status healthy --timeout 120 --apphost $AH --non-interactive
curl -s -H "$BUYER" -w ' [%{http_code}]\n' $G                      # still itemCount 4: the basket lives in Redis
curl -s -H "$BUYER" -X DELETE -w ' [%{http_code}]\n' $G/items/a0000000-0000-4000-8000-000000000010
# success, itemCount 2 [200]
curl -s -H "X-Buyer-Id: b0000000-0000-4000-8000-000000000002" -w ' [%{http_code}]\n' $G
# success, itemCount 0 [200]: baskets are per buyer
```

- [ ] **Step 4: Prove the Catalog-down path**

```bash
aspire resource catalog-api stop --apphost $AH --non-interactive
aspire wait catalog-api --status down --timeout 60 --apphost $AH --non-interactive
curl -s -m 120 -H "$BUYER" -H "content-type: application/json" -X PUT -d '{"productId":"a0000000-0000-4000-8000-000000000001","quantity":1}' -w ' [%{http_code}]\n' $G/items
# basket.catalog_unavailable [503] after about 30 seconds, which is the standard resilience handler retrying with backoff before giving up
curl -s -H "$BUYER" -w ' [%{http_code}]\n' $G                      # success [200]: reading the basket needs only Redis
aspire logs basket-api --search "Catalog unavailable" --apphost $AH --non-interactive
# one line: [BasketService] Catalog unavailable while adding product [...] for buyer [...]
aspire resource catalog-api start --apphost $AH --non-interactive
aspire wait catalog-api --status healthy --timeout 120 --apphost $AH --non-interactive
curl -s -H "$BUYER" -H "content-type: application/json" -X PUT -d '{"productId":"a0000000-0000-4000-8000-000000000001","quantity":1}' -w ' [%{http_code}]\n' $G/items
# success [200]
aspire otel traces gateway --apphost $AH --non-interactive
# PUT /api/basket traces show 8 spans: gateway, basket-api, its call to catalog-api, and the Redis commands
```

- [ ] **Step 5: Owner's browser check**

Open `http://localhost:5100`. Expected: the header shows a Basket link with no badge; clicking Add to basket on a product shows "Added ... to your basket" and the badge shows 1; adding the Aspire Launch Poster three times ends with the badge at the capped count and a message that only 2 are available; the Limited Edition Hoodie button stays disabled; the Basket page lists the lines with plus and minus controls, per-line totals and the total, minus on a quantity of 1 removes the line, Remove removes it directly with a confirmation message, and an empty basket shows the "Browse products" link. Reloading the page keeps the basket, because the buyer id is in local storage and the basket in Redis.

- [ ] **Step 6: Stop and record**

```bash
aspire stop --apphost $AH --non-interactive
```

The lead ticks phase 3 in `STATUS.md`, writes the phase entry in `SUMMARY.md`, and waits for the owner's review.
