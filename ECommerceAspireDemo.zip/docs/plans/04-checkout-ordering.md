# Phase 4 Checkout and Ordering Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** A buyer can check out. Basket validates the checkout details and the stock, publishes `OrderPlaced` through a durable outbox over RabbitMQ and clears the basket; Ordering consumes the event, stores the order snapshot in MongoDB and serves the buyer's order history; the frontend gains the checkout form and the orders page.

**Architecture:** `Ecommerce.Contracts` holds the integration events `OrderPlaced` and `OrderPaid`. `BuyerId` and `BuyerIdFilter` move from Basket into `Ecommerce.ServiceDefaults.Api` because Ordering needs them too, and ServiceDefaults subscribes to Wolverine's trace source and meters. Basket gets a Wolverine publisher behind `IOrderPlacedPublisher`, a `CheckoutService` holding the checkout rules, and a `POST /api/basket/checkout` endpoint; its Wolverine configuration persists outgoing messages in a Postgres message store (`basketdb`) so a checkout succeeds even while RabbitMQ is down and the event is delivered when the broker returns. `Ecommerce.Ordering.Api` has an `Order` document, a Mongo store with an insert-if-absent write so redelivery is harmless, an index initializer, the `OrderPlacedHandler`, and two read endpoints. The gateway routes `/api/orders`, the AppHost wires `basketdb`, the broker and `ordering-api`. The frontend adds order models, checkout on the basket client and store, an orders client, the checkout page with a reactive form prefilled with the approving test card, the orders page, an Orders link and a checkout button.

**Tech Stack:** WolverineFx 6.36.0 with WolverineFx.RabbitMQ, WolverineFx.RuntimeCompilation and WolverineFx.Postgresql (all MIT), Aspire.MongoDB.Driver 13.5.3 (MongoDB.Driver 3.x, Apache 2.0), Microsoft.Extensions.TimeProvider.Testing 10.10.0 (MIT, tests only), Angular reactive forms with Material form fields.

**Spec:** `docs/ARCHITECTURE.md` sections 2.1, 4.3, 4.4, 4.7, 5 and 6; `docs/CODING_GUIDELINES.md` sections 2, 3, 4, 5 and 6.

**Agents and ordering:** `backend-dev` runs sub-phases 4.1 to 4.4 in order, `frontend-dev` runs sub-phase 4.5. They run in parallel with no dependency between them; the frontend tests mock every HTTP call. Sub-phase 4.6 is the lead's acceptance and needs both halves.

## Global Constraints

- Everything from `docs/plans/README.md` Global constraints applies.
- New NuGet packages in this phase: `WolverineFx`, `WolverineFx.RabbitMQ`, `WolverineFx.RuntimeCompilation`, `WolverineFx.Postgresql` (all 6.36.0, MIT), `Aspire.MongoDB.Driver` 13.5.3 (MIT), `Microsoft.Extensions.TimeProvider.Testing` 10.10.0 (MIT, test projects only). No new npm packages. Add nothing else.
- `WolverineFx.RuntimeCompilation` is mandatory in every project that calls `UseWolverine`: Wolverine 6 no longer ships the runtime compiler and throws at startup without it.
- Wolverine handlers are non-static classes named `<Message>Handler` with a static `HandleAsync` whose first parameter is the message; dependencies follow as parameters.
- Endpoint classes are static and do not log; `CheckoutService`, the handler and the initializer log with `ILogger<T>` in the `[{Prefix}]` format. The card number is never logged and never stored; only its last four digits reach Mongo.
- Every response uses the envelope. New business codes: `basket.checkout_empty`, `basket.checkout_out_of_stock`, `basket.outbox_unavailable`, `orders.not_found`.
- Frontend commands run inside `src/ecommerce-frontend` after `source "$HOME/.nvm/nvm.sh" && nvm use`, and every frontend task ends with `npm test`, `npm run build`, `npm run lint` and `npm run format:check` passing.

---

## Sub-phase 4.1 Contracts, shared buyer identity and messaging telemetry (backend-dev)

### Task 4.1.1: Move BuyerId and BuyerIdFilter into ServiceDefaults, add Wolverine telemetry, test-first

**Files:**
- Create: `tests/Ecommerce.ServiceDefaults.Tests/Api/BuyerIdTests.cs`
- Create: `tests/Ecommerce.ServiceDefaults.Tests/Api/BuyerIdFilterTests.cs`
- Delete: `tests/Ecommerce.Basket.Api.Tests/Domain/BuyerIdTests.cs`
- Delete: `tests/Ecommerce.Basket.Api.Tests/Features/BuyerIdFilterTests.cs`
- Create: `src/Ecommerce.ServiceDefaults/Api/BuyerId.cs`
- Create: `src/Ecommerce.ServiceDefaults/Api/BuyerIdFilter.cs`
- Delete: `src/Ecommerce.Basket.Api/Domain/BuyerId.cs`
- Delete: `src/Ecommerce.Basket.Api/Features/BuyerIdFilter.cs`
- Modify: `src/Ecommerce.Basket.Api/Features/BasketService.cs` (one added using)
- Modify: `tests/Ecommerce.Basket.Api.Tests/Features/BasketServiceTests.cs` (one added using)
- Modify: `src/Ecommerce.ServiceDefaults/Extensions.cs` (Wolverine trace source and meter)

**Interfaces:**
- Consumes: the phase 3 types.
- Produces: `Ecommerce.ServiceDefaults.Api.BuyerId` and `Ecommerce.ServiceDefaults.Api.BuyerIdFilter`, identical in behavior to the phase 3 types, usable by every service; `ConfigureOpenTelemetry` now adds the `Wolverine` activity source and the `Wolverine*` meters.

- [ ] **Step 1: Move the two test files**

Create `tests/Ecommerce.ServiceDefaults.Tests/Api/BuyerIdTests.cs`:

```csharp
using Ecommerce.ServiceDefaults.Api;
using Microsoft.AspNetCore.Http;

namespace Ecommerce.ServiceDefaults.Tests.Api;

public sealed class BuyerIdTests
{
    [Fact]
    public async Task BindAsync_WithValidHeader_ReturnsBuyerId()
    {
        var context = new DefaultHttpContext();
        context.Request.Headers[BuyerId.HeaderName] = "b0000000-0000-4000-8000-000000000001";

        var buyerId = await BuyerId.BindAsync(context);

        Assert.NotNull(buyerId);
        Assert.True(buyerId.IsValid);
        Assert.Equal(Guid.Parse("b0000000-0000-4000-8000-000000000001"), buyerId.Value);
    }

    [Fact]
    public async Task BindAsync_WithoutHeader_ReturnsInvalid()
    {
        var buyerId = await BuyerId.BindAsync(new DefaultHttpContext());

        Assert.NotNull(buyerId);
        Assert.False(buyerId.IsValid);
    }

    [Theory]
    [InlineData("not-a-guid")]
    [InlineData("00000000-0000-0000-0000-000000000000")]
    public async Task BindAsync_WithMalformedOrEmptyHeader_ReturnsInvalid(string header)
    {
        var context = new DefaultHttpContext();
        context.Request.Headers[BuyerId.HeaderName] = header;

        var buyerId = await BuyerId.BindAsync(context);

        Assert.NotNull(buyerId);
        Assert.False(buyerId.IsValid);
    }
}
```

Create `tests/Ecommerce.ServiceDefaults.Tests/Api/BuyerIdFilterTests.cs`:

```csharp
using Ecommerce.ServiceDefaults.Api;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;

namespace Ecommerce.ServiceDefaults.Tests.Api;

public sealed class BuyerIdFilterTests
{
    [Fact]
    public async Task InvokeAsync_WithInvalidBuyerId_ReturnsBadRequestEnvelope()
    {
        var context = new DefaultEndpointFilterInvocationContext(new DefaultHttpContext(), BuyerId.Invalid);
        var filter = new BuyerIdFilter();

        var result = await filter.InvokeAsync(context, _ => ValueTask.FromResult<object?>("next"));

        var badRequest = Assert.IsType<BadRequest<ApiResponse>>(result);
        Assert.NotNull(badRequest.Value?.Error);
        Assert.Equal("common.buyer_id_invalid", badRequest.Value.Error.Code);
    }

    [Fact]
    public async Task InvokeAsync_WithValidBuyerId_CallsNext()
    {
        var context = new DefaultEndpointFilterInvocationContext(new DefaultHttpContext(), new BuyerId(Guid.NewGuid()));
        var filter = new BuyerIdFilter();

        var result = await filter.InvokeAsync(context, _ => ValueTask.FromResult<object?>("next"));

        Assert.Equal("next", result);
    }
}
```

Delete the Basket copies:

```bash
rm tests/Ecommerce.Basket.Api.Tests/Domain/BuyerIdTests.cs tests/Ecommerce.Basket.Api.Tests/Features/BuyerIdFilterTests.cs
```

- [ ] **Step 2: Run the ServiceDefaults tests and confirm they fail to compile**

```bash
dotnet test --project tests/Ecommerce.ServiceDefaults.Tests
```

Expected: compile errors naming `BuyerId` and `BuyerIdFilter` as missing.

- [ ] **Step 3: Create the shared types and delete the Basket copies**

`src/Ecommerce.ServiceDefaults/Api/BuyerId.cs`:

```csharp
using Microsoft.AspNetCore.Http;

namespace Ecommerce.ServiceDefaults.Api;

// Bound from the X-Buyer-Id header; an invalid or missing header yields Invalid so BuyerIdFilter can answer 400
public sealed record BuyerId(Guid Value)
{
    public const string HeaderName = "X-Buyer-Id";

    public static readonly BuyerId Invalid = new(Guid.Empty);

    public bool IsValid => Value != Guid.Empty;

    public static ValueTask<BuyerId?> BindAsync(HttpContext context)
    {
        var header = context.Request.Headers[HeaderName].ToString();
        var buyerId = Guid.TryParse(header, out var value) && value != Guid.Empty ? new BuyerId(value) : Invalid;
        return ValueTask.FromResult<BuyerId?>(buyerId);
    }
}
```

`src/Ecommerce.ServiceDefaults/Api/BuyerIdFilter.cs`:

```csharp
using Microsoft.AspNetCore.Http;

namespace Ecommerce.ServiceDefaults.Api;

// Answers 400 once for every endpoint in a group when the X-Buyer-Id header is missing or malformed
public sealed class BuyerIdFilter : IEndpointFilter
{
    public ValueTask<object?> InvokeAsync(EndpointFilterInvocationContext context, EndpointFilterDelegate next)
    {
        var buyerId = context.Arguments.OfType<BuyerId>().FirstOrDefault();
        if (buyerId is { IsValid: false })
        {
            return ValueTask.FromResult<object?>(ApiResults.BadRequest(
                CommonErrorCodes.BuyerIdInvalid,
                $"Header [{BuyerId.HeaderName}] must carry a valid buyer id"));
        }

        return next(context);
    }
}
```

```bash
rm src/Ecommerce.Basket.Api/Domain/BuyerId.cs src/Ecommerce.Basket.Api/Features/BuyerIdFilter.cs
```

- [ ] **Step 4: Point the two Basket files at the shared namespace**

Replace `src/Ecommerce.Basket.Api/Features/BasketService.cs` with:

```csharp
using Ecommerce.Basket.Api.Domain;
using Ecommerce.ServiceDefaults.Api;
using Ecommerce.Basket.Api.Infrastructure;

namespace Ecommerce.Basket.Api.Features;

public abstract record UpsertItemResult
{
    public sealed record Success(ShoppingBasket Basket, int RequestedQuantity, int AppliedQuantity) : UpsertItemResult
    {
        public bool Capped => AppliedQuantity < RequestedQuantity;
    }

    public sealed record ProductNotFound(Guid ProductId) : UpsertItemResult;

    public sealed record OutOfStock(Guid ProductId, string ProductName) : UpsertItemResult;

    public sealed record CatalogUnavailable : UpsertItemResult;
}

public sealed class BasketService(IBasketStore store, ICatalogClient catalog, ILogger<BasketService> logger)
{
    public async Task<ShoppingBasket> GetAsync(BuyerId buyerId, CancellationToken cancellationToken) =>
        await store.GetAsync(buyerId.Value, cancellationToken) ?? new ShoppingBasket(buyerId.Value);

    public async Task<UpsertItemResult> UpsertItemAsync(BuyerId buyerId, Guid productId, int quantity, CancellationToken cancellationToken)
    {
        CatalogProduct? product;
        try
        {
            product = await catalog.GetProductAsync(productId, cancellationToken);
        }
        catch (CatalogUnavailableException exception)
        {
            logger.LogWarning(exception, "[{Prefix}] Catalog unavailable while adding product [{ProductId}] for buyer [{BuyerId}]", nameof(BasketService), productId, buyerId.Value);
            return new UpsertItemResult.CatalogUnavailable();
        }

        if (product is null)
        {
            return new UpsertItemResult.ProductNotFound(productId);
        }

        if (product.AvailableStock == 0)
        {
            return new UpsertItemResult.OutOfStock(product.Id, product.Name);
        }

        var basket = await GetAsync(buyerId, cancellationToken);
        var applied = basket.UpsertItem(product.Id, product.Name, product.Price, quantity, product.AvailableStock);
        await store.SaveAsync(basket, cancellationToken);

        if (applied < quantity)
        {
            logger.LogWarning("[{Prefix}] Capped product [{ProductId}] at [{Applied}] of requested [{Requested}] for buyer [{BuyerId}]", nameof(BasketService), product.Id, applied, quantity, buyerId.Value);
        }
        else
        {
            logger.LogInformation("[{Prefix}] Set product [{ProductId}] quantity [{Quantity}] for buyer [{BuyerId}]", nameof(BasketService), product.Id, applied, buyerId.Value);
        }

        return new UpsertItemResult.Success(basket, quantity, applied);
    }

    public async Task<ShoppingBasket> RemoveItemAsync(BuyerId buyerId, Guid productId, CancellationToken cancellationToken)
    {
        var basket = await GetAsync(buyerId, cancellationToken);
        if (basket.RemoveItem(productId))
        {
            await store.SaveAsync(basket, cancellationToken);
            logger.LogInformation("[{Prefix}] Removed product [{ProductId}] for buyer [{BuyerId}]", nameof(BasketService), productId, buyerId.Value);
        }

        return basket;
    }
}
```

Replace `tests/Ecommerce.Basket.Api.Tests/Features/BasketServiceTests.cs` with:

```csharp
using Ecommerce.Basket.Api.Domain;
using Ecommerce.ServiceDefaults.Api;
using Ecommerce.Basket.Api.Features;
using Ecommerce.Basket.Api.Infrastructure;
using Ecommerce.Basket.Api.Tests.Fakes;
using Microsoft.Extensions.Logging.Abstractions;

namespace Ecommerce.Basket.Api.Tests.Features;

public sealed class BasketServiceTests
{
    private static readonly BuyerId Buyer = new(Guid.Parse("b0000000-0000-4000-8000-000000000001"));
    private static readonly CatalogProduct Mug = new(Guid.Parse("a0000000-0000-4000-8000-000000000001"), "Aspire Ceramic Mug", 12.50m, 25);
    private static readonly CatalogProduct Poster = new(Guid.Parse("a0000000-0000-4000-8000-000000000010"), "Aspire Launch Poster", 15.00m, 2);
    private static readonly CatalogProduct LimitedHoodie = new(Guid.Parse("a0000000-0000-4000-8000-000000000006"), "Aspire Limited Edition Hoodie", 59.00m, 0);

    private readonly InMemoryBasketStore _store = new();
    private readonly FakeCatalogClient _catalog = new FakeCatalogClient().With(Mug).With(Poster).With(LimitedHoodie);

    private BasketService CreateService() => new(_store, _catalog, NullLogger<BasketService>.Instance);

    [Fact]
    public async Task GetAsync_WithoutStoredBasket_ReturnsEmptyBasketForBuyer()
    {
        var basket = await CreateService().GetAsync(Buyer, TestContext.Current.CancellationToken);

        Assert.Equal(Buyer.Value, basket.BuyerId);
        Assert.Empty(basket.Items);
        Assert.Equal(0, _store.SaveCount);
    }

    [Fact]
    public async Task UpsertItemAsync_WithKnownProduct_StoresLineWithCatalogPrice()
    {
        var result = await CreateService().UpsertItemAsync(Buyer, Mug.Id, 2, TestContext.Current.CancellationToken);

        var success = Assert.IsType<UpsertItemResult.Success>(result);
        Assert.False(success.Capped);
        Assert.Equal(2, success.AppliedQuantity);
        var item = Assert.Single(success.Basket.Items);
        Assert.Equal(12.50m, item.UnitPrice);
        Assert.Equal("Aspire Ceramic Mug", item.ProductName);
        Assert.Equal(1, _store.SaveCount);
    }

    [Fact]
    public async Task UpsertItemAsync_BeyondStock_CapsAndFlags()
    {
        var result = await CreateService().UpsertItemAsync(Buyer, Poster.Id, 5, TestContext.Current.CancellationToken);

        var success = Assert.IsType<UpsertItemResult.Success>(result);
        Assert.True(success.Capped);
        Assert.Equal(5, success.RequestedQuantity);
        Assert.Equal(2, success.AppliedQuantity);
    }

    [Fact]
    public async Task UpsertItemAsync_WithUnknownProduct_ReturnsProductNotFound()
    {
        var unknown = Guid.Parse("a0000000-0000-4000-8000-0000000000ff");

        var result = await CreateService().UpsertItemAsync(Buyer, unknown, 1, TestContext.Current.CancellationToken);

        var notFound = Assert.IsType<UpsertItemResult.ProductNotFound>(result);
        Assert.Equal(unknown, notFound.ProductId);
        Assert.Equal(0, _store.SaveCount);
    }

    [Fact]
    public async Task UpsertItemAsync_WithOutOfStockProduct_ReturnsOutOfStock()
    {
        var result = await CreateService().UpsertItemAsync(Buyer, LimitedHoodie.Id, 1, TestContext.Current.CancellationToken);

        var outOfStock = Assert.IsType<UpsertItemResult.OutOfStock>(result);
        Assert.Equal("Aspire Limited Edition Hoodie", outOfStock.ProductName);
        Assert.Equal(0, _store.SaveCount);
    }

    [Fact]
    public async Task UpsertItemAsync_WhenCatalogUnavailable_ReturnsCatalogUnavailable()
    {
        _catalog.Unavailable = true;

        var result = await CreateService().UpsertItemAsync(Buyer, Mug.Id, 1, TestContext.Current.CancellationToken);

        Assert.IsType<UpsertItemResult.CatalogUnavailable>(result);
        Assert.Equal(0, _store.SaveCount);
    }

    [Fact]
    public async Task RemoveItemAsync_RemovesLineAndSaves()
    {
        var service = CreateService();
        await service.UpsertItemAsync(Buyer, Mug.Id, 2, TestContext.Current.CancellationToken);

        var basket = await service.RemoveItemAsync(Buyer, Mug.Id, TestContext.Current.CancellationToken);

        Assert.Empty(basket.Items);
        Assert.Equal(2, _store.SaveCount);
    }

    [Fact]
    public async Task RemoveItemAsync_WithUnknownLine_ReturnsBasketWithoutSaving()
    {
        var basket = await CreateService().RemoveItemAsync(Buyer, Mug.Id, TestContext.Current.CancellationToken);

        Assert.Empty(basket.Items);
        Assert.Equal(0, _store.SaveCount);
    }
}
```

The endpoint files and `Program.cs` already import `Ecommerce.ServiceDefaults.Api` and need no change.

- [ ] **Step 5: Add the Wolverine telemetry to ServiceDefaults**

Replace `src/Ecommerce.ServiceDefaults/Extensions.cs` with the template file plus two additions, the `.AddMeter("Wolverine*")` in metrics and `.AddSource("Wolverine")` in tracing:

```csharp
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.ServiceDiscovery;
using OpenTelemetry;
using OpenTelemetry.Metrics;
using OpenTelemetry.Trace;

namespace Microsoft.Extensions.Hosting;

// Adds common Aspire services: service discovery, resilience, health checks, and OpenTelemetry.
// This project should be referenced by each service project in your solution.
// To learn more about using this project, see https://aka.ms/aspire/service-defaults
public static class Extensions
{
    private const string HealthEndpointPath = "/health";
    private const string AlivenessEndpointPath = "/alive";

    public static TBuilder AddServiceDefaults<TBuilder>(this TBuilder builder) where TBuilder : IHostApplicationBuilder
    {
        builder.ConfigureOpenTelemetry();

        builder.AddDefaultHealthChecks();

        builder.Services.AddServiceDiscovery();

        builder.Services.ConfigureHttpClientDefaults(http =>
        {
            // Turn on resilience by default
            http.AddStandardResilienceHandler();

            // Turn on service discovery by default
            http.AddServiceDiscovery();
        });

        // Uncomment the following to restrict the allowed schemes for service discovery.
        // builder.Services.Configure<ServiceDiscoveryOptions>(options =>
        // {
        //     options.AllowedSchemes = ["https"];
        // });

        return builder;
    }

    public static TBuilder ConfigureOpenTelemetry<TBuilder>(this TBuilder builder) where TBuilder : IHostApplicationBuilder
    {
        builder.Logging.AddOpenTelemetry(logging =>
        {
            logging.IncludeFormattedMessage = true;
            logging.IncludeScopes = true;
        });

        builder.Services.AddOpenTelemetry()
            .WithMetrics(metrics =>
            {
                metrics.AddAspNetCoreInstrumentation()
                    .AddHttpClientInstrumentation()
                    .AddRuntimeInstrumentation()
                    .AddMeter("Wolverine*");
            })
            .WithTracing(tracing =>
            {
                tracing.AddSource(builder.Environment.ApplicationName)
                    .AddSource("Wolverine")
                    .AddAspNetCoreInstrumentation(tracing =>
                        // Exclude health check requests from tracing
                        tracing.Filter = context =>
                            !context.Request.Path.StartsWithSegments(HealthEndpointPath)
                            && !context.Request.Path.StartsWithSegments(AlivenessEndpointPath)
                    )
                    // Uncomment the following line to enable gRPC instrumentation (requires the OpenTelemetry.Instrumentation.GrpcNetClient package)
                    //.AddGrpcClientInstrumentation()
                    .AddHttpClientInstrumentation();
            });

        builder.AddOpenTelemetryExporters();

        return builder;
    }

    private static TBuilder AddOpenTelemetryExporters<TBuilder>(this TBuilder builder) where TBuilder : IHostApplicationBuilder
    {
        var useOtlpExporter = !string.IsNullOrWhiteSpace(builder.Configuration["OTEL_EXPORTER_OTLP_ENDPOINT"]);

        if (useOtlpExporter)
        {
            builder.Services.AddOpenTelemetry().UseOtlpExporter();
        }

        // Uncomment the following lines to enable the Azure Monitor exporter (requires the Azure.Monitor.OpenTelemetry.AspNetCore package)
        //if (!string.IsNullOrEmpty(builder.Configuration["APPLICATIONINSIGHTS_CONNECTION_STRING"]))
        //{
        //    builder.Services.AddOpenTelemetry()
        //       .UseAzureMonitor();
        //}

        return builder;
    }

    public static TBuilder AddDefaultHealthChecks<TBuilder>(this TBuilder builder) where TBuilder : IHostApplicationBuilder
    {
        builder.Services.AddHealthChecks()
            // Add a default liveness check to ensure app is responsive
            .AddCheck("self", () => HealthCheckResult.Healthy(), ["live"]);

        return builder;
    }

    public static WebApplication MapDefaultEndpoints(this WebApplication app)
    {
        // Adding health checks endpoints to applications in non-development environments has security implications.
        // See https://aka.ms/aspire/healthchecks for details before enabling these endpoints in non-development environments.
        if (app.Environment.IsDevelopment())
        {
            // All health checks must pass for app to be considered ready to accept traffic after starting
            app.MapHealthChecks(HealthEndpointPath);

            // Only health checks tagged with the "live" tag must pass for app to be considered alive
            app.MapHealthChecks(AlivenessEndpointPath, new HealthCheckOptions
            {
                Predicate = r => r.Tags.Contains("live")
            });
        }

        return app;
    }
}
```

- [ ] **Step 6: Run every test and build**

```bash
dotnet test
dotnet build
```

Expected: 32 ServiceDefaults tests, 19 Basket tests and 22 Catalog tests pass, 73 in total, with `0 Warning(s)`.

### Task 4.1.2: Contracts project

**Files:**
- Create: `src/Ecommerce.Contracts/Ecommerce.Contracts.csproj`
- Create: `src/Ecommerce.Contracts/OrderPlaced.cs`
- Create: `src/Ecommerce.Contracts/OrderPaid.cs`

**Interfaces:**
- Consumes: nothing.
- Produces: `OrderPlaced`, `OrderBuyer`, `OrderAddress`, `OrderCard`, `OrderLine`, `OrderPaid` and `OrderPaidLine` records in namespace `Ecommerce.Contracts`. `OrderPaid` is consumed in phase 5.

- [ ] **Step 1: Create the project**

`src/Ecommerce.Contracts/Ecommerce.Contracts.csproj`:

```xml
<Project Sdk="Microsoft.NET.Sdk">

</Project>
```

`src/Ecommerce.Contracts/OrderPlaced.cs`:

```csharp
namespace Ecommerce.Contracts;

public sealed record OrderBuyer(string Name, string Email);

public sealed record OrderAddress(string Street, string City, string PostalCode, string Country);

// The full test card number travels here because the simulator has no tokenization step; no service persists it
public sealed record OrderCard(string Number, string HolderName);

public sealed record OrderLine(Guid ProductId, string ProductName, decimal UnitPrice, int Quantity);

public sealed record OrderPlaced(
    Guid OrderId,
    Guid BuyerId,
    OrderBuyer Buyer,
    OrderAddress ShippingAddress,
    OrderCard Card,
    IReadOnlyList<OrderLine> Lines,
    decimal Total,
    string Currency,
    DateTimeOffset PlacedAt);
```

`src/Ecommerce.Contracts/OrderPaid.cs`:

```csharp
namespace Ecommerce.Contracts;

public sealed record OrderPaidLine(Guid ProductId, int Quantity);

public sealed record OrderPaid(Guid OrderId, IReadOnlyList<OrderPaidLine> Lines, DateTimeOffset PaidAt);
```

- [ ] **Step 2: Add to the solution and build**

```bash
dotnet sln add src/Ecommerce.Contracts
dotnet build
```

Expected: `Build succeeded.` with `0 Warning(s)`.

---

## Sub-phase 4.2 Checkout (backend-dev)

### Task 4.2.1: Catalog batch lookup, outbox publisher, packages and fakes

**Files:**
- Modify: `Directory.Packages.props`
- Modify: `src/Ecommerce.Basket.Api/Ecommerce.Basket.Api.csproj`
- Modify: `tests/Ecommerce.Basket.Api.Tests/Ecommerce.Basket.Api.Tests.csproj`
- Modify: `src/Ecommerce.Basket.Api/Infrastructure/ICatalogClient.cs`
- Modify: `src/Ecommerce.Basket.Api/Infrastructure/CatalogClient.cs`
- Create: `src/Ecommerce.Basket.Api/Infrastructure/IOrderPlacedPublisher.cs`
- Create: `src/Ecommerce.Basket.Api/Infrastructure/WolverineOrderPlacedPublisher.cs`
- Modify: `src/Ecommerce.Basket.Api/ErrorCodes.cs`
- Modify: `tests/Ecommerce.Basket.Api.Tests/Fakes/FakeCatalogClient.cs`
- Create: `tests/Ecommerce.Basket.Api.Tests/Fakes/FakeOrderPlacedPublisher.cs`

**Interfaces:**
- Consumes: `ApiResponse<T>`, `OrderPlaced`, Wolverine's `IMessageBus`.
- Produces: `ICatalogClient.GetProductsAsync(IReadOnlyCollection<Guid>, ct)` returning only the products the Catalog knows; `OutboxUnavailableException`; `IOrderPlacedPublisher.PublishAsync(OrderPlaced, ct)`; `WolverineOrderPlacedPublisher` wrapping `IMessageBus.PublishAsync` and translating any failure into `OutboxUnavailableException`; the three new error codes; fakes with `Unavailable` switches and, for the publisher, a `Published` list.

- [ ] **Step 1: Add the package versions**

In `Directory.Packages.props`, add a `Messaging` group directly before the `Basket` group, an `Ordering` group directly after it, and one line to the `Tests` group:

```xml
  <ItemGroup Label="Messaging">
    <PackageVersion Include="WolverineFx" Version="6.36.0" />
    <PackageVersion Include="WolverineFx.RabbitMQ" Version="6.36.0" />
    <PackageVersion Include="WolverineFx.RuntimeCompilation" Version="6.36.0" />
    <PackageVersion Include="WolverineFx.Postgresql" Version="6.36.0" />
  </ItemGroup>
```

```xml
  <ItemGroup Label="Ordering">
    <PackageVersion Include="Aspire.MongoDB.Driver" Version="13.5.3" />
  </ItemGroup>
```

```xml
    <PackageVersion Include="Microsoft.Extensions.TimeProvider.Testing" Version="10.10.0" />
```

- [ ] **Step 2: Replace the two project files**

`src/Ecommerce.Basket.Api/Ecommerce.Basket.Api.csproj`:

```xml
<Project Sdk="Microsoft.NET.Sdk.Web">

  <ItemGroup>
    <PackageReference Include="Aspire.StackExchange.Redis" />
    <PackageReference Include="WolverineFx" />
    <PackageReference Include="WolverineFx.RabbitMQ" />
    <PackageReference Include="WolverineFx.RuntimeCompilation" />
    <PackageReference Include="WolverineFx.Postgresql" />
  </ItemGroup>

  <ItemGroup>
    <ProjectReference Include="../Ecommerce.Contracts/Ecommerce.Contracts.csproj" />
    <ProjectReference Include="../Ecommerce.ServiceDefaults/Ecommerce.ServiceDefaults.csproj" />
  </ItemGroup>

</Project>
```

`tests/Ecommerce.Basket.Api.Tests/Ecommerce.Basket.Api.Tests.csproj`:

```xml
<Project Sdk="Microsoft.NET.Sdk">

  <PropertyGroup>
    <OutputType>Exe</OutputType>
    <IsPackable>false</IsPackable>
    <IsTestProject>true</IsTestProject>
  </PropertyGroup>

  <ItemGroup>
    <PackageReference Include="xunit.v3" />
    <PackageReference Include="Microsoft.Extensions.TimeProvider.Testing" />
  </ItemGroup>

  <ItemGroup>
    <Using Include="Xunit" />
  </ItemGroup>

  <ItemGroup>
    <ProjectReference Include="../../src/Ecommerce.Basket.Api/Ecommerce.Basket.Api.csproj" />
  </ItemGroup>

</Project>
```

- [ ] **Step 3: Write the infrastructure**

`src/Ecommerce.Basket.Api/Infrastructure/ICatalogClient.cs`:

```csharp
namespace Ecommerce.Basket.Api.Infrastructure;

public sealed record CatalogProduct(Guid Id, string Name, decimal Price, int AvailableStock);

// Thrown when the catalog cannot be reached after the resilience handler gave up
public sealed class CatalogUnavailableException(Exception inner) : Exception("The catalog service is unavailable", inner);

public interface ICatalogClient
{
    // Returns null when the catalog has no such product; throws CatalogUnavailableException when the catalog cannot be reached
    Task<CatalogProduct?> GetProductAsync(Guid productId, CancellationToken cancellationToken);

    // Returns only the products the catalog knows; throws CatalogUnavailableException when the catalog cannot be reached
    Task<IReadOnlyList<CatalogProduct>> GetProductsAsync(IReadOnlyCollection<Guid> productIds, CancellationToken cancellationToken);
}
```

`src/Ecommerce.Basket.Api/Infrastructure/CatalogClient.cs`:

```csharp
using System.Net;
using System.Net.Http.Json;
using Ecommerce.ServiceDefaults.Api;
using Polly.CircuitBreaker;
using Polly.Timeout;

namespace Ecommerce.Basket.Api.Infrastructure;

public sealed class CatalogClient(HttpClient httpClient) : ICatalogClient
{
    public async Task<CatalogProduct?> GetProductAsync(Guid productId, CancellationToken cancellationToken)
    {
        try
        {
            using var response = await httpClient.GetAsync($"/api/catalog/products/{productId}", cancellationToken);
            if (response.StatusCode == HttpStatusCode.NotFound)
            {
                return null;
            }

            response.EnsureSuccessStatusCode();
            var envelope = await response.Content.ReadFromJsonAsync<ApiResponse<CatalogProduct>>(cancellationToken);
            return envelope?.Data;
        }
        catch (Exception exception) when (IsTransport(exception))
        {
            throw new CatalogUnavailableException(exception);
        }
    }

    public async Task<IReadOnlyList<CatalogProduct>> GetProductsAsync(IReadOnlyCollection<Guid> productIds, CancellationToken cancellationToken)
    {
        if (productIds.Count == 0)
        {
            return [];
        }

        var query = string.Join("&", productIds.Select(id => $"ids={id}"));
        try
        {
            var envelope = await httpClient.GetFromJsonAsync<ApiResponse<List<CatalogProduct>>>($"/api/catalog/products?{query}", cancellationToken);
            return envelope?.Data ?? [];
        }
        catch (Exception exception) when (IsTransport(exception))
        {
            throw new CatalogUnavailableException(exception);
        }
    }

    private static bool IsTransport(Exception exception) =>
        exception is HttpRequestException or TimeoutRejectedException or BrokenCircuitException;
}
```

`src/Ecommerce.Basket.Api/Infrastructure/IOrderPlacedPublisher.cs`:

```csharp
using Ecommerce.Contracts;

namespace Ecommerce.Basket.Api.Infrastructure;

// Thrown when the event cannot be handed to the durable outbox, which is the only way a checkout cannot be submitted
public sealed class OutboxUnavailableException(Exception inner) : Exception("The order could not be stored for delivery", inner);

public interface IOrderPlacedPublisher
{
    Task PublishAsync(OrderPlaced orderPlaced, CancellationToken cancellationToken);
}
```

`src/Ecommerce.Basket.Api/Infrastructure/WolverineOrderPlacedPublisher.cs`:

```csharp
using Ecommerce.Contracts;
using Wolverine;

namespace Ecommerce.Basket.Api.Infrastructure;

// The exchange is a durable outbox endpoint in Program.cs: PublishAsync persists the envelope in the message store
// before returning, and Wolverine delivers it to the broker as soon as the broker is reachable
public sealed class WolverineOrderPlacedPublisher(IMessageBus bus) : IOrderPlacedPublisher
{
    public async Task PublishAsync(OrderPlaced orderPlaced, CancellationToken cancellationToken)
    {
        try
        {
            await bus.PublishAsync(orderPlaced);
        }
        catch (Exception exception) when (exception is not OperationCanceledException)
        {
            throw new OutboxUnavailableException(exception);
        }
    }
}
```

`src/Ecommerce.Basket.Api/ErrorCodes.cs`:

```csharp
namespace Ecommerce.Basket.Api;

public static class ErrorCodes
{
    public const string ProductNotFound = "basket.product_not_found";
    public const string ProductOutOfStock = "basket.product_out_of_stock";
    public const string CatalogUnavailable = "basket.catalog_unavailable";
    public const string CheckoutEmpty = "basket.checkout_empty";
    public const string CheckoutOutOfStock = "basket.checkout_out_of_stock";
    public const string OutboxUnavailable = "basket.outbox_unavailable";
}
```

- [ ] **Step 4: Update the fakes**

`tests/Ecommerce.Basket.Api.Tests/Fakes/FakeCatalogClient.cs`:

```csharp
using Ecommerce.Basket.Api.Infrastructure;

namespace Ecommerce.Basket.Api.Tests.Fakes;

public sealed class FakeCatalogClient : ICatalogClient
{
    private readonly Dictionary<Guid, CatalogProduct> _products = [];

    public bool Unavailable { get; set; }

    public FakeCatalogClient With(CatalogProduct product)
    {
        _products[product.Id] = product;
        return this;
    }

    public Task<CatalogProduct?> GetProductAsync(Guid productId, CancellationToken cancellationToken)
    {
        ThrowIfUnavailable();
        return Task.FromResult(_products.GetValueOrDefault(productId));
    }

    public Task<IReadOnlyList<CatalogProduct>> GetProductsAsync(IReadOnlyCollection<Guid> productIds, CancellationToken cancellationToken)
    {
        ThrowIfUnavailable();
        IReadOnlyList<CatalogProduct> found = productIds.Where(_products.ContainsKey).Select(id => _products[id]).ToList();
        return Task.FromResult(found);
    }

    private void ThrowIfUnavailable()
    {
        if (Unavailable)
        {
            throw new CatalogUnavailableException(new HttpRequestException("Catalog unreachable"));
        }
    }
}
```

`tests/Ecommerce.Basket.Api.Tests/Fakes/FakeOrderPlacedPublisher.cs`:

```csharp
using Ecommerce.Basket.Api.Infrastructure;
using Ecommerce.Contracts;

namespace Ecommerce.Basket.Api.Tests.Fakes;

public sealed class FakeOrderPlacedPublisher : IOrderPlacedPublisher
{
    public List<OrderPlaced> Published { get; } = [];

    public bool Unavailable { get; set; }

    public Task PublishAsync(OrderPlaced orderPlaced, CancellationToken cancellationToken)
    {
        if (Unavailable)
        {
            throw new OutboxUnavailableException(new InvalidOperationException("Message store unreachable"));
        }

        Published.Add(orderPlaced);
        return Task.CompletedTask;
    }
}
```

- [ ] **Step 5: Build and run the Basket tests**

```bash
dotnet build
dotnet test --project tests/Ecommerce.Basket.Api.Tests
```

Expected: `0 Warning(s)`, 19 tests still passing.

### Task 4.2.2: CheckoutService, checkout endpoint and the outbox-backed composition root, test-first

**Files:**
- Create: `tests/Ecommerce.Basket.Api.Tests/Features/CheckoutServiceTests.cs`
- Create: `tests/Ecommerce.Basket.Api.Tests/Features/CheckoutEndpointTests.cs`
- Create: `src/Ecommerce.Basket.Api/Features/Checkout/CheckoutService.cs`
- Create: `src/Ecommerce.Basket.Api/Features/Checkout/CheckoutEndpoint.cs`
- Modify: `src/Ecommerce.Basket.Api/Program.cs`

**Interfaces:**
- Consumes: everything from task 4.2.1, `ShoppingBasket`, `IBasketStore.DeleteAsync`, `TimeProvider`.
- Produces:
  - `CheckoutDetails`, `UnavailableLine`, `CheckoutResult` with cases `Placed(OrderId, Total)`, `EmptyBasket`, `OutOfStock(Lines)`, `CatalogUnavailable`, `OutboxUnavailable`; `CheckoutService.CheckoutAsync(BuyerId, CheckoutDetails, ct)` which re-reads every line from the Catalog, rejects lines beyond stock or no longer in the catalog, builds `OrderPlaced` with a version 7 id and the current Catalog prices, publishes it, then deletes the basket. The basket is kept on every failure.
  - `POST /api/basket/checkout` with `CheckoutRequest(Buyer, ShippingAddress, Card)` validated by data annotations on the nested records (name 2 to 100 characters, email address, address fields, card number exactly 16 digits), answering 202 with `CheckoutResponse(OrderId, Total, Currency)`, or 400 `basket.checkout_empty`, 409 `basket.checkout_out_of_stock` with the unavailable lines as details, 503 `basket.catalog_unavailable` or 503 `basket.outbox_unavailable`.
  - The final `Program.cs`: Wolverine with `PersistMessagesWithPostgresql` on the `basketdb` connection string and schema `wolverine`, the RabbitMQ transport from the `messaging` connection with `AutoProvision`, and `OrderPlaced` published to the `order-placed` exchange with `UseDurableOutbox`, so the message is stored before `PublishAsync` returns and delivered whenever the broker is reachable.

- [ ] **Step 1: Write the failing tests**

`tests/Ecommerce.Basket.Api.Tests/Features/CheckoutServiceTests.cs`:

```csharp
using Ecommerce.Basket.Api.Domain;
using Ecommerce.Basket.Api.Features.Checkout;
using Ecommerce.Basket.Api.Infrastructure;
using Ecommerce.Basket.Api.Tests.Fakes;
using Ecommerce.Contracts;
using Ecommerce.ServiceDefaults.Api;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Extensions.Time.Testing;

namespace Ecommerce.Basket.Api.Tests.Features;

public sealed class CheckoutServiceTests
{
    private static readonly BuyerId Buyer = new(Guid.Parse("b0000000-0000-4000-8000-000000000001"));
    private static readonly CatalogProduct Mug = new(Guid.Parse("a0000000-0000-4000-8000-000000000001"), "Aspire Ceramic Mug", 12.50m, 25);
    private static readonly CatalogProduct Poster = new(Guid.Parse("a0000000-0000-4000-8000-000000000010"), "Aspire Launch Poster", 15.00m, 2);
    private static readonly CheckoutDetails Details = new(
        new OrderBuyer("Goran", "goran@example.com"),
        new OrderAddress("Main Street 1", "Belgrade", "11000", "Serbia"),
        new OrderCard("4242424242424242", "Goran"));
    private static readonly DateTimeOffset Now = new(2026, 9, 12, 12, 0, 0, TimeSpan.Zero);

    private readonly InMemoryBasketStore _store = new();
    private readonly FakeCatalogClient _catalog = new FakeCatalogClient().With(Mug).With(Poster);
    private readonly FakeOrderPlacedPublisher _publisher = new();

    private CheckoutService CreateService() =>
        new(_store, _catalog, _publisher, new FakeTimeProvider(Now), NullLogger<CheckoutService>.Instance);

    private async Task SeedBasketAsync(params (CatalogProduct Product, int Quantity, decimal StoredPrice)[] lines)
    {
        var basket = new ShoppingBasket(Buyer.Value);
        foreach (var (product, quantity, storedPrice) in lines)
        {
            basket.UpsertItem(product.Id, product.Name, storedPrice, quantity, 99);
        }

        await _store.SaveAsync(basket, TestContext.Current.CancellationToken);
    }

    [Fact]
    public async Task CheckoutAsync_WithoutBasket_ReturnsEmptyBasket()
    {
        var result = await CreateService().CheckoutAsync(Buyer, Details, TestContext.Current.CancellationToken);

        Assert.IsType<CheckoutResult.EmptyBasket>(result);
        Assert.Empty(_publisher.Published);
    }

    [Fact]
    public async Task CheckoutAsync_PublishesOrderWithCurrentCatalogPricesAndClearsBasket()
    {
        await SeedBasketAsync((Mug, 2, 10.00m), (Poster, 1, 15.00m));

        var result = await CreateService().CheckoutAsync(Buyer, Details, TestContext.Current.CancellationToken);

        var placed = Assert.IsType<CheckoutResult.Placed>(result);
        var message = Assert.Single(_publisher.Published);
        Assert.Equal(placed.OrderId, message.OrderId);
        Assert.Equal(Buyer.Value, message.BuyerId);
        Assert.Equal(40.00m, placed.Total);
        Assert.Equal(40.00m, message.Total);
        Assert.Equal("EUR", message.Currency);
        Assert.Equal(Now, message.PlacedAt);
        Assert.Equal(12.50m, message.Lines.Single(line => line.ProductId == Mug.Id).UnitPrice);
        Assert.Equal("4242424242424242", message.Card.Number);
        Assert.Null(await _store.GetAsync(Buyer.Value, TestContext.Current.CancellationToken));
    }

    [Fact]
    public async Task CheckoutAsync_WithLineBeyondStock_ReturnsOutOfStockAndKeepsBasket()
    {
        await SeedBasketAsync((Mug, 1, 12.50m), (Poster, 3, 15.00m));

        var result = await CreateService().CheckoutAsync(Buyer, Details, TestContext.Current.CancellationToken);

        var outOfStock = Assert.IsType<CheckoutResult.OutOfStock>(result);
        var line = Assert.Single(outOfStock.Lines);
        Assert.Equal(Poster.Id, line.ProductId);
        Assert.Equal(3, line.Requested);
        Assert.Equal(2, line.Available);
        Assert.Empty(_publisher.Published);
        Assert.NotNull(await _store.GetAsync(Buyer.Value, TestContext.Current.CancellationToken));
    }

    [Fact]
    public async Task CheckoutAsync_WithProductNoLongerInCatalog_ReportsItWithZeroAvailable()
    {
        var vanished = new CatalogProduct(Guid.Parse("a0000000-0000-4000-8000-0000000000ee"), "Vanished", 1m, 1);
        await SeedBasketAsync((vanished, 1, 1m));

        var result = await CreateService().CheckoutAsync(Buyer, Details, TestContext.Current.CancellationToken);

        var outOfStock = Assert.IsType<CheckoutResult.OutOfStock>(result);
        Assert.Equal(0, Assert.Single(outOfStock.Lines).Available);
    }

    [Fact]
    public async Task CheckoutAsync_WhenCatalogUnavailable_ReturnsCatalogUnavailable()
    {
        await SeedBasketAsync((Mug, 1, 12.50m));
        _catalog.Unavailable = true;

        var result = await CreateService().CheckoutAsync(Buyer, Details, TestContext.Current.CancellationToken);

        Assert.IsType<CheckoutResult.CatalogUnavailable>(result);
        Assert.NotNull(await _store.GetAsync(Buyer.Value, TestContext.Current.CancellationToken));
    }

    [Fact]
    public async Task CheckoutAsync_WhenOutboxUnavailable_ReturnsOutboxUnavailableAndKeepsBasket()
    {
        await SeedBasketAsync((Mug, 1, 12.50m));
        _publisher.Unavailable = true;

        var result = await CreateService().CheckoutAsync(Buyer, Details, TestContext.Current.CancellationToken);

        Assert.IsType<CheckoutResult.OutboxUnavailable>(result);
        Assert.NotNull(await _store.GetAsync(Buyer.Value, TestContext.Current.CancellationToken));
    }
}
```

`tests/Ecommerce.Basket.Api.Tests/Features/CheckoutEndpointTests.cs`:

```csharp
using Ecommerce.Basket.Api.Domain;
using Ecommerce.Basket.Api.Features.Checkout;
using Ecommerce.Basket.Api.Infrastructure;
using Ecommerce.Basket.Api.Tests.Fakes;
using Ecommerce.ServiceDefaults.Api;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Extensions.Time.Testing;

namespace Ecommerce.Basket.Api.Tests.Features;

public sealed class CheckoutEndpointTests
{
    private static readonly BuyerId Buyer = new(Guid.Parse("b0000000-0000-4000-8000-000000000001"));
    private static readonly CatalogProduct Mug = new(Guid.Parse("a0000000-0000-4000-8000-000000000001"), "Aspire Ceramic Mug", 12.50m, 25);
    private static readonly CheckoutRequest Request = new(
        new CheckoutBuyer("Goran", "goran@example.com"),
        new CheckoutAddress("Main Street 1", "Belgrade", "11000", "Serbia"),
        new CheckoutCard("4242424242424242", "Goran"));

    private readonly InMemoryBasketStore _store = new();
    private readonly FakeOrderPlacedPublisher _publisher = new();

    private CheckoutService CreateService() =>
        new(_store, new FakeCatalogClient().With(Mug), _publisher, new FakeTimeProvider(), NullLogger<CheckoutService>.Instance);

    [Fact]
    public async Task HandleAsync_WithEmptyBasket_ReturnsBadRequestEnvelope()
    {
        var result = await CheckoutEndpoint.HandleAsync(Buyer, Request, CreateService(), TestContext.Current.CancellationToken);

        var badRequest = Assert.IsType<BadRequest<ApiResponse>>(result.Result);
        Assert.Equal("basket.checkout_empty", badRequest.Value?.Error?.Code);
    }

    [Fact]
    public async Task HandleAsync_WithItems_ReturnsAcceptedWithOrderId()
    {
        var basket = new ShoppingBasket(Buyer.Value);
        basket.UpsertItem(Mug.Id, Mug.Name, Mug.Price, 2, Mug.AvailableStock);
        await _store.SaveAsync(basket, TestContext.Current.CancellationToken);

        var result = await CheckoutEndpoint.HandleAsync(Buyer, Request, CreateService(), TestContext.Current.CancellationToken);

        var accepted = Assert.IsType<Accepted<ApiResponse<CheckoutResponse>>>(result.Result);
        Assert.Equal(StatusCodes.Status202Accepted, accepted.StatusCode);
        Assert.NotNull(accepted.Value?.Data);
        Assert.Equal(25.00m, accepted.Value.Data.Total);
        Assert.Equal("EUR", accepted.Value.Data.Currency);
        Assert.Equal(accepted.Value.Data.OrderId, Assert.Single(_publisher.Published).OrderId);
    }

    [Fact]
    public async Task HandleAsync_WhenOutboxUnavailable_ReturnsServiceUnavailableEnvelope()
    {
        var basket = new ShoppingBasket(Buyer.Value);
        basket.UpsertItem(Mug.Id, Mug.Name, Mug.Price, 1, Mug.AvailableStock);
        await _store.SaveAsync(basket, TestContext.Current.CancellationToken);
        _publisher.Unavailable = true;

        var result = await CheckoutEndpoint.HandleAsync(Buyer, Request, CreateService(), TestContext.Current.CancellationToken);

        var unavailable = Assert.IsType<JsonHttpResult<ApiResponse>>(result.Result);
        Assert.Equal(StatusCodes.Status503ServiceUnavailable, unavailable.StatusCode);
        Assert.Equal("basket.outbox_unavailable", unavailable.Value?.Error?.Code);
    }
}
```

- [ ] **Step 2: Run the Basket tests and confirm they fail to compile**

```bash
dotnet test --project tests/Ecommerce.Basket.Api.Tests
```

Expected: compile errors naming the `Ecommerce.Basket.Api.Features.Checkout` namespace as missing.

- [ ] **Step 3: Implement**

`src/Ecommerce.Basket.Api/Features/Checkout/CheckoutService.cs`:

```csharp
using Ecommerce.Basket.Api.Domain;
using Ecommerce.Basket.Api.Infrastructure;
using Ecommerce.Contracts;
using Ecommerce.ServiceDefaults.Api;

namespace Ecommerce.Basket.Api.Features.Checkout;

public sealed record CheckoutDetails(OrderBuyer Buyer, OrderAddress ShippingAddress, OrderCard Card);

public sealed record UnavailableLine(Guid ProductId, string ProductName, int Requested, int Available);

public abstract record CheckoutResult
{
    public sealed record Placed(Guid OrderId, decimal Total) : CheckoutResult;

    public sealed record EmptyBasket : CheckoutResult;

    public sealed record OutOfStock(IReadOnlyList<UnavailableLine> Lines) : CheckoutResult;

    public sealed record CatalogUnavailable : CheckoutResult;

    public sealed record OutboxUnavailable : CheckoutResult;
}

public sealed class CheckoutService(
    IBasketStore store,
    ICatalogClient catalog,
    IOrderPlacedPublisher publisher,
    TimeProvider timeProvider,
    ILogger<CheckoutService> logger)
{
    public const string Currency = "EUR";

    public async Task<CheckoutResult> CheckoutAsync(BuyerId buyerId, CheckoutDetails details, CancellationToken cancellationToken)
    {
        var basket = await store.GetAsync(buyerId.Value, cancellationToken);
        if (basket is null || basket.Items.Count == 0)
        {
            return new CheckoutResult.EmptyBasket();
        }

        IReadOnlyList<CatalogProduct> products;
        try
        {
            products = await catalog.GetProductsAsync(basket.Items.Select(item => item.ProductId).ToList(), cancellationToken);
        }
        catch (CatalogUnavailableException exception)
        {
            logger.LogWarning(exception, "[{Prefix}] Catalog unavailable during checkout for buyer [{BuyerId}]", nameof(CheckoutService), buyerId.Value);
            return new CheckoutResult.CatalogUnavailable();
        }

        var byId = products.ToDictionary(product => product.Id);
        var unavailable = basket.Items
            .Select(item => byId.TryGetValue(item.ProductId, out var product)
                ? new UnavailableLine(item.ProductId, product.Name, item.Quantity, product.AvailableStock)
                : new UnavailableLine(item.ProductId, item.ProductName, item.Quantity, 0))
            .Where(line => line.Available < line.Requested)
            .ToList();
        if (unavailable.Count > 0)
        {
            logger.LogWarning("[{Prefix}] Checkout blocked for buyer [{BuyerId}], [{Count}] lines exceed stock", nameof(CheckoutService), buyerId.Value, unavailable.Count);
            return new CheckoutResult.OutOfStock(unavailable);
        }

        var lines = basket.Items
            .Select(item => new OrderLine(item.ProductId, byId[item.ProductId].Name, byId[item.ProductId].Price, item.Quantity))
            .ToList();
        var orderPlaced = new OrderPlaced(
            Guid.CreateVersion7(),
            buyerId.Value,
            details.Buyer,
            details.ShippingAddress,
            details.Card,
            lines,
            lines.Sum(line => line.UnitPrice * line.Quantity),
            Currency,
            timeProvider.GetUtcNow());

        try
        {
            await publisher.PublishAsync(orderPlaced, cancellationToken);
        }
        catch (OutboxUnavailableException exception)
        {
            logger.LogWarning(exception, "[{Prefix}] Outbox unavailable, order [{OrderId}] for buyer [{BuyerId}] not placed, basket kept", nameof(CheckoutService), orderPlaced.OrderId, buyerId.Value);
            return new CheckoutResult.OutboxUnavailable();
        }

        await store.DeleteAsync(buyerId.Value, cancellationToken);
        logger.LogInformation("[{Prefix}] Published OrderPlaced for order [{OrderId}] buyer [{BuyerId}] total [{Total}]", nameof(CheckoutService), orderPlaced.OrderId, buyerId.Value, orderPlaced.Total);
        return new CheckoutResult.Placed(orderPlaced.OrderId, orderPlaced.Total);
    }
}
```

`src/Ecommerce.Basket.Api/Features/Checkout/CheckoutEndpoint.cs`:

```csharp
using System.ComponentModel.DataAnnotations;
using Ecommerce.Contracts;
using Ecommerce.ServiceDefaults.Api;
using Microsoft.AspNetCore.Http.HttpResults;

namespace Ecommerce.Basket.Api.Features.Checkout;

public sealed record CheckoutBuyer(
    [property: Required, StringLength(100, MinimumLength = 2)] string Name,
    [property: Required, EmailAddress, StringLength(200)] string Email);

public sealed record CheckoutAddress(
    [property: Required, StringLength(200, MinimumLength = 2)] string Street,
    [property: Required, StringLength(100, MinimumLength = 2)] string City,
    [property: Required, StringLength(20, MinimumLength = 2)] string PostalCode,
    [property: Required, StringLength(100, MinimumLength = 2)] string Country);

public sealed record CheckoutCard(
    [property: Required, RegularExpression(@"^\d{16}$", ErrorMessage = "Card number must be 16 digits")] string Number,
    [property: Required, StringLength(100, MinimumLength = 2)] string HolderName);

public sealed record CheckoutRequest(
    [property: Required] CheckoutBuyer Buyer,
    [property: Required] CheckoutAddress ShippingAddress,
    [property: Required] CheckoutCard Card);

public sealed record CheckoutResponse(Guid OrderId, decimal Total, string Currency);

public static class CheckoutEndpoint
{
    public static RouteGroupBuilder MapCheckout(this RouteGroupBuilder group)
    {
        group.MapPost("/checkout", HandleAsync).WithName("Checkout");
        return group;
    }

    public static async Task<Results<Accepted<ApiResponse<CheckoutResponse>>, BadRequest<ApiResponse>, Conflict<ApiResponse>, JsonHttpResult<ApiResponse>>> HandleAsync(
        BuyerId buyerId,
        CheckoutRequest request,
        CheckoutService service,
        CancellationToken cancellationToken)
    {
        var details = new CheckoutDetails(
            new OrderBuyer(request.Buyer.Name, request.Buyer.Email),
            new OrderAddress(request.ShippingAddress.Street, request.ShippingAddress.City, request.ShippingAddress.PostalCode, request.ShippingAddress.Country),
            new OrderCard(request.Card.Number, request.Card.HolderName));

        var result = await service.CheckoutAsync(buyerId, details, cancellationToken);

        return result switch
        {
            CheckoutResult.Placed placed => ApiResults.Accepted(new CheckoutResponse(placed.OrderId, placed.Total, CheckoutService.Currency)),
            CheckoutResult.EmptyBasket => ApiResults.BadRequest(ErrorCodes.CheckoutEmpty, "The basket is empty"),
            CheckoutResult.OutOfStock outOfStock => ApiResults.Conflict(ErrorCodes.CheckoutOutOfStock, $"[{outOfStock.Lines.Count}] lines exceed the available stock", outOfStock.Lines),
            CheckoutResult.CatalogUnavailable => ApiResults.ServiceUnavailable(ErrorCodes.CatalogUnavailable, "The catalog service is unavailable"),
            CheckoutResult.OutboxUnavailable => ApiResults.ServiceUnavailable(ErrorCodes.OutboxUnavailable, "The order could not be submitted, the basket was kept"),
            _ => throw new InvalidOperationException($"Unhandled result [{result.GetType().Name}]"),
        };
    }
}
```

- [ ] **Step 4: Replace `Program.cs`**

```csharp
using Ecommerce.Basket.Api.Features;
using Ecommerce.Basket.Api.Features.Checkout;
using Ecommerce.Basket.Api.Features.GetBasket;
using Ecommerce.Basket.Api.Features.RemoveItem;
using Ecommerce.Basket.Api.Features.UpsertItem;
using Ecommerce.Basket.Api.Infrastructure;
using Ecommerce.Contracts;
using Ecommerce.ServiceDefaults.Api;
using Wolverine;
using Wolverine.Postgresql;
using Wolverine.RabbitMQ;

var builder = WebApplication.CreateBuilder(args);

builder.AddServiceDefaults();
builder.AddApiDefaults();
builder.Services.AddValidation();
builder.AddRedisClient("basket-cache");
builder.Services.AddSingleton<IBasketStore, RedisBasketStore>();
builder.Services.AddHttpClient<ICatalogClient, CatalogClient>(client => client.BaseAddress = new Uri("https+http://catalog-api"));
builder.Services.AddSingleton(TimeProvider.System);
builder.Services.AddScoped<IOrderPlacedPublisher, WolverineOrderPlacedPublisher>();
builder.Services.AddScoped<BasketService>();
builder.Services.AddScoped<CheckoutService>();

builder.UseWolverine(options =>
{
    // The outbox tables live in the basket's own database; a message is persisted there before PublishAsync returns
    options.PersistMessagesWithPostgresql(builder.Configuration.GetConnectionString("basketdb")!, "wolverine");
    options.UseRabbitMqUsingNamedConnection("messaging").AutoProvision();
    options.PublishMessage<OrderPlaced>().ToRabbitExchange("order-placed").UseDurableOutbox();
});

var app = builder.Build();

app.UseApiDefaults();

var basket = app.MapGroup("/api/basket").WithTags("Basket").AddEndpointFilter<BuyerIdFilter>();
basket.MapGetBasket();
basket.MapUpsertItem();
basket.MapRemoveItem();
basket.MapCheckout();

app.Run();
```

- [ ] **Step 5: Run every test and build**

```bash
dotnet test
dotnet build
```

Expected: 28 Basket tests, 32 ServiceDefaults tests and 22 Catalog tests pass, 82 in total, with `0 Warning(s)`.

---

## Sub-phase 4.3 Ordering service (backend-dev)

### Task 4.3.1: Ordering project, order document, Mongo store, serialization and initializer, test-first

**Files:**
- Create: `src/Ecommerce.Ordering.Api/Ecommerce.Ordering.Api.csproj`
- Create: `src/Ecommerce.Ordering.Api/Program.cs` (intermediate version, replaced in task 4.4.1)
- Create: `src/Ecommerce.Ordering.Api/appsettings.json`
- Create: `src/Ecommerce.Ordering.Api/appsettings.Development.json`
- Create: `src/Ecommerce.Ordering.Api/Properties/launchSettings.json`
- Create: `src/Ecommerce.Ordering.Api/ErrorCodes.cs`
- Create: `src/Ecommerce.Ordering.Api/Domain/Order.cs`
- Create: `src/Ecommerce.Ordering.Api/Infrastructure/IOrderStore.cs`
- Create: `src/Ecommerce.Ordering.Api/Infrastructure/MongoOrderStore.cs`
- Create: `src/Ecommerce.Ordering.Api/Infrastructure/MongoSerialization.cs`
- Create: `src/Ecommerce.Ordering.Api/Infrastructure/OrderingDbInitializer.cs`
- Create: `tests/Ecommerce.Ordering.Api.Tests/Ecommerce.Ordering.Api.Tests.csproj`
- Create: `tests/Ecommerce.Ordering.Api.Tests/TestOrders.cs`
- Create: `tests/Ecommerce.Ordering.Api.Tests/Fakes/InMemoryOrderStore.cs`
- Create: `tests/Ecommerce.Ordering.Api.Tests/Domain/OrderTests.cs`

**Interfaces:**
- Consumes: `OrderPlaced`, `IMongoDatabase` from the Aspire MongoDB integration.
- Produces, in `Ecommerce.Ordering.Api`:
  - `OrderStatus` (`Submitted`, `Paid`, `Shipped`, `PaymentFailed`), `OrderBuyerInfo`, `OrderAddressInfo`, `OrderLineInfo`, and the `Order` document with the fields from ARCHITECTURE.md 4.4 including `NextAttemptAt`, `LeaseUntil`, `PaymentAttempts` and `PaidEventPublished` for the phase 5 processor; `Order.FromPlaced(OrderPlaced, DateTimeOffset now)` keeps only the last four card digits.
  - `IOrderStore` with `InsertIfAbsentAsync` (false on a duplicate id), `ListForBuyerAsync` (newest first) and `GetAsync(buyerId, orderId)`; `MongoOrderStore` on collection `orders`.
  - `MongoSerialization.Register()` applying camelCase element names, ignore-extra-elements, string enums and the standard GUID representation, called once at the top of `Program.cs`.
  - `OrderingDbInitializer` creating the `buyer_created` and `status_next_attempt` indexes at startup.
  - Test helpers `TestOrders` and `InMemoryOrderStore`.

- [ ] **Step 1: Create the project files**

Create the folders `src/Ecommerce.Ordering.Api`, `src/Ecommerce.Ordering.Api/Properties` and `tests/Ecommerce.Ordering.Api.Tests`.

`src/Ecommerce.Ordering.Api/Ecommerce.Ordering.Api.csproj`:

```xml
<Project Sdk="Microsoft.NET.Sdk.Web">

  <ItemGroup>
    <PackageReference Include="Aspire.MongoDB.Driver" />
    <PackageReference Include="WolverineFx" />
    <PackageReference Include="WolverineFx.RabbitMQ" />
    <PackageReference Include="WolverineFx.RuntimeCompilation" />
  </ItemGroup>

  <ItemGroup>
    <ProjectReference Include="../Ecommerce.Contracts/Ecommerce.Contracts.csproj" />
    <ProjectReference Include="../Ecommerce.ServiceDefaults/Ecommerce.ServiceDefaults.csproj" />
  </ItemGroup>

</Project>
```

`src/Ecommerce.Ordering.Api/Program.cs`, the intermediate composition root:

```csharp
using Ecommerce.ServiceDefaults.Api;

var builder = WebApplication.CreateBuilder(args);

builder.AddServiceDefaults();
builder.AddApiDefaults();
builder.Services.AddValidation();

var app = builder.Build();

app.UseApiDefaults();

app.Run();
```

`src/Ecommerce.Ordering.Api/appsettings.json`:

```json
{
  "Logging": {
    "LogLevel": {
      "Default": "Information",
      "Microsoft.AspNetCore": "Warning"
    }
  },
  "AllowedHosts": "*"
}
```

`src/Ecommerce.Ordering.Api/appsettings.Development.json`:

```json
{
  "Logging": {
    "LogLevel": {
      "Default": "Information",
      "Microsoft.AspNetCore": "Warning"
    }
  }
}
```

`src/Ecommerce.Ordering.Api/Properties/launchSettings.json`:

```json
{
  "$schema": "https://json.schemastore.org/launchsettings.json",
  "profiles": {
    "https": {
      "commandName": "Project",
      "dotnetRunMessages": true,
      "launchBrowser": false,
      "applicationUrl": "https://localhost:7130;http://localhost:5130",
      "environmentVariables": {
        "ASPNETCORE_ENVIRONMENT": "Development"
      }
    },
    "http": {
      "commandName": "Project",
      "dotnetRunMessages": true,
      "launchBrowser": false,
      "applicationUrl": "http://localhost:5130",
      "environmentVariables": {
        "ASPNETCORE_ENVIRONMENT": "Development"
      }
    }
  }
}
```

`src/Ecommerce.Ordering.Api/ErrorCodes.cs`:

```csharp
namespace Ecommerce.Ordering.Api;

public static class ErrorCodes
{
    public const string OrderNotFound = "orders.not_found";
}
```

`tests/Ecommerce.Ordering.Api.Tests/Ecommerce.Ordering.Api.Tests.csproj`:

```xml
<Project Sdk="Microsoft.NET.Sdk">

  <PropertyGroup>
    <OutputType>Exe</OutputType>
    <IsPackable>false</IsPackable>
    <IsTestProject>true</IsTestProject>
  </PropertyGroup>

  <ItemGroup>
    <PackageReference Include="xunit.v3" />
    <PackageReference Include="Microsoft.Extensions.TimeProvider.Testing" />
  </ItemGroup>

  <ItemGroup>
    <Using Include="Xunit" />
  </ItemGroup>

  <ItemGroup>
    <ProjectReference Include="../../src/Ecommerce.Ordering.Api/Ecommerce.Ordering.Api.csproj" />
  </ItemGroup>

</Project>
```

```bash
dotnet sln add src/Ecommerce.Ordering.Api tests/Ecommerce.Ordering.Api.Tests
dotnet build
```

Expected: `Build succeeded.` with `0 Warning(s)`.

- [ ] **Step 2: Write the failing test and its helpers**

`tests/Ecommerce.Ordering.Api.Tests/TestOrders.cs`:

```csharp
using Ecommerce.Contracts;

namespace Ecommerce.Ordering.Api.Tests;

public static class TestOrders
{
    public static readonly Guid BuyerId = Guid.Parse("b0000000-0000-4000-8000-000000000001");
    public static readonly Guid OrderId = Guid.Parse("c0000000-0000-4000-8000-000000000001");
    public static readonly DateTimeOffset PlacedAt = new(2026, 9, 12, 12, 0, 0, TimeSpan.Zero);

    public static OrderPlaced Placed(Guid? orderId = null) =>
        new(
            orderId ?? OrderId,
            BuyerId,
            new OrderBuyer("Goran", "goran@example.com"),
            new OrderAddress("Main Street 1", "Belgrade", "11000", "Serbia"),
            new OrderCard("4242424242424242", "Goran"),
            [
                new OrderLine(Guid.Parse("a0000000-0000-4000-8000-000000000001"), "Aspire Ceramic Mug", 12.50m, 2),
                new OrderLine(Guid.Parse("a0000000-0000-4000-8000-000000000010"), "Aspire Launch Poster", 15.00m, 1),
            ],
            40.00m,
            "EUR",
            PlacedAt);
}
```

`tests/Ecommerce.Ordering.Api.Tests/Fakes/InMemoryOrderStore.cs`:

```csharp
using Ecommerce.Ordering.Api.Domain;
using Ecommerce.Ordering.Api.Infrastructure;

namespace Ecommerce.Ordering.Api.Tests.Fakes;

public sealed class InMemoryOrderStore : IOrderStore
{
    public Dictionary<Guid, Order> Orders { get; } = [];

    public Task<bool> InsertIfAbsentAsync(Order order, CancellationToken cancellationToken) =>
        Task.FromResult(Orders.TryAdd(order.Id, order));

    public Task<IReadOnlyList<Order>> ListForBuyerAsync(Guid buyerId, CancellationToken cancellationToken)
    {
        IReadOnlyList<Order> orders = Orders.Values.Where(order => order.BuyerId == buyerId).OrderByDescending(order => order.CreatedAt).ToList();
        return Task.FromResult(orders);
    }

    public Task<Order?> GetAsync(Guid buyerId, Guid orderId, CancellationToken cancellationToken) =>
        Task.FromResult(Orders.TryGetValue(orderId, out var order) && order.BuyerId == buyerId ? order : null);
}
```

`tests/Ecommerce.Ordering.Api.Tests/Domain/OrderTests.cs`:

```csharp
using Ecommerce.Ordering.Api.Domain;

namespace Ecommerce.Ordering.Api.Tests.Domain;

public sealed class OrderTests
{
    [Fact]
    public void FromPlaced_CopiesTheSnapshotAndStartsSubmitted()
    {
        var now = TestOrders.PlacedAt.AddSeconds(1);

        var order = Order.FromPlaced(TestOrders.Placed(), now);

        Assert.Equal(TestOrders.OrderId, order.Id);
        Assert.Equal(TestOrders.BuyerId, order.BuyerId);
        Assert.Equal("Goran", order.Buyer.Name);
        Assert.Equal("Belgrade", order.ShippingAddress.City);
        Assert.Equal(2, order.Lines.Count);
        Assert.Equal(25.00m, order.Lines[0].LineTotal);
        Assert.Equal(40.00m, order.Total);
        Assert.Equal("EUR", order.Currency);
        Assert.Equal(OrderStatus.Submitted, order.Status);
        Assert.Equal(TestOrders.PlacedAt, order.CreatedAt);
        Assert.Equal(now, order.NextAttemptAt);
        Assert.Null(order.LeaseUntil);
        Assert.False(order.PaidEventPublished);
    }

    [Fact]
    public void FromPlaced_KeepsOnlyTheLastFourCardDigits()
    {
        var order = Order.FromPlaced(TestOrders.Placed(), TestOrders.PlacedAt);

        Assert.Equal("4242", order.CardLast4);
    }
}
```

```bash
dotnet test --project tests/Ecommerce.Ordering.Api.Tests
```

Expected: compile errors naming the `Ecommerce.Ordering.Api.Domain` and `Ecommerce.Ordering.Api.Infrastructure` namespaces as missing.

- [ ] **Step 3: Implement the domain and the infrastructure**

`src/Ecommerce.Ordering.Api/Domain/Order.cs`:

```csharp
using Ecommerce.Contracts;

namespace Ecommerce.Ordering.Api.Domain;

public enum OrderStatus
{
    Submitted,
    Paid,
    Shipped,
    PaymentFailed,
}

public sealed record OrderBuyerInfo(string Name, string Email);

public sealed record OrderAddressInfo(string Street, string City, string PostalCode, string Country);

public sealed record OrderLineInfo(Guid ProductId, string ProductName, decimal UnitPrice, int Quantity)
{
    public decimal LineTotal => UnitPrice * Quantity;
}

// The point-in-time snapshot of a purchase; the MongoDB driver materializes it through the property setters
public sealed class Order
{
    public required Guid Id { get; init; }

    public required Guid BuyerId { get; init; }

    public required OrderBuyerInfo Buyer { get; init; }

    public required OrderAddressInfo ShippingAddress { get; init; }

    public required string CardLast4 { get; init; }

    public required IReadOnlyList<OrderLineInfo> Lines { get; init; }

    public required decimal Total { get; init; }

    public required string Currency { get; init; }

    public OrderStatus Status { get; set; } = OrderStatus.Submitted;

    public required DateTimeOffset CreatedAt { get; init; }

    public DateTimeOffset? PaidAt { get; set; }

    public DateTimeOffset? ShippedAt { get; set; }

    public string? FailureReason { get; set; }

    public string? PaymentReference { get; set; }

    public int PaymentAttempts { get; set; }

    public required DateTimeOffset NextAttemptAt { get; set; }

    public DateTimeOffset? LeaseUntil { get; set; }

    public bool PaidEventPublished { get; set; }

    public static Order FromPlaced(OrderPlaced placed, DateTimeOffset now) =>
        new()
        {
            Id = placed.OrderId,
            BuyerId = placed.BuyerId,
            Buyer = new OrderBuyerInfo(placed.Buyer.Name, placed.Buyer.Email),
            ShippingAddress = new OrderAddressInfo(placed.ShippingAddress.Street, placed.ShippingAddress.City, placed.ShippingAddress.PostalCode, placed.ShippingAddress.Country),
            CardLast4 = placed.Card.Number.Length >= 4 ? placed.Card.Number[^4..] : placed.Card.Number,
            Lines = placed.Lines.Select(line => new OrderLineInfo(line.ProductId, line.ProductName, line.UnitPrice, line.Quantity)).ToList(),
            Total = placed.Total,
            Currency = placed.Currency,
            CreatedAt = placed.PlacedAt,
            NextAttemptAt = now,
        };
}
```

`src/Ecommerce.Ordering.Api/Infrastructure/IOrderStore.cs`:

```csharp
using Ecommerce.Ordering.Api.Domain;

namespace Ecommerce.Ordering.Api.Infrastructure;

public interface IOrderStore
{
    // Returns false when an order with the same id already exists, so a redelivered event changes nothing
    Task<bool> InsertIfAbsentAsync(Order order, CancellationToken cancellationToken);

    Task<IReadOnlyList<Order>> ListForBuyerAsync(Guid buyerId, CancellationToken cancellationToken);

    Task<Order?> GetAsync(Guid buyerId, Guid orderId, CancellationToken cancellationToken);
}
```

`src/Ecommerce.Ordering.Api/Infrastructure/MongoOrderStore.cs`:

```csharp
using Ecommerce.Ordering.Api.Domain;
using MongoDB.Driver;

namespace Ecommerce.Ordering.Api.Infrastructure;

public sealed class MongoOrderStore(IMongoDatabase database) : IOrderStore
{
    public const string CollectionName = "orders";

    private readonly IMongoCollection<Order> _orders = database.GetCollection<Order>(CollectionName);

    public async Task<bool> InsertIfAbsentAsync(Order order, CancellationToken cancellationToken)
    {
        try
        {
            await _orders.InsertOneAsync(order, cancellationToken: cancellationToken);
            return true;
        }
        catch (MongoWriteException exception) when (exception.WriteError.Category == ServerErrorCategory.DuplicateKey)
        {
            return false;
        }
    }

    public async Task<IReadOnlyList<Order>> ListForBuyerAsync(Guid buyerId, CancellationToken cancellationToken) =>
        await _orders.Find(order => order.BuyerId == buyerId)
            .SortByDescending(order => order.CreatedAt)
            .ToListAsync(cancellationToken);

    public Task<Order?> GetAsync(Guid buyerId, Guid orderId, CancellationToken cancellationToken) =>
        _orders.Find(order => order.Id == orderId && order.BuyerId == buyerId).FirstOrDefaultAsync(cancellationToken)!;
}
```

`src/Ecommerce.Ordering.Api/Infrastructure/MongoSerialization.cs`:

```csharp
using MongoDB.Bson;
using MongoDB.Bson.Serialization;
using MongoDB.Bson.Serialization.Conventions;
using MongoDB.Bson.Serialization.Serializers;

namespace Ecommerce.Ordering.Api.Infrastructure;

// Driver-wide serialization rules, registered once before the first document is mapped
public static class MongoSerialization
{
    private static bool _registered;

    public static void Register()
    {
        if (_registered)
        {
            return;
        }

        BsonSerializer.RegisterSerializer(new GuidSerializer(GuidRepresentation.Standard));
        ConventionRegistry.Register(
            "ecommerce",
            new ConventionPack
            {
                new CamelCaseElementNameConvention(),
                new IgnoreExtraElementsConvention(true),
                new EnumRepresentationConvention(BsonType.String),
            },
            _ => true);
        _registered = true;
    }
}
```

`src/Ecommerce.Ordering.Api/Infrastructure/OrderingDbInitializer.cs`:

```csharp
using Ecommerce.Ordering.Api.Domain;
using MongoDB.Driver;

namespace Ecommerce.Ordering.Api.Infrastructure;

// Creates the indexes the read endpoints and the order processor rely on
public sealed class OrderingDbInitializer(IMongoDatabase database, ILogger<OrderingDbInitializer> logger) : IHostedService
{
    public async Task StartAsync(CancellationToken cancellationToken)
    {
        var orders = database.GetCollection<Order>(MongoOrderStore.CollectionName);
        var byBuyer = new CreateIndexModel<Order>(
            Builders<Order>.IndexKeys.Ascending(order => order.BuyerId).Descending(order => order.CreatedAt),
            new CreateIndexOptions { Name = "buyer_created" });
        var dueForProcessing = new CreateIndexModel<Order>(
            Builders<Order>.IndexKeys.Ascending(order => order.Status).Ascending(order => order.NextAttemptAt),
            new CreateIndexOptions { Name = "status_next_attempt" });

        await orders.Indexes.CreateManyAsync([byBuyer, dueForProcessing], cancellationToken);
        logger.LogInformation("[{Prefix}] Ensured indexes on collection [{Collection}]", nameof(OrderingDbInitializer), MongoOrderStore.CollectionName);
    }

    public Task StopAsync(CancellationToken cancellationToken) => Task.CompletedTask;
}
```

- [ ] **Step 4: Run the tests and build**

```bash
dotnet test --project tests/Ecommerce.Ordering.Api.Tests
dotnet build
```

Expected: `Passed!` with 2 succeeded, `0 Warning(s)`.

### Task 4.3.2: OrderPlacedHandler, test-first

**Files:**
- Create: `tests/Ecommerce.Ordering.Api.Tests/Messaging/OrderPlacedHandlerTests.cs`
- Create: `src/Ecommerce.Ordering.Api/Messaging/OrderPlacedHandler.cs`

**Interfaces:**
- Consumes: `Order.FromPlaced`, `IOrderStore`, `TimeProvider`.
- Produces: `OrderPlacedHandler.HandleAsync(OrderPlaced, IOrderStore, TimeProvider, ILogger<OrderPlacedHandler>, CancellationToken)` which inserts the order if absent and logs either the stored order or the ignored redelivery. Wolverine discovers it by the class and method names.

- [ ] **Step 1: Write the failing tests**

`tests/Ecommerce.Ordering.Api.Tests/Messaging/OrderPlacedHandlerTests.cs`:

```csharp
using Ecommerce.Ordering.Api.Messaging;
using Ecommerce.Ordering.Api.Tests.Fakes;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Extensions.Time.Testing;

namespace Ecommerce.Ordering.Api.Tests.Messaging;

public sealed class OrderPlacedHandlerTests
{
    private readonly InMemoryOrderStore _store = new();
    private readonly FakeTimeProvider _time = new(TestOrders.PlacedAt.AddSeconds(2));

    [Fact]
    public async Task HandleAsync_StoresTheOrder()
    {
        await OrderPlacedHandler.HandleAsync(TestOrders.Placed(), _store, _time, NullLogger<OrderPlacedHandler>.Instance, TestContext.Current.CancellationToken);

        var order = Assert.Single(_store.Orders.Values);
        Assert.Equal(TestOrders.OrderId, order.Id);
        Assert.Equal(_time.GetUtcNow(), order.NextAttemptAt);
    }

    [Fact]
    public async Task HandleAsync_IgnoresRedelivery()
    {
        await OrderPlacedHandler.HandleAsync(TestOrders.Placed(), _store, _time, NullLogger<OrderPlacedHandler>.Instance, TestContext.Current.CancellationToken);
        _store.Orders[TestOrders.OrderId].Status = Ecommerce.Ordering.Api.Domain.OrderStatus.Paid;

        await OrderPlacedHandler.HandleAsync(TestOrders.Placed(), _store, _time, NullLogger<OrderPlacedHandler>.Instance, TestContext.Current.CancellationToken);

        Assert.Single(_store.Orders);
        Assert.Equal(Ecommerce.Ordering.Api.Domain.OrderStatus.Paid, _store.Orders[TestOrders.OrderId].Status);
    }
}
```

- [ ] **Step 2: Run the tests and confirm they fail to compile**

```bash
dotnet test --project tests/Ecommerce.Ordering.Api.Tests
```

Expected: a compile error naming the `Ecommerce.Ordering.Api.Messaging` namespace as missing.

- [ ] **Step 3: Implement the handler**

`src/Ecommerce.Ordering.Api/Messaging/OrderPlacedHandler.cs`:

```csharp
using Ecommerce.Contracts;
using Ecommerce.Ordering.Api.Domain;
using Ecommerce.Ordering.Api.Infrastructure;

namespace Ecommerce.Ordering.Api.Messaging;

public sealed class OrderPlacedHandler
{
    public static async Task HandleAsync(
        OrderPlaced message,
        IOrderStore store,
        TimeProvider timeProvider,
        ILogger<OrderPlacedHandler> logger,
        CancellationToken cancellationToken)
    {
        var order = Order.FromPlaced(message, timeProvider.GetUtcNow());
        var inserted = await store.InsertIfAbsentAsync(order, cancellationToken);
        if (inserted)
        {
            logger.LogInformation("[{Prefix}] Stored order [{OrderId}] for buyer [{BuyerId}] with [{Lines}] lines total [{Total}]", nameof(OrderPlacedHandler), order.Id, order.BuyerId, order.Lines.Count, order.Total);
        }
        else
        {
            logger.LogInformation("[{Prefix}] Order [{OrderId}] already stored, redelivery ignored", nameof(OrderPlacedHandler), order.Id);
        }
    }
}
```

- [ ] **Step 4: Run the tests and confirm they pass**

```bash
dotnet test --project tests/Ecommerce.Ordering.Api.Tests
```

Expected: `Passed!` with 4 succeeded, no warnings.

---

## Sub-phase 4.4 Ordering read endpoints and wiring (backend-dev)

### Task 4.4.1: OrderResponse, list and get endpoints, composition root, gateway route and AppHost wiring, test-first

**Files:**
- Create: `tests/Ecommerce.Ordering.Api.Tests/Features/OrderEndpointsTests.cs`
- Create: `src/Ecommerce.Ordering.Api/Features/OrderResponse.cs`
- Create: `src/Ecommerce.Ordering.Api/Features/ListOrders/ListOrdersEndpoint.cs`
- Create: `src/Ecommerce.Ordering.Api/Features/GetOrder/GetOrderEndpoint.cs`
- Modify: `src/Ecommerce.Ordering.Api/Program.cs`
- Modify: `src/Ecommerce.Gateway/appsettings.json`
- Modify: `src/Ecommerce.AppHost/Ecommerce.AppHost.csproj`
- Modify: `src/Ecommerce.AppHost/AppHost.cs`

**Interfaces:**
- Consumes: `IOrderStore`, `BuyerId`, `BuyerIdFilter`, `ApiResults`.
- Produces: `OrderResponse` with `OrderLineResponse`; `GET /api/orders` (the buyer's orders newest first) and `GET /api/orders/{id}` (404 `orders.not_found` for unknown ids or another buyer's order); the final Ordering `Program.cs` with the Mongo client for `orderingdb`, the store, the initializer, and Wolverine listening on `ordering.order-placed` bound to the `order-placed` exchange with inline processing; the gateway route `orders` (order 0) to `https+http://ordering-api`; the AppHost with `basketdb`, `basket-api` referencing `basketdb` and `messaging`, `ordering-api` referencing `orderingdb` and `messaging`, and the gateway referencing `ordering-api`.

- [ ] **Step 1: Write the failing tests**

`tests/Ecommerce.Ordering.Api.Tests/Features/OrderEndpointsTests.cs`:

```csharp
using Ecommerce.Ordering.Api.Domain;
using Ecommerce.Ordering.Api.Features;
using Ecommerce.Ordering.Api.Features.GetOrder;
using Ecommerce.Ordering.Api.Features.ListOrders;
using Ecommerce.Ordering.Api.Tests.Fakes;
using Ecommerce.ServiceDefaults.Api;
using Microsoft.AspNetCore.Http.HttpResults;

namespace Ecommerce.Ordering.Api.Tests.Features;

public sealed class OrderEndpointsTests
{
    private static readonly BuyerId Buyer = new(TestOrders.BuyerId);
    private readonly InMemoryOrderStore _store = new();

    [Fact]
    public async Task ListOrders_ReturnsTheBuyersOrdersNewestFirst()
    {
        var older = Order.FromPlaced(TestOrders.Placed(Guid.Parse("c0000000-0000-4000-8000-000000000001")), TestOrders.PlacedAt);
        var newer = Order.FromPlaced(TestOrders.Placed(Guid.Parse("c0000000-0000-4000-8000-000000000002")) with { PlacedAt = TestOrders.PlacedAt.AddMinutes(5) }, TestOrders.PlacedAt);
        _store.Orders[older.Id] = older;
        _store.Orders[newer.Id] = newer;

        var result = await ListOrdersEndpoint.HandleAsync(Buyer, _store, TestContext.Current.CancellationToken);

        Assert.NotNull(result.Value?.Data);
        Assert.Equal([newer.Id, older.Id], result.Value.Data.Select(order => order.Id));
        Assert.Equal("Submitted", result.Value.Data[0].Status);
    }

    [Fact]
    public async Task GetOrder_WithAnotherBuyersOrder_ReturnsNotFound()
    {
        var order = Order.FromPlaced(TestOrders.Placed(), TestOrders.PlacedAt);
        _store.Orders[order.Id] = order;

        var result = await GetOrderEndpoint.HandleAsync(new BuyerId(Guid.NewGuid()), order.Id, _store, TestContext.Current.CancellationToken);

        var notFound = Assert.IsType<NotFound<ApiResponse>>(result.Result);
        Assert.Equal("orders.not_found", notFound.Value?.Error?.Code);
    }

    [Fact]
    public async Task GetOrder_WithOwnOrder_ReturnsIt()
    {
        var order = Order.FromPlaced(TestOrders.Placed(), TestOrders.PlacedAt);
        _store.Orders[order.Id] = order;

        var result = await GetOrderEndpoint.HandleAsync(Buyer, order.Id, _store, TestContext.Current.CancellationToken);

        var ok = Assert.IsType<Ok<ApiResponse<OrderResponse>>>(result.Result);
        Assert.Equal("4242", ok.Value?.Data?.CardLast4);
        Assert.Equal(2, ok.Value?.Data?.Lines.Count);
    }
}
```

- [ ] **Step 2: Run the tests and confirm they fail to compile**

```bash
dotnet test --project tests/Ecommerce.Ordering.Api.Tests
```

Expected: compile errors naming the `Ecommerce.Ordering.Api.Features` namespace as missing.

- [ ] **Step 3: Implement the endpoints**

`src/Ecommerce.Ordering.Api/Features/OrderResponse.cs`:

```csharp
using Ecommerce.Ordering.Api.Domain;

namespace Ecommerce.Ordering.Api.Features;

public sealed record OrderLineResponse(Guid ProductId, string ProductName, decimal UnitPrice, int Quantity, decimal LineTotal);

public sealed record OrderResponse(
    Guid Id,
    string Status,
    decimal Total,
    string Currency,
    DateTimeOffset CreatedAt,
    DateTimeOffset? PaidAt,
    DateTimeOffset? ShippedAt,
    string? FailureReason,
    string CardLast4,
    OrderBuyerInfo Buyer,
    OrderAddressInfo ShippingAddress,
    IReadOnlyList<OrderLineResponse> Lines)
{
    public static OrderResponse From(Order order) =>
        new(
            order.Id,
            order.Status.ToString(),
            order.Total,
            order.Currency,
            order.CreatedAt,
            order.PaidAt,
            order.ShippedAt,
            order.FailureReason,
            order.CardLast4,
            order.Buyer,
            order.ShippingAddress,
            order.Lines.Select(line => new OrderLineResponse(line.ProductId, line.ProductName, line.UnitPrice, line.Quantity, line.LineTotal)).ToList());
}
```

`src/Ecommerce.Ordering.Api/Features/ListOrders/ListOrdersEndpoint.cs`:

```csharp
using Ecommerce.Ordering.Api.Infrastructure;
using Ecommerce.ServiceDefaults.Api;
using Microsoft.AspNetCore.Http.HttpResults;

namespace Ecommerce.Ordering.Api.Features.ListOrders;

public static class ListOrdersEndpoint
{
    public static RouteGroupBuilder MapListOrders(this RouteGroupBuilder group)
    {
        group.MapGet("/", HandleAsync).WithName("ListOrders");
        return group;
    }

    public static async Task<Ok<ApiResponse<IReadOnlyList<OrderResponse>>>> HandleAsync(
        BuyerId buyerId,
        IOrderStore store,
        CancellationToken cancellationToken)
    {
        var orders = await store.ListForBuyerAsync(buyerId.Value, cancellationToken);
        IReadOnlyList<OrderResponse> response = orders.Select(OrderResponse.From).ToList();
        return ApiResults.Ok(response);
    }
}
```

`src/Ecommerce.Ordering.Api/Features/GetOrder/GetOrderEndpoint.cs`:

```csharp
using Ecommerce.Ordering.Api.Infrastructure;
using Ecommerce.ServiceDefaults.Api;
using Microsoft.AspNetCore.Http.HttpResults;

namespace Ecommerce.Ordering.Api.Features.GetOrder;

public static class GetOrderEndpoint
{
    public static RouteGroupBuilder MapGetOrder(this RouteGroupBuilder group)
    {
        group.MapGet("/{id:guid}", HandleAsync).WithName("GetOrder");
        return group;
    }

    public static async Task<Results<Ok<ApiResponse<OrderResponse>>, NotFound<ApiResponse>>> HandleAsync(
        BuyerId buyerId,
        Guid id,
        IOrderStore store,
        CancellationToken cancellationToken)
    {
        var order = await store.GetAsync(buyerId.Value, id, cancellationToken);
        if (order is null)
        {
            return ApiResults.NotFound(ErrorCodes.OrderNotFound, $"Order [{id}] not found");
        }

        return ApiResults.Ok(OrderResponse.From(order));
    }
}
```

- [ ] **Step 4: Replace the Ordering `Program.cs`**

```csharp
using Ecommerce.Ordering.Api.Features.GetOrder;
using Ecommerce.Ordering.Api.Features.ListOrders;
using Ecommerce.Ordering.Api.Infrastructure;
using Ecommerce.ServiceDefaults.Api;
using Wolverine;
using Wolverine.RabbitMQ;

MongoSerialization.Register();

var builder = WebApplication.CreateBuilder(args);

builder.AddServiceDefaults();
builder.AddApiDefaults();
builder.Services.AddValidation();
builder.AddMongoDBClient("orderingdb");
builder.Services.AddSingleton(TimeProvider.System);
builder.Services.AddSingleton<IOrderStore, MongoOrderStore>();
builder.Services.AddHostedService<OrderingDbInitializer>();

builder.UseWolverine(options =>
{
    options.UseRabbitMqUsingNamedConnection("messaging")
        .AutoProvision()
        .DeclareExchange("order-placed", exchange => exchange.BindQueue("ordering.order-placed"));
    options.ListenToRabbitQueue("ordering.order-placed").ProcessInline();
});

var app = builder.Build();

app.UseApiDefaults();

var orders = app.MapGroup("/api/orders").WithTags("Orders").AddEndpointFilter<BuyerIdFilter>();
orders.MapListOrders();
orders.MapGetOrder();

app.Run();
```

- [ ] **Step 5: Run every test**

```bash
dotnet test
```

Expected: 7 Ordering tests, 28 Basket, 32 ServiceDefaults and 22 Catalog tests pass, 89 in total.

- [ ] **Step 6: Gateway route and AppHost wiring**

Replace `src/Ecommerce.Gateway/appsettings.json`:

```json
{
  "Logging": {
    "LogLevel": {
      "Default": "Information",
      "Microsoft.AspNetCore": "Warning",
      "Yarp": "Warning"
    }
  },
  "AllowedHosts": "*",
  "ReverseProxy": {
    "Routes": {
      "catalog": {
        "ClusterId": "catalog",
        "Order": 0,
        "Match": {
          "Path": "/api/catalog/{**catch-all}"
        }
      },
      "basket": {
        "ClusterId": "basket",
        "Order": 0,
        "Match": {
          "Path": "/api/basket/{**catch-all}"
        }
      },
      "orders": {
        "ClusterId": "ordering",
        "Order": 0,
        "Match": {
          "Path": "/api/orders/{**catch-all}"
        }
      },
      "frontend": {
        "ClusterId": "frontend",
        "Order": 1000,
        "Match": {
          "Path": "/{**catch-all}"
        }
      }
    },
    "Clusters": {
      "catalog": {
        "Destinations": {
          "catalog-api": {
            "Address": "https+http://catalog-api"
          }
        }
      },
      "basket": {
        "Destinations": {
          "basket-api": {
            "Address": "https+http://basket-api"
          }
        }
      },
      "ordering": {
        "Destinations": {
          "ordering-api": {
            "Address": "https+http://ordering-api"
          }
        }
      },
      "frontend": {
        "Destinations": {
          "frontend": {
            "Address": "http://frontend"
          }
        }
      }
    }
  }
}
```

Replace `src/Ecommerce.AppHost/Ecommerce.AppHost.csproj`:

```xml
<Project Sdk="Aspire.AppHost.Sdk/13.5.3">

  <PropertyGroup>
    <OutputType>Exe</OutputType>
    <AspireUseCliBundle>true</AspireUseCliBundle>
    <UserSecretsId>ecommerce-aspire-demo-apphost</UserSecretsId>
  </PropertyGroup>

  <ItemGroup>
    <PackageReference Include="Aspire.Hosting.PostgreSQL" />
    <PackageReference Include="Aspire.Hosting.Redis" />
    <PackageReference Include="Aspire.Hosting.RabbitMQ" />
    <PackageReference Include="Aspire.Hosting.MongoDB" />
    <PackageReference Include="Aspire.Hosting.JavaScript" />
  </ItemGroup>

  <ItemGroup>
    <ProjectReference Include="../Ecommerce.Catalog.Api/Ecommerce.Catalog.Api.csproj" />
    <ProjectReference Include="../Ecommerce.Basket.Api/Ecommerce.Basket.Api.csproj" />
    <ProjectReference Include="../Ecommerce.Gateway/Ecommerce.Gateway.csproj" />
    <ProjectReference Include="../Ecommerce.Ordering.Api/Ecommerce.Ordering.Api.csproj" />
  </ItemGroup>

</Project>
```

Replace `src/Ecommerce.AppHost/AppHost.cs`:

```csharp
var builder = DistributedApplication.CreateBuilder(args);

var postgres = builder.AddPostgres("postgres");
var catalogDb = postgres.AddDatabase("catalogdb");
var basketDb = postgres.AddDatabase("basketdb");

var redis = builder.AddRedis("basket-cache");

var rabbitMq = builder.AddRabbitMQ("messaging")
    .WithManagementPlugin();

var mongo = builder.AddMongoDB("mongo");
var orderingDb = mongo.AddDatabase("orderingdb");

var catalogApi = builder.AddProject<Projects.Ecommerce_Catalog_Api>("catalog-api")
    .WithReference(catalogDb)
    .WaitFor(catalogDb)
    .WithHttpHealthCheck("/health");

var basketApi = builder.AddProject<Projects.Ecommerce_Basket_Api>("basket-api")
    .WithReference(redis)
    .WaitFor(redis)
    .WithReference(basketDb)
    .WaitFor(basketDb)
    .WithReference(rabbitMq)
    .WaitFor(rabbitMq)
    .WithReference(catalogApi)
    .WaitFor(catalogApi)
    .WithHttpHealthCheck("/health");

var orderingApi = builder.AddProject<Projects.Ecommerce_Ordering_Api>("ordering-api")
    .WithReference(orderingDb)
    .WaitFor(orderingDb)
    .WithReference(rabbitMq)
    .WaitFor(rabbitMq)
    .WithHttpHealthCheck("/health");

var frontend = builder.AddViteApp("frontend", "../ecommerce-frontend");

builder.AddProject<Projects.Ecommerce_Gateway>("gateway")
    .WithReference(catalogApi)
    .WaitFor(catalogApi)
    .WithReference(basketApi)
    .WaitFor(basketApi)
    .WithReference(orderingApi)
    .WaitFor(orderingApi)
    .WithReference(frontend)
    .WithHttpHealthCheck("/health")
    .WithExternalHttpEndpoints();

builder.Build().Run();
```

- [ ] **Step 7: Build**

```bash
dotnet build
```

Expected: `Build succeeded.` with `0 Warning(s)`. Do not run the AppHost; the lead runs phase acceptance.

---

## Sub-phase 4.5 Checkout and orders in the frontend (frontend-dev)

### Task 4.5.1: Order models, checkout on the basket client and store, orders client, test-first

**Files:**
- Modify: `src/ecommerce-frontend/src/app/core/basket-store.spec.ts`
- Create: `src/ecommerce-frontend/src/app/shared/models/order.ts`
- Modify: `src/ecommerce-frontend/src/app/core/api/basket-api.ts`
- Modify: `src/ecommerce-frontend/src/app/core/basket-store.ts`
- Create: `src/ecommerce-frontend/src/app/core/api/orders-api.ts`

**Interfaces:**
- Consumes: `unwrap`, `toApiFailure`, `httpResource`.
- Produces: `CheckoutRequest`, `CheckoutResponse`, `OrderStatus`, `OrderLine` and `Order` interfaces mirroring the backend responses; `BasketApi.checkout(request)`; `BasketStore.checkout(request)` which empties the local basket on success; `OrdersApi.listOrders()` returning an `httpResource<Order[]>` for `GET /api/orders`.

- [ ] **Step 1: Write the failing spec**

Replace `src/app/core/basket-store.spec.ts` with:

```typescript
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';

import { Basket } from '../shared/models/basket';
import { ApiFailure } from './api/api-response';
import { BasketStore } from './basket-store';

const buyerId = 'b0000000-0000-4000-8000-000000000001';
const mugId = 'a0000000-0000-4000-8000-000000000001';

function basketWith(quantity: number): Basket {
  const items =
    quantity === 0
      ? []
      : [
          {
            productId: mugId,
            productName: 'Aspire Ceramic Mug',
            unitPrice: 12.5,
            quantity,
            lineTotal: 12.5 * quantity,
          },
        ];
  return { buyerId, items, itemCount: quantity, total: 12.5 * quantity };
}

describe('BasketStore', () => {
  let store: BasketStore;
  let controller: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting()],
    });
    store = TestBed.inject(BasketStore);
    controller = TestBed.inject(HttpTestingController);
  });

  afterEach(() => controller.verify());

  it('load fills the basket and the count', async () => {
    const loading = store.load();
    controller.expectOne('/api/basket').flush({ success: true, data: basketWith(2), error: null });
    await loading;

    expect(store.count()).toBe(2);
    expect(store.total()).toBe(25);
    expect(store.failure()).toBeNull();
  });

  it('load records a failure instead of throwing', async () => {
    const loading = store.load();
    controller.expectOne('/api/basket').flush(
      {
        success: false,
        data: null,
        error: {
          code: 'common.upstream_unavailable',
          message: 'An upstream service is unavailable',
          details: null,
          traceId: null,
        },
      },
      { status: 504, statusText: 'Gateway Timeout' },
    );
    await loading;

    expect(store.count()).toBe(0);
    expect(store.failure()?.code).toBe('common.upstream_unavailable');
  });

  it('setQuantity sends the line and replaces the basket with the result', async () => {
    const changing = store.setQuantity(mugId, 3);
    const request = controller.expectOne('/api/basket/items');
    expect(request.request.method).toBe('PUT');
    expect(request.request.body).toEqual({ productId: mugId, quantity: 3 });
    request.flush({
      success: true,
      data: { basket: basketWith(3), requestedQuantity: 3, appliedQuantity: 3, capped: false },
      error: null,
    });

    const result = await changing;

    expect(result.capped).toBe(false);
    expect(store.count()).toBe(3);
  });

  it('add requests one more than the current line quantity', async () => {
    const loading = store.load();
    controller.expectOne('/api/basket').flush({ success: true, data: basketWith(2), error: null });
    await loading;

    const adding = store.add(mugId);
    const request = controller.expectOne('/api/basket/items');
    expect(request.request.body).toEqual({ productId: mugId, quantity: 3 });
    request.flush({
      success: true,
      data: { basket: basketWith(3), requestedQuantity: 3, appliedQuantity: 3, capped: false },
      error: null,
    });
    await adding;

    expect(store.count()).toBe(3);
  });

  it('setQuantity throws an ApiFailure carrying the envelope code', async () => {
    const changing = store.setQuantity(mugId, 1);
    controller.expectOne('/api/basket/items').flush(
      {
        success: false,
        data: null,
        error: {
          code: 'basket.product_out_of_stock',
          message: 'Product [Mug] has [0] units available',
          details: null,
          traceId: null,
        },
      },
      { status: 409, statusText: 'Conflict' },
    );

    await expect(changing).rejects.toMatchObject({ code: 'basket.product_out_of_stock' });
    await expect(changing).rejects.toBeInstanceOf(ApiFailure);
    expect(store.busy()).toBe(false);
  });

  it('checkout posts the details and empties the local basket', async () => {
    const loading = store.load();
    controller.expectOne('/api/basket').flush({ success: true, data: basketWith(2), error: null });
    await loading;

    const request = {
      buyer: { name: 'Goran', email: 'goran@example.com' },
      shippingAddress: {
        street: 'Main Street 1',
        city: 'Belgrade',
        postalCode: '11000',
        country: 'Serbia',
      },
      card: { number: '4242424242424242', holderName: 'Goran' },
    };
    const checkingOut = store.checkout(request);
    const call = controller.expectOne('/api/basket/checkout');
    expect(call.request.method).toBe('POST');
    expect(call.request.body).toEqual(request);
    call.flush(
      { success: true, data: { orderId: 'c1', total: 25, currency: 'EUR' }, error: null },
      { status: 202, statusText: 'Accepted' },
    );
    const response = await checkingOut;

    expect(response.orderId).toBe('c1');
    expect(store.count()).toBe(0);
    expect(store.items()).toEqual([]);
  });

  it('remove sends a DELETE and replaces the basket', async () => {
    const removing = store.remove(mugId);
    const request = controller.expectOne(`/api/basket/items/${mugId}`);
    expect(request.request.method).toBe('DELETE');
    request.flush({ success: true, data: basketWith(0), error: null });
    await removing;

    expect(store.count()).toBe(0);
    expect(store.items()).toEqual([]);
  });
});
```

- [ ] **Step 2: Run the tests and confirm they fail**

```bash
npm test
```

Expected: the store spec fails to compile because `checkout` does not exist on `BasketStore`.

- [ ] **Step 3: Implement**

`src/app/shared/models/order.ts`:

```typescript
export interface CheckoutRequest {
  buyer: { name: string; email: string };
  shippingAddress: { street: string; city: string; postalCode: string; country: string };
  card: { number: string; holderName: string };
}

export interface CheckoutResponse {
  orderId: string;
  total: number;
  currency: string;
}

export type OrderStatus = 'Submitted' | 'Paid' | 'Shipped' | 'PaymentFailed';

export interface OrderLine {
  productId: string;
  productName: string;
  unitPrice: number;
  quantity: number;
  lineTotal: number;
}

export interface Order {
  id: string;
  status: OrderStatus;
  total: number;
  currency: string;
  createdAt: string;
  paidAt: string | null;
  shippedAt: string | null;
  failureReason: string | null;
  cardLast4: string;
  buyer: { name: string; email: string };
  shippingAddress: { street: string; city: string; postalCode: string; country: string };
  lines: OrderLine[];
}
```

`src/app/core/api/basket-api.ts`:

```typescript
import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable, firstValueFrom } from 'rxjs';

import { Basket, UpsertItemResult } from '../../shared/models/basket';
import { CheckoutRequest, CheckoutResponse } from '../../shared/models/order';
import { ApiResponse, toApiFailure, unwrap } from './api-response';

@Injectable({ providedIn: 'root' })
export class BasketApi {
  private readonly http = inject(HttpClient);

  get(): Promise<Basket> {
    return this.request(this.http.get<ApiResponse<Basket>>('/api/basket'));
  }

  upsertItem(productId: string, quantity: number): Promise<UpsertItemResult> {
    return this.request(
      this.http.put<ApiResponse<UpsertItemResult>>('/api/basket/items', { productId, quantity }),
    );
  }

  removeItem(productId: string): Promise<Basket> {
    return this.request(this.http.delete<ApiResponse<Basket>>(`/api/basket/items/${productId}`));
  }

  checkout(request: CheckoutRequest): Promise<CheckoutResponse> {
    return this.request(
      this.http.post<ApiResponse<CheckoutResponse>>('/api/basket/checkout', request),
    );
  }

  private async request<T>(call: Observable<ApiResponse<T>>): Promise<T> {
    try {
      return unwrap(await firstValueFrom(call));
    } catch (error) {
      throw toApiFailure(error);
    }
  }
}
```

`src/app/core/basket-store.ts`:

```typescript
import { Injectable, computed, inject, signal } from '@angular/core';

import { Basket, UpsertItemResult } from '../shared/models/basket';
import { CheckoutRequest, CheckoutResponse } from '../shared/models/order';
import { ApiFailure, toApiFailure } from './api/api-response';
import { BasketApi } from './api/basket-api';

// The single source of truth for the basket in the browser; every mutation replaces it with the server's copy
@Injectable({ providedIn: 'root' })
export class BasketStore {
  private readonly api = inject(BasketApi);
  private readonly basketState = signal<Basket | null>(null);
  private readonly busyState = signal(false);
  private readonly failureState = signal<ApiFailure | null>(null);

  readonly basket = this.basketState.asReadonly();
  readonly busy = this.busyState.asReadonly();
  readonly failure = this.failureState.asReadonly();
  readonly items = computed(() => this.basketState()?.items ?? []);
  readonly count = computed(() => this.basketState()?.itemCount ?? 0);
  readonly total = computed(() => this.basketState()?.total ?? 0);

  async load(): Promise<void> {
    this.busyState.set(true);
    try {
      this.basketState.set(await this.api.get());
      this.failureState.set(null);
    } catch (error) {
      this.failureState.set(toApiFailure(error));
    } finally {
      this.busyState.set(false);
    }
  }

  add(productId: string): Promise<UpsertItemResult> {
    const existing = this.items().find((item) => item.productId === productId);
    return this.setQuantity(productId, (existing?.quantity ?? 0) + 1);
  }

  async setQuantity(productId: string, quantity: number): Promise<UpsertItemResult> {
    this.busyState.set(true);
    try {
      const result = await this.api.upsertItem(productId, quantity);
      this.basketState.set(result.basket);
      return result;
    } finally {
      this.busyState.set(false);
    }
  }

  async remove(productId: string): Promise<void> {
    this.busyState.set(true);
    try {
      this.basketState.set(await this.api.removeItem(productId));
    } finally {
      this.busyState.set(false);
    }
  }

  // On success the server has already cleared the basket, so the local copy is emptied too
  async checkout(request: CheckoutRequest): Promise<CheckoutResponse> {
    this.busyState.set(true);
    try {
      const response = await this.api.checkout(request);
      const current = this.basketState();
      this.basketState.set(current ? { ...current, items: [], itemCount: 0, total: 0 } : null);
      return response;
    } finally {
      this.busyState.set(false);
    }
  }
}
```

`src/app/core/api/orders-api.ts`:

```typescript
import { httpResource } from '@angular/common/http';
import { Injectable, Injector, inject } from '@angular/core';

import { Order } from '../../shared/models/order';
import { ApiResponse, unwrap } from './api-response';

@Injectable({ providedIn: 'root' })
export class OrdersApi {
  private readonly injector = inject(Injector);

  listOrders() {
    return httpResource<Order[]>(() => '/api/orders', {
      injector: this.injector,
      parse: (raw) => unwrap(raw as ApiResponse<Order[]>),
    });
  }
}
```

- [ ] **Step 4: Run the tests, then the full check**

```bash
npm test
npm run build
npm run lint
npm run format:check
```

Expected: `Test Files  6 passed (6)` and `Tests  23 passed (23)`; build, lint and format check clean.

### Task 4.5.2: Checkout page, orders page, navigation and routes, test-first

**Files:**
- Create: `src/ecommerce-frontend/src/app/features/checkout/checkout-page.spec.ts`
- Modify: `src/ecommerce-frontend/src/app/app.spec.ts`
- Create: `src/ecommerce-frontend/src/app/features/checkout/checkout-page.ts`, `checkout-page.html`, `checkout-page.scss`
- Create: `src/ecommerce-frontend/src/app/features/orders/orders-page.ts`, `orders-page.html`, `orders-page.scss`
- Modify: `src/ecommerce-frontend/src/app/core/layout/site-header.html`
- Modify: `src/ecommerce-frontend/src/app/features/basket/basket-page.html`
- Modify: `src/ecommerce-frontend/src/app/app.routes.ts`

**Interfaces:**
- Consumes: `BasketStore.checkout`, `OrdersApi.listOrders`, Material form field and input modules.
- Produces: `CheckoutPage` at `/checkout` with a reactive form (name, email, street, city, postal code, country, card number prefilled with `4242 4242 4242 4242`, card holder), an order summary, and on success a snack bar and navigation to `/orders`; `OrdersPage` at `/orders` listing the buyer's orders with status, lines and total; an Orders link in the header; a "Proceed to checkout" button on the basket page.

- [ ] **Step 1: Write the failing specs**

`src/app/features/checkout/checkout-page.spec.ts`:

```typescript
import { provideHttpClient } from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';

import { CheckoutRequest } from '../../shared/models/order';
import { CheckoutPage } from './checkout-page';

interface FormOwner {
  form: CheckoutPage['form'];
  toRequest(): CheckoutRequest;
}

describe('CheckoutPage', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CheckoutPage],
      providers: [provideRouter([]), provideHttpClient(), provideHttpClientTesting()],
    }).compileComponents();
  });

  function create(): FormOwner {
    return TestBed.createComponent(CheckoutPage).componentInstance as unknown as FormOwner;
  }

  it('starts with the approving test card and an otherwise invalid form', () => {
    const page = create();

    expect(page.form.controls.cardNumber.value).toBe('4242 4242 4242 4242');
    expect(page.form.valid).toBe(false);
  });

  it('becomes valid with complete details and strips spaces from the card number', () => {
    const page = create();
    page.form.setValue({
      name: 'Goran',
      email: 'goran@example.com',
      street: 'Main Street 1',
      city: 'Belgrade',
      postalCode: '11000',
      country: 'Serbia',
      cardNumber: '4242 4242 4242 4242',
      cardHolder: 'Goran',
    });

    expect(page.form.valid).toBe(true);
    expect(page.toRequest()).toEqual({
      buyer: { name: 'Goran', email: 'goran@example.com' },
      shippingAddress: {
        street: 'Main Street 1',
        city: 'Belgrade',
        postalCode: '11000',
        country: 'Serbia',
      },
      card: { number: '4242424242424242', holderName: 'Goran' },
    });
  });

  it('rejects a card number that is not 16 digits', () => {
    const page = create();
    page.form.controls.cardNumber.setValue('1234');

    expect(page.form.controls.cardNumber.valid).toBe(false);
  });
});
```

Replace `src/app/app.spec.ts` with:

```typescript
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';

import { App } from './app';

describe('App', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [App],
      providers: [provideRouter([]), provideHttpClient(), provideHttpClientTesting()],
    }).compileComponents();
  });

  it('renders the header label and the footer credit and loads the basket', async () => {
    const fixture = TestBed.createComponent(App);
    const controller = TestBed.inject(HttpTestingController);
    controller.expectOne('/api/basket').flush({
      success: true,
      data: { buyerId: 'b', items: [], itemCount: 0, total: 0 },
      error: null,
    });
    await fixture.whenStable();

    const text = (fixture.nativeElement as HTMLElement).textContent ?? '';
    expect(text).toContain('ECommerce Demo');
    expect(text).toContain('Basket');
    expect(text).toContain('Orders');
    expect(text).toContain('Developed by Goran Todorovic 2026');
    controller.verify();
  });
});
```

- [ ] **Step 2: Run the tests and confirm they fail**

```bash
npm test
```

Expected: the checkout spec fails to resolve `./checkout-page` and the App spec fails on the missing Orders link.

- [ ] **Step 3: Implement**

`src/app/features/checkout/checkout-page.ts`:

```typescript
import { CurrencyPipe } from '@angular/common';
import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router, RouterLink } from '@angular/router';

import { toApiFailure } from '../../core/api/api-response';
import { BasketStore } from '../../core/basket-store';
import { CheckoutRequest } from '../../shared/models/order';

export const approvingTestCard = '4242 4242 4242 4242';

@Component({
  selector: 'app-checkout-page',
  imports: [
    CurrencyPipe,
    ReactiveFormsModule,
    MatCardModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    RouterLink,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './checkout-page.html',
  styleUrl: './checkout-page.scss',
})
export class CheckoutPage {
  private readonly formBuilder = inject(FormBuilder).nonNullable;
  private readonly router = inject(Router);
  private readonly snackBar = inject(MatSnackBar);

  protected readonly store = inject(BasketStore);
  protected readonly submitting = signal(false);

  protected readonly form = this.formBuilder.group({
    name: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(100)]],
    email: ['', [Validators.required, Validators.email, Validators.maxLength(200)]],
    street: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(200)]],
    city: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(100)]],
    postalCode: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(20)]],
    country: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(100)]],
    cardNumber: [approvingTestCard, [Validators.required, Validators.pattern(/^(\d\s*){16}$/)]],
    cardHolder: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(100)]],
  });

  protected toRequest(): CheckoutRequest {
    const value = this.form.getRawValue();
    return {
      buyer: { name: value.name.trim(), email: value.email.trim() },
      shippingAddress: {
        street: value.street.trim(),
        city: value.city.trim(),
        postalCode: value.postalCode.trim(),
        country: value.country.trim(),
      },
      card: { number: value.cardNumber.replace(/\s+/g, ''), holderName: value.cardHolder.trim() },
    };
  }

  protected async submit(): Promise<void> {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    this.submitting.set(true);
    try {
      const response = await this.store.checkout(this.toRequest());
      this.snackBar.open(
        `Order placed, total ${response.total.toFixed(2)} ${response.currency}`,
        undefined,
        {
          duration: 4000,
        },
      );
      await this.router.navigate(['/orders']);
    } catch (error) {
      this.snackBar.open(toApiFailure(error).message, 'Dismiss', { duration: 6000 });
    } finally {
      this.submitting.set(false);
    }
  }
}
```

`src/app/features/checkout/checkout-page.html`:

```html
<h1 class="title">Checkout</h1>

@if (store.items().length === 0) {
  <mat-card class="notice" appearance="outlined">
    <mat-card-content>
      <p>Your basket is empty, there is nothing to check out.</p>
    </mat-card-content>
    <mat-card-actions>
      <a mat-flat-button routerLink="/products">Browse products</a>
    </mat-card-actions>
  </mat-card>
} @else {
  <div class="layout">
    <mat-card appearance="outlined">
      <mat-card-header>
        <mat-card-title>Delivery and payment</mat-card-title>
      </mat-card-header>
      <mat-card-content>
        <form [formGroup]="form" (ngSubmit)="submit()" class="form">
          <mat-form-field>
            <mat-label>Full name</mat-label>
            <input matInput formControlName="name" autocomplete="name" />
          </mat-form-field>
          <mat-form-field>
            <mat-label>Email</mat-label>
            <input matInput formControlName="email" type="email" autocomplete="email" />
          </mat-form-field>
          <mat-form-field class="wide">
            <mat-label>Street</mat-label>
            <input matInput formControlName="street" autocomplete="street-address" />
          </mat-form-field>
          <mat-form-field>
            <mat-label>City</mat-label>
            <input matInput formControlName="city" autocomplete="address-level2" />
          </mat-form-field>
          <mat-form-field>
            <mat-label>Postal code</mat-label>
            <input matInput formControlName="postalCode" autocomplete="postal-code" />
          </mat-form-field>
          <mat-form-field>
            <mat-label>Country</mat-label>
            <input matInput formControlName="country" autocomplete="country-name" />
          </mat-form-field>
          <mat-form-field class="wide">
            <mat-label>Card number</mat-label>
            <input matInput formControlName="cardNumber" inputmode="numeric" autocomplete="off" />
            <mat-hint
              >Test cards: 4242 4242 4242 4242 is approved, any number ending in 0002 is
              declined</mat-hint
            >
          </mat-form-field>
          <mat-form-field class="wide">
            <mat-label>Card holder</mat-label>
            <input matInput formControlName="cardHolder" autocomplete="cc-name" />
          </mat-form-field>
          <div class="actions">
            <a mat-button routerLink="/basket">Back to basket</a>
            <button mat-flat-button type="submit" [disabled]="submitting() || store.busy()">
              Place order
            </button>
          </div>
        </form>
      </mat-card-content>
    </mat-card>

    <mat-card appearance="outlined" class="summary">
      <mat-card-header>
        <mat-card-title>Order summary</mat-card-title>
      </mat-card-header>
      <mat-card-content>
        <ul class="lines">
          @for (item of store.items(); track item.productId) {
            <li>
              <span>{{ item.quantity }} x {{ item.productName }}</span>
              <span>{{ item.lineTotal | currency: 'EUR' }}</span>
            </li>
          }
        </ul>
        <div class="total">
          <span>Total</span>
          <span>{{ store.total() | currency: 'EUR' }}</span>
        </div>
      </mat-card-content>
    </mat-card>
  </div>
}
```

`src/app/features/checkout/checkout-page.scss`:

```scss
.title {
  font: var(--mat-sys-headline-medium);
  margin: 0 0 1rem;
}

.layout {
  display: grid;
  grid-template-columns: minmax(0, 2fr) minmax(260px, 1fr);
  gap: 1rem;
  align-items: start;
}

.form {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 0.25rem 1rem;
  padding-top: 0.5rem;
}

.wide {
  grid-column: 1 / -1;
}

.actions {
  grid-column: 1 / -1;
  display: flex;
  justify-content: flex-end;
  gap: 0.5rem;
  margin-top: 0.5rem;
}

.lines {
  list-style: none;
  margin: 0;
  padding: 0;
}

.lines li {
  display: flex;
  justify-content: space-between;
  padding: 0.35rem 0;
}

.total {
  display: flex;
  justify-content: space-between;
  border-top: 1px solid var(--mat-sys-outline-variant);
  padding-top: 0.75rem;
  margin-top: 0.5rem;
  font: var(--mat-sys-title-medium);
}

@media (max-width: 760px) {
  .layout,
  .form {
    grid-template-columns: 1fr;
  }
}
```

`src/app/features/orders/orders-page.ts`:

```typescript
import { CurrencyPipe, DatePipe } from '@angular/common';
import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { RouterLink } from '@angular/router';

import { toApiFailure } from '../../core/api/api-response';
import { OrdersApi } from '../../core/api/orders-api';

@Component({
  selector: 'app-orders-page',
  imports: [
    CurrencyPipe,
    DatePipe,
    MatCardModule,
    MatButtonModule,
    MatProgressBarModule,
    RouterLink,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './orders-page.html',
  styleUrl: './orders-page.scss',
})
export class OrdersPage {
  private readonly api = inject(OrdersApi);

  protected readonly orders = this.api.listOrders();
  protected readonly failure = computed(() => {
    const error = this.orders.error();
    return error ? toApiFailure(error) : null;
  });

  protected reload(): void {
    this.orders.reload();
  }
}
```

`src/app/features/orders/orders-page.html`:

```html
<h1 class="title">Your orders</h1>

@if (orders.isLoading()) {
  <mat-progress-bar mode="indeterminate" aria-label="Loading orders" />
}

@if (failure(); as failure) {
  <mat-card class="notice" appearance="outlined">
    <mat-card-content>
      <p>{{ failure.message }}</p>
      <p class="code">[{{ failure.code }}]</p>
    </mat-card-content>
    <mat-card-actions>
      <button mat-button (click)="reload()">Retry</button>
    </mat-card-actions>
  </mat-card>
} @else if (orders.value(); as items) {
  @if (items.length === 0) {
    <mat-card class="notice" appearance="outlined">
      <mat-card-content>
        <p>You have not placed any orders yet.</p>
      </mat-card-content>
      <mat-card-actions>
        <a mat-flat-button routerLink="/products">Browse products</a>
      </mat-card-actions>
    </mat-card>
  }
  <div class="list">
    @for (order of items; track order.id) {
      <mat-card appearance="outlined" class="order">
        <mat-card-header>
          <mat-card-title>Order {{ order.id.slice(0, 8) }}</mat-card-title>
          <mat-card-subtitle>{{ order.createdAt | date: 'medium' }}</mat-card-subtitle>
          <span class="status" [class]="'status ' + order.status.toLowerCase()">{{
            order.status
          }}</span>
        </mat-card-header>
        <mat-card-content>
          <ul class="lines">
            @for (line of order.lines; track line.productId) {
              <li>
                <span>{{ line.quantity }} x {{ line.productName }}</span>
                <span>{{ line.lineTotal | currency: 'EUR' }}</span>
              </li>
            }
          </ul>
          <div class="footer">
            <span
              >Card ending {{ order.cardLast4 }}, shipping to {{ order.shippingAddress.city }}</span
            >
            <span class="total">{{ order.total | currency: 'EUR' }}</span>
          </div>
          @if (order.failureReason) {
            <p class="reason">{{ order.failureReason }}</p>
          }
        </mat-card-content>
      </mat-card>
    }
  </div>
}
```

`src/app/features/orders/orders-page.scss`:

```scss
.title {
  font: var(--mat-sys-headline-medium);
  margin: 0 0 1rem;
}

.list {
  display: grid;
  gap: 1rem;
}

.order mat-card-header {
  align-items: center;
  gap: 1rem;
}

.status {
  margin-left: auto;
  padding: 0.2rem 0.75rem;
  border-radius: 999px;
  font: var(--mat-sys-label-large);
  background: var(--mat-sys-surface-container-high);
  color: var(--mat-sys-on-surface);
}

.status.paid {
  background: var(--mat-sys-primary-container);
  color: var(--mat-sys-on-primary-container);
}

.status.shipped {
  background: var(--mat-sys-tertiary-container);
  color: var(--mat-sys-on-tertiary-container);
}

.status.paymentfailed {
  background: var(--mat-sys-error-container);
  color: var(--mat-sys-on-error-container);
}

.lines {
  list-style: none;
  margin: 0;
  padding: 0;
}

.lines li {
  display: flex;
  justify-content: space-between;
  padding: 0.3rem 0;
}

.footer {
  display: flex;
  justify-content: space-between;
  border-top: 1px solid var(--mat-sys-outline-variant);
  padding-top: 0.75rem;
  margin-top: 0.5rem;
  color: var(--mat-sys-on-surface-variant);
}

.total {
  font: var(--mat-sys-title-medium);
  color: var(--mat-sys-on-surface);
}

.reason {
  color: var(--mat-sys-error);
}

.notice .code {
  font: var(--mat-sys-label-medium);
  color: var(--mat-sys-on-surface-variant);
}
```

`src/app/core/layout/site-header.html`:

```html
<mat-toolbar class="header">
  <a class="brand" routerLink="/products">ECommerce Demo</a>
  <nav class="nav" aria-label="Main">
    <a mat-button routerLink="/products" routerLinkActive="active">Products</a>
    <a
      mat-button
      routerLink="/basket"
      routerLinkActive="active"
      [matBadge]="basket.count()"
      [matBadgeHidden]="basket.count() === 0"
      matBadgeSize="small"
      aria-label="Basket"
    >
      Basket
    </a>
    <a mat-button routerLink="/orders" routerLinkActive="active">Orders</a>
  </nav>
</mat-toolbar>
```

`src/app/features/basket/basket-page.html`:

```html
<h1 class="title">Your basket</h1>

@if (store.failure(); as failure) {
  <mat-card class="notice" appearance="outlined">
    <mat-card-content>
      <p>{{ failure.message }}</p>
      <p class="code">[{{ failure.code }}]</p>
    </mat-card-content>
    <mat-card-actions>
      <button mat-button (click)="store.load()">Retry</button>
    </mat-card-actions>
  </mat-card>
} @else if (store.items().length === 0) {
  <mat-card class="notice" appearance="outlined">
    <mat-card-content>
      <p>Your basket is empty.</p>
    </mat-card-content>
    <mat-card-actions>
      <a mat-flat-button routerLink="/products">Browse products</a>
    </mat-card-actions>
  </mat-card>
} @else {
  <mat-card appearance="outlined">
    <mat-card-content>
      <ul class="lines">
        @for (item of store.items(); track item.productId) {
          <li class="line">
            <div class="name">
              <span>{{ item.productName }}</span>
              <small>{{ item.unitPrice | currency: 'EUR' }} each</small>
            </div>
            <div
              class="quantity"
              role="group"
              [attr.aria-label]="'Quantity of ' + item.productName"
            >
              <button
                mat-stroked-button
                (click)="decrease(item)"
                [disabled]="store.busy()"
                aria-label="Decrease quantity"
              >
                -
              </button>
              <span class="value">{{ item.quantity }}</span>
              <button
                mat-stroked-button
                (click)="increase(item)"
                [disabled]="store.busy()"
                aria-label="Increase quantity"
              >
                +
              </button>
            </div>
            <div class="line-total">{{ item.lineTotal | currency: 'EUR' }}</div>
            <button mat-button (click)="remove(item)" [disabled]="store.busy()">Remove</button>
          </li>
        }
      </ul>
      <div class="summary">
        <span>Total</span>
        <span class="total">{{ store.total() | currency: 'EUR' }}</span>
      </div>
    </mat-card-content>
    <mat-card-actions align="end">
      <a mat-flat-button routerLink="/checkout" [class.disabled]="store.busy()"
        >Proceed to checkout</a
      >
    </mat-card-actions>
  </mat-card>
}
```

`src/app/app.routes.ts`:

```typescript
import { Routes } from '@angular/router';

export const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'products' },
  {
    path: 'products',
    loadComponent: () => import('./features/products/product-list').then((m) => m.ProductList),
  },
  {
    path: 'basket',
    loadComponent: () => import('./features/basket/basket-page').then((m) => m.BasketPage),
  },
  {
    path: 'checkout',
    loadComponent: () => import('./features/checkout/checkout-page').then((m) => m.CheckoutPage),
  },
  {
    path: 'orders',
    loadComponent: () => import('./features/orders/orders-page').then((m) => m.OrdersPage),
  },
  { path: '**', redirectTo: 'products' },
];
```

- [ ] **Step 4: Run the tests, then the full check**

```bash
npm test
npm run build
npm run lint
npm run format:check
```

Expected: `Test Files  7 passed (7)` and `Tests  26 passed (26)`; the build lists lazy chunks named `checkout-page` and `orders-page`; lint and format check clean.

---

## Sub-phase 4.6 Phase acceptance

Run by the lead after every task above is reviewed and ticked.

- [ ] **Step 1: Clean build and full test runs**

```bash
dotnet build
dotnet test
cd src/ecommerce-frontend && source "$HOME/.nvm/nvm.sh" && nvm use && npm run lint && npm test && cd ../..
```

Expected: `0 Warning(s)`, 89 .NET tests, 26 frontend tests, lint clean.

- [ ] **Step 2: Start the AppHost and wait**

```bash
export PATH="$PATH:$HOME/.dotnet/tools"
source "$HOME/.nvm/nvm.sh" && nvm use 24
AH=src/Ecommerce.AppHost/Ecommerce.AppHost.csproj
aspire start --apphost $AH --non-interactive --format Json
for r in catalog-api basket-api ordering-api frontend gateway; do aspire wait $r --status healthy --timeout 300 --apphost $AH --non-interactive; done
aspire logs ordering-api --search OrderingDbInitializer --apphost $AH --non-interactive
```

Expected: all five healthy; the Ordering log contains `[OrderingDbInitializer] Ensured indexes on collection [orders]`; both Basket and Ordering logs contain `Starting Wolverine messaging`.

- [ ] **Step 3: Check out through the gateway**

```bash
G=http://localhost:5100/api
BUYER="X-Buyer-Id: b0000000-0000-4000-8000-000000000011"
CT="content-type: application/json"
BODY='{"buyer":{"name":"Goran","email":"goran@example.com"},"shippingAddress":{"street":"Main Street 1","city":"Belgrade","postalCode":"11000","country":"Serbia"},"card":{"number":"4242424242424242","holderName":"Goran"}}'
curl -s -H "$BUYER" -H "$CT" -X POST -d "$BODY" -w ' [%{http_code}]\n' $G/basket/checkout
# basket.checkout_empty [400]
curl -s -H "$BUYER" -H "$CT" -X PUT -d '{"productId":"a0000000-0000-4000-8000-000000000001","quantity":2}' -o /dev/null -w '%{http_code}\n' $G/basket/items
curl -s -H "$BUYER" -H "$CT" -X PUT -d '{"productId":"a0000000-0000-4000-8000-000000000010","quantity":1}' -o /dev/null -w '%{http_code}\n' $G/basket/items
curl -s -H "$BUYER" -H "$CT" -X POST -d '{"buyer":{"name":"G","email":"nope"},"shippingAddress":{"street":"Main Street 1","city":"Belgrade","postalCode":"11000","country":"Serbia"},"card":{"number":"1234","holderName":"Goran"}}' -w ' [%{http_code}]\n' $G/basket/checkout
# common.validation_failed with details for Buyer.Name, Buyer.Email and Card.Number [400]
curl -s -H "$BUYER" -H "$CT" -X POST -d "$BODY" -w ' [%{http_code}]\n' $G/basket/checkout
# success with orderId, total 40 and currency EUR [202]
curl -s -H "$BUYER" $G/basket
# itemCount 0: the basket was cleared
sleep 3
curl -s -H "$BUYER" $G/orders
# one order: status Submitted, total 40, two lines, cardLast4 4242, buyer name Goran
aspire logs ordering-api --search OrderPlacedHandler --apphost $AH --non-interactive
# [OrderPlacedHandler] Stored order [...] for buyer [...] with [2] lines total [40.00]
```

The first order can take a second or two to appear because Wolverine compiles the handler on first use; later orders arrive within a second.

- [ ] **Step 4: Prove the durable outbox**

```bash
curl -s -H "$BUYER" -H "$CT" -X PUT -d '{"productId":"a0000000-0000-4000-8000-000000000004","quantity":1}' -o /dev/null -w '%{http_code}\n' $G/basket/items
aspire resource messaging stop --apphost $AH --non-interactive
aspire wait messaging --status down --timeout 60 --apphost $AH --non-interactive
sleep 3
curl -s -H "$BUYER" -H "$CT" -X POST -d "$BODY" -w ' [%{http_code}]\n' $G/basket/checkout
# success [202] immediately: the event is stored in the basketdb outbox
curl -s -H "$BUYER" $G/orders
# still one order: nothing can reach Ordering while the broker is down
aspire resource messaging start --apphost $AH --non-interactive
aspire wait messaging --status healthy --timeout 120 --apphost $AH --non-interactive
sleep 5
curl -s -H "$BUYER" $G/orders
# two orders: the outbox delivered the stored event
aspire logs basket-api --search "has resumed" --apphost $AH --non-interactive
# Sending agent for rabbitmq://exchange/order-placed has resumed
```

- [ ] **Step 5: Owner's browser check**

Open `http://localhost:5100`. Expected: the header shows Products, Basket and Orders; the basket page has a "Proceed to checkout" button; the checkout page shows the form with the approving card prefilled and the order summary, rejects invalid input inline, and on Place order shows "Order placed, total ..." and lands on the orders page where the order appears as Submitted with its lines, the card's last four digits and the shipping city.

- [ ] **Step 6: Stop and record**

```bash
aspire stop --apphost $AH --non-interactive
```

The lead ticks phase 4 in `STATUS.md`, writes the phase entry in `SUMMARY.md`, and continues with phase 5.
