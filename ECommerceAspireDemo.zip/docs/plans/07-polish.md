# Phase 7 Polish Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Fix the orders page so the first order after startup shows up without a refresh, and apply the new header, page title and footer texts.

**Architecture:** Checkout answers 202 before Ordering has consumed the message, so the orders page's first fetch can predate the order (about 740 ms on the cold path, about 35 ms afterwards). The page's polling rule only polled while some order was `Submitted` or `Paid`, which an empty list never satisfies. A small `PendingOrder` service in `core/` remembers the id returned by checkout; the polling rule also polls while that id is missing from the list, the page shows a waiting notice instead of the empty state, and it forgets the id as soon as the list contains it. The 202 design is untouched. The text changes are plain edits of the header, `index.html`, the footer and the app spec.

**Tech Stack:** Angular 22, Angular Material, Vitest. No new packages.

**Spec:** `docs/ARCHITECTURE.md` section 4.7; `docs/CODING_GUIDELINES.md` sections 5 and 6.

**Agents and ordering:** `frontend-dev` runs task 7.1.1, then task 7.2.1. There is no backend work. Sub-phase 7.3 is the lead's acceptance.

## Global Constraints

- Everything from `docs/plans/README.md` Global constraints applies.
- No new npm packages.
- Every user-visible string stays in the template or component where it is today; phase 8 moves them to translation files, so do not introduce constants for them here.
- Run every npm command from `src/ecommerce-frontend` with Node 24 from nvm (`source "$HOME/.nvm/nvm.sh" && nvm use 24`).
- The files you touch pass `npm run lint` and `npm run format:check`; run `npm run format` before the check.
- Nothing under `docs/` is edited by the agent.

---

## Sub-phase 7.1 Orders page shows the order just placed (frontend-dev)

### Task 7.1.1: Pending order service, polling rule and waiting notice

**Files:**
- Create: `src/ecommerce-frontend/src/app/core/pending-order.ts`
- Create: `src/ecommerce-frontend/src/app/core/pending-order.spec.ts`
- Modify: `src/ecommerce-frontend/src/app/features/orders/orders-polling.ts`
- Modify: `src/ecommerce-frontend/src/app/features/orders/orders-polling.spec.ts`
- Modify: `src/ecommerce-frontend/src/app/features/orders/orders-page.ts`
- Modify: `src/ecommerce-frontend/src/app/features/orders/orders-page.html`
- Create: `src/ecommerce-frontend/src/app/features/orders/orders-page.spec.ts`
- Modify: `src/ecommerce-frontend/src/app/features/checkout/checkout-page.ts`
- Modify: `src/ecommerce-frontend/src/app/features/checkout/checkout-page.spec.ts`

**Interfaces:**
- Consumes: `CheckoutResponse.orderId` from the basket store's `checkout`, `OrdersApi.listOrders()` (an `httpResource` of `Order[]`), the existing `shouldPollOrders` rule.
- Produces: `PendingOrder` (root service with `orderId` signal, `placed(orderId)` and `seen(orderId)`); `shouldPollOrders(orders, pendingOrderId = null)`; `OrdersPage.waitingForOrder` signal; the checkout page calls `placed` right after a successful checkout.

- [ ] **Step 1: Write the failing tests**

Create `src/ecommerce-frontend/src/app/core/pending-order.spec.ts`:

```ts
import { TestBed } from '@angular/core/testing';

import { PendingOrder } from './pending-order';

describe('PendingOrder', () => {
  it('starts empty, remembers the placed order and forgets it once seen', () => {
    const pending = TestBed.inject(PendingOrder);
    expect(pending.orderId()).toBeNull();

    pending.placed('o-1');
    expect(pending.orderId()).toBe('o-1');

    pending.seen('o-2');
    expect(pending.orderId()).toBe('o-1');

    pending.seen('o-1');
    expect(pending.orderId()).toBeNull();
  });
});
```

Replace `src/ecommerce-frontend/src/app/features/orders/orders-polling.spec.ts` with:

```ts
import { Order } from '../../shared/models/order';
import { shouldPollOrders } from './orders-polling';

function order(status: Order['status']): Order {
  return {
    id: `o-${status}`,
    status,
    total: 10,
    currency: 'EUR',
    createdAt: '2026-09-12T12:00:00Z',
    paidAt: null,
    shippedAt: null,
    failureReason: null,
    cardLast4: '4242',
    buyer: { name: 'Goran', email: 'goran@example.com' },
    shippingAddress: {
      street: 'Main Street 1',
      city: 'Belgrade',
      postalCode: '11000',
      country: 'Serbia',
    },
    lines: [],
  };
}

describe('shouldPollOrders', () => {
  it('is false without orders', () => {
    expect(shouldPollOrders(undefined)).toBe(false);
    expect(shouldPollOrders([])).toBe(false);
  });

  it('is false when every order is terminal', () => {
    expect(shouldPollOrders([order('Shipped'), order('PaymentFailed')])).toBe(false);
  });

  it('is true while an order is Submitted or Paid', () => {
    expect(shouldPollOrders([order('Shipped'), order('Submitted')])).toBe(true);
    expect(shouldPollOrders([order('Paid')])).toBe(true);
  });
});

describe('shouldPollOrders with a pending order', () => {
  it('is true while the order just placed is not listed yet', () => {
    expect(shouldPollOrders(undefined, 'o-new')).toBe(true);
    expect(shouldPollOrders([], 'o-new')).toBe(true);
    expect(shouldPollOrders([order('Shipped')], 'o-new')).toBe(true);
  });

  it('falls back to the status rule once the placed order is listed', () => {
    expect(shouldPollOrders([order('Shipped')], 'o-Shipped')).toBe(false);
    expect(shouldPollOrders([order('Paid')], 'o-Paid')).toBe(true);
  });
});
```

Create `src/ecommerce-frontend/src/app/features/orders/orders-page.spec.ts`:

```ts
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';

import { PendingOrder } from '../../core/pending-order';
import { Order } from '../../shared/models/order';
import { OrdersPage } from './orders-page';

function order(id: string, status: Order['status']): Order {
  return {
    id,
    status,
    total: 10,
    currency: 'EUR',
    createdAt: '2026-09-12T12:00:00Z',
    paidAt: null,
    shippedAt: null,
    failureReason: null,
    cardLast4: '4242',
    buyer: { name: 'Goran', email: 'goran@example.com' },
    shippingAddress: {
      street: 'Main Street 1',
      city: 'Belgrade',
      postalCode: '11000',
      country: 'Serbia',
    },
    lines: [],
  };
}

describe('OrdersPage', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [OrdersPage],
      providers: [provideRouter([]), provideHttpClient(), provideHttpClientTesting()],
    }).compileComponents();
  });

  async function render(orders: Order[]): Promise<HTMLElement> {
    const fixture = TestBed.createComponent(OrdersPage);
    fixture.detectChanges();
    const controller = TestBed.inject(HttpTestingController);
    controller.expectOne('/api/orders').flush({ success: true, data: orders, error: null });
    await fixture.whenStable();
    fixture.detectChanges();
    controller.verify();
    return fixture.nativeElement as HTMLElement;
  }

  it('shows the waiting notice instead of the empty state while the placed order is missing', async () => {
    TestBed.inject(PendingOrder).placed('o-1');

    const element = await render([]);

    expect(element.textContent).toContain('Your order is being placed');
    expect(element.textContent).not.toContain('You have not placed any orders yet');
    expect(element.textContent).toContain('Watching for status changes');
  });

  it('forgets the placed order once the list contains it', async () => {
    const pending = TestBed.inject(PendingOrder);
    pending.placed('o-1');

    const element = await render([order('o-1', 'Shipped')]);

    expect(pending.orderId()).toBeNull();
    expect(element.textContent).not.toContain('Your order is being placed');
    expect(element.textContent).not.toContain('Watching for status changes');
  });

  it('shows the empty state when nothing is pending', async () => {
    const element = await render([]);

    expect(element.textContent).toContain('You have not placed any orders yet');
    expect(element.textContent).not.toContain('Watching for status changes');
  });
});
```

Replace `src/ecommerce-frontend/src/app/features/checkout/checkout-page.spec.ts` with:

```ts
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';

import { PendingOrder } from '../../core/pending-order';
import { CheckoutRequest } from '../../shared/models/order';
import { CheckoutPage } from './checkout-page';

interface FormOwner {
  form: CheckoutPage['form'];
  toRequest(): CheckoutRequest;
  submit(): Promise<void>;
}

describe('CheckoutPage', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CheckoutPage],
      providers: [provideRouter([]), provideHttpClient(), provideHttpClientTesting()],
    }).compileComponents();
  });

  function create(): FormOwner {
    return TestBed.createComponent(CheckoutPage).componentInstance as unknown as FormOwner;
  }

  it('starts with the approving test card and an otherwise invalid form', () => {
    const page = create();

    expect(page.form.controls.cardNumber.value).toBe('4242 4242 4242 4242');
    expect(page.form.valid).toBe(false);
  });

  it('becomes valid with complete details and strips spaces from the card number', () => {
    const page = create();
    page.form.setValue({
      name: 'Goran',
      email: 'goran@example.com',
      street: 'Main Street 1',
      city: 'Belgrade',
      postalCode: '11000',
      country: 'Serbia',
      cardNumber: '4242 4242 4242 4242',
      cardHolder: 'Goran',
    });

    expect(page.form.valid).toBe(true);
    expect(page.toRequest()).toEqual({
      buyer: { name: 'Goran', email: 'goran@example.com' },
      shippingAddress: {
        street: 'Main Street 1',
        city: 'Belgrade',
        postalCode: '11000',
        country: 'Serbia',
      },
      card: { number: '4242424242424242', holderName: 'Goran' },
    });
  });

  it('rejects a card number that is not 16 digits', () => {
    const page = create();
    page.form.controls.cardNumber.setValue('1234');

    expect(page.form.controls.cardNumber.valid).toBe(false);
  });
});

describe('CheckoutPage after placing an order', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CheckoutPage],
      providers: [
        provideRouter([{ path: 'orders', component: CheckoutPage }]),
        provideHttpClient(),
        provideHttpClientTesting(),
      ],
    }).compileComponents();
  });

  it('remembers the placed order id for the orders page', async () => {
    const page = TestBed.createComponent(CheckoutPage).componentInstance as unknown as FormOwner;
    page.form.setValue({
      name: 'Goran',
      email: 'goran@example.com',
      street: 'Main Street 1',
      city: 'Belgrade',
      postalCode: '11000',
      country: 'Serbia',
      cardNumber: '4242 4242 4242 4242',
      cardHolder: 'Goran',
    });
    const controller = TestBed.inject(HttpTestingController);

    const submitted = page.submit();
    controller.expectOne('/api/basket/checkout').flush({
      success: true,
      data: { orderId: 'o-1', total: 12.5, currency: 'EUR' },
      error: null,
    });
    await submitted;

    expect(TestBed.inject(PendingOrder).orderId()).toBe('o-1');
    controller.verify();
  });
});
```

- [ ] **Step 2: Run the tests and confirm the new ones fail**

```bash
npm test
```

Expected: the three new or changed spec files fail (`pending-order.spec.ts` and `orders-page.spec.ts` cannot resolve `../../core/pending-order` or `./pending-order`, the second `shouldPollOrders` argument is a type error, and the checkout spec cannot resolve `PendingOrder`); the other spec files still pass. Copy the summary line into the report.

- [ ] **Step 3: Implement**

Create `src/ecommerce-frontend/src/app/core/pending-order.ts`:

```ts
import { Injectable, signal } from '@angular/core';

// Remembers the order placed a moment ago until the orders page has seen it in the list
@Injectable({ providedIn: 'root' })
export class PendingOrder {
  private readonly orderIdState = signal<string | null>(null);

  readonly orderId = this.orderIdState.asReadonly();

  placed(orderId: string): void {
    this.orderIdState.set(orderId);
  }

  seen(orderId: string): void {
    if (this.orderIdState() === orderId) {
      this.orderIdState.set(null);
    }
  }
}
```

Replace `src/ecommerce-frontend/src/app/features/orders/orders-polling.ts` with:

```ts
import { Order } from '../../shared/models/order';

export const ordersPollIntervalMs = 3000;

// Poll while an order can still change, or while the order placed a moment ago is not listed yet;
// Shipped and PaymentFailed are terminal
export function shouldPollOrders(
  orders: readonly Order[] | undefined,
  pendingOrderId: string | null = null,
): boolean {
  if (pendingOrderId !== null && !orders?.some((order) => order.id === pendingOrderId)) {
    return true;
  }
  return orders?.some((order) => order.status === 'Submitted' || order.status === 'Paid') ?? false;
}
```

Replace `src/ecommerce-frontend/src/app/features/orders/orders-page.ts` with:

```ts
import { CurrencyPipe, DatePipe } from '@angular/common';
import {
  ChangeDetectionStrategy,
  Component,
  DestroyRef,
  computed,
  effect,
  inject,
} from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { RouterLink } from '@angular/router';

import { toApiFailure } from '../../core/api/api-response';
import { OrdersApi } from '../../core/api/orders-api';
import { PendingOrder } from '../../core/pending-order';
import { ordersPollIntervalMs, shouldPollOrders } from './orders-polling';

@Component({
  selector: 'app-orders-page',
  imports: [
    CurrencyPipe,
    DatePipe,
    MatCardModule,
    MatButtonModule,
    MatProgressBarModule,
    RouterLink,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './orders-page.html',
  styleUrl: './orders-page.scss',
})
export class OrdersPage {
  private readonly api = inject(OrdersApi);
  private readonly pending = inject(PendingOrder);
  private readonly destroyRef = inject(DestroyRef);

  protected readonly orders = this.api.listOrders();
  protected readonly failure = computed(() => {
    const error = this.orders.error();
    return error ? toApiFailure(error) : null;
  });
  protected readonly polling = computed(() =>
    shouldPollOrders(this.orders.value(), this.pending.orderId()),
  );
  protected readonly waitingForOrder = computed(() => {
    const pendingId = this.pending.orderId();
    return pendingId !== null && !this.orders.value()?.some((order) => order.id === pendingId);
  });

  constructor() {
    // Refreshes only while an order is still moving or expected, so the dashboard is not flooded with idle requests
    const timer = setInterval(() => {
      if (this.polling() && this.orders.status() === 'resolved') {
        this.orders.reload();
      }
    }, ordersPollIntervalMs);
    this.destroyRef.onDestroy(() => clearInterval(timer));

    effect(() => {
      const pendingId = this.pending.orderId();
      if (pendingId !== null && this.orders.value()?.some((order) => order.id === pendingId)) {
        this.pending.seen(pendingId);
      }
    });
  }

  protected reload(): void {
    this.orders.reload();
  }
}
```

Replace `src/ecommerce-frontend/src/app/features/orders/orders-page.html` with:

```html
<h1 class="title">Your orders</h1>

@if (orders.status() === 'loading') {
  <mat-progress-bar mode="indeterminate" aria-label="Loading orders" />
}
@if (polling()) {
  <p class="hint">Watching for status changes</p>
}

@if (failure(); as failure) {
  <mat-card class="notice" appearance="outlined">
    <mat-card-content>
      <p>{{ failure.message }}</p>
      <p class="code">[{{ failure.code }}]</p>
    </mat-card-content>
    <mat-card-actions>
      <button mat-button (click)="reload()">Retry</button>
    </mat-card-actions>
  </mat-card>
} @else if (orders.value(); as items) {
  @if (items.length === 0) {
    <mat-card class="notice" appearance="outlined">
      <mat-card-content>
        @if (waitingForOrder()) {
          <p>Your order is being placed and will appear here in a moment.</p>
        } @else {
          <p>You have not placed any orders yet.</p>
        }
      </mat-card-content>
      <mat-card-actions>
        <a mat-flat-button routerLink="/products">Browse products</a>
      </mat-card-actions>
    </mat-card>
  }
  <div class="list">
    @for (order of items; track order.id) {
      <mat-card appearance="outlined" class="order">
        <mat-card-header>
          <mat-card-title>Order {{ order.id.slice(0, 8) }}</mat-card-title>
          <mat-card-subtitle>{{ order.createdAt | date: 'medium' }}</mat-card-subtitle>
          <span class="status" [class]="'status ' + order.status.toLowerCase()">{{
            order.status
          }}</span>
        </mat-card-header>
        <mat-card-content>
          <ul class="lines">
            @for (line of order.lines; track line.productId) {
              <li>
                <span>{{ line.quantity }} x {{ line.productName }}</span>
                <span>{{ line.lineTotal | currency: 'EUR' }}</span>
              </li>
            }
          </ul>
          <div class="footer">
            <span
              >Card ending {{ order.cardLast4 }}, shipping to {{ order.shippingAddress.city }}</span
            >
            <span class="total">{{ order.total | currency: 'EUR' }}</span>
          </div>
          @if (order.failureReason) {
            <p class="reason">{{ order.failureReason }}</p>
          }
        </mat-card-content>
      </mat-card>
    }
  </div>
}
```

Replace `src/ecommerce-frontend/src/app/features/checkout/checkout-page.ts` with:

```ts
import { CurrencyPipe } from '@angular/common';
import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router, RouterLink } from '@angular/router';

import { toApiFailure } from '../../core/api/api-response';
import { BasketStore } from '../../core/basket-store';
import { PendingOrder } from '../../core/pending-order';
import { CheckoutRequest } from '../../shared/models/order';

export const approvingTestCard = '4242 4242 4242 4242';

@Component({
  selector: 'app-checkout-page',
  imports: [
    CurrencyPipe,
    ReactiveFormsModule,
    MatCardModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    RouterLink,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './checkout-page.html',
  styleUrl: './checkout-page.scss',
})
export class CheckoutPage {
  private readonly formBuilder = inject(FormBuilder).nonNullable;
  private readonly router = inject(Router);
  private readonly snackBar = inject(MatSnackBar);
  private readonly pending = inject(PendingOrder);

  protected readonly store = inject(BasketStore);
  protected readonly submitting = signal(false);

  protected readonly form = this.formBuilder.group({
    name: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(100)]],
    email: ['', [Validators.required, Validators.email, Validators.maxLength(200)]],
    street: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(200)]],
    city: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(100)]],
    postalCode: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(20)]],
    country: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(100)]],
    cardNumber: [approvingTestCard, [Validators.required, Validators.pattern(/^(\d\s*){16}$/)]],
    cardHolder: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(100)]],
  });

  protected toRequest(): CheckoutRequest {
    const value = this.form.getRawValue();
    return {
      buyer: { name: value.name.trim(), email: value.email.trim() },
      shippingAddress: {
        street: value.street.trim(),
        city: value.city.trim(),
        postalCode: value.postalCode.trim(),
        country: value.country.trim(),
      },
      card: { number: value.cardNumber.replace(/\s+/g, ''), holderName: value.cardHolder.trim() },
    };
  }

  protected async submit(): Promise<void> {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    this.submitting.set(true);
    try {
      const response = await this.store.checkout(this.toRequest());
      this.pending.placed(response.orderId);
      this.snackBar.open(
        `Order placed, total ${response.total.toFixed(2)} ${response.currency}`,
        undefined,
        {
          duration: 4000,
        },
      );
      await this.router.navigate(['/orders']);
    } catch (error) {
      this.snackBar.open(toApiFailure(error).message, 'Dismiss', { duration: 6000 });
    } finally {
      this.submitting.set(false);
    }
  }
}
```

- [ ] **Step 4: Run the checks**

```bash
npm run format
npm test
npm run lint
npm run format:check
```

Expected: 36 tests passed across 10 files, `All files pass linting.`, `All matched files use Prettier code style!`.

## Sub-phase 7.2 Header, page title and footer texts (frontend-dev)

### Task 7.2.1: New texts

**Files:**
- Modify: `src/ecommerce-frontend/src/index.html`
- Modify: `src/ecommerce-frontend/src/app/core/layout/site-header.html`
- Modify: `src/ecommerce-frontend/src/app/core/layout/site-footer.html`
- Modify: `src/ecommerce-frontend/src/app/app.spec.ts`

**Interfaces:**
- Consumes: nothing new.
- Produces: the brand link and the page title read "E-Commerce Aspire Demo", the footer reads "Goran Todorovic 2026 - Master" (a plain hyphen).

- [ ] **Step 1: Change the app spec first and see it fail**

Replace `src/ecommerce-frontend/src/app/app.spec.ts` with:

```ts
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';

import { App } from './app';

describe('App', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [App],
      providers: [provideRouter([]), provideHttpClient(), provideHttpClientTesting()],
    }).compileComponents();
  });

  it('renders the header label and the footer credit and loads the basket', async () => {
    const fixture = TestBed.createComponent(App);
    const controller = TestBed.inject(HttpTestingController);
    controller.expectOne('/api/basket').flush({
      success: true,
      data: { buyerId: 'b', items: [], itemCount: 0, total: 0 },
      error: null,
    });
    await fixture.whenStable();

    const text = (fixture.nativeElement as HTMLElement).textContent ?? '';
    expect(text).toContain('E-Commerce Aspire Demo');
    expect(text).toContain('Basket');
    expect(text).toContain('Orders');
    expect(text).toContain('Goran Todorovic 2026 - Master');
    controller.verify();
  });
});
```

```bash
npm test
```

Expected: the `App` spec fails on `E-Commerce Aspire Demo`; everything else passes.

- [ ] **Step 2: Apply the texts**

Replace `src/ecommerce-frontend/src/index.html` with:

```html
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <title>E-Commerce Aspire Demo</title>
    <base href="/" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="icon" type="image/x-icon" href="favicon.ico" />
  </head>
  <body>
    <app-root></app-root>
  </body>
</html>
```

Replace `src/ecommerce-frontend/src/app/core/layout/site-header.html` with:

```html
<mat-toolbar class="header">
  <a class="brand" routerLink="/products">E-Commerce Aspire Demo</a>
  <nav class="nav" aria-label="Main">
    <a mat-button routerLink="/products" routerLinkActive="active">Products</a>
    <a
      mat-button
      routerLink="/basket"
      routerLinkActive="active"
      [matBadge]="basket.count()"
      [matBadgeHidden]="basket.count() === 0"
      matBadgeSize="small"
      aria-label="Basket"
    >
      Basket
    </a>
    <a mat-button routerLink="/orders" routerLinkActive="active">Orders</a>
  </nav>
</mat-toolbar>
```

Replace `src/ecommerce-frontend/src/app/core/layout/site-footer.html` with:

```html
<footer class="footer">Goran Todorovic 2026 - Master</footer>
```

- [ ] **Step 3: Run the checks**

```bash
npm run format
npm test
npm run lint
npm run format:check
```

Expected: 36 tests passed, lint and format clean.

## Sub-phase 7.3 Acceptance

Run by the lead after both tasks are reviewed.

```bash
export PATH="$PATH:$HOME/.dotnet/tools"
source "$HOME/.nvm/nvm.sh" && nvm use 24
dotnet build
dotnet test
cd src/ecommerce-frontend && npm run lint && npm test && npm run format:check && cd ../..
AH=src/Ecommerce.AppHost/Ecommerce.AppHost.csproj
aspire start --apphost $AH --non-interactive --format Json
for r in catalog-api basket-api ordering-api payment-api frontend gateway; do aspire wait $r --status healthy --timeout 300 --apphost $AH --non-interactive; done
curl -s http://localhost:5100/ | grep -o "<title>[^<]*</title>"
for r in catalog-api basket-api ordering-api payment-api gateway frontend; do aspire logs $r --apphost $AH --non-interactive | sed 's/\x1b\[[0-9;]*m//g' | grep -E "warn:|fail:" | sed "s/^/$r: /"; done
aspire stop --apphost $AH --non-interactive
```

Expected: `0 Warning(s)`, 114 .NET tests, 36 frontend tests, six healthy, the title tag reads `E-Commerce Aspire Demo`, the sweep prints nothing. Owner's browser check: on a fresh start place the first order; the orders page shows "Your order is being placed" with the progress bar and then the order within a few seconds, without a refresh; the header, tab title and footer show the new texts.
