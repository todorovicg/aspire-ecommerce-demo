# Phase 0 Foundation Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** A building, testing solution skeleton with ServiceDefaults carrying the API response envelope, and an AppHost that starts Postgres, Redis, RabbitMQ and Mongo healthy in the dashboard.

**Architecture:** Central package management and shared build properties at the root; `Ecommerce.ServiceDefaults` from the Aspire template plus an `Api` folder with the envelope types, a problem details writer and two extension methods; `Ecommerce.AppHost` from the Aspire template with only infrastructure resources. One unit test project for ServiceDefaults.

**Tech Stack:** .NET 10 SDK 10.0.201, Aspire 13.5.3, xUnit v3 4.0.0 on Microsoft Testing Platform, Scalar 2.17.3, OpenTelemetry 1.18.0.

**Spec:** `docs/ARCHITECTURE.md` sections 3, 6, 7 and 9; `docs/CODING_GUIDELINES.md` sections 2.5, 2.6 and 2.11.

**Agent:** `backend-dev` for every task. No frontend work in this phase.

## Global Constraints

- .NET SDK 10.0.201 or later 10.0.x. Aspire CLI and templates 13.5.3. Docker daemon running.
- Only dependencies that are fully open source with no personal or commercial license requirement. The packages named in this plan are the complete list; add nothing else.
- Project names use the `Ecommerce.` prefix. Solution file is `ECommerceAspireDemo.slnx` at the repository root.
- Every response body uses the envelope `{ success, data, error: { code, message, details, traceId } }` from CODING_GUIDELINES.md section 2.5.
- Log lines: `[{Prefix}]` first from `nameof`, values in square brackets, one line, no trailing full stop, message templates never interpolation.
- No XML documentation comments. `//` comments only where the code cannot say why. No em dashes anywhere.
- Default analyzers only, no warnings-as-errors, but every task ends with a build that reports zero warnings for the files touched.
- No git commands. Every task ends with a build and, where tests exist, a test run.
- All commands run from `/Users/goran/Projects/Private/ECommerceAspireDemo` unless stated otherwise. The Aspire CLI is installed at `$HOME/.dotnet/tools`; if `aspire` is not found, run `export PATH="$PATH:$HOME/.dotnet/tools"` first.

---

## Sub-phase 0.1 Tooling check and repository skeleton

### Task 0.1.1: Verify tooling

**Files:** none created.

**Interfaces:**
- Consumes: nothing.
- Produces: confirmation that every later command can run.

- [ ] **Step 1: Run each check and compare with the expected output**

```bash
dotnet --version
# Expected: 10.0.201 or any later 10.0.x

dotnet --list-runtimes | grep "Microsoft.AspNetCore.App 10"
# Expected: at least one line, for example Microsoft.AspNetCore.App 10.0.5

export PATH="$PATH:$HOME/.dotnet/tools"
aspire --version
# Expected: starts with 13.5.3

dotnet new list aspire | grep -E "aspire-apphost|aspire-servicedefaults"
# Expected: both template short names listed

docker info --format '{{.ServerVersion}}'
# Expected: a version such as 28.1.1, meaning the daemon is running

source "$HOME/.nvm/nvm.sh" && nvm ls 24 | head -1
# Expected: a line containing v24., meaning Node 24 is installed

dotnet ef --version
# Expected: Entity Framework Core .NET Command-line Tools followed by 10.x

dotnet dev-certs https --check --trust
# Expected: "A valid certificate was found" and that it is trusted. If not, run: dotnet dev-certs https --trust
```

- [ ] **Step 2: Fix anything missing**

If `aspire` is missing: `dotnet tool install -g Aspire.Cli`. If the templates are missing: `dotnet new install Aspire.ProjectTemplates`. If `dotnet ef` is missing: `dotnet tool install -g dotnet-ef`. If Node 24 is missing: `source "$HOME/.nvm/nvm.sh" && nvm install 24`. If Docker is not running, report it; do not attempt to start it.

- [ ] **Step 3: Report the actual versions observed**

### Task 0.1.2: Repository files and empty solution

**Files:**
- Create: `global.json`
- Create: `Directory.Build.props`
- Create: `Directory.Packages.props`
- Create: `.editorconfig`
- Create: `.gitignore`
- Modify: `README.md` (currently empty)
- Create: `ECommerceAspireDemo.slnx`

**Interfaces:**
- Consumes: nothing.
- Produces: the build properties every project inherits and the central package versions every later task references by name only.

- [ ] **Step 1: Create `global.json`**

```json
{
  "sdk": {
    "version": "10.0.201",
    "rollForward": "latestFeature"
  },
  "test": {
    "runner": "Microsoft.Testing.Platform"
  }
}
```

- [ ] **Step 2: Create `Directory.Build.props`**

```xml
<Project>

  <PropertyGroup>
    <TargetFramework>net10.0</TargetFramework>
    <Nullable>enable</Nullable>
    <ImplicitUsings>enable</ImplicitUsings>
    <InterceptorsNamespaces>$(InterceptorsNamespaces);Microsoft.AspNetCore.Http.Validation.Generated;Microsoft.AspNetCore.OpenApi.Generated</InterceptorsNamespaces>
  </PropertyGroup>

</Project>
```

- [ ] **Step 3: Create `Directory.Packages.props`**

`Aspire.Hosting.AppHost` is deliberately absent: the AppHost SDK references it implicitly and a `PackageVersion` entry for it breaks restore with NU1009.

```xml
<Project>

  <PropertyGroup>
    <ManagePackageVersionsCentrally>true</ManagePackageVersionsCentrally>
  </PropertyGroup>

  <ItemGroup Label="Aspire hosting">
    <PackageVersion Include="Aspire.Hosting.PostgreSQL" Version="13.5.3" />
    <PackageVersion Include="Aspire.Hosting.Redis" Version="13.5.3" />
    <PackageVersion Include="Aspire.Hosting.RabbitMQ" Version="13.5.3" />
    <PackageVersion Include="Aspire.Hosting.MongoDB" Version="13.5.3" />
  </ItemGroup>

  <ItemGroup Label="Service defaults">
    <PackageVersion Include="Microsoft.Extensions.Http.Resilience" Version="10.10.0" />
    <PackageVersion Include="Microsoft.Extensions.ServiceDiscovery" Version="10.10.0" />
    <PackageVersion Include="OpenTelemetry.Exporter.OpenTelemetryProtocol" Version="1.18.0" />
    <PackageVersion Include="OpenTelemetry.Extensions.Hosting" Version="1.18.0" />
    <PackageVersion Include="OpenTelemetry.Instrumentation.AspNetCore" Version="1.18.0" />
    <PackageVersion Include="OpenTelemetry.Instrumentation.Http" Version="1.18.0" />
    <PackageVersion Include="OpenTelemetry.Instrumentation.Runtime" Version="1.18.0" />
    <PackageVersion Include="Microsoft.AspNetCore.OpenApi" Version="10.0.12" />
    <PackageVersion Include="Scalar.AspNetCore" Version="2.17.3" />
  </ItemGroup>

  <ItemGroup Label="Tests">
    <PackageVersion Include="xunit.v3" Version="4.0.0" />
  </ItemGroup>

</Project>
```

- [ ] **Step 4: Create `.editorconfig`**

```ini
root = true

[*]
charset = utf-8
end_of_line = lf
insert_final_newline = true
trim_trailing_whitespace = true
indent_style = space

[*.{cs,csx}]
indent_size = 4
csharp_style_namespace_declarations = file_scoped:warning
csharp_style_var_for_built_in_types = true:suggestion
csharp_style_var_when_type_is_apparent = true:suggestion
csharp_style_var_elsewhere = true:suggestion
csharp_prefer_braces = true:warning
csharp_new_line_before_open_brace = all
csharp_new_line_before_else = true
csharp_new_line_before_catch = true
csharp_new_line_before_finally = true
csharp_style_expression_bodied_methods = when_on_single_line:suggestion
csharp_style_expression_bodied_properties = true:suggestion
csharp_using_directive_placement = outside_namespace:warning
dotnet_sort_system_directives_first = true
dotnet_separate_import_directive_groups = false
dotnet_style_qualification_for_field = false:suggestion
dotnet_style_qualification_for_property = false:suggestion
dotnet_style_qualification_for_method = false:suggestion
dotnet_style_predefined_type_for_locals_parameters_members = true:suggestion
dotnet_style_readonly_field = true:suggestion
dotnet_naming_rule.private_fields_underscore.symbols = private_fields
dotnet_naming_rule.private_fields_underscore.style = underscore_camel_case
dotnet_naming_rule.private_fields_underscore.severity = suggestion
dotnet_naming_symbols.private_fields.applicable_kinds = field
dotnet_naming_symbols.private_fields.applicable_accessibilities = private
dotnet_naming_style.underscore_camel_case.capitalization = camel_case
dotnet_naming_style.underscore_camel_case.required_prefix = _

[*.{csproj,props,targets,slnx}]
indent_size = 2

[*.{json,yml,yaml}]
indent_size = 2

[*.{ts,html,scss,css,js,mjs}]
indent_size = 2
max_line_length = 100

[*.md]
trim_trailing_whitespace = false
```

- [ ] **Step 5: Create `.gitignore`**

Run `dotnet new gitignore` at the root, which writes the standard .NET ignore file, then append the Node section:

```bash
dotnet new gitignore
cat >> .gitignore <<'NODE'

# Node and Angular
node_modules/
dist/
.angular/
npm-debug.log*
NODE
```

- [ ] **Step 6: Write `README.md`**

````markdown
# ECommerce Aspire Demo

A small e-commerce simulator built to show what Aspire gives a team building a
cloud-native microservice system: orchestration from C#, integrations for databases and
brokers, service discovery, resilience and end-to-end observability.

The design is in [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md), the coding rules in
[docs/CODING_GUIDELINES.md](docs/CODING_GUIDELINES.md) and the execution plans in
[docs/plans](docs/plans/README.md).

## Prerequisites

| Tool | Version |
|---|---|
| .NET SDK | 10.0.x |
| Aspire CLI | 13.5.3, `dotnet tool install -g Aspire.Cli` |
| Docker | running daemon |
| Node | 24 through nvm, for the frontend |

## Run

```bash
aspire run --apphost src/Ecommerce.AppHost/Ecommerce.AppHost.csproj
```

The command prints the dashboard URL. The shop itself is at `https://localhost:7100`
once the gateway exists.

## Test

```bash
dotnet test
```

Developed by Goran Todorovic 2026.
````

- [ ] **Step 7: Create the solution file and verify the empty build**

```bash
dotnet new sln -n ECommerceAspireDemo
ls ECommerceAspireDemo.slnx
dotnet build
```

Expected: `ECommerceAspireDemo.slnx` exists and `dotnet build` ends with `Build succeeded.` and one warning, `Unable to find a project to restore!`, which is NuGet complaining that the solution is still empty. It disappears in task 0.2.1 when the first project is added.

---

## Sub-phase 0.2 ServiceDefaults with the API response envelope

### Task 0.2.1: ServiceDefaults project from the template

**Files:**
- Create: `src/Ecommerce.ServiceDefaults/` from the `aspire-servicedefaults` template
- Modify: `src/Ecommerce.ServiceDefaults/Ecommerce.ServiceDefaults.csproj`
- Keep unchanged: `src/Ecommerce.ServiceDefaults/Extensions.cs`

**Interfaces:**
- Consumes: package versions from `Directory.Packages.props`.
- Produces: `AddServiceDefaults()` and `MapDefaultEndpoints()` from the template, in namespace `Microsoft.Extensions.Hosting`. That namespace is the Aspire template convention and is the one deliberate exception to the folder-matches-namespace rule.

- [ ] **Step 1: Scaffold and add to the solution**

```bash
dotnet new aspire-servicedefaults -n Ecommerce.ServiceDefaults -o src/Ecommerce.ServiceDefaults
dotnet sln add src/Ecommerce.ServiceDefaults
```

The template's post-creation restore fails with NU1008 because the generated project
file carries explicit package versions, which central package management forbids. That
is expected; step 2 replaces the file and the next restore succeeds.

- [ ] **Step 2: Replace the project file**

The template writes explicit versions and properties that the root files now own. Replace `src/Ecommerce.ServiceDefaults/Ecommerce.ServiceDefaults.csproj` with:

```xml
<Project Sdk="Microsoft.NET.Sdk">

  <PropertyGroup>
    <IsAspireSharedProject>true</IsAspireSharedProject>
  </PropertyGroup>

  <ItemGroup>
    <FrameworkReference Include="Microsoft.AspNetCore.App" />
  </ItemGroup>

  <ItemGroup>
    <PackageReference Include="Microsoft.Extensions.Http.Resilience" />
    <PackageReference Include="Microsoft.Extensions.ServiceDiscovery" />
    <PackageReference Include="OpenTelemetry.Exporter.OpenTelemetryProtocol" />
    <PackageReference Include="OpenTelemetry.Extensions.Hosting" />
    <PackageReference Include="OpenTelemetry.Instrumentation.AspNetCore" />
    <PackageReference Include="OpenTelemetry.Instrumentation.Http" />
    <PackageReference Include="OpenTelemetry.Instrumentation.Runtime" />
    <PackageReference Include="Microsoft.AspNetCore.OpenApi" />
    <PackageReference Include="Scalar.AspNetCore" />
  </ItemGroup>

</Project>
```

- [ ] **Step 3: Build**

```bash
dotnet build
```

Expected: `Build succeeded.` with `0 Warning(s)`. Do not edit `Extensions.cs`; the template's comments are the one place existing comment style is left as generated.

### Task 0.2.2: Envelope types and ApiResults, test-first

**Files:**
- Create: `tests/Ecommerce.ServiceDefaults.Tests/Ecommerce.ServiceDefaults.Tests.csproj`
- Create: `tests/Ecommerce.ServiceDefaults.Tests/Api/ApiResponseTests.cs`
- Create: `tests/Ecommerce.ServiceDefaults.Tests/Api/ApiResultsTests.cs`
- Create: `src/Ecommerce.ServiceDefaults/Api/ApiResponse.cs`
- Create: `src/Ecommerce.ServiceDefaults/Api/ApiResults.cs`

**Interfaces:**
- Consumes: nothing beyond ASP.NET Core.
- Produces, in namespace `Ecommerce.ServiceDefaults.Api`:
  - `sealed record ApiError(string Code, string Message, object? Details, string? TraceId)`
  - `sealed record ApiResponse<T>(bool Success, T? Data, ApiError? Error)`
  - `sealed record ApiResponse(bool Success, object? Data, ApiError? Error)` with static factories `Ok<T>(T data)`, `Empty()`, `Fail(string code, string message, object? details = null)`
  - `static class ApiResults` with `Ok<T>(T)`, `Accepted<T>(T)`, `Empty()`, `BadRequest(code, message, details?)`, `NotFound(code, message)`, `Conflict(code, message, details?)`, `ServiceUnavailable(code, message)` returning the typed results named in the code below.

- [ ] **Step 1: Create the test project**

`tests/Ecommerce.ServiceDefaults.Tests/Ecommerce.ServiceDefaults.Tests.csproj`:

```xml
<Project Sdk="Microsoft.NET.Sdk">

  <PropertyGroup>
    <OutputType>Exe</OutputType>
    <IsPackable>false</IsPackable>
    <IsTestProject>true</IsTestProject>
  </PropertyGroup>

  <ItemGroup>
    <FrameworkReference Include="Microsoft.AspNetCore.App" />
  </ItemGroup>

  <ItemGroup>
    <PackageReference Include="xunit.v3" />
  </ItemGroup>

  <ItemGroup>
    <Using Include="Xunit" />
  </ItemGroup>

  <ItemGroup>
    <ProjectReference Include="../../src/Ecommerce.ServiceDefaults/Ecommerce.ServiceDefaults.csproj" />
  </ItemGroup>

</Project>
```

```bash
dotnet sln add tests/Ecommerce.ServiceDefaults.Tests
```

- [ ] **Step 2: Write the failing tests for the envelope records**

`tests/Ecommerce.ServiceDefaults.Tests/Api/ApiResponseTests.cs`:

```csharp
using System.Diagnostics;
using Ecommerce.ServiceDefaults.Api;

namespace Ecommerce.ServiceDefaults.Tests.Api;

public sealed class ApiResponseTests
{
    [Fact]
    public void Ok_WithData_SetsSuccessTrueAndNoError()
    {
        var response = ApiResponse.Ok(new { Name = "Mug" });

        Assert.True(response.Success);
        Assert.NotNull(response.Data);
        Assert.Null(response.Error);
    }

    [Fact]
    public void Empty_SetsSuccessTrueWithNullData()
    {
        var response = ApiResponse.Empty();

        Assert.True(response.Success);
        Assert.Null(response.Data);
        Assert.Null(response.Error);
    }

    [Fact]
    public void Fail_SetsSuccessFalseAndError()
    {
        var response = ApiResponse.Fail("catalog.product_not_found", "Product [1] not found");

        Assert.False(response.Success);
        Assert.Null(response.Data);
        Assert.NotNull(response.Error);
        Assert.Equal("catalog.product_not_found", response.Error.Code);
        Assert.Equal("Product [1] not found", response.Error.Message);
        Assert.Null(response.Error.Details);
    }

    [Fact]
    public void Fail_WithDetails_KeepsDetails()
    {
        var details = new Dictionary<string, string[]> { ["Name"] = ["Required"] };

        var response = ApiResponse.Fail("common.validation_failed", "Request validation failed", details);

        Assert.NotNull(response.Error);
        Assert.Same(details, response.Error.Details);
    }

    [Fact]
    public void Fail_WithCurrentActivity_SetsTraceIdFromActivity()
    {
        using var source = new ActivitySource("Ecommerce.ServiceDefaults.Tests");
        using var listener = new ActivityListener
        {
            ShouldListenTo = _ => true,
            Sample = (ref ActivityCreationOptions<ActivityContext> _) => ActivitySamplingResult.AllData,
        };
        ActivitySource.AddActivityListener(listener);
        using var activity = source.StartActivity("test");

        var response = ApiResponse.Fail("common.error", "Failed");

        Assert.NotNull(activity);
        Assert.NotNull(response.Error);
        Assert.Equal(activity.Id, response.Error.TraceId);
    }

    [Fact]
    public void Fail_WithoutActivity_LeavesTraceIdNull()
    {
        Activity.Current = null;

        var response = ApiResponse.Fail("common.error", "Failed");

        Assert.NotNull(response.Error);
        Assert.Null(response.Error.TraceId);
    }
}
```

- [ ] **Step 3: Run the tests and confirm they fail to compile**

```bash
dotnet test --project tests/Ecommerce.ServiceDefaults.Tests
```

Expected: build errors naming `ApiResponse` as missing. That is the failing state.

- [ ] **Step 4: Implement the envelope records**

`src/Ecommerce.ServiceDefaults/Api/ApiResponse.cs`:

```csharp
using System.Diagnostics;

namespace Ecommerce.ServiceDefaults.Api;

public sealed record ApiError(string Code, string Message, object? Details, string? TraceId);

public sealed record ApiResponse<T>(bool Success, T? Data, ApiError? Error);

public sealed record ApiResponse(bool Success, object? Data, ApiError? Error)
{
    public static ApiResponse<T> Ok<T>(T data) => new(true, data, null);

    public static ApiResponse Empty() => new(true, null, null);

    public static ApiResponse Fail(string code, string message, object? details = null) =>
        new(false, null, new ApiError(code, message, details, Activity.Current?.Id));
}
```

- [ ] **Step 5: Run the tests and confirm they pass**

```bash
dotnet test --project tests/Ecommerce.ServiceDefaults.Tests
```

Expected: `Passed!` with 6 succeeded.

- [ ] **Step 6: Write the failing tests for ApiResults**

`tests/Ecommerce.ServiceDefaults.Tests/Api/ApiResultsTests.cs`:

```csharp
using Ecommerce.ServiceDefaults.Api;
using Microsoft.AspNetCore.Http;

namespace Ecommerce.ServiceDefaults.Tests.Api;

public sealed class ApiResultsTests
{
    [Fact]
    public void Ok_WrapsDataInSuccessEnvelope()
    {
        var result = ApiResults.Ok(42);

        Assert.Equal(StatusCodes.Status200OK, result.StatusCode);
        Assert.NotNull(result.Value);
        Assert.True(result.Value.Success);
        Assert.Equal(42, result.Value.Data);
    }

    [Fact]
    public void Accepted_WrapsDataInSuccessEnvelope()
    {
        var result = ApiResults.Accepted("order-1");

        Assert.Equal(StatusCodes.Status202Accepted, result.StatusCode);
        Assert.NotNull(result.Value);
        Assert.True(result.Value.Success);
        Assert.Equal("order-1", result.Value.Data);
    }

    [Fact]
    public void Empty_IsOkWithNullData()
    {
        var result = ApiResults.Empty();

        Assert.Equal(StatusCodes.Status200OK, result.StatusCode);
        Assert.NotNull(result.Value);
        Assert.True(result.Value.Success);
        Assert.Null(result.Value.Data);
    }

    [Fact]
    public void BadRequest_CarriesCodeMessageAndDetails()
    {
        var details = new { Field = "Name" };

        var result = ApiResults.BadRequest("common.buyer_id_invalid", "Header [X-Buyer-Id] is missing", details);

        Assert.Equal(StatusCodes.Status400BadRequest, result.StatusCode);
        Assert.NotNull(result.Value?.Error);
        Assert.Equal("common.buyer_id_invalid", result.Value.Error.Code);
        Assert.Equal("Header [X-Buyer-Id] is missing", result.Value.Error.Message);
        Assert.Same(details, result.Value.Error.Details);
    }

    [Fact]
    public void NotFound_CarriesCodeAndMessage()
    {
        var result = ApiResults.NotFound("catalog.product_not_found", "Product [1] not found");

        Assert.Equal(StatusCodes.Status404NotFound, result.StatusCode);
        Assert.NotNull(result.Value?.Error);
        Assert.False(result.Value.Success);
        Assert.Equal("catalog.product_not_found", result.Value.Error.Code);
    }

    [Fact]
    public void Conflict_CarriesCodeMessageAndDetails()
    {
        var details = new[] { "a", "b" };

        var result = ApiResults.Conflict("basket.product_out_of_stock", "Product [Mug] has [0] units available", details);

        Assert.Equal(StatusCodes.Status409Conflict, result.StatusCode);
        Assert.NotNull(result.Value?.Error);
        Assert.Equal("basket.product_out_of_stock", result.Value.Error.Code);
        Assert.Same(details, result.Value.Error.Details);
    }

    [Fact]
    public void ServiceUnavailable_Uses503AndFailureEnvelope()
    {
        var result = ApiResults.ServiceUnavailable("basket.broker_unavailable", "Message broker is unavailable");

        Assert.Equal(StatusCodes.Status503ServiceUnavailable, result.StatusCode);
        Assert.NotNull(result.Value?.Error);
        Assert.False(result.Value.Success);
        Assert.Equal("basket.broker_unavailable", result.Value.Error.Code);
    }
}
```

- [ ] **Step 7: Run the tests and confirm they fail to compile**

```bash
dotnet test --project tests/Ecommerce.ServiceDefaults.Tests
```

Expected: build errors naming `ApiResults` as missing.

- [ ] **Step 8: Implement ApiResults**

`src/Ecommerce.ServiceDefaults/Api/ApiResults.cs`:

```csharp
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;

namespace Ecommerce.ServiceDefaults.Api;

public static class ApiResults
{
    public static Ok<ApiResponse<T>> Ok<T>(T data) =>
        TypedResults.Ok(ApiResponse.Ok(data));

    public static Accepted<ApiResponse<T>> Accepted<T>(T data) =>
        TypedResults.Accepted((string?)null, ApiResponse.Ok(data));

    public static Ok<ApiResponse> Empty() =>
        TypedResults.Ok(ApiResponse.Empty());

    public static BadRequest<ApiResponse> BadRequest(string code, string message, object? details = null) =>
        TypedResults.BadRequest(ApiResponse.Fail(code, message, details));

    public static NotFound<ApiResponse> NotFound(string code, string message) =>
        TypedResults.NotFound(ApiResponse.Fail(code, message));

    public static Conflict<ApiResponse> Conflict(string code, string message, object? details = null) =>
        TypedResults.Conflict(ApiResponse.Fail(code, message, details));

    public static JsonHttpResult<ApiResponse> ServiceUnavailable(string code, string message) =>
        TypedResults.Json(ApiResponse.Fail(code, message), statusCode: StatusCodes.Status503ServiceUnavailable);
}
```

- [ ] **Step 9: Run the tests and confirm they pass**

```bash
dotnet test --project tests/Ecommerce.ServiceDefaults.Tests
```

Expected: `Passed!` with 13 succeeded, and the build output shows no warnings.

### Task 0.2.3: Problem details writer, test-first

**Files:**
- Create: `tests/Ecommerce.ServiceDefaults.Tests/Api/ApiEnvelopeProblemDetailsWriterTests.cs`
- Create: `src/Ecommerce.ServiceDefaults/Api/CommonErrorCodes.cs`
- Create: `src/Ecommerce.ServiceDefaults/Api/ApiEnvelopeProblemDetailsWriter.cs`

**Interfaces:**
- Consumes: `ApiResponse`, `ApiError` from task 0.2.2.
- Produces:
  - `static class CommonErrorCodes` with constants `ValidationFailed`, `BadRequest`, `BuyerIdInvalid`, `NotFound`, `MethodNotAllowed`, `UnsupportedMediaType`, `InternalError`.
  - `sealed class ApiEnvelopeProblemDetailsWriter : IProblemDetailsWriter` that converts any `ProblemDetails` into the failure envelope.

- [ ] **Step 1: Write the failing tests**

`tests/Ecommerce.ServiceDefaults.Tests/Api/ApiEnvelopeProblemDetailsWriterTests.cs`:

```csharp
using System.Text.Json;
using Ecommerce.ServiceDefaults.Api;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Ecommerce.ServiceDefaults.Tests.Api;

public sealed class ApiEnvelopeProblemDetailsWriterTests
{
    [Fact]
    public void CanWrite_AlwaysReturnsTrue()
    {
        var writer = new ApiEnvelopeProblemDetailsWriter();
        var context = new ProblemDetailsContext
        {
            HttpContext = new DefaultHttpContext(),
            ProblemDetails = new ProblemDetails { Status = 418 },
        };

        Assert.True(writer.CanWrite(context));
    }

    [Fact]
    public async Task WriteAsync_WithValidationProblem_WritesValidationFailedEnvelopeWithFieldErrors()
    {
        var errors = new Dictionary<string, string[]> { ["Name"] = ["The Name field is required."] };
        var problem = new HttpValidationProblemDetails(errors) { Status = StatusCodes.Status400BadRequest };

        var (status, root) = await WriteAsync(problem);

        Assert.Equal(400, status);
        Assert.False(root.GetProperty("success").GetBoolean());
        Assert.Equal(JsonValueKind.Null, root.GetProperty("data").ValueKind);
        var error = root.GetProperty("error");
        Assert.Equal("common.validation_failed", error.GetProperty("code").GetString());
        Assert.Equal("Request validation failed", error.GetProperty("message").GetString());
        Assert.Equal("The Name field is required.", error.GetProperty("details").GetProperty("Name")[0].GetString());
        Assert.False(string.IsNullOrEmpty(error.GetProperty("traceId").GetString()));
    }

    [Fact]
    public async Task WriteAsync_WithPlain400_WritesBadRequestEnvelope()
    {
        var problem = new ProblemDetails { Status = StatusCodes.Status400BadRequest };

        var (status, root) = await WriteAsync(problem);

        Assert.Equal(400, status);
        Assert.Equal("common.bad_request", root.GetProperty("error").GetProperty("code").GetString());
        Assert.Equal("The request could not be read", root.GetProperty("error").GetProperty("message").GetString());
    }

    [Fact]
    public async Task WriteAsync_With404_WritesNotFoundEnvelopeNamingThePath()
    {
        var problem = new ProblemDetails { Status = StatusCodes.Status404NotFound };

        var (status, root) = await WriteAsync(problem, "/api/nope");

        Assert.Equal(404, status);
        Assert.Equal("common.not_found", root.GetProperty("error").GetProperty("code").GetString());
        Assert.Equal("No endpoint matches [/api/nope]", root.GetProperty("error").GetProperty("message").GetString());
    }

    [Fact]
    public async Task WriteAsync_With500_WritesInternalErrorEnvelope()
    {
        var problem = new ProblemDetails { Status = StatusCodes.Status500InternalServerError };

        var (status, root) = await WriteAsync(problem);

        Assert.Equal(500, status);
        Assert.Equal("common.internal_error", root.GetProperty("error").GetProperty("code").GetString());
        Assert.Equal("An unexpected error occurred", root.GetProperty("error").GetProperty("message").GetString());
    }

    [Fact]
    public async Task WriteAsync_WithoutStatus_UsesResponseStatusCode()
    {
        var problem = new ProblemDetails();

        var (status, root) = await WriteAsync(problem, responseStatus: StatusCodes.Status405MethodNotAllowed);

        Assert.Equal(405, status);
        Assert.Equal("common.method_not_allowed", root.GetProperty("error").GetProperty("code").GetString());
    }

    [Fact]
    public async Task WriteAsync_WithUnmappedStatus_UsesGenericCodeAndTrimsTitle()
    {
        var problem = new ProblemDetails { Status = 418, Title = "I am a teapot." };

        var (status, root) = await WriteAsync(problem);

        Assert.Equal(418, status);
        Assert.Equal("common.http_418", root.GetProperty("error").GetProperty("code").GetString());
        Assert.Equal("I am a teapot", root.GetProperty("error").GetProperty("message").GetString());
    }

    [Fact]
    public async Task WriteAsync_WithCodeExtension_PrefersThatCode()
    {
        var problem = new ProblemDetails { Status = 409, Detail = "Basket is empty" };
        problem.Extensions["code"] = "basket.checkout_empty";

        var (status, root) = await WriteAsync(problem);

        Assert.Equal(409, status);
        Assert.Equal("basket.checkout_empty", root.GetProperty("error").GetProperty("code").GetString());
        Assert.Equal("Basket is empty", root.GetProperty("error").GetProperty("message").GetString());
    }

    private static async Task<(int Status, JsonElement Root)> WriteAsync(
        ProblemDetails problem,
        string path = "/api/test",
        int responseStatus = StatusCodes.Status200OK)
    {
        var http = new DefaultHttpContext();
        http.Request.Path = path;
        http.Response.StatusCode = responseStatus;
        http.Response.Body = new MemoryStream();
        var writer = new ApiEnvelopeProblemDetailsWriter();

        await writer.WriteAsync(new ProblemDetailsContext { HttpContext = http, ProblemDetails = problem });

        http.Response.Body.Position = 0;
        using var document = await JsonDocument.ParseAsync(
            http.Response.Body,
            cancellationToken: TestContext.Current.CancellationToken);
        return (http.Response.StatusCode, document.RootElement.Clone());
    }
}
```

- [ ] **Step 2: Run the tests and confirm they fail to compile**

```bash
dotnet test --project tests/Ecommerce.ServiceDefaults.Tests
```

Expected: build errors naming `ApiEnvelopeProblemDetailsWriter` as missing.

- [ ] **Step 3: Implement the error code constants**

`src/Ecommerce.ServiceDefaults/Api/CommonErrorCodes.cs`:

```csharp
namespace Ecommerce.ServiceDefaults.Api;

public static class CommonErrorCodes
{
    public const string ValidationFailed = "common.validation_failed";
    public const string BadRequest = "common.bad_request";
    public const string BuyerIdInvalid = "common.buyer_id_invalid";
    public const string NotFound = "common.not_found";
    public const string MethodNotAllowed = "common.method_not_allowed";
    public const string UnsupportedMediaType = "common.unsupported_media_type";
    public const string InternalError = "common.internal_error";
}
```

- [ ] **Step 4: Implement the writer**

`src/Ecommerce.ServiceDefaults/Api/ApiEnvelopeProblemDetailsWriter.cs`:

```csharp
using System.Diagnostics;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Ecommerce.ServiceDefaults.Api;

// Converts every ProblemDetails the framework produces into the API response envelope
public sealed class ApiEnvelopeProblemDetailsWriter : IProblemDetailsWriter
{
    public bool CanWrite(ProblemDetailsContext context) => true;

    public ValueTask WriteAsync(ProblemDetailsContext context)
    {
        var http = context.HttpContext;
        var problem = context.ProblemDetails;
        var status = problem.Status ?? http.Response.StatusCode;
        http.Response.StatusCode = status;

        var code = ResolveCode(problem, status);
        var message = ResolveMessage(problem, status, http.Request.Path);
        var details = problem is HttpValidationProblemDetails validation ? validation.Errors : null;
        var traceId = Activity.Current?.Id ?? http.TraceIdentifier;
        var envelope = new ApiResponse(false, null, new ApiError(code, message, details, traceId));

        return new ValueTask(http.Response.WriteAsJsonAsync(envelope, http.RequestAborted));
    }

    private static string ResolveCode(ProblemDetails problem, int status)
    {
        if (problem.Extensions.TryGetValue("code", out var value) && value is string code)
        {
            return code;
        }

        return status switch
        {
            StatusCodes.Status400BadRequest when problem is HttpValidationProblemDetails => CommonErrorCodes.ValidationFailed,
            StatusCodes.Status400BadRequest => CommonErrorCodes.BadRequest,
            StatusCodes.Status404NotFound => CommonErrorCodes.NotFound,
            StatusCodes.Status405MethodNotAllowed => CommonErrorCodes.MethodNotAllowed,
            StatusCodes.Status415UnsupportedMediaType => CommonErrorCodes.UnsupportedMediaType,
            StatusCodes.Status500InternalServerError => CommonErrorCodes.InternalError,
            _ => $"common.http_{status}",
        };
    }

    private static string ResolveMessage(ProblemDetails problem, int status, PathString path)
    {
        if (!string.IsNullOrWhiteSpace(problem.Detail))
        {
            return TrimFullStop(problem.Detail);
        }

        return status switch
        {
            StatusCodes.Status400BadRequest when problem is HttpValidationProblemDetails => "Request validation failed",
            StatusCodes.Status400BadRequest => "The request could not be read",
            StatusCodes.Status404NotFound => $"No endpoint matches [{path}]",
            StatusCodes.Status500InternalServerError => "An unexpected error occurred",
            _ => TrimFullStop(problem.Title ?? $"Request failed with status [{status}]"),
        };
    }

    private static string TrimFullStop(string text) => text.TrimEnd('.');
}
```

- [ ] **Step 5: Run the tests and confirm they pass**

```bash
dotnet test --project tests/Ecommerce.ServiceDefaults.Tests
```

Expected: `Passed!` with 21 succeeded, no warnings.

### Task 0.2.4: AddApiDefaults and UseApiDefaults, test-first

**Files:**
- Create: `tests/Ecommerce.ServiceDefaults.Tests/Api/ApiDefaultsExtensionsTests.cs`
- Create: `src/Ecommerce.ServiceDefaults/Api/ApiDefaultsExtensions.cs`

**Interfaces:**
- Consumes: `ApiEnvelopeProblemDetailsWriter` from task 0.2.3, `MapDefaultEndpoints()` from the template.
- Produces, in namespace `Ecommerce.ServiceDefaults.Api`:
  - `TBuilder AddApiDefaults<TBuilder>(this TBuilder builder) where TBuilder : IHostApplicationBuilder`, registering the envelope writer first, then problem details and OpenAPI. It does not call `AddValidation()`; each API project calls that itself because the validation source generator intercepts the call site.
  - `WebApplication UseApiDefaults(this WebApplication app)`, adding the exception handler with a status code selector, status code pages, the default health endpoints, and OpenAPI plus Scalar in development.

- [ ] **Step 1: Write the failing test**

`tests/Ecommerce.ServiceDefaults.Tests/Api/ApiDefaultsExtensionsTests.cs`:

```csharp
using Ecommerce.ServiceDefaults.Api;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;

namespace Ecommerce.ServiceDefaults.Tests.Api;

public sealed class ApiDefaultsExtensionsTests
{
    [Fact]
    public void AddApiDefaults_RegistersEnvelopeWriterAheadOfTheFrameworkWriter()
    {
        var builder = WebApplication.CreateBuilder();
        builder.AddApiDefaults();
        using var app = builder.Build();

        var writers = app.Services.GetServices<IProblemDetailsWriter>().ToList();

        Assert.True(writers.Count >= 2);
        Assert.IsType<ApiEnvelopeProblemDetailsWriter>(writers[0]);
        Assert.NotNull(app.Services.GetService<IProblemDetailsService>());
    }
}
```

- [ ] **Step 2: Run the tests and confirm they fail to compile**

```bash
dotnet test --project tests/Ecommerce.ServiceDefaults.Tests
```

Expected: build error naming `AddApiDefaults` as missing.

- [ ] **Step 3: Implement the extensions**

`src/Ecommerce.ServiceDefaults/Api/ApiDefaultsExtensions.cs`:

```csharp
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.Hosting;
using Scalar.AspNetCore;

namespace Ecommerce.ServiceDefaults.Api;

public static class ApiDefaultsExtensions
{
    // The envelope writer must be registered before AddProblemDetails so it is asked first
    public static TBuilder AddApiDefaults<TBuilder>(this TBuilder builder) where TBuilder : IHostApplicationBuilder
    {
        builder.Services.TryAddEnumerable(ServiceDescriptor.Singleton<IProblemDetailsWriter, ApiEnvelopeProblemDetailsWriter>());
        builder.Services.AddProblemDetails();
        builder.Services.AddOpenApi();

        return builder;
    }

    public static WebApplication UseApiDefaults(this WebApplication app)
    {
        app.UseExceptionHandler(new ExceptionHandlerOptions
        {
            StatusCodeSelector = exception => exception is BadHttpRequestException badRequest
                ? badRequest.StatusCode
                : StatusCodes.Status500InternalServerError,
        });
        app.UseStatusCodePages();
        app.MapDefaultEndpoints();

        if (app.Environment.IsDevelopment())
        {
            app.MapOpenApi();
            app.MapScalarApiReference();
        }

        return app;
    }
}
```

- [ ] **Step 4: Run the tests and confirm they pass**

```bash
dotnet test --project tests/Ecommerce.ServiceDefaults.Tests
```

Expected: `Passed!` with 22 succeeded, no warnings.

---

## Sub-phase 0.3 AppHost with infrastructure resources

### Task 0.3.1: AppHost project with Postgres, Redis, RabbitMQ and Mongo

**Files:**
- Create: `src/Ecommerce.AppHost/` from the `aspire-apphost` template
- Modify: `src/Ecommerce.AppHost/Ecommerce.AppHost.csproj`
- Modify: `src/Ecommerce.AppHost/AppHost.cs`
- Modify: `src/Ecommerce.AppHost/Properties/launchSettings.json`
- Keep as generated: `src/Ecommerce.AppHost/aspire.config.json`, `appsettings.json`, `appsettings.Development.json`

**Interfaces:**
- Consumes: hosting package versions from `Directory.Packages.props`.
- Produces: resources named `postgres`, `catalogdb`, `basket-cache`, `messaging`, `mongo`, `orderingdb`. Later phases reference `catalogDb`, `redis`, `rabbitMq` and `orderingDb` variables by these exact names in `AppHost.cs`.

- [ ] **Step 1: Scaffold and add to the solution**

```bash
dotnet new aspire-apphost -n Ecommerce.AppHost -o src/Ecommerce.AppHost
dotnet sln add src/Ecommerce.AppHost
```

- [ ] **Step 2: Replace the project file**

`src/Ecommerce.AppHost/Ecommerce.AppHost.csproj`:

```xml
<Project Sdk="Aspire.AppHost.Sdk/13.5.3">

  <PropertyGroup>
    <OutputType>Exe</OutputType>
    <AspireUseCliBundle>true</AspireUseCliBundle>
    <UserSecretsId>ecommerce-aspire-demo-apphost</UserSecretsId>
  </PropertyGroup>

  <ItemGroup>
    <PackageReference Include="Aspire.Hosting.PostgreSQL" />
    <PackageReference Include="Aspire.Hosting.Redis" />
    <PackageReference Include="Aspire.Hosting.RabbitMQ" />
    <PackageReference Include="Aspire.Hosting.MongoDB" />
  </ItemGroup>

</Project>
```

- [ ] **Step 3: Write `AppHost.cs`**

```csharp
var builder = DistributedApplication.CreateBuilder(args);

var postgres = builder.AddPostgres("postgres");
var catalogDb = postgres.AddDatabase("catalogdb");

var redis = builder.AddRedis("basket-cache");

var rabbitMq = builder.AddRabbitMQ("messaging")
    .WithManagementPlugin();

var mongo = builder.AddMongoDB("mongo");
var orderingDb = mongo.AddDatabase("orderingdb");

builder.Build().Run();
```

- [ ] **Step 4: Fix the dashboard ports**

Replace `src/Ecommerce.AppHost/Properties/launchSettings.json` so the dashboard address never changes between runs:

```json
{
  "$schema": "https://json.schemastore.org/launchsettings.json",
  "profiles": {
    "https": {
      "commandName": "Project",
      "dotnetRunMessages": true,
      "launchBrowser": true,
      "applicationUrl": "https://localhost:17000;http://localhost:15000",
      "environmentVariables": {
        "ASPNETCORE_ENVIRONMENT": "Development",
        "DOTNET_ENVIRONMENT": "Development",
        "ASPIRE_DASHBOARD_OTLP_ENDPOINT_URL": "https://localhost:21000",
        "ASPIRE_RESOURCE_SERVICE_ENDPOINT_URL": "https://localhost:22000"
      }
    },
    "http": {
      "commandName": "Project",
      "dotnetRunMessages": true,
      "launchBrowser": true,
      "applicationUrl": "http://localhost:15000",
      "environmentVariables": {
        "ASPNETCORE_ENVIRONMENT": "Development",
        "DOTNET_ENVIRONMENT": "Development",
        "ASPIRE_DASHBOARD_OTLP_ENDPOINT_URL": "http://localhost:19000",
        "ASPIRE_RESOURCE_SERVICE_ENDPOINT_URL": "http://localhost:20000"
      }
    }
  }
}
```

- [ ] **Step 5: Build the whole solution**

```bash
dotnet build
```

Expected: `Build succeeded.` with `0 Warning(s)`. The four `catalogDb`, `redis`, `rabbitMq` and `orderingDb` variables are unused in this phase and produce no build warning.

---

## Sub-phase 0.4 Phase acceptance

Run by the lead after every task above is reviewed and ticked.

- [ ] **Step 1: Clean build and full test run**

```bash
dotnet build
dotnet test
```

Expected: `0 Warning(s)`, 22 tests passed.

- [ ] **Step 2: Start the AppHost**

```bash
export PATH="$PATH:$HOME/.dotnet/tools"
aspire run --apphost src/Ecommerce.AppHost/Ecommerce.AppHost.csproj
```

Expected: the CLI prints the dashboard login URL on `https://localhost:17000` and opens it. On the first run macOS asks for authorization to trust the Aspire developer certificate; approve it. Docker pulls the four images on the first run, which can take a few minutes. `dotnet run --project src/Ecommerce.AppHost` gives the same result, because the AppHost project delegates to the Aspire CLI bundle.

- [ ] **Step 3: Check the dashboard**

Resources page shows, all in state Running with a healthy check mark: `postgres`, `catalogdb`, `basket-cache`, `messaging`, `mongo`, `orderingdb`. The `messaging` resource has a management UI endpoint link that opens the RabbitMQ management page with login `guest` and the generated password shown in the resource details. Console logs for `postgres` show `database system is ready to accept connections`.

- [ ] **Step 4: Stop and record**

Press Ctrl+C. The lead ticks phase 0 in `STATUS.md`, writes the phase entry in `SUMMARY.md`, and waits for the owner's review.

**Non-interactive equivalent used by the lead.** The same acceptance can be run without a terminal session or the certificate prompt:

```bash
export PATH="$PATH:$HOME/.dotnet/tools"
AH=src/Ecommerce.AppHost/Ecommerce.AppHost.csproj
aspire start --apphost $AH --non-interactive --format Json
for r in postgres catalogdb basket-cache messaging mongo orderingdb; do
  aspire wait $r --status healthy --timeout 240 --apphost $AH --non-interactive
done
aspire describe --apphost $AH --non-interactive --format Table
aspire logs postgres --tail 3 --apphost $AH --non-interactive
aspire stop --apphost $AH --non-interactive
```

Expected: every `wait` prints `Resource '<name>' is healthy`, `describe` lists all six resources as Running and Healthy, and `stop` reports the AppHost stopped. The containers disappear from `docker ps` a few seconds after the stop.
