# Phase 5 Payment and Lifecycle Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** The full loop. A submitted order is paid by the simulated Payment service, published as `OrderPaid`, decremented from the Catalog stock through a durable inbox, and shipped a few seconds later; a declined test card ends in PaymentFailed; the orders page follows the changes without a refresh.

**Architecture:** `Ecommerce.Payment.Api` is a stateless minimal API with one endpoint, a configurable processing delay and the test card rule (numbers ending in 0002 are declined). Ordering gains the state transitions on `Order`, an atomic lease claim and update in the Mongo store, a typed `PaymentClient` on `https+http://payment-api`, an outbox-backed `OrderPaid` publisher (Postgres message store in a new `orderingmessages` database), an `OrderProcessingService` holding the decisions and an `OrderProcessor` background service polling for due orders. The card number stays on the order only until the payment step completes and is then dropped, leaving the last four digits. Catalog consumes `OrderPaid` through Wolverine's durable inbox in its own database with EF Core transactional middleware, decrementing stock with a guarded update that floors at zero. The frontend orders page polls every three seconds only while an order is Submitted or Paid.

**Tech Stack:** WolverineFx 6.36.0 with RabbitMQ, RuntimeCompilation, Postgresql and EntityFrameworkCore packages (MIT), Microsoft.Extensions.TimeProvider.Testing (MIT, tests), Polly exception types through the resilience handler.

**Spec:** `docs/ARCHITECTURE.md` sections 2.1, 4.2, 4.4, 4.5, 4.6, 4.7, 5 and 6; `docs/CODING_GUIDELINES.md` sections 2, 3, 4, 5 and 6.

**Agents and ordering:** `backend-dev` runs sub-phases 5.1 to 5.3 in order, `frontend-dev` runs sub-phase 5.4. They run in parallel with no dependency between them. Sub-phase 5.5 is the lead's acceptance and needs both halves.

## Global Constraints

- Everything from `docs/plans/README.md` Global constraints applies.
- New NuGet package version in this phase: `WolverineFx.EntityFrameworkCore` 6.36.0 (MIT). Every other package is already declared. No new npm packages. Add nothing else.
- A DbContext that Wolverine wraps in a transaction must be registered with `DisableRetry = true` on the Aspire Npgsql EF Core settings: EF Core refuses user-initiated transactions under the retrying execution strategy, and without this the `OrderPaid` handler fails on every message and the event ends in the dead-letter queue.
- The card number is never logged and never returned by an endpoint. It stays on the order document only until the payment step completes.
- Endpoint classes are static and do not log; `PaymentService`, `OrderProcessingService`, `OrderProcessor` and `OrderPaidHandler` log with `ILogger<T>` in the `[{Prefix}]` format.
- Frontend commands run inside `src/ecommerce-frontend` after `source "$HOME/.nvm/nvm.sh" && nvm use`, and every frontend task ends with `npm test`, `npm run build`, `npm run lint` and `npm run format:check` passing.

---

## Sub-phase 5.1 Payment service (backend-dev)

### Task 5.1.1: Payment API with the test card rule, test-first

**Files:**
- Create: `src/Ecommerce.Payment.Api/Ecommerce.Payment.Api.csproj`
- Create: `src/Ecommerce.Payment.Api/Program.cs`
- Create: `src/Ecommerce.Payment.Api/appsettings.json`
- Create: `src/Ecommerce.Payment.Api/appsettings.Development.json`
- Create: `src/Ecommerce.Payment.Api/Properties/launchSettings.json`
- Create: `src/Ecommerce.Payment.Api/Features/PaymentOptions.cs`
- Create: `src/Ecommerce.Payment.Api/Features/PaymentDecision.cs`
- Create: `src/Ecommerce.Payment.Api/Features/PaymentService.cs`
- Create: `src/Ecommerce.Payment.Api/Features/Authorize/AuthorizeEndpoint.cs`
- Create: `tests/Ecommerce.Payment.Api.Tests/Ecommerce.Payment.Api.Tests.csproj`
- Create: `tests/Ecommerce.Payment.Api.Tests/Features/PaymentDecisionTests.cs`
- Create: `tests/Ecommerce.Payment.Api.Tests/Features/PaymentServiceTests.cs`
- Create: `tests/Ecommerce.Payment.Api.Tests/Features/AuthorizeEndpointTests.cs`

**Interfaces:**
- Consumes: ServiceDefaults.
- Produces: `POST /api/payments` with `AuthorizeRequest(OrderId, Amount, Currency, CardNumber, CardHolder)` validated by data annotations (amount above zero, three-letter currency, sixteen-digit card number, holder name), answering 200 with `AuthorizeResponse(PaymentId, Status, Reason)` where `Status` is `Approved` or `Declined` and `Reason` is `card_declined` for declines; `PaymentOptions.ProcessingDelay` bound from the `Payment` section (default 1.5 seconds) and awaited through `TimeProvider` so tests can fake it; `PaymentDecision.IsDeclined` for numbers ending in `0002`. Fixed ports 7140 and 5140. Not routed through the gateway.

- [ ] **Step 1: Create the project files**

Create the folders `src/Ecommerce.Payment.Api`, `src/Ecommerce.Payment.Api/Properties` and `tests/Ecommerce.Payment.Api.Tests`.

`src/Ecommerce.Payment.Api/Ecommerce.Payment.Api.csproj`:

```xml
<Project Sdk="Microsoft.NET.Sdk.Web">

  <ItemGroup>
    <ProjectReference Include="../Ecommerce.ServiceDefaults/Ecommerce.ServiceDefaults.csproj" />
  </ItemGroup>

</Project>
```

`src/Ecommerce.Payment.Api/appsettings.json`:

```json
{
  "Logging": {
    "LogLevel": {
      "Default": "Information",
      "Microsoft.AspNetCore": "Warning"
    }
  },
  "AllowedHosts": "*",
  "Payment": {
    "ProcessingDelay": "00:00:01.500"
  }
}
```

`src/Ecommerce.Payment.Api/appsettings.Development.json`:

```json
{
  "Logging": {
    "LogLevel": {
      "Default": "Information",
      "Microsoft.AspNetCore": "Warning"
    }
  }
}
```

`src/Ecommerce.Payment.Api/Properties/launchSettings.json`:

```json
{
  "$schema": "https://json.schemastore.org/launchsettings.json",
  "profiles": {
    "https": {
      "commandName": "Project",
      "dotnetRunMessages": true,
      "launchBrowser": false,
      "applicationUrl": "https://localhost:7140;http://localhost:5140",
      "environmentVariables": {
        "ASPNETCORE_ENVIRONMENT": "Development"
      }
    },
    "http": {
      "commandName": "Project",
      "dotnetRunMessages": true,
      "launchBrowser": false,
      "applicationUrl": "http://localhost:5140",
      "environmentVariables": {
        "ASPNETCORE_ENVIRONMENT": "Development"
      }
    }
  }
}
```

`tests/Ecommerce.Payment.Api.Tests/Ecommerce.Payment.Api.Tests.csproj`:

```xml
<Project Sdk="Microsoft.NET.Sdk">

  <PropertyGroup>
    <OutputType>Exe</OutputType>
    <IsPackable>false</IsPackable>
    <IsTestProject>true</IsTestProject>
  </PropertyGroup>

  <ItemGroup>
    <PackageReference Include="xunit.v3" />
    <PackageReference Include="Microsoft.Extensions.TimeProvider.Testing" />
  </ItemGroup>

  <ItemGroup>
    <Using Include="Xunit" />
  </ItemGroup>

  <ItemGroup>
    <ProjectReference Include="../../src/Ecommerce.Payment.Api/Ecommerce.Payment.Api.csproj" />
  </ItemGroup>

</Project>
```

- [ ] **Step 2: Write the failing tests**

`tests/Ecommerce.Payment.Api.Tests/Features/PaymentDecisionTests.cs`:

```csharp
using Ecommerce.Payment.Api.Features;

namespace Ecommerce.Payment.Api.Tests.Features;

public sealed class PaymentDecisionTests
{
    [Theory]
    [InlineData("4242424242424242", false)]
    [InlineData("4000000000000002", true)]
    [InlineData("1111222233330002", true)]
    [InlineData("4000000000000020", false)]
    public void IsDeclined_FollowsTheSuffixRule(string cardNumber, bool declined)
    {
        Assert.Equal(declined, PaymentDecision.IsDeclined(cardNumber));
    }
}
```

`tests/Ecommerce.Payment.Api.Tests/Features/PaymentServiceTests.cs`:

```csharp
using Ecommerce.Payment.Api.Features;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.Time.Testing;

namespace Ecommerce.Payment.Api.Tests.Features;

public sealed class PaymentServiceTests
{
    private static readonly Guid OrderId = Guid.Parse("c0000000-0000-4000-8000-000000000001");

    private static PaymentService CreateService(FakeTimeProvider time, TimeSpan delay) =>
        new(Options.Create(new PaymentOptions { ProcessingDelay = delay }), time, NullLogger<PaymentService>.Instance);

    [Fact]
    public async Task AuthorizeAsync_WithApprovingCard_ReturnsApprovedAfterTheDelay()
    {
        var time = new FakeTimeProvider();
        var service = CreateService(time, TimeSpan.FromSeconds(2));

        var pending = service.AuthorizeAsync(OrderId, 40m, "EUR", "4242424242424242", TestContext.Current.CancellationToken);
        Assert.False(pending.IsCompleted);
        time.Advance(TimeSpan.FromSeconds(2));
        var result = await pending;

        Assert.True(result.Approved);
        Assert.Null(result.Reason);
        Assert.NotEqual(Guid.Empty, result.PaymentId);
    }

    [Fact]
    public async Task AuthorizeAsync_WithDecliningCard_ReturnsDeclinedWithReason()
    {
        var service = CreateService(new FakeTimeProvider(), TimeSpan.Zero);

        var result = await service.AuthorizeAsync(OrderId, 40m, "EUR", "4000000000000002", TestContext.Current.CancellationToken);

        Assert.False(result.Approved);
        Assert.Equal("card_declined", result.Reason);
    }
}
```

`tests/Ecommerce.Payment.Api.Tests/Features/AuthorizeEndpointTests.cs`:

```csharp
using Ecommerce.Payment.Api.Features;
using Ecommerce.Payment.Api.Features.Authorize;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.Time.Testing;

namespace Ecommerce.Payment.Api.Tests.Features;

public sealed class AuthorizeEndpointTests
{
    private static PaymentService CreateService() =>
        new(Options.Create(new PaymentOptions { ProcessingDelay = TimeSpan.Zero }), new FakeTimeProvider(), NullLogger<PaymentService>.Instance);

    [Fact]
    public async Task HandleAsync_MapsApprovalToStatusText()
    {
        var request = new AuthorizeRequest(Guid.NewGuid(), 40m, "EUR", "4242424242424242", "Goran");

        var result = await AuthorizeEndpoint.HandleAsync(request, CreateService(), TestContext.Current.CancellationToken);

        Assert.NotNull(result.Value?.Data);
        Assert.Equal("Approved", result.Value.Data.Status);
        Assert.Null(result.Value.Data.Reason);
    }

    [Fact]
    public async Task HandleAsync_MapsDeclineToStatusTextAndReason()
    {
        var request = new AuthorizeRequest(Guid.NewGuid(), 40m, "EUR", "4000000000000002", "Goran");

        var result = await AuthorizeEndpoint.HandleAsync(request, CreateService(), TestContext.Current.CancellationToken);

        Assert.NotNull(result.Value?.Data);
        Assert.Equal("Declined", result.Value.Data.Status);
        Assert.Equal("card_declined", result.Value.Data.Reason);
    }
}
```

The API project needs a `Program.cs` to compile at all, so create it now with the final content; the types it references arrive in step 4:

```csharp
using Ecommerce.Payment.Api.Features;
using Ecommerce.Payment.Api.Features.Authorize;
using Ecommerce.ServiceDefaults.Api;

var builder = WebApplication.CreateBuilder(args);

builder.AddServiceDefaults();
builder.AddApiDefaults();
builder.Services.AddValidation();
builder.Services.AddOptions<PaymentOptions>().BindConfiguration(PaymentOptions.SectionName).ValidateDataAnnotations().ValidateOnStart();
builder.Services.AddSingleton(TimeProvider.System);
builder.Services.AddScoped<PaymentService>();

var app = builder.Build();

app.UseApiDefaults();

var payments = app.MapGroup("/api/payments").WithTags("Payments");
payments.MapAuthorize();

app.Run();
```

```bash
dotnet sln add src/Ecommerce.Payment.Api tests/Ecommerce.Payment.Api.Tests
dotnet test --project tests/Ecommerce.Payment.Api.Tests
```

Expected: compile errors naming the `Ecommerce.Payment.Api.Features` namespace as missing.

- [ ] **Step 3: Implement the features**

`src/Ecommerce.Payment.Api/Features/PaymentOptions.cs`:

```csharp
using System.ComponentModel.DataAnnotations;

namespace Ecommerce.Payment.Api.Features;

public sealed record PaymentOptions
{
    public const string SectionName = "Payment";

    // Simulated processing time so the payment step is visible in traces and on the orders page
    [Range(typeof(TimeSpan), "00:00:00", "00:01:00")]
    public TimeSpan ProcessingDelay { get; init; } = TimeSpan.FromMilliseconds(1500);
}
```

`src/Ecommerce.Payment.Api/Features/PaymentDecision.cs`:

```csharp
namespace Ecommerce.Payment.Api.Features;

// Test card rule: any number ending in 0002 is declined, everything else is approved
public static class PaymentDecision
{
    public const string DeclinedSuffix = "0002";
    public const string DeclinedReason = "card_declined";

    public static bool IsDeclined(string cardNumber) => cardNumber.EndsWith(DeclinedSuffix, StringComparison.Ordinal);
}
```

`src/Ecommerce.Payment.Api/Features/PaymentService.cs`:

```csharp
using Microsoft.Extensions.Options;

namespace Ecommerce.Payment.Api.Features;

public sealed record PaymentResult(Guid PaymentId, bool Approved, string? Reason);

public sealed class PaymentService(IOptions<PaymentOptions> options, TimeProvider timeProvider, ILogger<PaymentService> logger)
{
    public async Task<PaymentResult> AuthorizeAsync(Guid orderId, decimal amount, string currency, string cardNumber, CancellationToken cancellationToken)
    {
        await Task.Delay(options.Value.ProcessingDelay, timeProvider, cancellationToken);

        var paymentId = Guid.CreateVersion7();
        if (PaymentDecision.IsDeclined(cardNumber))
        {
            logger.LogWarning("[{Prefix}] Declined payment [{PaymentId}] for order [{OrderId}] amount [{Amount}] [{Currency}]", nameof(PaymentService), paymentId, orderId, amount, currency);
            return new PaymentResult(paymentId, false, PaymentDecision.DeclinedReason);
        }

        logger.LogInformation("[{Prefix}] Approved payment [{PaymentId}] for order [{OrderId}] amount [{Amount}] [{Currency}]", nameof(PaymentService), paymentId, orderId, amount, currency);
        return new PaymentResult(paymentId, true, null);
    }
}
```

`src/Ecommerce.Payment.Api/Features/Authorize/AuthorizeEndpoint.cs`:

```csharp
using System.ComponentModel.DataAnnotations;
using Ecommerce.ServiceDefaults.Api;
using Microsoft.AspNetCore.Http.HttpResults;

namespace Ecommerce.Payment.Api.Features.Authorize;

public sealed record AuthorizeRequest(
    Guid OrderId,
    [property: Range(0.01, 1_000_000)] decimal Amount,
    [property: Required, StringLength(3, MinimumLength = 3)] string Currency,
    [property: Required, RegularExpression(@"^\d{16}$", ErrorMessage = "Card number must be 16 digits")] string CardNumber,
    [property: Required, StringLength(100, MinimumLength = 2)] string CardHolder);

public sealed record AuthorizeResponse(Guid PaymentId, string Status, string? Reason);

public static class AuthorizeEndpoint
{
    public const string Approved = "Approved";
    public const string Declined = "Declined";

    public static RouteGroupBuilder MapAuthorize(this RouteGroupBuilder group)
    {
        group.MapPost("/", HandleAsync).WithName("AuthorizePayment");
        return group;
    }

    public static async Task<Ok<ApiResponse<AuthorizeResponse>>> HandleAsync(
        AuthorizeRequest request,
        PaymentService service,
        CancellationToken cancellationToken)
    {
        var result = await service.AuthorizeAsync(request.OrderId, request.Amount, request.Currency, request.CardNumber, cancellationToken);
        return ApiResults.Ok(new AuthorizeResponse(result.PaymentId, result.Approved ? Approved : Declined, result.Reason));
    }
}
```

- [ ] **Step 4: Run the tests, build, and smoke test standalone**

```bash
dotnet test --project tests/Ecommerce.Payment.Api.Tests
dotnet build
dotnet run --project src/Ecommerce.Payment.Api --launch-profile http --no-build > /tmp/payment-smoke.log 2>&1 &
PAYMENT_PID=$!
curl -s --retry 30 --retry-delay 1 --retry-connrefused -w ' [%{http_code}]\n' http://localhost:5140/alive
curl -s -H "content-type: application/json" -X POST -d '{"orderId":"c0000000-0000-4000-8000-000000000001","amount":40,"currency":"EUR","cardNumber":"4242424242424242","cardHolder":"Goran"}' -w ' [%{http_code}]\n' http://localhost:5140/api/payments
curl -s -H "content-type: application/json" -X POST -d '{"orderId":"c0000000-0000-4000-8000-000000000001","amount":40,"currency":"EUR","cardNumber":"4000000000000002","cardHolder":"Goran"}' -w ' [%{http_code}]\n' http://localhost:5140/api/payments
curl -s -H "content-type: application/json" -X POST -d '{"orderId":"c0000000-0000-4000-8000-000000000001","amount":0,"currency":"EURO","cardNumber":"12","cardHolder":"G"}' -w ' [%{http_code}]\n' http://localhost:5140/api/payments
kill $PAYMENT_PID
```

Expected: 8 tests pass (4 decision cases, 2 service, 2 endpoint); `0 Warning(s)`; `Healthy [200]`; an envelope with `"status":"Approved"` after about 1.5 seconds; an envelope with `"status":"Declined"` and `"reason":"card_declined"`; a `common.validation_failed` envelope naming `Amount`, `Currency`, `CardNumber` and `CardHolder`. Confirm with `pgrep -fl Ecommerce.Payment.Api` that nothing is left running.

---

## Sub-phase 5.2 Order processor (backend-dev)

### Task 5.2.1: Order transitions, store claim and update, payment client, outbox publisher and fakes, test-first

**Files:**
- Modify: `tests/Ecommerce.Ordering.Api.Tests/Domain/OrderTests.cs`
- Modify: `tests/Ecommerce.Ordering.Api.Tests/Fakes/InMemoryOrderStore.cs`
- Create: `tests/Ecommerce.Ordering.Api.Tests/Fakes/FakePaymentClient.cs`
- Create: `tests/Ecommerce.Ordering.Api.Tests/Fakes/FakeOrderPaidPublisher.cs`
- Modify: `src/Ecommerce.Ordering.Api/Domain/Order.cs`
- Modify: `src/Ecommerce.Ordering.Api/Infrastructure/IOrderStore.cs`
- Modify: `src/Ecommerce.Ordering.Api/Infrastructure/MongoOrderStore.cs`
- Modify: `src/Ecommerce.Ordering.Api/Infrastructure/MongoSerialization.cs`
- Create: `src/Ecommerce.Ordering.Api/Infrastructure/IPaymentClient.cs`
- Create: `src/Ecommerce.Ordering.Api/Infrastructure/PaymentClient.cs`
- Create: `src/Ecommerce.Ordering.Api/Infrastructure/IOrderPaidPublisher.cs`
- Create: `src/Ecommerce.Ordering.Api/Infrastructure/WolverineOrderPaidPublisher.cs`
- Modify: `src/Ecommerce.Ordering.Api/Ecommerce.Ordering.Api.csproj`

**Interfaces:**
- Consumes: the phase 4 Ordering types, `OrderPaid`, `ApiResponse<T>`.
- Produces:
  - `Order` gains `PaymentCardNumber` (set from the event, cleared by `MarkPaid` and `MarkPaymentFailed`) and the transitions `MarkPaid(reference, now, shipAfter)`, `MarkPaymentFailed(reason)`, `ScheduleRetry(nextAttemptAt)`, `MarkPaidEventPublished(shipAfter)`, `IsShippingDue(now)`, `MarkShipped(now)`, `ReleaseLease()`.
  - `IOrderStore` gains `ClaimDueAsync(now, leaseUntil, ct)`, an atomic `FindOneAndUpdate` that leases the oldest due order, and `UpdateAsync(order, ct)`.
  - `MongoSerialization` also stores `DateTimeOffset` as BSON dates so the claim filter compares instants.
  - `PaymentOutcome`, `PaymentUnavailableException`, `IPaymentClient.AuthorizeAsync(...)` and the typed `PaymentClient` translating every transport failure and non-success status into `PaymentUnavailableException`.
  - `OutboxUnavailableException`, `IOrderPaidPublisher` and `WolverineOrderPaidPublisher`.
  - Fakes: the store with `ClaimDueAsync`, `UpdateAsync` and `UpdateCount`; `FakePaymentClient` with `Unavailable`, `Decline` and `Calls`; `FakeOrderPaidPublisher` with `Unavailable` and `Published`.

- [ ] **Step 1: Write the failing tests and fakes**

Replace `tests/Ecommerce.Ordering.Api.Tests/Domain/OrderTests.cs` with:

```csharp
using Ecommerce.Ordering.Api.Domain;

namespace Ecommerce.Ordering.Api.Tests.Domain;

public sealed class OrderTests
{
    private static readonly TimeSpan ShipAfter = TimeSpan.FromSeconds(5);

    [Fact]
    public void FromPlaced_CopiesTheSnapshotAndStartsSubmitted()
    {
        var now = TestOrders.PlacedAt.AddSeconds(1);

        var order = Order.FromPlaced(TestOrders.Placed(), now);

        Assert.Equal(TestOrders.OrderId, order.Id);
        Assert.Equal(TestOrders.BuyerId, order.BuyerId);
        Assert.Equal("Goran", order.Buyer.Name);
        Assert.Equal("Belgrade", order.ShippingAddress.City);
        Assert.Equal(2, order.Lines.Count);
        Assert.Equal(25.00m, order.Lines[0].LineTotal);
        Assert.Equal(40.00m, order.Total);
        Assert.Equal("EUR", order.Currency);
        Assert.Equal(OrderStatus.Submitted, order.Status);
        Assert.Equal(TestOrders.PlacedAt, order.CreatedAt);
        Assert.Equal(now, order.NextAttemptAt);
        Assert.Null(order.LeaseUntil);
        Assert.False(order.PaidEventPublished);
    }

    [Fact]
    public void FromPlaced_KeepsTheCardNumberOnlyUntilPayment()
    {
        var order = Order.FromPlaced(TestOrders.Placed(), TestOrders.PlacedAt);

        Assert.Equal("4242", order.CardLast4);
        Assert.Equal("4242424242424242", order.PaymentCardNumber);
    }

    [Fact]
    public void MarkPaid_SetsPaidStateSchedulesShippingAndDropsTheCardNumber()
    {
        var order = Order.FromPlaced(TestOrders.Placed(), TestOrders.PlacedAt);
        var now = TestOrders.PlacedAt.AddSeconds(3);

        order.MarkPaid("pay-1", now, ShipAfter);

        Assert.Equal(OrderStatus.Paid, order.Status);
        Assert.Equal(now, order.PaidAt);
        Assert.Equal("pay-1", order.PaymentReference);
        Assert.Null(order.PaymentCardNumber);
        Assert.False(order.PaidEventPublished);
        Assert.Equal(now + ShipAfter, order.NextAttemptAt);
    }

    [Fact]
    public void MarkPaymentFailed_SetsReasonAndDropsTheCardNumber()
    {
        var order = Order.FromPlaced(TestOrders.Placed(), TestOrders.PlacedAt);

        order.MarkPaymentFailed("card_declined");

        Assert.Equal(OrderStatus.PaymentFailed, order.Status);
        Assert.Equal("card_declined", order.FailureReason);
        Assert.Null(order.PaymentCardNumber);
    }

    [Fact]
    public void IsShippingDue_RequiresPaidPublishedAndElapsedDelay()
    {
        var order = Order.FromPlaced(TestOrders.Placed(), TestOrders.PlacedAt);
        var paidAt = TestOrders.PlacedAt.AddSeconds(3);
        order.MarkPaid("pay-1", paidAt, ShipAfter);

        Assert.False(order.IsShippingDue(paidAt + ShipAfter));
        order.MarkPaidEventPublished(ShipAfter);
        Assert.False(order.IsShippingDue(paidAt + ShipAfter - TimeSpan.FromSeconds(1)));
        Assert.True(order.IsShippingDue(paidAt + ShipAfter));
    }

    [Fact]
    public void MarkShipped_SetsShippedState()
    {
        var order = Order.FromPlaced(TestOrders.Placed(), TestOrders.PlacedAt);
        var shippedAt = TestOrders.PlacedAt.AddSeconds(10);

        order.MarkShipped(shippedAt);

        Assert.Equal(OrderStatus.Shipped, order.Status);
        Assert.Equal(shippedAt, order.ShippedAt);
    }
}
```

Replace `tests/Ecommerce.Ordering.Api.Tests/Fakes/InMemoryOrderStore.cs` with:

```csharp
using Ecommerce.Ordering.Api.Domain;
using Ecommerce.Ordering.Api.Infrastructure;

namespace Ecommerce.Ordering.Api.Tests.Fakes;

public sealed class InMemoryOrderStore : IOrderStore
{
    public Dictionary<Guid, Order> Orders { get; } = [];

    public int UpdateCount { get; private set; }

    public Task<bool> InsertIfAbsentAsync(Order order, CancellationToken cancellationToken) =>
        Task.FromResult(Orders.TryAdd(order.Id, order));

    public Task<IReadOnlyList<Order>> ListForBuyerAsync(Guid buyerId, CancellationToken cancellationToken)
    {
        IReadOnlyList<Order> orders = Orders.Values.Where(order => order.BuyerId == buyerId).OrderByDescending(order => order.CreatedAt).ToList();
        return Task.FromResult(orders);
    }

    public Task<Order?> GetAsync(Guid buyerId, Guid orderId, CancellationToken cancellationToken) =>
        Task.FromResult(Orders.TryGetValue(orderId, out var order) && order.BuyerId == buyerId ? order : null);

    public Task<Order?> ClaimDueAsync(DateTimeOffset now, DateTimeOffset leaseUntil, CancellationToken cancellationToken)
    {
        var due = Orders.Values
            .Where(order => order.Status is OrderStatus.Submitted or OrderStatus.Paid)
            .Where(order => order.NextAttemptAt <= now)
            .Where(order => order.LeaseUntil is null || order.LeaseUntil < now)
            .OrderBy(order => order.NextAttemptAt)
            .FirstOrDefault();
        if (due is not null)
        {
            due.LeaseUntil = leaseUntil;
        }

        return Task.FromResult(due);
    }

    public Task UpdateAsync(Order order, CancellationToken cancellationToken)
    {
        Orders[order.Id] = order;
        UpdateCount++;
        return Task.CompletedTask;
    }
}
```

`tests/Ecommerce.Ordering.Api.Tests/Fakes/FakePaymentClient.cs`:

```csharp
using Ecommerce.Ordering.Api.Infrastructure;

namespace Ecommerce.Ordering.Api.Tests.Fakes;

public sealed class FakePaymentClient : IPaymentClient
{
    public bool Unavailable { get; set; }

    public bool Decline { get; set; }

    public List<(Guid OrderId, decimal Amount, string CardNumber)> Calls { get; } = [];

    public Task<PaymentOutcome> AuthorizeAsync(Guid orderId, decimal amount, string currency, string cardNumber, string cardHolder, CancellationToken cancellationToken)
    {
        if (Unavailable)
        {
            throw new PaymentUnavailableException(new HttpRequestException("Payment unreachable"));
        }

        Calls.Add((orderId, amount, cardNumber));
        return Task.FromResult(Decline
            ? new PaymentOutcome(false, Guid.NewGuid(), "card_declined")
            : new PaymentOutcome(true, Guid.Parse("d0000000-0000-4000-8000-000000000001"), null));
    }
}
```

`tests/Ecommerce.Ordering.Api.Tests/Fakes/FakeOrderPaidPublisher.cs`:

```csharp
using Ecommerce.Contracts;
using Ecommerce.Ordering.Api.Infrastructure;

namespace Ecommerce.Ordering.Api.Tests.Fakes;

public sealed class FakeOrderPaidPublisher : IOrderPaidPublisher
{
    public bool Unavailable { get; set; }

    public List<OrderPaid> Published { get; } = [];

    public Task PublishAsync(OrderPaid orderPaid, CancellationToken cancellationToken)
    {
        if (Unavailable)
        {
            throw new OutboxUnavailableException(new InvalidOperationException("Message store unreachable"));
        }

        Published.Add(orderPaid);
        return Task.CompletedTask;
    }
}
```

- [ ] **Step 2: Run the Ordering tests and confirm they fail to compile**

```bash
dotnet test --project tests/Ecommerce.Ordering.Api.Tests
```

Expected: compile errors naming `IPaymentClient`, `IOrderPaidPublisher`, `ClaimDueAsync`, `UpdateAsync`, `PaymentCardNumber` and the new `Order` methods as missing.

- [ ] **Step 3: Implement**

Replace `src/Ecommerce.Ordering.Api/Domain/Order.cs` with:

```csharp
using Ecommerce.Contracts;

namespace Ecommerce.Ordering.Api.Domain;

public enum OrderStatus
{
    Submitted,
    Paid,
    Shipped,
    PaymentFailed,
}

public sealed record OrderBuyerInfo(string Name, string Email);

public sealed record OrderAddressInfo(string Street, string City, string PostalCode, string Country);

public sealed record OrderLineInfo(Guid ProductId, string ProductName, decimal UnitPrice, int Quantity)
{
    public decimal LineTotal => UnitPrice * Quantity;
}

// The point-in-time snapshot of a purchase; the MongoDB driver materializes it through the property setters
public sealed class Order
{
    public required Guid Id { get; init; }

    public required Guid BuyerId { get; init; }

    public required OrderBuyerInfo Buyer { get; init; }

    public required OrderAddressInfo ShippingAddress { get; init; }

    public required string CardLast4 { get; init; }

    // The simulator has no tokenization step: the test card number stays on the order only until the payment step completes
    public string? PaymentCardNumber { get; set; }

    public required IReadOnlyList<OrderLineInfo> Lines { get; init; }

    public required decimal Total { get; init; }

    public required string Currency { get; init; }

    public OrderStatus Status { get; set; } = OrderStatus.Submitted;

    public required DateTimeOffset CreatedAt { get; init; }

    public DateTimeOffset? PaidAt { get; set; }

    public DateTimeOffset? ShippedAt { get; set; }

    public string? FailureReason { get; set; }

    public string? PaymentReference { get; set; }

    public int PaymentAttempts { get; set; }

    public required DateTimeOffset NextAttemptAt { get; set; }

    public DateTimeOffset? LeaseUntil { get; set; }

    public bool PaidEventPublished { get; set; }

    public static Order FromPlaced(OrderPlaced placed, DateTimeOffset now) =>
        new()
        {
            Id = placed.OrderId,
            BuyerId = placed.BuyerId,
            Buyer = new OrderBuyerInfo(placed.Buyer.Name, placed.Buyer.Email),
            ShippingAddress = new OrderAddressInfo(placed.ShippingAddress.Street, placed.ShippingAddress.City, placed.ShippingAddress.PostalCode, placed.ShippingAddress.Country),
            CardLast4 = placed.Card.Number.Length >= 4 ? placed.Card.Number[^4..] : placed.Card.Number,
            PaymentCardNumber = placed.Card.Number,
            Lines = placed.Lines.Select(line => new OrderLineInfo(line.ProductId, line.ProductName, line.UnitPrice, line.Quantity)).ToList(),
            Total = placed.Total,
            Currency = placed.Currency,
            CreatedAt = placed.PlacedAt,
            NextAttemptAt = now,
        };

    public void MarkPaid(string paymentReference, DateTimeOffset now, TimeSpan shipAfter)
    {
        Status = OrderStatus.Paid;
        PaidAt = now;
        PaymentReference = paymentReference;
        PaymentCardNumber = null;
        PaidEventPublished = false;
        NextAttemptAt = now + shipAfter;
    }

    public void MarkPaymentFailed(string reason)
    {
        Status = OrderStatus.PaymentFailed;
        FailureReason = reason;
        PaymentCardNumber = null;
    }

    public void ScheduleRetry(DateTimeOffset nextAttemptAt) => NextAttemptAt = nextAttemptAt;

    public void MarkPaidEventPublished(TimeSpan shipAfter)
    {
        PaidEventPublished = true;
        NextAttemptAt = (PaidAt ?? NextAttemptAt) + shipAfter;
    }

    public bool IsShippingDue(DateTimeOffset now) => Status == OrderStatus.Paid && PaidEventPublished && NextAttemptAt <= now;

    public void MarkShipped(DateTimeOffset now)
    {
        Status = OrderStatus.Shipped;
        ShippedAt = now;
    }

    public void ReleaseLease() => LeaseUntil = null;
}
```

Replace `src/Ecommerce.Ordering.Api/Infrastructure/IOrderStore.cs` with:

```csharp
using Ecommerce.Ordering.Api.Domain;

namespace Ecommerce.Ordering.Api.Infrastructure;

public interface IOrderStore
{
    // Returns false when an order with the same id already exists, so a redelivered event changes nothing
    Task<bool> InsertIfAbsentAsync(Order order, CancellationToken cancellationToken);

    Task<IReadOnlyList<Order>> ListForBuyerAsync(Guid buyerId, CancellationToken cancellationToken);

    Task<Order?> GetAsync(Guid buyerId, Guid orderId, CancellationToken cancellationToken);

    // Atomically leases the oldest due order (Submitted or Paid, NextAttemptAt reached, no live lease); null when nothing is due
    Task<Order?> ClaimDueAsync(DateTimeOffset now, DateTimeOffset leaseUntil, CancellationToken cancellationToken);

    Task UpdateAsync(Order order, CancellationToken cancellationToken);
}
```

Replace `src/Ecommerce.Ordering.Api/Infrastructure/MongoOrderStore.cs` with:

```csharp
using Ecommerce.Ordering.Api.Domain;
using MongoDB.Driver;

namespace Ecommerce.Ordering.Api.Infrastructure;

public sealed class MongoOrderStore(IMongoDatabase database) : IOrderStore
{
    public const string CollectionName = "orders";

    private readonly IMongoCollection<Order> _orders = database.GetCollection<Order>(CollectionName);

    public async Task<bool> InsertIfAbsentAsync(Order order, CancellationToken cancellationToken)
    {
        try
        {
            await _orders.InsertOneAsync(order, cancellationToken: cancellationToken);
            return true;
        }
        catch (MongoWriteException exception) when (exception.WriteError.Category == ServerErrorCategory.DuplicateKey)
        {
            return false;
        }
    }

    public async Task<IReadOnlyList<Order>> ListForBuyerAsync(Guid buyerId, CancellationToken cancellationToken) =>
        await _orders.Find(order => order.BuyerId == buyerId)
            .SortByDescending(order => order.CreatedAt)
            .ToListAsync(cancellationToken);

    public Task<Order?> GetAsync(Guid buyerId, Guid orderId, CancellationToken cancellationToken) =>
        _orders.Find(order => order.Id == orderId && order.BuyerId == buyerId).FirstOrDefaultAsync(cancellationToken)!;

    public Task<Order?> ClaimDueAsync(DateTimeOffset now, DateTimeOffset leaseUntil, CancellationToken cancellationToken)
    {
        var filter = Builders<Order>.Filter.And(
            Builders<Order>.Filter.In(order => order.Status, [OrderStatus.Submitted, OrderStatus.Paid]),
            Builders<Order>.Filter.Lte(order => order.NextAttemptAt, now),
            Builders<Order>.Filter.Or(
                Builders<Order>.Filter.Eq(order => order.LeaseUntil, null),
                Builders<Order>.Filter.Lt(order => order.LeaseUntil, now)));
        var update = Builders<Order>.Update.Set(order => order.LeaseUntil, leaseUntil);
        var options = new FindOneAndUpdateOptions<Order>
        {
            ReturnDocument = ReturnDocument.After,
            Sort = Builders<Order>.Sort.Ascending(order => order.NextAttemptAt),
        };

        return _orders.FindOneAndUpdateAsync(filter, update, options, cancellationToken)!;
    }

    public Task UpdateAsync(Order order, CancellationToken cancellationToken) =>
        _orders.ReplaceOneAsync(existing => existing.Id == order.Id, order, cancellationToken: cancellationToken);
}
```

Replace `src/Ecommerce.Ordering.Api/Infrastructure/MongoSerialization.cs` with:

```csharp
using MongoDB.Bson;
using MongoDB.Bson.Serialization;
using MongoDB.Bson.Serialization.Conventions;
using MongoDB.Bson.Serialization.Serializers;

namespace Ecommerce.Ordering.Api.Infrastructure;

// Driver-wide serialization rules, registered once before the first document is mapped
public static class MongoSerialization
{
    private static bool _registered;

    public static void Register()
    {
        if (_registered)
        {
            return;
        }

        BsonSerializer.RegisterSerializer(new GuidSerializer(GuidRepresentation.Standard));
        // Stored as BSON dates so range filters on NextAttemptAt and LeaseUntil compare as instants
        BsonSerializer.RegisterSerializer(new DateTimeOffsetSerializer(BsonType.DateTime));
        ConventionRegistry.Register(
            "ecommerce",
            new ConventionPack
            {
                new CamelCaseElementNameConvention(),
                new IgnoreExtraElementsConvention(true),
                new EnumRepresentationConvention(BsonType.String),
            },
            _ => true);
        _registered = true;
    }
}
```

`src/Ecommerce.Ordering.Api/Infrastructure/IPaymentClient.cs`:

```csharp
namespace Ecommerce.Ordering.Api.Infrastructure;

public sealed record PaymentOutcome(bool Approved, Guid PaymentId, string? Reason);

// Thrown when the payment service cannot be reached or answers with an error after the resilience handler gave up
public sealed class PaymentUnavailableException(Exception inner) : Exception("The payment service is unavailable", inner);

public interface IPaymentClient
{
    Task<PaymentOutcome> AuthorizeAsync(Guid orderId, decimal amount, string currency, string cardNumber, string cardHolder, CancellationToken cancellationToken);
}
```

`src/Ecommerce.Ordering.Api/Infrastructure/PaymentClient.cs`:

```csharp
using System.Net.Http.Json;
using Ecommerce.ServiceDefaults.Api;
using Polly.CircuitBreaker;
using Polly.Timeout;

namespace Ecommerce.Ordering.Api.Infrastructure;

public sealed class PaymentClient(HttpClient httpClient) : IPaymentClient
{
    private sealed record AuthorizeRequest(Guid OrderId, decimal Amount, string Currency, string CardNumber, string CardHolder);

    private sealed record AuthorizeResponse(Guid PaymentId, string Status, string? Reason);

    public async Task<PaymentOutcome> AuthorizeAsync(Guid orderId, decimal amount, string currency, string cardNumber, string cardHolder, CancellationToken cancellationToken)
    {
        try
        {
            using var response = await httpClient.PostAsJsonAsync("/api/payments", new AuthorizeRequest(orderId, amount, currency, cardNumber, cardHolder), cancellationToken);
            response.EnsureSuccessStatusCode();
            var envelope = await response.Content.ReadFromJsonAsync<ApiResponse<AuthorizeResponse>>(cancellationToken);
            var data = envelope?.Data ?? throw new HttpRequestException("The payment service returned an empty response");
            return new PaymentOutcome(data.Status == "Approved", data.PaymentId, data.Reason);
        }
        catch (Exception exception) when (exception is HttpRequestException or TimeoutRejectedException or BrokenCircuitException)
        {
            throw new PaymentUnavailableException(exception);
        }
    }
}
```

`src/Ecommerce.Ordering.Api/Infrastructure/IOrderPaidPublisher.cs`:

```csharp
using Ecommerce.Contracts;

namespace Ecommerce.Ordering.Api.Infrastructure;

// Thrown when the event cannot be handed to the durable outbox
public sealed class OutboxUnavailableException(Exception inner) : Exception("The order event could not be stored for delivery", inner);

public interface IOrderPaidPublisher
{
    Task PublishAsync(OrderPaid orderPaid, CancellationToken cancellationToken);
}
```

`src/Ecommerce.Ordering.Api/Infrastructure/WolverineOrderPaidPublisher.cs`:

```csharp
using Ecommerce.Contracts;
using Wolverine;

namespace Ecommerce.Ordering.Api.Infrastructure;

// The order-paid exchange is a durable outbox endpoint in Program.cs, so PublishAsync persists the envelope before returning
public sealed class WolverineOrderPaidPublisher(IMessageBus bus) : IOrderPaidPublisher
{
    public async Task PublishAsync(OrderPaid orderPaid, CancellationToken cancellationToken)
    {
        try
        {
            await bus.PublishAsync(orderPaid);
        }
        catch (Exception exception) when (exception is not OperationCanceledException)
        {
            throw new OutboxUnavailableException(exception);
        }
    }
}
```

Replace `src/Ecommerce.Ordering.Api/Ecommerce.Ordering.Api.csproj` with:

```xml
<Project Sdk="Microsoft.NET.Sdk.Web">

  <ItemGroup>
    <PackageReference Include="Aspire.MongoDB.Driver" />
    <PackageReference Include="WolverineFx" />
    <PackageReference Include="WolverineFx.RabbitMQ" />
    <PackageReference Include="WolverineFx.RuntimeCompilation" />
    <PackageReference Include="WolverineFx.Postgresql" />
  </ItemGroup>

  <ItemGroup>
    <ProjectReference Include="../Ecommerce.Contracts/Ecommerce.Contracts.csproj" />
    <ProjectReference Include="../Ecommerce.ServiceDefaults/Ecommerce.ServiceDefaults.csproj" />
  </ItemGroup>

</Project>
```

- [ ] **Step 4: Run the tests and build**

```bash
dotnet test --project tests/Ecommerce.Ordering.Api.Tests
dotnet build
```

Expected: `Passed!` with 11 succeeded (6 order tests, 2 handler tests, 3 endpoint tests), `0 Warning(s)`.

### Task 5.2.2: OrderProcessingService, OrderProcessor, options and the composition root, test-first

**Files:**
- Create: `tests/Ecommerce.Ordering.Api.Tests/Processing/OrderProcessingServiceTests.cs`
- Create: `src/Ecommerce.Ordering.Api/Processing/OrderProcessorOptions.cs`
- Create: `src/Ecommerce.Ordering.Api/Processing/OrderProcessingService.cs`
- Create: `src/Ecommerce.Ordering.Api/Processing/OrderProcessor.cs`
- Modify: `src/Ecommerce.Ordering.Api/appsettings.json`
- Modify: `src/Ecommerce.Ordering.Api/Program.cs`

**Interfaces:**
- Consumes: everything from task 5.2.1, `TimeProvider`, `IOptions<T>`.
- Produces:
  - `OrderProcessorOptions` bound from `Ordering:Processor` with `PollInterval` 1 s, `LeaseDuration` 30 s, `PaidToShippedDelay` 5 s and `PaymentRetryDelay` 5 s, validated at startup.
  - `OrderProcessingService.ProcessAsync(order, ct)`: for a Submitted order it calls Payment (counting the attempt), marks Paid and persists before publishing `OrderPaid`, marks the event published on success or schedules a retry on outbox failure, marks PaymentFailed on a decline, or schedules a retry when Payment is unavailable; for a Paid order it publishes a missing event first and ships when due; in every case it releases the lease and persists the order.
  - `OrderProcessor` background service claiming due orders each poll and handing them to the service, one scope per tick.
  - The final Ordering `Program.cs` with the options, the typed `PaymentClient` on `https+http://payment-api`, the publisher, the service, the processor, and Wolverine with the Postgres message store on `orderingmessages` and `OrderPaid` published to the `order-paid` exchange through the durable outbox.

- [ ] **Step 1: Write the failing tests**

`tests/Ecommerce.Ordering.Api.Tests/Processing/OrderProcessingServiceTests.cs`:

```csharp
using Ecommerce.Ordering.Api.Domain;
using Ecommerce.Ordering.Api.Processing;
using Ecommerce.Ordering.Api.Tests.Fakes;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.Time.Testing;

namespace Ecommerce.Ordering.Api.Tests.Processing;

public sealed class OrderProcessingServiceTests
{
    private static readonly OrderProcessorOptions Options = new()
    {
        PollInterval = TimeSpan.FromSeconds(1),
        LeaseDuration = TimeSpan.FromSeconds(30),
        PaidToShippedDelay = TimeSpan.FromSeconds(5),
        PaymentRetryDelay = TimeSpan.FromSeconds(5),
    };

    private readonly InMemoryOrderStore _store = new();
    private readonly FakePaymentClient _payment = new();
    private readonly FakeOrderPaidPublisher _publisher = new();
    private readonly FakeTimeProvider _time = new(TestOrders.PlacedAt.AddSeconds(2));

    private OrderProcessingService CreateService() =>
        new(_store, _payment, _publisher, Microsoft.Extensions.Options.Options.Create(Options), _time, NullLogger<OrderProcessingService>.Instance);

    private Order SubmittedOrder()
    {
        var order = Order.FromPlaced(TestOrders.Placed(), _time.GetUtcNow());
        _store.Orders[order.Id] = order;
        return order;
    }

    [Fact]
    public async Task ProcessAsync_SubmittedAndApproved_MarksPaidPublishesAndReleasesLease()
    {
        var order = SubmittedOrder();
        order.LeaseUntil = _time.GetUtcNow().AddSeconds(30);

        await CreateService().ProcessAsync(order, TestContext.Current.CancellationToken);

        Assert.Equal(OrderStatus.Paid, order.Status);
        Assert.Equal(1, order.PaymentAttempts);
        Assert.Equal("d0000000-0000-4000-8000-000000000001", order.PaymentReference);
        Assert.True(order.PaidEventPublished);
        Assert.Null(order.PaymentCardNumber);
        Assert.Null(order.LeaseUntil);
        Assert.Equal(_time.GetUtcNow() + Options.PaidToShippedDelay, order.NextAttemptAt);
        var published = Assert.Single(_publisher.Published);
        Assert.Equal(order.Id, published.OrderId);
        Assert.Equal(2, published.Lines.Count);
        Assert.Equal("4242424242424242", Assert.Single(_payment.Calls).CardNumber);
    }

    [Fact]
    public async Task ProcessAsync_SubmittedAndDeclined_MarksPaymentFailedWithoutPublishing()
    {
        var order = SubmittedOrder();
        _payment.Decline = true;

        await CreateService().ProcessAsync(order, TestContext.Current.CancellationToken);

        Assert.Equal(OrderStatus.PaymentFailed, order.Status);
        Assert.Equal("card_declined", order.FailureReason);
        Assert.Empty(_publisher.Published);
        Assert.Null(order.LeaseUntil);
    }

    [Fact]
    public async Task ProcessAsync_SubmittedAndPaymentUnavailable_SchedulesRetryAndStaysSubmitted()
    {
        var order = SubmittedOrder();
        _payment.Unavailable = true;

        await CreateService().ProcessAsync(order, TestContext.Current.CancellationToken);

        Assert.Equal(OrderStatus.Submitted, order.Status);
        Assert.Equal(1, order.PaymentAttempts);
        Assert.Equal(_time.GetUtcNow() + Options.PaymentRetryDelay, order.NextAttemptAt);
        Assert.Equal("4242424242424242", order.PaymentCardNumber);
        Assert.Null(order.LeaseUntil);
    }

    [Fact]
    public async Task ProcessAsync_PaidAndOutboxUnavailable_KeepsPaidAndRetriesPublishLater()
    {
        var order = SubmittedOrder();
        _publisher.Unavailable = true;

        await CreateService().ProcessAsync(order, TestContext.Current.CancellationToken);

        Assert.Equal(OrderStatus.Paid, order.Status);
        Assert.False(order.PaidEventPublished);
        Assert.Equal(_time.GetUtcNow() + Options.PaymentRetryDelay, order.NextAttemptAt);
    }

    [Fact]
    public async Task ProcessAsync_PaidWithUnpublishedEvent_PublishesBeforeShipping()
    {
        var order = SubmittedOrder();
        order.MarkPaid("pay-1", _time.GetUtcNow(), Options.PaidToShippedDelay);
        order.ScheduleRetry(_time.GetUtcNow());

        await CreateService().ProcessAsync(order, TestContext.Current.CancellationToken);

        Assert.Single(_publisher.Published);
        Assert.True(order.PaidEventPublished);
        Assert.Equal(OrderStatus.Paid, order.Status);
        Assert.Equal(order.PaidAt + Options.PaidToShippedDelay, order.NextAttemptAt);
    }

    [Fact]
    public async Task ProcessAsync_PaidAndDue_MarksShipped()
    {
        var order = SubmittedOrder();
        order.MarkPaid("pay-1", _time.GetUtcNow(), Options.PaidToShippedDelay);
        order.MarkPaidEventPublished(Options.PaidToShippedDelay);
        _time.Advance(Options.PaidToShippedDelay);

        await CreateService().ProcessAsync(order, TestContext.Current.CancellationToken);

        Assert.Equal(OrderStatus.Shipped, order.Status);
        Assert.Equal(_time.GetUtcNow(), order.ShippedAt);
        Assert.Empty(_publisher.Published);
    }

    [Fact]
    public async Task ClaimDueAsync_SkipsLeasedAndNotYetDueOrders()
    {
        var due = SubmittedOrder();
        var later = Order.FromPlaced(TestOrders.Placed(Guid.NewGuid()), _time.GetUtcNow().AddMinutes(1));
        _store.Orders[later.Id] = later;

        var first = await _store.ClaimDueAsync(_time.GetUtcNow(), _time.GetUtcNow().AddSeconds(30), TestContext.Current.CancellationToken);
        var second = await _store.ClaimDueAsync(_time.GetUtcNow(), _time.GetUtcNow().AddSeconds(30), TestContext.Current.CancellationToken);

        Assert.Same(due, first);
        Assert.Null(second);
    }
}
```

- [ ] **Step 2: Run the Ordering tests and confirm they fail to compile**

```bash
dotnet test --project tests/Ecommerce.Ordering.Api.Tests
```

Expected: a compile error naming the `Ecommerce.Ordering.Api.Processing` namespace as missing.

- [ ] **Step 3: Implement**

`src/Ecommerce.Ordering.Api/Processing/OrderProcessorOptions.cs`:

```csharp
using System.ComponentModel.DataAnnotations;

namespace Ecommerce.Ordering.Api.Processing;

public sealed record OrderProcessorOptions
{
    public const string SectionName = "Ordering:Processor";

    [Range(typeof(TimeSpan), "00:00:00.100", "00:01:00")]
    public TimeSpan PollInterval { get; init; } = TimeSpan.FromSeconds(1);

    [Range(typeof(TimeSpan), "00:00:01", "00:10:00")]
    public TimeSpan LeaseDuration { get; init; } = TimeSpan.FromSeconds(30);

    [Range(typeof(TimeSpan), "00:00:00", "00:10:00")]
    public TimeSpan PaidToShippedDelay { get; init; } = TimeSpan.FromSeconds(5);

    [Range(typeof(TimeSpan), "00:00:01", "00:10:00")]
    public TimeSpan PaymentRetryDelay { get; init; } = TimeSpan.FromSeconds(5);
}
```

`src/Ecommerce.Ordering.Api/Processing/OrderProcessingService.cs`:

```csharp
using Ecommerce.Contracts;
using Ecommerce.Ordering.Api.Domain;
using Ecommerce.Ordering.Api.Infrastructure;
using Microsoft.Extensions.Options;

namespace Ecommerce.Ordering.Api.Processing;

// Drives one claimed order through its next transition; the store persists the outcome and releases the lease
public sealed class OrderProcessingService(
    IOrderStore store,
    IPaymentClient payment,
    IOrderPaidPublisher publisher,
    IOptions<OrderProcessorOptions> options,
    TimeProvider timeProvider,
    ILogger<OrderProcessingService> logger)
{
    public async Task ProcessAsync(Order order, CancellationToken cancellationToken)
    {
        try
        {
            switch (order.Status)
            {
                case OrderStatus.Submitted:
                    await PayAsync(order, cancellationToken);
                    break;
                case OrderStatus.Paid:
                    await ContinuePaidAsync(order, cancellationToken);
                    break;
            }
        }
        finally
        {
            order.ReleaseLease();
            await store.UpdateAsync(order, cancellationToken);
        }
    }

    private async Task PayAsync(Order order, CancellationToken cancellationToken)
    {
        var now = timeProvider.GetUtcNow();
        order.PaymentAttempts++;
        PaymentOutcome outcome;
        try
        {
            outcome = await payment.AuthorizeAsync(order.Id, order.Total, order.Currency, order.PaymentCardNumber ?? string.Empty, order.Buyer.Name, cancellationToken);
        }
        catch (PaymentUnavailableException exception)
        {
            order.ScheduleRetry(now + options.Value.PaymentRetryDelay);
            logger.LogWarning(exception, "[{Prefix}] Payment unavailable for order [{OrderId}], attempt [{Attempt}], retrying at [{NextAttemptAt}]", nameof(OrderProcessingService), order.Id, order.PaymentAttempts, order.NextAttemptAt);
            return;
        }

        if (!outcome.Approved)
        {
            order.MarkPaymentFailed(outcome.Reason ?? "declined");
            logger.LogWarning("[{Prefix}] Payment declined for order [{OrderId}] reason [{Reason}]", nameof(OrderProcessingService), order.Id, order.FailureReason);
            return;
        }

        order.MarkPaid(outcome.PaymentId.ToString(), now, options.Value.PaidToShippedDelay);
        await store.UpdateAsync(order, cancellationToken);
        logger.LogInformation("[{Prefix}] Order [{OrderId}] paid with reference [{PaymentReference}]", nameof(OrderProcessingService), order.Id, order.PaymentReference);
        await PublishPaidAsync(order, cancellationToken);
    }

    private async Task ContinuePaidAsync(Order order, CancellationToken cancellationToken)
    {
        if (!order.PaidEventPublished)
        {
            await PublishPaidAsync(order, cancellationToken);
        }

        var now = timeProvider.GetUtcNow();
        if (order.IsShippingDue(now))
        {
            order.MarkShipped(now);
            logger.LogInformation("[{Prefix}] Order [{OrderId}] shipped", nameof(OrderProcessingService), order.Id);
        }
    }

    private async Task PublishPaidAsync(Order order, CancellationToken cancellationToken)
    {
        var message = new OrderPaid(order.Id, order.Lines.Select(line => new OrderPaidLine(line.ProductId, line.Quantity)).ToList(), order.PaidAt ?? timeProvider.GetUtcNow());
        try
        {
            await publisher.PublishAsync(message, cancellationToken);
            order.MarkPaidEventPublished(options.Value.PaidToShippedDelay);
            logger.LogInformation("[{Prefix}] Published OrderPaid for order [{OrderId}] with [{Lines}] lines", nameof(OrderProcessingService), order.Id, message.Lines.Count);
        }
        catch (OutboxUnavailableException exception)
        {
            order.ScheduleRetry(timeProvider.GetUtcNow() + options.Value.PaymentRetryDelay);
            logger.LogWarning(exception, "[{Prefix}] Could not store OrderPaid for order [{OrderId}], retrying at [{NextAttemptAt}]", nameof(OrderProcessingService), order.Id, order.NextAttemptAt);
        }
    }
}
```

`src/Ecommerce.Ordering.Api/Processing/OrderProcessor.cs`:

```csharp
using Ecommerce.Ordering.Api.Infrastructure;
using Microsoft.Extensions.Options;

namespace Ecommerce.Ordering.Api.Processing;

// Polls for due orders and hands each claimed one to the processing service; safe to run on several instances
public sealed class OrderProcessor(
    IServiceProvider services,
    IOptions<OrderProcessorOptions> options,
    TimeProvider timeProvider,
    ILogger<OrderProcessor> logger) : BackgroundService
{
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        logger.LogInformation("[{Prefix}] Started with poll interval [{PollInterval}]", nameof(OrderProcessor), options.Value.PollInterval);
        using var timer = new PeriodicTimer(options.Value.PollInterval, timeProvider);
        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                await ProcessDueOrdersAsync(stoppingToken);
            }
            catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
            {
                break;
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "[{Prefix}] Processing tick failed", nameof(OrderProcessor));
            }

            if (!await timer.WaitForNextTickAsync(stoppingToken))
            {
                break;
            }
        }
    }

    private async Task ProcessDueOrdersAsync(CancellationToken cancellationToken)
    {
        await using var scope = services.CreateAsyncScope();
        var store = scope.ServiceProvider.GetRequiredService<IOrderStore>();
        var processing = scope.ServiceProvider.GetRequiredService<OrderProcessingService>();

        while (!cancellationToken.IsCancellationRequested)
        {
            var now = timeProvider.GetUtcNow();
            var order = await store.ClaimDueAsync(now, now + options.Value.LeaseDuration, cancellationToken);
            if (order is null)
            {
                return;
            }

            await processing.ProcessAsync(order, cancellationToken);
        }
    }
}
```

Replace `src/Ecommerce.Ordering.Api/appsettings.json` with:

```json
{
  "Logging": {
    "LogLevel": {
      "Default": "Information",
      "Microsoft.AspNetCore": "Warning"
    }
  },
  "AllowedHosts": "*",
  "Ordering": {
    "Processor": {
      "PollInterval": "00:00:01",
      "LeaseDuration": "00:00:30",
      "PaidToShippedDelay": "00:00:05",
      "PaymentRetryDelay": "00:00:05"
    }
  }
}
```

Replace `src/Ecommerce.Ordering.Api/Program.cs` with:

```csharp
using Ecommerce.Contracts;
using Ecommerce.Ordering.Api.Features.GetOrder;
using Ecommerce.Ordering.Api.Features.ListOrders;
using Ecommerce.Ordering.Api.Infrastructure;
using Ecommerce.Ordering.Api.Processing;
using Ecommerce.ServiceDefaults.Api;
using Wolverine;
using Wolverine.Postgresql;
using Wolverine.RabbitMQ;

MongoSerialization.Register();

var builder = WebApplication.CreateBuilder(args);

builder.AddServiceDefaults();
builder.AddApiDefaults();
builder.Services.AddValidation();
builder.AddMongoDBClient("orderingdb");
builder.Services.AddSingleton(TimeProvider.System);
builder.Services.AddSingleton<IOrderStore, MongoOrderStore>();
builder.Services.AddHostedService<OrderingDbInitializer>();
builder.Services.AddOptions<OrderProcessorOptions>().BindConfiguration(OrderProcessorOptions.SectionName).ValidateDataAnnotations().ValidateOnStart();
builder.Services.AddHttpClient<IPaymentClient, PaymentClient>(client => client.BaseAddress = new Uri("https+http://payment-api"));
builder.Services.AddScoped<IOrderPaidPublisher, WolverineOrderPaidPublisher>();
builder.Services.AddScoped<OrderProcessingService>();
builder.Services.AddHostedService<OrderProcessor>();

builder.UseWolverine(options =>
{
    // Outgoing OrderPaid events are stored in the orderingmessages database before delivery; orders themselves stay in Mongo
    options.PersistMessagesWithPostgresql(builder.Configuration.GetConnectionString("orderingmessages")!, "wolverine");
    options.UseRabbitMqUsingNamedConnection("messaging")
        .AutoProvision()
        .DeclareExchange("order-placed", exchange => exchange.BindQueue("ordering.order-placed"));
    options.ListenToRabbitQueue("ordering.order-placed").ProcessInline();
    options.PublishMessage<OrderPaid>().ToRabbitExchange("order-paid").UseDurableOutbox();
});

var app = builder.Build();

app.UseApiDefaults();

var orders = app.MapGroup("/api/orders").WithTags("Orders").AddEndpointFilter<BuyerIdFilter>();
orders.MapListOrders();
orders.MapGetOrder();

app.Run();
```

- [ ] **Step 4: Run every test and build**

```bash
dotnet test
dotnet build
```

Expected: 18 Ordering tests, 8 Payment, 28 Basket, 32 ServiceDefaults and 22 Catalog tests pass, 108 in total, with `0 Warning(s)`.

---

## Sub-phase 5.3 Catalog durable inbox and wiring (backend-dev)

### Task 5.3.1: OrderPaid handler with the durable inbox, Catalog wiring and AppHost wiring, test-first

**Files:**
- Create: `tests/Ecommerce.Catalog.Api.Tests/Messaging/OrderPaidHandlerTests.cs`
- Modify: `Directory.Packages.props`
- Modify: `src/Ecommerce.Catalog.Api/Ecommerce.Catalog.Api.csproj`
- Create: `src/Ecommerce.Catalog.Api/Messaging/OrderPaidHandler.cs`
- Modify: `src/Ecommerce.Catalog.Api/Program.cs`
- Modify: `src/Ecommerce.AppHost/Ecommerce.AppHost.csproj`
- Modify: `src/Ecommerce.AppHost/AppHost.cs`

**Interfaces:**
- Consumes: `OrderPaid`, `CatalogDbContext`, the SQLite test fixture.
- Produces: `OrderPaidHandler.HandleAsync(OrderPaid, CatalogDbContext, ILogger<OrderPaidHandler>, CancellationToken)` running one guarded `ExecuteUpdateAsync` per line, flooring at zero with a warning when the guard fails and warning when the product is unknown; the Catalog `Program.cs` with the DbContext registered with `DisableRetry = true`, and Wolverine with the Postgres message store in `catalogdb`, EF Core transactions auto-applied, a durable inbox on every listener, and the `catalog.order-paid` queue bound to the `order-paid` exchange; the AppHost with the `orderingmessages` database, `payment-api`, `ordering-api` referencing `orderingmessages` and `payment-api` (without waiting for it), and `catalog-api` referencing the broker.

- [ ] **Step 1: Write the failing tests**

`tests/Ecommerce.Catalog.Api.Tests/Messaging/OrderPaidHandlerTests.cs`:

```csharp
using Ecommerce.Catalog.Api.Infrastructure;
using Ecommerce.Catalog.Api.Messaging;
using Ecommerce.Contracts;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging.Abstractions;

namespace Ecommerce.Catalog.Api.Tests.Messaging;

public sealed class OrderPaidHandlerTests
{
    private static readonly Guid MugId = Guid.Parse("a0000000-0000-4000-8000-000000000001");
    private static readonly Guid PosterId = Guid.Parse("a0000000-0000-4000-8000-000000000010");
    private static readonly DateTimeOffset PaidAt = new(2026, 9, 12, 12, 0, 0, TimeSpan.Zero);

    [Fact]
    public async Task HandleAsync_DecrementsEachLine()
    {
        using var db = new SqliteCatalogDb();
        await CatalogDbInitializer.SeedAsync(db.Context, TestContext.Current.CancellationToken);
        var message = new OrderPaid(Guid.NewGuid(), [new OrderPaidLine(MugId, 2), new OrderPaidLine(PosterId, 1)], PaidAt);

        await OrderPaidHandler.HandleAsync(message, db.Context, NullLogger<OrderPaidHandler>.Instance, TestContext.Current.CancellationToken);

        Assert.Equal(23, await StockAsync(db.Context, MugId));
        Assert.Equal(1, await StockAsync(db.Context, PosterId));
    }

    [Fact]
    public async Task HandleAsync_FloorsAtZeroWhenStockIsShort()
    {
        using var db = new SqliteCatalogDb();
        await CatalogDbInitializer.SeedAsync(db.Context, TestContext.Current.CancellationToken);
        var message = new OrderPaid(Guid.NewGuid(), [new OrderPaidLine(PosterId, 5)], PaidAt);

        await OrderPaidHandler.HandleAsync(message, db.Context, NullLogger<OrderPaidHandler>.Instance, TestContext.Current.CancellationToken);

        Assert.Equal(0, await StockAsync(db.Context, PosterId));
    }

    [Fact]
    public async Task HandleAsync_IgnoresUnknownProducts()
    {
        using var db = new SqliteCatalogDb();
        await CatalogDbInitializer.SeedAsync(db.Context, TestContext.Current.CancellationToken);
        var message = new OrderPaid(Guid.NewGuid(), [new OrderPaidLine(Guid.NewGuid(), 1), new OrderPaidLine(MugId, 1)], PaidAt);

        await OrderPaidHandler.HandleAsync(message, db.Context, NullLogger<OrderPaidHandler>.Instance, TestContext.Current.CancellationToken);

        Assert.Equal(24, await StockAsync(db.Context, MugId));
    }

    private static Task<int> StockAsync(CatalogDbContext db, Guid productId) =>
        db.Products.AsNoTracking().Where(product => product.Id == productId).Select(product => product.AvailableStock).SingleAsync(TestContext.Current.CancellationToken);
}
```

- [ ] **Step 2: Add the package version and references, then confirm the failing state**

In `Directory.Packages.props`, add one line to the `Messaging` group after the `WolverineFx.Postgresql` line:

```xml
    <PackageVersion Include="WolverineFx.EntityFrameworkCore" Version="6.36.0" />
```

Replace `src/Ecommerce.Catalog.Api/Ecommerce.Catalog.Api.csproj` with:

```xml
<Project Sdk="Microsoft.NET.Sdk.Web">

  <ItemGroup>
    <PackageReference Include="Aspire.Npgsql.EntityFrameworkCore.PostgreSQL" />
    <PackageReference Include="Microsoft.EntityFrameworkCore.Design">
      <PrivateAssets>all</PrivateAssets>
      <IncludeAssets>runtime; build; native; contentfiles; analyzers; buildtransitive</IncludeAssets>
    </PackageReference>
    <PackageReference Include="WolverineFx" />
    <PackageReference Include="WolverineFx.RabbitMQ" />
    <PackageReference Include="WolverineFx.RuntimeCompilation" />
    <PackageReference Include="WolverineFx.Postgresql" />
    <PackageReference Include="WolverineFx.EntityFrameworkCore" />
  </ItemGroup>

  <ItemGroup>
    <ProjectReference Include="../Ecommerce.Contracts/Ecommerce.Contracts.csproj" />
    <ProjectReference Include="../Ecommerce.ServiceDefaults/Ecommerce.ServiceDefaults.csproj" />
  </ItemGroup>

</Project>
```

```bash
dotnet test --project tests/Ecommerce.Catalog.Api.Tests
```

Expected: a compile error naming the `Ecommerce.Catalog.Api.Messaging` namespace as missing.

- [ ] **Step 3: Implement the handler and the composition root**

`src/Ecommerce.Catalog.Api/Messaging/OrderPaidHandler.cs`:

```csharp
using Ecommerce.Catalog.Api.Infrastructure;
using Ecommerce.Contracts;
using Microsoft.EntityFrameworkCore;

namespace Ecommerce.Catalog.Api.Messaging;

// Decrements stock once per paid order; the durable inbox keeps a redelivered event from running this twice
public sealed class OrderPaidHandler
{
    public static async Task HandleAsync(OrderPaid message, CatalogDbContext db, ILogger<OrderPaidHandler> logger, CancellationToken cancellationToken)
    {
        foreach (var line in message.Lines)
        {
            var decremented = await db.Products
                .Where(product => product.Id == line.ProductId && product.AvailableStock >= line.Quantity)
                .ExecuteUpdateAsync(setters => setters.SetProperty(product => product.AvailableStock, product => product.AvailableStock - line.Quantity), cancellationToken);
            if (decremented == 1)
            {
                logger.LogInformation("[{Prefix}] Decremented stock of product [{ProductId}] by [{Quantity}] for order [{OrderId}]", nameof(OrderPaidHandler), line.ProductId, line.Quantity, message.OrderId);
                continue;
            }

            // The guard failed: either the product is gone or two orders raced for the last units, so the stock floors at zero
            var floored = await db.Products
                .Where(product => product.Id == line.ProductId && product.AvailableStock < line.Quantity)
                .ExecuteUpdateAsync(setters => setters.SetProperty(product => product.AvailableStock, 0), cancellationToken);
            if (floored == 1)
            {
                logger.LogWarning("[{Prefix}] Stock shortfall for product [{ProductId}], order [{OrderId}] needed [{Quantity}], stock floored at [0]", nameof(OrderPaidHandler), line.ProductId, message.OrderId, line.Quantity);
            }
            else
            {
                logger.LogWarning("[{Prefix}] Product [{ProductId}] from order [{OrderId}] not found in the catalog", nameof(OrderPaidHandler), line.ProductId, message.OrderId);
            }
        }
    }
}
```

Replace `src/Ecommerce.Catalog.Api/Program.cs` with:

```csharp
using Ecommerce.Catalog.Api.Features.GetProduct;
using Ecommerce.Catalog.Api.Features.ListProducts;
using Ecommerce.Catalog.Api.Infrastructure;
using Ecommerce.ServiceDefaults.Api;
using Wolverine;
using Wolverine.EntityFrameworkCore;
using Wolverine.Postgresql;
using Wolverine.RabbitMQ;

var builder = WebApplication.CreateBuilder(args);

builder.AddServiceDefaults();
builder.AddApiDefaults();
builder.Services.AddValidation();
// Wolverine opens an explicit transaction around each handler, which EF Core forbids under the retrying execution strategy
builder.AddNpgsqlDbContext<CatalogDbContext>("catalogdb", settings => settings.DisableRetry = true);
builder.Services.AddHostedService<CatalogDbInitializer>();

builder.UseWolverine(options =>
{
    // Incoming OrderPaid events are tracked in a durable inbox in the catalog database, so a redelivery never decrements twice
    options.PersistMessagesWithPostgresql(builder.Configuration.GetConnectionString("catalogdb")!, "wolverine");
    options.UseEntityFrameworkCoreTransactions();
    options.Policies.AutoApplyTransactions();
    options.Policies.UseDurableInboxOnAllListeners();
    options.UseRabbitMqUsingNamedConnection("messaging")
        .AutoProvision()
        .DeclareExchange("order-paid", exchange => exchange.BindQueue("catalog.order-paid"));
    options.ListenToRabbitQueue("catalog.order-paid");
});

var app = builder.Build();

app.UseApiDefaults();

var catalog = app.MapGroup("/api/catalog").WithTags("Catalog");
catalog.MapListProducts();
catalog.MapGetProduct();

app.Run();
```

- [ ] **Step 4: Run every test**

```bash
dotnet test
```

Expected: 25 Catalog tests and 111 in total.

- [ ] **Step 5: AppHost wiring and build**

Replace `src/Ecommerce.AppHost/Ecommerce.AppHost.csproj` with:

```xml
<Project Sdk="Aspire.AppHost.Sdk/13.5.3">

  <PropertyGroup>
    <OutputType>Exe</OutputType>
    <AspireUseCliBundle>true</AspireUseCliBundle>
    <UserSecretsId>ecommerce-aspire-demo-apphost</UserSecretsId>
  </PropertyGroup>

  <ItemGroup>
    <PackageReference Include="Aspire.Hosting.PostgreSQL" />
    <PackageReference Include="Aspire.Hosting.Redis" />
    <PackageReference Include="Aspire.Hosting.RabbitMQ" />
    <PackageReference Include="Aspire.Hosting.MongoDB" />
    <PackageReference Include="Aspire.Hosting.JavaScript" />
  </ItemGroup>

  <ItemGroup>
    <ProjectReference Include="../Ecommerce.Catalog.Api/Ecommerce.Catalog.Api.csproj" />
    <ProjectReference Include="../Ecommerce.Basket.Api/Ecommerce.Basket.Api.csproj" />
    <ProjectReference Include="../Ecommerce.Gateway/Ecommerce.Gateway.csproj" />
    <ProjectReference Include="../Ecommerce.Ordering.Api/Ecommerce.Ordering.Api.csproj" />
    <ProjectReference Include="../Ecommerce.Payment.Api/Ecommerce.Payment.Api.csproj" />
  </ItemGroup>

</Project>
```

Replace `src/Ecommerce.AppHost/AppHost.cs` with:

```csharp
var builder = DistributedApplication.CreateBuilder(args);

var postgres = builder.AddPostgres("postgres");
var catalogDb = postgres.AddDatabase("catalogdb");
var basketDb = postgres.AddDatabase("basketdb");
var orderingMessagesDb = postgres.AddDatabase("orderingmessages");

var redis = builder.AddRedis("basket-cache");

var rabbitMq = builder.AddRabbitMQ("messaging")
    .WithManagementPlugin();

var mongo = builder.AddMongoDB("mongo");
var orderingDb = mongo.AddDatabase("orderingdb");

var catalogApi = builder.AddProject<Projects.Ecommerce_Catalog_Api>("catalog-api")
    .WithReference(catalogDb)
    .WaitFor(catalogDb)
    .WithReference(rabbitMq)
    .WaitFor(rabbitMq)
    .WithHttpHealthCheck("/health");

var paymentApi = builder.AddProject<Projects.Ecommerce_Payment_Api>("payment-api")
    .WithHttpHealthCheck("/health");

var basketApi = builder.AddProject<Projects.Ecommerce_Basket_Api>("basket-api")
    .WithReference(redis)
    .WaitFor(redis)
    .WithReference(basketDb)
    .WaitFor(basketDb)
    .WithReference(rabbitMq)
    .WaitFor(rabbitMq)
    .WithReference(catalogApi)
    .WaitFor(catalogApi)
    .WithHttpHealthCheck("/health");

var orderingApi = builder.AddProject<Projects.Ecommerce_Ordering_Api>("ordering-api")
    .WithReference(orderingDb)
    .WaitFor(orderingDb)
    .WithReference(orderingMessagesDb)
    .WaitFor(orderingMessagesDb)
    .WithReference(rabbitMq)
    .WaitFor(rabbitMq)
    .WithReference(paymentApi)
    .WithHttpHealthCheck("/health");

var frontend = builder.AddViteApp("frontend", "../ecommerce-frontend");

builder.AddProject<Projects.Ecommerce_Gateway>("gateway")
    .WithReference(catalogApi)
    .WaitFor(catalogApi)
    .WithReference(basketApi)
    .WaitFor(basketApi)
    .WithReference(orderingApi)
    .WaitFor(orderingApi)
    .WithReference(frontend)
    .WithHttpHealthCheck("/health")
    .WithExternalHttpEndpoints();

builder.Build().Run();
```

```bash
dotnet build
```

Expected: `Build succeeded.` with `0 Warning(s)`. Do not run the AppHost; the lead runs phase acceptance.

---

## Sub-phase 5.4 Orders page polling (frontend-dev)

### Task 5.4.1: Polling rule and live orders page, test-first

**Files:**
- Create: `src/ecommerce-frontend/src/app/features/orders/orders-polling.spec.ts`
- Create: `src/ecommerce-frontend/src/app/features/orders/orders-polling.ts`
- Modify: `src/ecommerce-frontend/src/app/features/orders/orders-page.ts`
- Modify: `src/ecommerce-frontend/src/app/features/orders/orders-page.html`
- Modify: `src/ecommerce-frontend/src/app/features/orders/orders-page.scss`

**Interfaces:**
- Consumes: `OrdersApi.listOrders()` and the `Order` model.
- Produces: `shouldPollOrders(orders)` returning true only while an order is Submitted or Paid, `ordersPollIntervalMs` of 3000, and an `OrdersPage` that reloads its resource on that interval while the rule holds and the resource is resolved, shows the progress bar only during the first load, and shows a "Watching for status changes" hint while polling.

- [ ] **Step 1: Write the failing spec**

`src/app/features/orders/orders-polling.spec.ts`:

```typescript
import { Order } from '../../shared/models/order';
import { shouldPollOrders } from './orders-polling';

function order(status: Order['status']): Order {
  return {
    id: `o-${status}`,
    status,
    total: 10,
    currency: 'EUR',
    createdAt: '2026-09-12T12:00:00Z',
    paidAt: null,
    shippedAt: null,
    failureReason: null,
    cardLast4: '4242',
    buyer: { name: 'Goran', email: 'goran@example.com' },
    shippingAddress: {
      street: 'Main Street 1',
      city: 'Belgrade',
      postalCode: '11000',
      country: 'Serbia',
    },
    lines: [],
  };
}

describe('shouldPollOrders', () => {
  it('is false without orders', () => {
    expect(shouldPollOrders(undefined)).toBe(false);
    expect(shouldPollOrders([])).toBe(false);
  });

  it('is false when every order is terminal', () => {
    expect(shouldPollOrders([order('Shipped'), order('PaymentFailed')])).toBe(false);
  });

  it('is true while an order is Submitted or Paid', () => {
    expect(shouldPollOrders([order('Shipped'), order('Submitted')])).toBe(true);
    expect(shouldPollOrders([order('Paid')])).toBe(true);
  });
});
```

- [ ] **Step 2: Run the tests and confirm they fail**

```bash
npm test
```

Expected: the run fails to resolve `./orders-polling`.

- [ ] **Step 3: Implement**

`src/app/features/orders/orders-polling.ts`:

```typescript
import { Order } from '../../shared/models/order';

export const ordersPollIntervalMs = 3000;

// Poll only while an order can still change; Shipped and PaymentFailed are terminal
export function shouldPollOrders(orders: readonly Order[] | undefined): boolean {
  return orders?.some((order) => order.status === 'Submitted' || order.status === 'Paid') ?? false;
}
```

`src/app/features/orders/orders-page.ts`:

```typescript
import { CurrencyPipe, DatePipe } from '@angular/common';
import { ChangeDetectionStrategy, Component, DestroyRef, computed, inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { RouterLink } from '@angular/router';

import { toApiFailure } from '../../core/api/api-response';
import { OrdersApi } from '../../core/api/orders-api';
import { ordersPollIntervalMs, shouldPollOrders } from './orders-polling';

@Component({
  selector: 'app-orders-page',
  imports: [
    CurrencyPipe,
    DatePipe,
    MatCardModule,
    MatButtonModule,
    MatProgressBarModule,
    RouterLink,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './orders-page.html',
  styleUrl: './orders-page.scss',
})
export class OrdersPage {
  private readonly api = inject(OrdersApi);
  private readonly destroyRef = inject(DestroyRef);

  protected readonly orders = this.api.listOrders();
  protected readonly failure = computed(() => {
    const error = this.orders.error();
    return error ? toApiFailure(error) : null;
  });
  protected readonly polling = computed(() => shouldPollOrders(this.orders.value()));

  constructor() {
    // Refreshes only while an order is still moving, so the dashboard is not flooded with idle requests
    const timer = setInterval(() => {
      if (shouldPollOrders(this.orders.value()) && this.orders.status() === 'resolved') {
        this.orders.reload();
      }
    }, ordersPollIntervalMs);
    this.destroyRef.onDestroy(() => clearInterval(timer));
  }

  protected reload(): void {
    this.orders.reload();
  }
}
```

`src/app/features/orders/orders-page.html`:

```html
<h1 class="title">Your orders</h1>

@if (orders.status() === 'loading') {
  <mat-progress-bar mode="indeterminate" aria-label="Loading orders" />
}
@if (polling()) {
  <p class="hint">Watching for status changes</p>
}

@if (failure(); as failure) {
  <mat-card class="notice" appearance="outlined">
    <mat-card-content>
      <p>{{ failure.message }}</p>
      <p class="code">[{{ failure.code }}]</p>
    </mat-card-content>
    <mat-card-actions>
      <button mat-button (click)="reload()">Retry</button>
    </mat-card-actions>
  </mat-card>
} @else if (orders.value(); as items) {
  @if (items.length === 0) {
    <mat-card class="notice" appearance="outlined">
      <mat-card-content>
        <p>You have not placed any orders yet.</p>
      </mat-card-content>
      <mat-card-actions>
        <a mat-flat-button routerLink="/products">Browse products</a>
      </mat-card-actions>
    </mat-card>
  }
  <div class="list">
    @for (order of items; track order.id) {
      <mat-card appearance="outlined" class="order">
        <mat-card-header>
          <mat-card-title>Order {{ order.id.slice(0, 8) }}</mat-card-title>
          <mat-card-subtitle>{{ order.createdAt | date: 'medium' }}</mat-card-subtitle>
          <span class="status" [class]="'status ' + order.status.toLowerCase()">{{
            order.status
          }}</span>
        </mat-card-header>
        <mat-card-content>
          <ul class="lines">
            @for (line of order.lines; track line.productId) {
              <li>
                <span>{{ line.quantity }} x {{ line.productName }}</span>
                <span>{{ line.lineTotal | currency: 'EUR' }}</span>
              </li>
            }
          </ul>
          <div class="footer">
            <span
              >Card ending {{ order.cardLast4 }}, shipping to {{ order.shippingAddress.city }}</span
            >
            <span class="total">{{ order.total | currency: 'EUR' }}</span>
          </div>
          @if (order.failureReason) {
            <p class="reason">{{ order.failureReason }}</p>
          }
        </mat-card-content>
      </mat-card>
    }
  </div>
}
```

`src/app/features/orders/orders-page.scss`:

```scss
.title {
  font: var(--mat-sys-headline-medium);
  margin: 0 0 1rem;
}

.hint {
  font: var(--mat-sys-label-medium);
  color: var(--mat-sys-on-surface-variant);
  margin: 0 0 0.75rem;
}

.list {
  display: grid;
  gap: 1rem;
}

.order mat-card-header {
  align-items: center;
  gap: 1rem;
}

.status {
  margin-left: auto;
  padding: 0.2rem 0.75rem;
  border-radius: 999px;
  font: var(--mat-sys-label-large);
  background: var(--mat-sys-surface-container-high);
  color: var(--mat-sys-on-surface);
}

.status.paid {
  background: var(--mat-sys-primary-container);
  color: var(--mat-sys-on-primary-container);
}

.status.shipped {
  background: var(--mat-sys-tertiary-container);
  color: var(--mat-sys-on-tertiary-container);
}

.status.paymentfailed {
  background: var(--mat-sys-error-container);
  color: var(--mat-sys-on-error-container);
}

.lines {
  list-style: none;
  margin: 0;
  padding: 0;
}

.lines li {
  display: flex;
  justify-content: space-between;
  padding: 0.3rem 0;
}

.footer {
  display: flex;
  justify-content: space-between;
  border-top: 1px solid var(--mat-sys-outline-variant);
  padding-top: 0.75rem;
  margin-top: 0.5rem;
  color: var(--mat-sys-on-surface-variant);
}

.total {
  font: var(--mat-sys-title-medium);
  color: var(--mat-sys-on-surface);
}

.reason {
  color: var(--mat-sys-error);
}

.notice .code {
  font: var(--mat-sys-label-medium);
  color: var(--mat-sys-on-surface-variant);
}
```

- [ ] **Step 4: Run the tests, then the full check**

```bash
npm test
npm run build
npm run lint
npm run format:check
```

Expected: `Test Files  8 passed (8)` and `Tests  29 passed (29)`; build, lint and format check clean.

---

## Sub-phase 5.5 Phase acceptance

Run by the lead after every task above is reviewed and ticked.

- [ ] **Step 1: Clean build and full test runs**

```bash
dotnet build
dotnet test
cd src/ecommerce-frontend && source "$HOME/.nvm/nvm.sh" && nvm use && npm run lint && npm test && cd ../..
```

Expected: `0 Warning(s)`, 111 .NET tests, 29 frontend tests, lint clean.

- [ ] **Step 2: Start the AppHost and wait**

```bash
export PATH="$PATH:$HOME/.dotnet/tools"
source "$HOME/.nvm/nvm.sh" && nvm use 24
AH=src/Ecommerce.AppHost/Ecommerce.AppHost.csproj
aspire start --apphost $AH --non-interactive --format Json
for r in catalog-api basket-api ordering-api payment-api frontend gateway; do aspire wait $r --status healthy --timeout 300 --apphost $AH --non-interactive; done
aspire logs ordering-api --search OrderProcessor --apphost $AH --non-interactive
```

Expected: all six healthy; the Ordering log contains `[OrderProcessor] Started with poll interval [00:00:01]`; the Catalog log contains `Started message listening at rabbitmq://queue/catalog.order-paid`.

- [ ] **Step 3: An approved order, start to finish**

```bash
G=http://localhost:5100/api
CT="content-type: application/json"
MUG=a0000000-0000-4000-8000-000000000001
B1="X-Buyer-Id: b0000000-0000-4000-8000-000000000051"
BODY='{"buyer":{"name":"Goran","email":"goran@example.com"},"shippingAddress":{"street":"Main Street 1","city":"Belgrade","postalCode":"11000","country":"Serbia"},"card":{"number":"4242424242424242","holderName":"Goran"}}'
curl -s $G/catalog/products/$MUG                       # availableStock 25
curl -s -H "$B1" -H "$CT" -X PUT -d "{\"productId\":\"$MUG\",\"quantity\":2}" -o /dev/null $G/basket/items
curl -s -H "$B1" -H "$CT" -X POST -d "$BODY" $G/basket/checkout    # 202 with the orderId
sleep 4;  curl -s -H "$B1" $G/orders                   # status Paid, paidAt set
sleep 6;  curl -s -H "$B1" $G/orders                   # status Shipped, shippedAt set
curl -s $G/catalog/products/$MUG                       # availableStock 23
aspire logs ordering-api --search OrderProcessingService --apphost $AH --non-interactive
# paid with reference [...], Published OrderPaid ... with [1] lines, shipped
aspire logs catalog-api --search OrderPaidHandler --apphost $AH --non-interactive
# [OrderPaidHandler] Decremented stock of product [...] by [2] for order [...]
```

- [ ] **Step 4: A declined card**

```bash
B2="X-Buyer-Id: b0000000-0000-4000-8000-000000000052"
POSTER=a0000000-0000-4000-8000-000000000010
curl -s -H "$B2" -H "$CT" -X PUT -d "{\"productId\":\"$POSTER\",\"quantity\":1}" -o /dev/null $G/basket/items
curl -s -H "$B2" -H "$CT" -X POST -d "${BODY/4242424242424242/4000000000000002}" $G/basket/checkout
sleep 4; curl -s -H "$B2" $G/orders                    # status PaymentFailed, failureReason card_declined
curl -s $G/catalog/products/$POSTER                    # availableStock still 2
```

- [ ] **Step 5: Payment down, then Catalog down**

```bash
TSHIRT=a0000000-0000-4000-8000-000000000004
B3="X-Buyer-Id: b0000000-0000-4000-8000-000000000053"
aspire resource payment-api stop --apphost $AH --non-interactive
aspire wait payment-api --status down --timeout 60 --apphost $AH --non-interactive
curl -s -H "$B3" -H "$CT" -X PUT -d "{\"productId\":\"$TSHIRT\",\"quantity\":1}" -o /dev/null $G/basket/items
curl -s -H "$B3" -H "$CT" -X POST -d "$BODY" $G/basket/checkout     # 202
sleep 10; curl -s -H "$B3" $G/orders                   # still Submitted: the processor is retrying Payment
aspire resource catalog-api stop --apphost $AH --non-interactive
aspire wait catalog-api --status down --timeout 60 --apphost $AH --non-interactive
aspire resource payment-api start --apphost $AH --non-interactive
aspire wait payment-api --status healthy --timeout 120 --apphost $AH --non-interactive
sleep 6; curl -s -H "$B3" $G/orders                    # Paid, or already Shipped if the waits took longer than the ship delay; OrderPaid is now waiting for Catalog
aspire resource catalog-api start --apphost $AH --non-interactive
aspire wait catalog-api --status healthy --timeout 120 --apphost $AH --non-interactive
sleep 4; curl -s $G/catalog/products/$TSHIRT           # availableStock 29
aspire logs catalog-api --search OrderPaidHandler --apphost $AH --non-interactive
# a second Decremented stock line, for the T-shirt
```

The resilience handler retries a Payment call for about 30 seconds before the processor logs `Payment unavailable` and schedules the next attempt, so with a short outage the order proceeds as soon as Payment is back, without that warning ever appearing.

- [ ] **Step 6: Owner's browser check**

Open `http://localhost:5100`, add a product, check out with the prefilled card, and watch the orders page: the order appears as Submitted with "Watching for status changes", turns Paid within a few seconds, then Shipped, and the hint disappears. Back on the products page the stock has dropped. Check out again with `4000 0000 0000 0002` and the order shows PaymentFailed with `card_declined`. In the dashboard, one checkout produces traces through gateway, basket-api, catalog-api, the broker, ordering-api, payment-api, the broker again and catalog-api.

- [ ] **Step 7: Stop and record**

```bash
aspire stop --apphost $AH --non-interactive
```

The lead ticks phase 5 in `STATUS.md`, writes the phase entry in `SUMMARY.md`, and continues with phase 6.
