# Status

Maintained by the lead only. Updated after every task review and every phase acceptance.

## Current position

| | |
|---|---|
| Phase | 9 API Defaults, started 2026-09-14 (phases 0 to 8 accepted) |
| Sub-phase | 9.1 and 9.2 accepted, 9.3 acceptance pending |
| Task | none active |
| Active agents | none (backend-dev finished 9.1.1 and 9.1.2) |
| Last verified | sub-phase 9.2 done on 2026-09-14: ARCHITECTURE.md (header, tree, references table, 7.1, 7.2, test table, dependency table, decision log) and CODING_GUIDELINES.md (three mentions) name `Ecommerce.ApiDefaults`, no `ServiceDefaults.Api` or `ServiceDefaults.Tests` left outside docs/plans, no em dashes; 9.3 static part done: `dotnet new aspire-servicedefaults` output differs from `Extensions.cs` only by `.AddMeter("Wolverine*")` and `.AddSource("Wolverine")` once CRLF is ignored, build warning-free, 154 tests; 9.3 runtime part (aspire start, seven healthy, envelope checks through the gateway, Scalar, a purchase to Shipped, sweep, stop) not run yet; task 9.1.2 accepted on 2026-09-14: the six web project files carry the ApiDefaults reference next to ServiceDefaults, all 39 files with `using Ecommerce.ApiDefaults;` have it first among the project usings with System usings ahead and the block sorted by namespace, the activity source literal renamed, no `ServiceDefaults.Api` or `ServiceDefaults.Tests` left in code, the lead's own `dotnet build` warning-free and `dotnet test` 154 passed in 39 s while the owner's Rider AppHost was running; task 9.1.1 accepted on 2026-09-14: the seven moved sources identical to the pre-move copies apart from the namespace line, the three project files, the solution file and the package groups as in the plan, old folders gone, the build of the new test project warning-free, 32 tests passed on the lead's rerun; one leftover found in review, the `ActivitySource("Ecommerce.ServiceDefaults.Tests")` literal in `ApiResponseTests.cs`, added to task 9.1.2 as a one-line rename; the plan `09-api-defaults.md` was written on 2026-09-14 from a tree where `Ecommerce.ServiceDefaults.Tests` had 32 tests and the solution 154; phase 8 acceptance passed on 2026-09-13: task 8.3.1 files identical to the scratch copies and the whole .NET tree equal to the verified prototype, build warning-free, 154 .NET tests, 49 frontend tests, lint, format and build clean, seven services healthy, preference default en then stored sr and read back, de rejected with 400, the Mug answers "Aspire keramička šolja" and "Posuđe za piće" for sr-Latn and English for en, basket lines named per read language, both dictionary URLs served as JSON, a checkout made in Serbian reached Shipped with the Serbian line name in the order, warn and fail sweep empty, AppHost stopped with no containers left; task 8.2.1 accepted on 2026-09-13: 19 files identical to the scratch copies, the generated migration and snapshot identical apart from the timestamp, build warning-free, 42 Catalog tests, the agent's full run 147 passed; task 8.4.1 accepted on 2026-09-13: all 36 frontend files identical to the scratch snapshot, 49 tests, lint, format and production build clean; task 8.1.1 accepted on 2026-09-13: 25 files identical to the scratch copies (Basket Program.cs differs only by the header propagation that 8.3.1 adds), build warning-free, 14 Preferences tests, the agent's full run 130 passed; phase 7 acceptance passed on 2026-09-13: task 7.2.1 files identical to the snapshot, build warning-free, 114 .NET tests, 36 frontend tests, lint and format clean, six healthy, the page title through the gateway reads E-Commerce Aspire Demo, warn and fail sweep empty, AppHost stopped; task 7.1.1 accepted on 2026-09-13: all nine files identical to the verified scratch snapshot, the new specs seen failing first, 36 frontend tests, lint and format clean; sub-phase 6.5 acceptance passed on 2026-09-12: six healthy, the frontend's own URL answers `/api/catalog/products` with JSON and `/products` with HTML, the gateway answers on 5100 and 7100, the dev server environment carries `services__gateway__http__0`, a purchase driven entirely through the frontend URL reached Shipped with stock 25 to 24, warn and fail sweep empty before and after, AppHost stopped with no containers left; task 6.5.2 accepted on 2026-09-12: both files identical to the verified scratch copies, lint, format and 29 frontend tests clean; 6.5 acceptance so far: build warning-free, full `dotnet test` 114 passed in 48 s with the frontend proxy test green through randomized ports while the owner's Rider instance was running; task 6.5.1 accepted on 2026-09-12: all five files identical to the verified scratch copies, build warning-free, the new frontend test seen failing on text/html as planned with the two purchase tests passing; phase 6 acceptance passed on 2026-09-12: build warning-free, 113 .NET tests, 29 frontend tests, lint and format clean, six services healthy, the warn and fail sweep over every resource log empty at startup and again after the purchase (Catalog migrated a fresh database without the history-table error, Basket without the no-handlers warning), the three JasperFx commands listed on catalog-api, `jasperfx-check-env` printed "All environment checks are good!", `jasperfx-describe` printed "Wolverine Options", purchase through the gateway 202 then Shipped with stock 25 to 24, `aspire otel traces basket-api` returned the trace table, AppHost stopped with no containers left; task 6.3.1 accepted on 2026-09-12: all three files identical to the verified scratch copies, build warning-free, full `dotnet test` 113 passed, frontend lint, 29 tests and format check clean (6.4 step 1); task 6.2.1 accepted on 2026-09-12: all six files identical to the verified scratch copies, build warning-free, full `dotnet test` 113 passed in 39 s, no demo containers left; task 6.1.1 accepted on 2026-09-12: all six files identical to the verified scratch copies, build warning-free, full `dotnet test` 113 passed including the 2 integration tests that boot the AppHost in about 37 s, no containers left behind; phase 5 acceptance passed on 2026-09-12: build warning-free, 111 .NET tests, 29 frontend tests, six services healthy, approved order Submitted to Paid in 4 s and Shipped in 10 s with stock 25 to 23, declined card to PaymentFailed with stock unchanged, Payment outage retried until Payment returned, OrderPaid queued through a Catalog outage and applied on restart (30 to 29), no card number in responses or logs |
| Half-finished work to look for | none; code and documents are at the phase 9 state, only the runtime acceptance is outstanding |
| Next action | run the 9.3 runtime acceptance from the plan once the owner's Rider AppHost (PID 69503 on 2026-09-14, serving the old build on port 5100) is stopped; both use the launch profile ports, so `aspire start` cannot run beside it |

States: `[ ]` not started, `[~]` in progress, `[r]` in review, `[x]` done, `[!]` blocked.

## Phase overview

| Phase | State | Plan |
|---|---|---|
| 0 Foundation | [x] | accepted 2026-09-12 |
| 1 Catalog | [x] | accepted 2026-09-12 |
| 2 Gateway and frontend shell | [x] | accepted 2026-09-12 |
| 3 Basket | [x] | accepted 2026-09-12 |
| 4 Checkout and Ordering | [x] | accepted 2026-09-12 |
| 5 Payment and lifecycle | [x] | accepted 2026-09-12 |
| 6 Hardening | [x] | accepted 2026-09-12, sub-phase 6.5 added and accepted the same day |
| 7 Polish | [x] | accepted 2026-09-13 |
| 8 Localization | [x] | accepted 2026-09-13 |
| 9 API Defaults | [~] | started 2026-09-14 |

## Phase 0 Foundation

- [x] 0.1 Tooling check and repository skeleton
  - [x] 0.1.1 Verify tooling
  - [x] 0.1.2 Repository files and empty solution
- [x] 0.2 ServiceDefaults with the API response envelope
  - [x] 0.2.1 ServiceDefaults project from the template
  - [x] 0.2.2 Envelope types and ApiResults, test-first
  - [x] 0.2.3 Problem details writer, test-first
  - [x] 0.2.4 AddApiDefaults and UseApiDefaults, test-first
- [x] 0.3 AppHost with infrastructure resources
  - [x] 0.3.1 AppHost project with Postgres, Redis, RabbitMQ and Mongo
- [x] 0.4 Phase acceptance

## Phase 1 Catalog

- [x] 1.1 Project skeleton and test project
  - [x] 1.1.1 Catalog API project
  - [x] 1.1.2 Catalog test project
- [x] 1.2 Domain model and persistence
  - [x] 1.2.1 Product entity, test-first
  - [x] 1.2.2 CatalogDbContext, configuration, design-time factory, SQLite test fixture
  - [x] 1.2.3 InitialCreate migration
- [x] 1.3 Seed data and database initializer
  - [x] 1.3.1 Seed data, test-first
  - [x] 1.3.2 CatalogDbInitializer hosted service, test-first
- [x] 1.4 Product endpoints
  - [x] 1.4.1 ProductResponse and ErrorCodes, test-first
  - [x] 1.4.2 ListProducts endpoint, test-first
  - [x] 1.4.3 GetProduct endpoint, test-first
  - [x] 1.4.4 Program.cs composition
- [x] 1.5 AppHost wiring and phase acceptance
  - [x] 1.5.1 Register catalog-api in the AppHost
  - [x] 1.5.2 Phase acceptance

## Phase 2 Gateway and frontend shell

- [x] 2.1 Gateway (backend)
  - [x] 2.1.1 Error handling split and upstream error code in ServiceDefaults, test-first
  - [x] 2.1.2 Gateway project
  - [x] 2.1.3 AppHost wiring for the frontend and the gateway (after 2.2.1)
- [x] 2.2 Angular workspace, theme and layout (frontend)
  - [x] 2.2.1 Workspace and tooling
  - [x] 2.2.2 Theme, shell layout, header and footer, test-first
- [x] 2.3 Buyer identity, interceptor and response helper (frontend)
  - [x] 2.3.1 Buyer identity, interceptor and envelope helper, test-first
- [x] 2.4 Products page (frontend)
  - [x] 2.4.1 Product model, Catalog client, placeholder image and products page, test-first
- [x] 2.5 Phase acceptance

## Phase 3 Basket

- [x] 3.1 Basket domain, store and Catalog client (backend)
  - [x] 3.1.1 Basket API project and test project
  - [x] 3.1.2 ShoppingBasket, BasketItem and BuyerId, test-first
  - [x] 3.1.3 Basket store, Catalog client and test fakes
- [x] 3.2 Basket endpoints and rules (backend)
  - [x] 3.2.1 BasketResponse and BasketService, test-first
  - [x] 3.2.2 BuyerIdFilter, the three endpoints and the composition root, test-first
  - [x] 3.2.3 Gateway route and AppHost wiring
- [x] 3.3 Basket store, header count, basket page and add action (frontend)
  - [x] 3.3.1 Basket models, BasketApi and BasketStore, test-first
  - [x] 3.3.2 Header badge, basket page, add action and routes, test-first
- [x] 3.4 Phase acceptance

## Phase 4 Checkout and Ordering

- [x] 4.1 Contracts, shared buyer identity and messaging telemetry (backend)
  - [x] 4.1.1 Move BuyerId and BuyerIdFilter into ServiceDefaults, add Wolverine telemetry, test-first
  - [x] 4.1.2 Contracts project
- [x] 4.2 Checkout (backend)
  - [x] 4.2.1 Catalog batch lookup, outbox publisher, packages and fakes
  - [x] 4.2.2 CheckoutService, checkout endpoint and the outbox-backed composition root, test-first
- [x] 4.3 Ordering service (backend)
  - [x] 4.3.1 Ordering project, order document, Mongo store, serialization and initializer, test-first
  - [x] 4.3.2 OrderPlacedHandler, test-first
- [x] 4.4 Ordering read endpoints and wiring (backend)
  - [x] 4.4.1 OrderResponse, list and get endpoints, composition root, gateway route and AppHost wiring, test-first
- [x] 4.5 Checkout and orders in the frontend (frontend)
  - [x] 4.5.1 Order models, checkout on the basket client and store, orders client, test-first
  - [x] 4.5.2 Checkout page, orders page, navigation and routes, test-first
- [x] 4.6 Phase acceptance

## Phase 5 Payment and lifecycle

- [x] 5.1 Payment service (backend)
  - [x] 5.1.1 Payment API with the test card rule, test-first
- [x] 5.2 Order processor (backend)
  - [x] 5.2.1 Order transitions, store claim and update, payment client, outbox publisher and fakes, test-first
  - [x] 5.2.2 OrderProcessingService, OrderProcessor, options and the composition root, test-first
- [x] 5.3 Catalog durable inbox and wiring (backend)
  - [x] 5.3.1 OrderPaid handler with the durable inbox, Catalog wiring and AppHost wiring, test-first
- [x] 5.4 Orders page polling (frontend)
  - [x] 5.4.1 Polling rule and live orders page, test-first
- [x] 5.5 Phase acceptance

## Phase 6 Hardening

- [x] 6.1 Integration tests (backend)
  - [x] 6.1.1 Integration test project that boots the AppHost and buys a product
- [x] 6.2 JasperFx dashboard commands (backend)
  - [x] 6.2.1 Dashboard commands on the Wolverine services
- [x] 6.3 Clean startup log and README (backend)
  - [x] 6.3.1 History table before migrating, Basket log filter, final README
- [x] 6.4 Final acceptance
- [x] 6.5 Dashboard URLs (backend, then frontend)
  - [x] 6.5.1 Frontend regression test and the gateway reference on the frontend
  - [x] 6.5.2 Dev server proxy for /api
  - [x] 6.5.3 Sub-phase acceptance

## Phase 7 Polish

- [x] 7.1 Orders page shows the order just placed (frontend)
  - [x] 7.1.1 Pending order service, polling rule and waiting notice
- [x] 7.2 Header, page title and footer texts (frontend)
  - [x] 7.2.1 New texts
- [x] 7.3 Phase acceptance

## Phase 8 Localization

- [x] 8.1 Preferences service (backend)
  - [x] 8.1.1 Preferences API on the shared Redis, gateway route, AppHost wiring, integration test
- [x] 8.2 Catalog product translations (backend)
  - [x] 8.2.1 Translations owned by the product, request language from Accept-Language, Serbian seed
- [x] 8.3 Basket names resolved from Catalog per request language (backend)
  - [x] 8.3.1 Nameless basket lines, one catalog lookup per read, Accept-Language propagation
- [x] 8.4 Frontend localization with Transloco, language menu and persisted choice (frontend)
  - [x] 8.4.1 Dictionaries, language store, menu, interceptor, translated pages
- [x] 8.5 Phase acceptance

## Phase 9 API Defaults

- [x] 9.1 Move the shared API code (backend)
  - [x] 9.1.1 ApiDefaults project and its tests, ServiceDefaults back to the template
  - [x] 9.1.2 Re-point every web project and test project to ApiDefaults
- [x] 9.2 Documentation (lead)
- [~] 9.3 Phase acceptance (static checks, build and tests passed; runtime part pending)
