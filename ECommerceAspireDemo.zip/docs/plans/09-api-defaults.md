# Phase 9 API Defaults Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Move the project-specific shared API code out of `Ecommerce.ServiceDefaults` into a new `Ecommerce.ApiDefaults` class library, so ServiceDefaults is again what the Aspire template generates and the code is split the way ARCHITECTURE.md section 7 splits it.

**Architecture:** Today `src/Ecommerce.ServiceDefaults/Api/` holds seven files that have nothing to do with Aspire: the response envelope records, `ApiResults`, `CommonErrorCodes`, the `ApiEnvelopeProblemDetailsWriter`, the two registration layers in `ApiDefaultsExtensions`, and the `BuyerId` binding with its `BuyerIdFilter`. They move unchanged, apart from the namespace line, into a new `src/Ecommerce.ApiDefaults/` project with the namespace `Ecommerce.ApiDefaults`. The new project references ServiceDefaults, because `UseApiDefaults` calls the template's `MapDefaultEndpoints`, and takes the `Microsoft.AspNetCore.OpenApi` and `Scalar.AspNetCore` packages with it. ServiceDefaults keeps the template's `Extensions.cs` and the template's package list. Every web project references both projects; the gateway keeps using only the error handling layer. `Ecommerce.ServiceDefaults.Tests` becomes `Ecommerce.ApiDefaults.Tests`, since all of its tests cover the moved code. No behavior changes, no test changes beyond namespaces, and the .NET test count stays at 154.

**Tech Stack:** .NET 10, xunit.v3. No new packages. `Microsoft.AspNetCore.OpenApi` 10.0.12 and `Scalar.AspNetCore` 2.17.3 move from ServiceDefaults to ApiDefaults.

**Spec:** `docs/ARCHITECTURE.md` sections 3, 7.1 and 7.2 (the lead rewrites them in sub-phase 9.2 to describe the state this phase produces); `docs/CODING_GUIDELINES.md` section 2.5 for the envelope.

**Agents and ordering:** `backend-dev` runs task 9.1.1, then task 9.1.2, in that order and in one agent. There is no frontend work. Sub-phase 9.2 is the lead's documentation update and sub-phase 9.3 the lead's acceptance.

## Global Constraints

- Everything from `docs/plans/README.md` Global constraints applies.
- No new NuGet packages. The only package changes are the two `PackageReference` lines that move from the ServiceDefaults project file to the ApiDefaults project file, and the matching two `PackageVersion` lines that move between label groups in `Directory.Packages.props`.
- No behavior change. A moved source file changes only its `namespace` line. A moved test file changes only its `using` line and its `namespace` line. No test is added, removed, renamed or edited otherwise. Re-pointed files change only the one `using` line.
- `Extensions.cs` in ServiceDefaults is not touched.
- The solution does not build between task 9.1.1 and task 9.1.2; that is expected. Task 9.1.1 builds and tests only the two new projects. Task 9.1.2 ends with the full build and the full `dotnet test`.
- The full `dotnet test` boots the AppHost, so Docker must be running and Node 24 must be on the PATH (`source "$HOME/.nvm/nvm.sh" && nvm use 24`). Run it from the repository root.
- Usings stay outside the namespace, `System` namespaces first, then everything else sorted alphabetically; `using Ecommerce.ApiDefaults;` therefore sits first among the `Ecommerce.` usings of any file that has it.
- Use `mv` for the moves and `rm -r` for the deletions. No git commands.
- Nothing under `docs/` is edited by the agent.

---

## Sub-phase 9.1 Move the shared API code (backend-dev)

### Task 9.1.1: The `Ecommerce.ApiDefaults` project and its tests, ServiceDefaults back to the template

**Files:**
- Create: `src/Ecommerce.ApiDefaults/Ecommerce.ApiDefaults.csproj`
- Create: `tests/Ecommerce.ApiDefaults.Tests/Ecommerce.ApiDefaults.Tests.csproj`
- Move: `src/Ecommerce.ServiceDefaults/Api/ApiDefaultsExtensions.cs` to `src/Ecommerce.ApiDefaults/ApiDefaultsExtensions.cs`
- Move: `src/Ecommerce.ServiceDefaults/Api/ApiEnvelopeProblemDetailsWriter.cs` to `src/Ecommerce.ApiDefaults/ApiEnvelopeProblemDetailsWriter.cs`
- Move: `src/Ecommerce.ServiceDefaults/Api/ApiResponse.cs` to `src/Ecommerce.ApiDefaults/ApiResponse.cs`
- Move: `src/Ecommerce.ServiceDefaults/Api/ApiResults.cs` to `src/Ecommerce.ApiDefaults/ApiResults.cs`
- Move: `src/Ecommerce.ServiceDefaults/Api/BuyerId.cs` to `src/Ecommerce.ApiDefaults/BuyerId.cs`
- Move: `src/Ecommerce.ServiceDefaults/Api/BuyerIdFilter.cs` to `src/Ecommerce.ApiDefaults/BuyerIdFilter.cs`
- Move: `src/Ecommerce.ServiceDefaults/Api/CommonErrorCodes.cs` to `src/Ecommerce.ApiDefaults/CommonErrorCodes.cs`
- Move: `tests/Ecommerce.ServiceDefaults.Tests/Api/ApiDefaultsExtensionsTests.cs` to `tests/Ecommerce.ApiDefaults.Tests/ApiDefaultsExtensionsTests.cs`
- Move: `tests/Ecommerce.ServiceDefaults.Tests/Api/ApiEnvelopeProblemDetailsWriterTests.cs` to `tests/Ecommerce.ApiDefaults.Tests/ApiEnvelopeProblemDetailsWriterTests.cs`
- Move: `tests/Ecommerce.ServiceDefaults.Tests/Api/ApiResponseTests.cs` to `tests/Ecommerce.ApiDefaults.Tests/ApiResponseTests.cs`
- Move: `tests/Ecommerce.ServiceDefaults.Tests/Api/ApiResultsTests.cs` to `tests/Ecommerce.ApiDefaults.Tests/ApiResultsTests.cs`
- Move: `tests/Ecommerce.ServiceDefaults.Tests/Api/BuyerIdFilterTests.cs` to `tests/Ecommerce.ApiDefaults.Tests/BuyerIdFilterTests.cs`
- Move: `tests/Ecommerce.ServiceDefaults.Tests/Api/BuyerIdTests.cs` to `tests/Ecommerce.ApiDefaults.Tests/BuyerIdTests.cs`
- Delete: `src/Ecommerce.ServiceDefaults/Api/` (empty after the moves)
- Delete: `tests/Ecommerce.ServiceDefaults.Tests/` (the project file, its `Api/` folder, `bin/` and `obj/`)
- Modify: `src/Ecommerce.ServiceDefaults/Ecommerce.ServiceDefaults.csproj`
- Modify: `Directory.Packages.props`
- Modify: `ECommerceAspireDemo.slnx`

**Interfaces:**
- Consumes: `MapDefaultEndpoints` from ServiceDefaults (namespace `Microsoft.Extensions.Hosting`), which `UseApiDefaults` already calls.
- Produces: the namespace `Ecommerce.ApiDefaults` with the same public types and members as `Ecommerce.ServiceDefaults.Api` had: `ApiResponse<T>`, `ApiResponse`, `ApiError`, `ApiResults`, `CommonErrorCodes`, `ApiEnvelopeProblemDetailsWriter`, `ApiDefaultsExtensions` (`AddApiErrorHandling`, `AddApiDefaults`, `UseApiErrorHandling`, `UseApiDefaults`), `BuyerId`, `BuyerIdFilter`. Task 9.1.2 re-points every consumer to it.

- [ ] **Step 1: The two project files, the package version groups and the solution entries**

Create `src/Ecommerce.ApiDefaults/Ecommerce.ApiDefaults.csproj`. `IsAspireSharedProject` is the same hint ServiceDefaults carries, so the Aspire tooling treats the project as a shared library and never as a service:

```xml
<Project Sdk="Microsoft.NET.Sdk">

  <PropertyGroup>
    <IsAspireSharedProject>true</IsAspireSharedProject>
  </PropertyGroup>

  <ItemGroup>
    <FrameworkReference Include="Microsoft.AspNetCore.App" />
  </ItemGroup>

  <ItemGroup>
    <PackageReference Include="Microsoft.AspNetCore.OpenApi" />
    <PackageReference Include="Scalar.AspNetCore" />
  </ItemGroup>

  <ItemGroup>
    <ProjectReference Include="../Ecommerce.ServiceDefaults/Ecommerce.ServiceDefaults.csproj" />
  </ItemGroup>

</Project>
```

Create `tests/Ecommerce.ApiDefaults.Tests/Ecommerce.ApiDefaults.Tests.csproj`:

```xml
<Project Sdk="Microsoft.NET.Sdk">

  <PropertyGroup>
    <OutputType>Exe</OutputType>
    <IsPackable>false</IsPackable>
    <IsTestProject>true</IsTestProject>
  </PropertyGroup>

  <ItemGroup>
    <FrameworkReference Include="Microsoft.AspNetCore.App" />
  </ItemGroup>

  <ItemGroup>
    <PackageReference Include="xunit.v3" />
  </ItemGroup>

  <ItemGroup>
    <Using Include="Xunit" />
  </ItemGroup>

  <ItemGroup>
    <ProjectReference Include="../../src/Ecommerce.ApiDefaults/Ecommerce.ApiDefaults.csproj" />
  </ItemGroup>

</Project>
```

In `Directory.Packages.props`, remove the last two lines of the `Service defaults` group and add a new group right after it, so the file reads:

```xml
  <ItemGroup Label="Service defaults">
    <PackageVersion Include="Microsoft.Extensions.Http.Resilience" Version="10.10.0" />
    <PackageVersion Include="Microsoft.Extensions.ServiceDiscovery" Version="10.10.0" />
    <PackageVersion Include="OpenTelemetry.Exporter.OpenTelemetryProtocol" Version="1.18.0" />
    <PackageVersion Include="OpenTelemetry.Extensions.Hosting" Version="1.18.0" />
    <PackageVersion Include="OpenTelemetry.Instrumentation.AspNetCore" Version="1.18.0" />
    <PackageVersion Include="OpenTelemetry.Instrumentation.Http" Version="1.18.0" />
    <PackageVersion Include="OpenTelemetry.Instrumentation.Runtime" Version="1.18.0" />
  </ItemGroup>

  <ItemGroup Label="API defaults">
    <PackageVersion Include="Microsoft.AspNetCore.OpenApi" Version="10.0.12" />
    <PackageVersion Include="Scalar.AspNetCore" Version="2.17.3" />
  </ItemGroup>
```

Nothing else in that file changes.

Replace `ECommerceAspireDemo.slnx` with:

```xml
<Solution>
  <Folder Name="/src/">
    <Project Path="src/Ecommerce.ApiDefaults/Ecommerce.ApiDefaults.csproj" />
    <Project Path="src/Ecommerce.AppHost/Ecommerce.AppHost.csproj" />
    <Project Path="src/Ecommerce.Basket.Api/Ecommerce.Basket.Api.csproj" />
    <Project Path="src/Ecommerce.Catalog.Api/Ecommerce.Catalog.Api.csproj" />
    <Project Path="src/Ecommerce.Contracts/Ecommerce.Contracts.csproj" />
    <Project Path="src/Ecommerce.Gateway/Ecommerce.Gateway.csproj" />
    <Project Path="src/Ecommerce.Ordering.Api/Ecommerce.Ordering.Api.csproj" />
    <Project Path="src/Ecommerce.Payment.Api/Ecommerce.Payment.Api.csproj" />
    <Project Path="src/Ecommerce.Preferences.Api/Ecommerce.Preferences.Api.csproj" />
    <Project Path="src/Ecommerce.ServiceDefaults/Ecommerce.ServiceDefaults.csproj" />
  </Folder>
  <Folder Name="/tests/">
    <Project Path="tests/Ecommerce.ApiDefaults.Tests/Ecommerce.ApiDefaults.Tests.csproj" />
    <Project Path="tests/Ecommerce.Basket.Api.Tests/Ecommerce.Basket.Api.Tests.csproj" />
    <Project Path="tests/Ecommerce.Catalog.Api.Tests/Ecommerce.Catalog.Api.Tests.csproj" />
    <Project Path="tests/Ecommerce.IntegrationTests/Ecommerce.IntegrationTests.csproj" />
    <Project Path="tests/Ecommerce.Ordering.Api.Tests/Ecommerce.Ordering.Api.Tests.csproj" />
    <Project Path="tests/Ecommerce.Payment.Api.Tests/Ecommerce.Payment.Api.Tests.csproj" />
    <Project Path="tests/Ecommerce.Preferences.Api.Tests/Ecommerce.Preferences.Api.Tests.csproj" />
  </Folder>
</Solution>
```

The `Ecommerce.ServiceDefaults.Tests` entry is gone; the project is deleted in step 4.

- [ ] **Step 2: Move the six test files to the new namespace and see the build fail**

From the repository root:

```bash
mkdir -p tests/Ecommerce.ApiDefaults.Tests
for f in ApiDefaultsExtensionsTests ApiEnvelopeProblemDetailsWriterTests ApiResponseTests ApiResultsTests BuyerIdFilterTests BuyerIdTests; do
  mv "tests/Ecommerce.ServiceDefaults.Tests/Api/$f.cs" "tests/Ecommerce.ApiDefaults.Tests/$f.cs"
done
sed -i '' \
  -e 's/^using Ecommerce\.ServiceDefaults\.Api;$/using Ecommerce.ApiDefaults;/' \
  -e 's/^namespace Ecommerce\.ServiceDefaults\.Tests\.Api;$/namespace Ecommerce.ApiDefaults.Tests;/' \
  tests/Ecommerce.ApiDefaults.Tests/*.cs
grep -c "ServiceDefaults" tests/Ecommerce.ApiDefaults.Tests/*.cs
```

Expected: the `grep -c` prints `0` for every file. Each test file now starts the way `ApiResultsTests.cs` does:

```csharp
using Ecommerce.ApiDefaults;
using Microsoft.AspNetCore.Http;

namespace Ecommerce.ApiDefaults.Tests;
```

The two files that begin with a `System` using keep it first: `ApiEnvelopeProblemDetailsWriterTests.cs` starts with `using System.Text.Json;` and `ApiResponseTests.cs` with `using System.Diagnostics;`, each followed by `using Ecommerce.ApiDefaults;`. The test bodies are untouched.

Run:

```bash
dotnet build tests/Ecommerce.ApiDefaults.Tests/Ecommerce.ApiDefaults.Tests.csproj
```

Expected: FAIL with `error CS0246: The type or namespace name 'ApiResults' could not be found` and the same error for `ApiResponse`, `BuyerId`, `BuyerIdFilter`, `ApiEnvelopeProblemDetailsWriter` and `CommonErrorCodes`, because the new project compiles no types yet (the `using Ecommerce.ApiDefaults;` line itself resolves, since the test namespace `Ecommerce.ApiDefaults.Tests` declares that parent namespace). If the failure is anything else, stop and report it.

- [ ] **Step 3: Move the seven source files, slim the ServiceDefaults project, and see the tests pass**

```bash
mkdir -p src/Ecommerce.ApiDefaults
for f in ApiDefaultsExtensions ApiEnvelopeProblemDetailsWriter ApiResponse ApiResults BuyerId BuyerIdFilter CommonErrorCodes; do
  mv "src/Ecommerce.ServiceDefaults/Api/$f.cs" "src/Ecommerce.ApiDefaults/$f.cs"
done
rmdir src/Ecommerce.ServiceDefaults/Api
sed -i '' -e 's/^namespace Ecommerce\.ServiceDefaults\.Api;$/namespace Ecommerce.ApiDefaults;/' src/Ecommerce.ApiDefaults/*.cs
grep -c "ServiceDefaults" src/Ecommerce.ApiDefaults/*.cs
```

Expected: `rmdir` succeeds because the folder is empty, and `grep -c` prints `0` for every file. Every moved file keeps its usings and its body; only the namespace line reads `namespace Ecommerce.ApiDefaults;`. `ApiDefaultsExtensions.cs` keeps `using Microsoft.Extensions.Hosting;`, which is what resolves `MapDefaultEndpoints` from ServiceDefaults.

Replace `src/Ecommerce.ServiceDefaults/Ecommerce.ServiceDefaults.csproj` with the template's package list:

```xml
<Project Sdk="Microsoft.NET.Sdk">

  <PropertyGroup>
    <IsAspireSharedProject>true</IsAspireSharedProject>
  </PropertyGroup>

  <ItemGroup>
    <FrameworkReference Include="Microsoft.AspNetCore.App" />
  </ItemGroup>

  <ItemGroup>
    <PackageReference Include="Microsoft.Extensions.Http.Resilience" />
    <PackageReference Include="Microsoft.Extensions.ServiceDiscovery" />
    <PackageReference Include="OpenTelemetry.Exporter.OpenTelemetryProtocol" />
    <PackageReference Include="OpenTelemetry.Extensions.Hosting" />
    <PackageReference Include="OpenTelemetry.Instrumentation.AspNetCore" />
    <PackageReference Include="OpenTelemetry.Instrumentation.Http" />
    <PackageReference Include="OpenTelemetry.Instrumentation.Runtime" />
  </ItemGroup>

</Project>
```

`src/Ecommerce.ServiceDefaults/Extensions.cs` is not touched.

Run:

```bash
dotnet build tests/Ecommerce.ApiDefaults.Tests/Ecommerce.ApiDefaults.Tests.csproj
dotnet test --project tests/Ecommerce.ApiDefaults.Tests/Ecommerce.ApiDefaults.Tests.csproj
```

Expected: the build ends with `0 Warning(s)` and `0 Error(s)` for the three projects it compiles (ServiceDefaults, ApiDefaults, ApiDefaults.Tests); the test run prints `total: 32`, `failed: 0`, `succeeded: 32`. That is the same 32 tests the old project had.

- [ ] **Step 4: Delete the old test project and confirm what is left**

```bash
rm -r tests/Ecommerce.ServiceDefaults.Tests
ls src/Ecommerce.ServiceDefaults
ls src/Ecommerce.ApiDefaults
ls tests/Ecommerce.ApiDefaults.Tests
grep -rn "ServiceDefaults.Api\|ServiceDefaults.Tests" src tests --include='*.cs' --include='*.csproj' | grep -v '/obj/' | grep -v '/bin/'
```

Expected: ServiceDefaults lists `Ecommerce.ServiceDefaults.csproj`, `Extensions.cs`, `bin` and `obj`; ApiDefaults lists its project file, the seven source files, `bin` and `obj`; the test folder lists its project file, the six test files, `bin` and `obj`. The `grep` prints only the `using Ecommerce.ServiceDefaults.Api;` lines of the 33 consumer files that task 9.1.2 re-points, and nothing from `src/Ecommerce.ApiDefaults`, `src/Ecommerce.ServiceDefaults` or `tests/Ecommerce.ApiDefaults.Tests`.

Do not run the full solution build in this task; the six web projects fail to compile until task 9.1.2, which is expected. Report the file lists, the failing build output from step 2, and the passing build and test output from step 3.

### Task 9.1.2: Re-point every web project and test project to `Ecommerce.ApiDefaults`

**Files:**
- Modify: `src/Ecommerce.Gateway/Ecommerce.Gateway.csproj`
- Modify: `src/Ecommerce.Catalog.Api/Ecommerce.Catalog.Api.csproj`
- Modify: `src/Ecommerce.Basket.Api/Ecommerce.Basket.Api.csproj`
- Modify: `src/Ecommerce.Ordering.Api/Ecommerce.Ordering.Api.csproj`
- Modify: `src/Ecommerce.Payment.Api/Ecommerce.Payment.Api.csproj`
- Modify: `src/Ecommerce.Preferences.Api/Ecommerce.Preferences.Api.csproj`
- Modify (one `using` line each): `src/Ecommerce.Basket.Api/Features/BasketService.cs`
- Modify: `src/Ecommerce.Basket.Api/Features/Checkout/CheckoutEndpoint.cs`
- Modify: `src/Ecommerce.Basket.Api/Features/Checkout/CheckoutService.cs`
- Modify: `src/Ecommerce.Basket.Api/Features/GetBasket/GetBasketEndpoint.cs`
- Modify: `src/Ecommerce.Basket.Api/Features/RemoveItem/RemoveItemEndpoint.cs`
- Modify: `src/Ecommerce.Basket.Api/Features/UpsertItem/UpsertItemEndpoint.cs`
- Modify: `src/Ecommerce.Basket.Api/Infrastructure/CatalogClient.cs`
- Modify: `src/Ecommerce.Basket.Api/Program.cs`
- Modify: `src/Ecommerce.Catalog.Api/Features/GetProduct/GetProductEndpoint.cs`
- Modify: `src/Ecommerce.Catalog.Api/Features/ListProducts/ListProductsEndpoint.cs`
- Modify: `src/Ecommerce.Catalog.Api/Program.cs`
- Modify: `src/Ecommerce.Gateway/Program.cs`
- Modify: `src/Ecommerce.Ordering.Api/Features/GetOrder/GetOrderEndpoint.cs`
- Modify: `src/Ecommerce.Ordering.Api/Features/ListOrders/ListOrdersEndpoint.cs`
- Modify: `src/Ecommerce.Ordering.Api/Infrastructure/PaymentClient.cs`
- Modify: `src/Ecommerce.Ordering.Api/Program.cs`
- Modify: `src/Ecommerce.Payment.Api/Features/Authorize/AuthorizeEndpoint.cs`
- Modify: `src/Ecommerce.Payment.Api/Program.cs`
- Modify: `src/Ecommerce.Preferences.Api/Features/GetPreferences/GetPreferencesEndpoint.cs`
- Modify: `src/Ecommerce.Preferences.Api/Features/PreferencesService.cs`
- Modify: `src/Ecommerce.Preferences.Api/Features/UpdatePreferences/UpdatePreferencesEndpoint.cs`
- Modify: `src/Ecommerce.Preferences.Api/Program.cs`
- Modify: `tests/Ecommerce.Basket.Api.Tests/Features/BasketServiceTests.cs`
- Modify: `tests/Ecommerce.Basket.Api.Tests/Features/CheckoutEndpointTests.cs`
- Modify: `tests/Ecommerce.Basket.Api.Tests/Features/CheckoutServiceTests.cs`
- Modify: `tests/Ecommerce.Basket.Api.Tests/Features/GetBasketEndpointTests.cs`
- Modify: `tests/Ecommerce.Basket.Api.Tests/Features/RemoveItemEndpointTests.cs`
- Modify: `tests/Ecommerce.Basket.Api.Tests/Features/UpsertItemEndpointTests.cs`
- Modify: `tests/Ecommerce.Catalog.Api.Tests/Features/GetProductEndpointTests.cs`
- Modify: `tests/Ecommerce.Ordering.Api.Tests/Features/OrderEndpointsTests.cs`
- Modify: `tests/Ecommerce.Preferences.Api.Tests/Features/GetPreferencesEndpointTests.cs`
- Modify: `tests/Ecommerce.Preferences.Api.Tests/Features/PreferencesServiceTests.cs`
- Modify: `tests/Ecommerce.Preferences.Api.Tests/Features/UpdatePreferencesEndpointTests.cs`
- Modify (one string literal, added after the 9.1.1 review): `tests/Ecommerce.ApiDefaults.Tests/ApiResponseTests.cs`

**Interfaces:**
- Consumes: the namespace `Ecommerce.ApiDefaults` from task 9.1.1, whose types and members are identical to the old `Ecommerce.ServiceDefaults.Api`.
- Produces: a warning-free solution build and a green full `dotnet test` with 154 tests; no source file anywhere mentions `Ecommerce.ServiceDefaults.Api`.

- [ ] **Step 1: See the solution fail to build**

```bash
dotnet build 2>&1 | grep -E "error|Warning\(s\)|Error\(s\)" | sort -u | head -n 20
```

Expected: `error CS0234: The type or namespace name 'ServiceDefaults' does not exist in the namespace 'Ecommerce'` from the six web projects, because no assembly declares that namespace any more (the template's `Extensions.cs` lives in `Microsoft.Extensions.Hosting`), plus follow-on `CS0246` errors for the envelope types, and a non-zero error count. That is the failing run for this task.

- [ ] **Step 2: Add the project reference to the six web projects**

Add one `ProjectReference` line to each project file, placed alphabetically before the `Ecommerce.Contracts` or `Ecommerce.ServiceDefaults` line, and keep the existing references.

`src/Ecommerce.Gateway/Ecommerce.Gateway.csproj` becomes:

```xml
<Project Sdk="Microsoft.NET.Sdk.Web">

  <ItemGroup>
    <PackageReference Include="Yarp.ReverseProxy" />
    <PackageReference Include="Microsoft.Extensions.ServiceDiscovery.Yarp" />
  </ItemGroup>

  <ItemGroup>
    <ProjectReference Include="../Ecommerce.ApiDefaults/Ecommerce.ApiDefaults.csproj" />
    <ProjectReference Include="../Ecommerce.ServiceDefaults/Ecommerce.ServiceDefaults.csproj" />
  </ItemGroup>

</Project>
```

`src/Ecommerce.Basket.Api/Ecommerce.Basket.Api.csproj` becomes:

```xml
<Project Sdk="Microsoft.NET.Sdk.Web">

  <ItemGroup>
    <PackageReference Include="Aspire.StackExchange.Redis" />
    <PackageReference Include="Microsoft.AspNetCore.HeaderPropagation" />
    <PackageReference Include="WolverineFx" />
    <PackageReference Include="WolverineFx.RabbitMQ" />
    <PackageReference Include="WolverineFx.RuntimeCompilation" />
    <PackageReference Include="WolverineFx.Postgresql" />
  </ItemGroup>

  <ItemGroup>
    <ProjectReference Include="../Ecommerce.ApiDefaults/Ecommerce.ApiDefaults.csproj" />
    <ProjectReference Include="../Ecommerce.Contracts/Ecommerce.Contracts.csproj" />
    <ProjectReference Include="../Ecommerce.ServiceDefaults/Ecommerce.ServiceDefaults.csproj" />
  </ItemGroup>

</Project>
```

In `Ecommerce.Catalog.Api.csproj`, `Ecommerce.Ordering.Api.csproj`, `Ecommerce.Payment.Api.csproj` and `Ecommerce.Preferences.Api.csproj`, insert the same line

```xml
    <ProjectReference Include="../Ecommerce.ApiDefaults/Ecommerce.ApiDefaults.csproj" />
```

as the first line of the existing `ProjectReference` item group. Change nothing else in those files.

- [ ] **Step 3: Replace the using line in the 33 source and test files**

The replacement must keep each using block sorted, and `Ecommerce.ApiDefaults` sorts before every other `Ecommerce.` namespace. In 26 of the files the old line is not the first `Ecommerce.` using, so a plain in-place substitution would leave the block out of order. Run this script from the repository root; it removes the old line and inserts the new one before the first `using` that sorts after it, skipping `System` usings, or at the old position when no such line exists:

```bash
python3 - <<'PY'
from pathlib import Path

files = """
src/Ecommerce.Basket.Api/Features/BasketService.cs
src/Ecommerce.Basket.Api/Features/Checkout/CheckoutEndpoint.cs
src/Ecommerce.Basket.Api/Features/Checkout/CheckoutService.cs
src/Ecommerce.Basket.Api/Features/GetBasket/GetBasketEndpoint.cs
src/Ecommerce.Basket.Api/Features/RemoveItem/RemoveItemEndpoint.cs
src/Ecommerce.Basket.Api/Features/UpsertItem/UpsertItemEndpoint.cs
src/Ecommerce.Basket.Api/Infrastructure/CatalogClient.cs
src/Ecommerce.Basket.Api/Program.cs
src/Ecommerce.Catalog.Api/Features/GetProduct/GetProductEndpoint.cs
src/Ecommerce.Catalog.Api/Features/ListProducts/ListProductsEndpoint.cs
src/Ecommerce.Catalog.Api/Program.cs
src/Ecommerce.Gateway/Program.cs
src/Ecommerce.Ordering.Api/Features/GetOrder/GetOrderEndpoint.cs
src/Ecommerce.Ordering.Api/Features/ListOrders/ListOrdersEndpoint.cs
src/Ecommerce.Ordering.Api/Infrastructure/PaymentClient.cs
src/Ecommerce.Ordering.Api/Program.cs
src/Ecommerce.Payment.Api/Features/Authorize/AuthorizeEndpoint.cs
src/Ecommerce.Payment.Api/Program.cs
src/Ecommerce.Preferences.Api/Features/GetPreferences/GetPreferencesEndpoint.cs
src/Ecommerce.Preferences.Api/Features/PreferencesService.cs
src/Ecommerce.Preferences.Api/Features/UpdatePreferences/UpdatePreferencesEndpoint.cs
src/Ecommerce.Preferences.Api/Program.cs
tests/Ecommerce.Basket.Api.Tests/Features/BasketServiceTests.cs
tests/Ecommerce.Basket.Api.Tests/Features/CheckoutEndpointTests.cs
tests/Ecommerce.Basket.Api.Tests/Features/CheckoutServiceTests.cs
tests/Ecommerce.Basket.Api.Tests/Features/GetBasketEndpointTests.cs
tests/Ecommerce.Basket.Api.Tests/Features/RemoveItemEndpointTests.cs
tests/Ecommerce.Basket.Api.Tests/Features/UpsertItemEndpointTests.cs
tests/Ecommerce.Catalog.Api.Tests/Features/GetProductEndpointTests.cs
tests/Ecommerce.Ordering.Api.Tests/Features/OrderEndpointsTests.cs
tests/Ecommerce.Preferences.Api.Tests/Features/GetPreferencesEndpointTests.cs
tests/Ecommerce.Preferences.Api.Tests/Features/PreferencesServiceTests.cs
tests/Ecommerce.Preferences.Api.Tests/Features/UpdatePreferencesEndpointTests.cs
""".split()

old = "using Ecommerce.ServiceDefaults.Api;\n"
new = "using Ecommerce.ApiDefaults;\n"

for name in files:
    path = Path(name)
    lines = path.read_text().splitlines(keepends=True)
    if lines.count(old) != 1:
        raise SystemExit(f"expected exactly one old using in {name}")
    position = lines.index(old)
    del lines[position]
    target = position
    for index, line in enumerate(lines):
        if not line.startswith("using "):
            if index >= position:
                break
            continue
        if line.startswith("using System"):
            continue
        if line > new:
            target = index
            break
    lines.insert(target, new)
    path.write_text("".join(lines))
    print(f"{name}: using at line {target + 1}")
PY
grep -rn "ServiceDefaults.Api" src tests --include='*.cs' | grep -v '/obj/'
```

Expected: 33 lines of `<file>: using at line N` and an empty `grep`. Spot-check three files; they must read:

`src/Ecommerce.Basket.Api/Features/Checkout/CheckoutEndpoint.cs`:

```csharp
using System.ComponentModel.DataAnnotations;
using Ecommerce.ApiDefaults;
using Ecommerce.Contracts;
using Microsoft.AspNetCore.Http.HttpResults;
```

`src/Ecommerce.Basket.Api/Program.cs`:

```csharp
using Ecommerce.ApiDefaults;
using Ecommerce.Basket.Api.Features;
using Ecommerce.Basket.Api.Features.Checkout;
using Ecommerce.Basket.Api.Features.GetBasket;
using Ecommerce.Basket.Api.Features.RemoveItem;
using Ecommerce.Basket.Api.Features.UpsertItem;
using Ecommerce.Basket.Api.Infrastructure;
using Ecommerce.Contracts;
using JasperFx;
using Wolverine;
using Wolverine.Postgresql;
using Wolverine.RabbitMQ;
```

`src/Ecommerce.Gateway/Program.cs` starts with `using Ecommerce.ApiDefaults;` as its only using. If a file does not match this pattern, fix that file by hand so `using Ecommerce.ApiDefaults;` is the first `Ecommerce.` using after any `System` usings, and report it.

- [ ] **Step 4: Rename the activity source in the moved envelope test**

Task 9.1.1 moved `tests/Ecommerce.ApiDefaults.Tests/ApiResponseTests.cs` and its review found one string literal that still names the old test assembly. In the test `Fail_WithCurrentActivity_SetsTraceIdFromActivity`, change the line

```csharp
        using var source = new ActivitySource("Ecommerce.ServiceDefaults.Tests");
```

to

```csharp
        using var source = new ActivitySource("Ecommerce.ApiDefaults.Tests");
```

Nothing else in that file changes; the listener in that test accepts every source, so the name has no effect on the assertion. After this, `grep -rn "ServiceDefaults.Api\|ServiceDefaults.Tests" src tests --include='*.cs' --include='*.csproj' | grep -v '/obj/' | grep -v '/bin/'` prints nothing.

- [ ] **Step 5: Full build and full test run**

```bash
source "$HOME/.nvm/nvm.sh" && nvm use 24
dotnet build
dotnet test
```

Expected: the build ends with `0 Warning(s)` and `0 Error(s)`; the test run ends with `total: 154`, `failed: 0`, `succeeded: 154` (32 ApiDefaults, the rest unchanged). The integration tests boot the AppHost, so this takes about a minute and needs Docker. Report the two summary lines verbatim.

---

## Sub-phase 9.2 Documentation (lead)

Done by the lead after task 9.1.2 passes review. The agent does not touch these files.

- `docs/ARCHITECTURE.md`: section 3 tree (ServiceDefaults becomes "Aspire service defaults from the template"; add `Ecommerce.ApiDefaults/` and `Ecommerce.ApiDefaults.Tests/`, remove `Ecommerce.ServiceDefaults.Tests/`), section 3 project references table (every web project references ServiceDefaults and ApiDefaults; ApiDefaults references ServiceDefaults; add the Preferences row that was missing), section 7.1 (drop the "same assembly" paragraph in favor of a pointer to 7.2), section 7.2 (the code now lives in `Ecommerce.ApiDefaults`), section 8 test table row, section 9 dependency table rows for `Microsoft.AspNetCore.OpenApi` and `Scalar.AspNetCore`, and the decision log row about shared API code.
- `docs/CODING_GUIDELINES.md`: the three mentions of `Ecommerce.ServiceDefaults.Api` and of the writer being "registered in ServiceDefaults" now name `Ecommerce.ApiDefaults`.
- `docs/plans/README.md`: phase 9 row in the phases table and its sub-phase list.
- `docs/plans/STATUS.md` and `docs/plans/SUMMARY.md`: per protocol.
- Root `README.md`: no change expected; verify with `grep -n "ServiceDefaults" README.md`.

## Sub-phase 9.3 Acceptance (lead)

Run by the lead after 9.2. The AppHost started from Rider must be stopped first, because `aspire start` uses the same launch profile ports.

```bash
export PATH="$PATH:$HOME/.dotnet/tools"
source "$HOME/.nvm/nvm.sh" && nvm use 24
grep -rn "ServiceDefaults.Api\|ServiceDefaults.Tests" src tests docs README.md --include='*.cs' --include='*.csproj' --include='*.md' --include='*.slnx' | grep -v '/obj/' | grep -v '/bin/' | grep -v 'docs/plans/'   # nothing
T=/private/tmp/claude-501/-Users-goran-Projects-Private-ECommerceAspireDemo/3cde809c-a763-4b48-862b-d20a347042ec/scratchpad/template
dotnet new aspire-servicedefaults -n Ecommerce.ServiceDefaults -o $T --force
diff $T/Extensions.cs src/Ecommerce.ServiceDefaults/Extensions.cs                # only the two Wolverine lines
dotnet build
dotnet test
AH=src/Ecommerce.AppHost/Ecommerce.AppHost.csproj
aspire start --apphost $AH --non-interactive --format Json
for r in catalog-api basket-api ordering-api payment-api preferences-api frontend gateway; do aspire wait $r --status healthy --timeout 300 --apphost $AH --non-interactive; done
G=http://localhost:5100/api
CT="content-type: application/json"
MUG=a0000000-0000-4000-8000-000000000001
B1="X-Buyer-Id: b0000000-0000-4000-8000-000000000091"
BODY='{"buyer":{"name":"Goran","email":"goran@example.com"},"shippingAddress":{"street":"Main Street 1","city":"Belgrade","postalCode":"11000","country":"Serbia"},"card":{"number":"4242424242424242","holderName":"Goran"}}'
curl -s $G/catalog/products | head -c 80                                          # {"success":true,"data":[
curl -s $G/basket | head -c 120                                                   # success false, common.buyer_id_invalid
curl -s -H "X-Buyer-Id: not-a-guid" $G/orders | head -c 120                       # success false, common.buyer_id_invalid
curl -s $G/nothing | head -c 120                                                  # success false, common.not_found
curl -s -H "$CT" -X POST -d '{}' $G/basket/checkout -H "$B1" | head -c 120        # success false, common.validation_failed
C=$(aspire describe catalog-api --apphost $AH --non-interactive --format Json | grep -o '"url": "http://localhost:[0-9]*"' | head -1 | cut -d'"' -f4)
curl -s -o /dev/null -w "%{http_code}\n" $C/scalar                               # 200
curl -s -H "$B1" -H "$CT" -X PUT -d "{\"productId\":\"$MUG\",\"quantity\":1}" -o /dev/null $G/basket/items
curl -s -H "$B1" -H "$CT" -X POST -d "$BODY" $G/basket/checkout                   # 202 envelope with orderId
sleep 12; curl -s -H "$B1" $G/orders | grep -o '"status":"[^"]*"'                 # Shipped
curl -s $G/catalog/products/$MUG | grep -o '"availableStock":[0-9]*'              # 24
for r in catalog-api basket-api ordering-api payment-api preferences-api gateway frontend; do aspire logs $r --apphost $AH --non-interactive | sed 's/\x1b\[[0-9;]*m//g' | grep -E "warn:|fail:" | sed "s/^/$r: /"; done
aspire stop --apphost $AH --non-interactive
```

Expected: the leftover `grep` empty, the template diff limited to the `.AddMeter("Wolverine*")` and `.AddSource("Wolverine")` lines, `0 Warning(s)`, 154 .NET tests, seven healthy, every error response still in the envelope with the codes as commented, Scalar served, the purchase shipped with stock 25 to 24, the sweep empty, the AppHost stopped with no containers left. The frontend is untouched by this phase, so its checks are not rerun.
