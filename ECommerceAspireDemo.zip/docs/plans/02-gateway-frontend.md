# Phase 2 Gateway and Frontend Shell Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** One public entry point. A YARP gateway resolves backend services by Aspire resource name and serves the Angular application, and the Angular application shows the product catalog with the agreed header, footer and theme.

**Architecture:** `Ecommerce.Gateway` is a .NET project running YARP with the Aspire service discovery destination resolver and the shared envelope error handling; it routes `/api/catalog/*` to `catalog-api`, answers 404 for any other `/api/*` path, and forwards everything else to the Angular dev server, WebSocket upgrades included. `ecommerce-frontend` is an Angular 22 workspace with standalone components, signals, zoneless change detection, Angular Material themed by hand, a buyer identity kept in local storage and sent as `X-Buyer-Id`, a response helper for the envelope, and a products page fed by `httpResource`. The AppHost starts the Angular dev server through `AddViteApp` and gives the gateway references to both `catalog-api` and `frontend`.

**Tech Stack:** Yarp.ReverseProxy 2.3.0, Microsoft.Extensions.ServiceDiscovery.Yarp 10.10.0, Aspire.Hosting.JavaScript 13.5.3, Angular 22.1 with Angular Material 22.1 and CDK, angular-eslint 22, Prettier 3, Vitest 4, Node 24 through nvm.

**Spec:** `docs/ARCHITECTURE.md` sections 2, 4.1, 4.7 and 6; `docs/CODING_GUIDELINES.md` sections 2.5, 2.6 and 6.

**Agents and ordering:** `backend-dev` runs sub-phase 2.1, `frontend-dev` runs sub-phases 2.2 to 2.4. They run in parallel with one dependency: task 2.1.3 (AppHost wiring) needs the frontend workspace from task 2.2.1 to exist, so the lead sends 2.1.3 only after 2.2.1 is accepted. Sub-phase 2.5 is the lead's acceptance.

## Global Constraints

- Everything from `docs/plans/README.md` Global constraints applies.
- New NuGet packages in this phase, all MIT: `Yarp.ReverseProxy` 2.3.0, `Microsoft.Extensions.ServiceDiscovery.Yarp` 10.10.0, `Aspire.Hosting.JavaScript` 13.5.3. Add nothing else.
- New npm packages in this phase, all MIT: `@angular/material` 22, `@angular/cdk` 22, and whatever `ng add angular-eslint` installs (`angular-eslint`, `eslint`, `typescript-eslint`, `@eslint/js`). Add nothing else. Everything else the Angular CLI generates (Prettier, Vitest, jsdom) is already MIT.
- Frontend commands run inside `src/ecommerce-frontend` after `source "$HOME/.nvm/nvm.sh" && nvm use`, which selects Node 24 from `.nvmrc`.
- No external fonts, icons, images or CDN links anywhere in the frontend. The demo must run offline.
- Frontend files follow CODING_GUIDELINES.md section 6: 2025 file naming without type suffixes, `inject()`, `input()`, signals, `OnPush`, new control flow, Prettier formatting with single quotes and 100 columns.
- Every frontend task ends with `npm run build`, `npm run lint`, `npm test` and `npm run format:check` all passing.
- Gateway routes for basket and orders are not added in this phase; they arrive with their services.

---

## Sub-phase 2.1 Gateway (backend-dev)

### Task 2.1.1: Error handling split and upstream error code in ServiceDefaults, test-first

**Files:**
- Modify: `tests/Ecommerce.ServiceDefaults.Tests/Api/ApiEnvelopeProblemDetailsWriterTests.cs`
- Modify: `tests/Ecommerce.ServiceDefaults.Tests/Api/ApiDefaultsExtensionsTests.cs`
- Modify: `src/Ecommerce.ServiceDefaults/Api/CommonErrorCodes.cs`
- Modify: `src/Ecommerce.ServiceDefaults/Api/ApiEnvelopeProblemDetailsWriter.cs`
- Modify: `src/Ecommerce.ServiceDefaults/Api/ApiDefaultsExtensions.cs`

**Interfaces:**
- Consumes: the phase 0 envelope types.
- Produces: `CommonErrorCodes.UpstreamUnavailable = "common.upstream_unavailable"`, used for 502, 503 and 504 problem responses with the message `An upstream service is unavailable`; and two new extension methods, `AddApiErrorHandling()` (envelope writer plus problem details, no OpenAPI) and `UseApiErrorHandling()` (exception handler plus status code pages, no health endpoints, no Scalar). `AddApiDefaults()` and `UseApiDefaults()` keep their behavior and now call the new methods internally, so Catalog does not change.

- [ ] **Step 1: Replace the two test files with their new content**

`tests/Ecommerce.ServiceDefaults.Tests/Api/ApiEnvelopeProblemDetailsWriterTests.cs` gains a theory for the gateway statuses; the whole file is:

```csharp
using System.Text.Json;
using Ecommerce.ServiceDefaults.Api;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Ecommerce.ServiceDefaults.Tests.Api;

public sealed class ApiEnvelopeProblemDetailsWriterTests
{
    [Fact]
    public void CanWrite_AlwaysReturnsTrue()
    {
        var writer = new ApiEnvelopeProblemDetailsWriter();
        var context = new ProblemDetailsContext
        {
            HttpContext = new DefaultHttpContext(),
            ProblemDetails = new ProblemDetails { Status = 418 },
        };

        Assert.True(writer.CanWrite(context));
    }

    [Fact]
    public async Task WriteAsync_WithValidationProblem_WritesValidationFailedEnvelopeWithFieldErrors()
    {
        var errors = new Dictionary<string, string[]> { ["Name"] = ["The Name field is required."] };
        var problem = new HttpValidationProblemDetails(errors) { Status = StatusCodes.Status400BadRequest };

        var (status, root) = await WriteAsync(problem);

        Assert.Equal(400, status);
        Assert.False(root.GetProperty("success").GetBoolean());
        Assert.Equal(JsonValueKind.Null, root.GetProperty("data").ValueKind);
        var error = root.GetProperty("error");
        Assert.Equal("common.validation_failed", error.GetProperty("code").GetString());
        Assert.Equal("Request validation failed", error.GetProperty("message").GetString());
        Assert.Equal("The Name field is required.", error.GetProperty("details").GetProperty("Name")[0].GetString());
        Assert.False(string.IsNullOrEmpty(error.GetProperty("traceId").GetString()));
    }

    [Fact]
    public async Task WriteAsync_WithPlain400_WritesBadRequestEnvelope()
    {
        var problem = new ProblemDetails { Status = StatusCodes.Status400BadRequest };

        var (status, root) = await WriteAsync(problem);

        Assert.Equal(400, status);
        Assert.Equal("common.bad_request", root.GetProperty("error").GetProperty("code").GetString());
        Assert.Equal("The request could not be read", root.GetProperty("error").GetProperty("message").GetString());
    }

    [Fact]
    public async Task WriteAsync_With404_WritesNotFoundEnvelopeNamingThePath()
    {
        var problem = new ProblemDetails { Status = StatusCodes.Status404NotFound };

        var (status, root) = await WriteAsync(problem, "/api/nope");

        Assert.Equal(404, status);
        Assert.Equal("common.not_found", root.GetProperty("error").GetProperty("code").GetString());
        Assert.Equal("No endpoint matches [/api/nope]", root.GetProperty("error").GetProperty("message").GetString());
    }

    [Fact]
    public async Task WriteAsync_With500_WritesInternalErrorEnvelope()
    {
        var problem = new ProblemDetails { Status = StatusCodes.Status500InternalServerError };

        var (status, root) = await WriteAsync(problem);

        Assert.Equal(500, status);
        Assert.Equal("common.internal_error", root.GetProperty("error").GetProperty("code").GetString());
        Assert.Equal("An unexpected error occurred", root.GetProperty("error").GetProperty("message").GetString());
    }

    [Theory]
    [InlineData(502)]
    [InlineData(503)]
    [InlineData(504)]
    public async Task WriteAsync_WithGatewayStatus_WritesUpstreamUnavailableEnvelope(int gatewayStatus)
    {
        var problem = new ProblemDetails { Status = gatewayStatus };

        var (status, root) = await WriteAsync(problem);

        Assert.Equal(gatewayStatus, status);
        Assert.Equal("common.upstream_unavailable", root.GetProperty("error").GetProperty("code").GetString());
        Assert.Equal("An upstream service is unavailable", root.GetProperty("error").GetProperty("message").GetString());
    }

    [Fact]
    public async Task WriteAsync_WithoutStatus_UsesResponseStatusCode()
    {
        var problem = new ProblemDetails();

        var (status, root) = await WriteAsync(problem, responseStatus: StatusCodes.Status405MethodNotAllowed);

        Assert.Equal(405, status);
        Assert.Equal("common.method_not_allowed", root.GetProperty("error").GetProperty("code").GetString());
    }

    [Fact]
    public async Task WriteAsync_WithUnmappedStatus_UsesGenericCodeAndTrimsTitle()
    {
        var problem = new ProblemDetails { Status = 418, Title = "I am a teapot." };

        var (status, root) = await WriteAsync(problem);

        Assert.Equal(418, status);
        Assert.Equal("common.http_418", root.GetProperty("error").GetProperty("code").GetString());
        Assert.Equal("I am a teapot", root.GetProperty("error").GetProperty("message").GetString());
    }

    [Fact]
    public async Task WriteAsync_WithCodeExtension_PrefersThatCode()
    {
        var problem = new ProblemDetails { Status = 409, Detail = "Basket is empty" };
        problem.Extensions["code"] = "basket.checkout_empty";

        var (status, root) = await WriteAsync(problem);

        Assert.Equal(409, status);
        Assert.Equal("basket.checkout_empty", root.GetProperty("error").GetProperty("code").GetString());
        Assert.Equal("Basket is empty", root.GetProperty("error").GetProperty("message").GetString());
    }

    private static async Task<(int Status, JsonElement Root)> WriteAsync(
        ProblemDetails problem,
        string path = "/api/test",
        int responseStatus = StatusCodes.Status200OK)
    {
        var http = new DefaultHttpContext();
        http.Request.Path = path;
        http.Response.StatusCode = responseStatus;
        http.Response.Body = new MemoryStream();
        var writer = new ApiEnvelopeProblemDetailsWriter();

        await writer.WriteAsync(new ProblemDetailsContext { HttpContext = http, ProblemDetails = problem });

        http.Response.Body.Position = 0;
        using var document = await JsonDocument.ParseAsync(
            http.Response.Body,
            cancellationToken: TestContext.Current.CancellationToken);
        return (http.Response.StatusCode, document.RootElement.Clone());
    }
}
```

`tests/Ecommerce.ServiceDefaults.Tests/Api/ApiDefaultsExtensionsTests.cs` gains a test for the new registration method; the whole file is:

```csharp
using Ecommerce.ServiceDefaults.Api;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;

namespace Ecommerce.ServiceDefaults.Tests.Api;

public sealed class ApiDefaultsExtensionsTests
{
    [Fact]
    public void AddApiDefaults_RegistersEnvelopeWriterAheadOfTheFrameworkWriter()
    {
        var builder = WebApplication.CreateBuilder();
        builder.AddApiDefaults();
        using var app = builder.Build();

        var writers = app.Services.GetServices<IProblemDetailsWriter>().ToList();

        Assert.True(writers.Count >= 2);
        Assert.IsType<ApiEnvelopeProblemDetailsWriter>(writers[0]);
        Assert.NotNull(app.Services.GetService<IProblemDetailsService>());
    }

    [Fact]
    public void AddApiErrorHandling_RegistersEnvelopeWriterWithoutOpenApi()
    {
        var builder = WebApplication.CreateBuilder();
        builder.AddApiErrorHandling();
        using var app = builder.Build();

        var writers = app.Services.GetServices<IProblemDetailsWriter>().ToList();

        Assert.IsType<ApiEnvelopeProblemDetailsWriter>(writers[0]);
        Assert.NotNull(app.Services.GetService<IProblemDetailsService>());
    }
}
```

- [ ] **Step 2: Run the tests and confirm the failing state**

```bash
dotnet test --project tests/Ecommerce.ServiceDefaults.Tests
```

Expected: a compile error naming `AddApiErrorHandling` as missing on `WebApplicationBuilder`. The theory cannot run yet because of that error; it would fail on its own with `common.http_502` instead of `common.upstream_unavailable`.

- [ ] **Step 3: Replace the three source files**

`src/Ecommerce.ServiceDefaults/Api/CommonErrorCodes.cs`:

```csharp
namespace Ecommerce.ServiceDefaults.Api;

public static class CommonErrorCodes
{
    public const string ValidationFailed = "common.validation_failed";
    public const string BadRequest = "common.bad_request";
    public const string BuyerIdInvalid = "common.buyer_id_invalid";
    public const string NotFound = "common.not_found";
    public const string MethodNotAllowed = "common.method_not_allowed";
    public const string UnsupportedMediaType = "common.unsupported_media_type";
    public const string InternalError = "common.internal_error";
    public const string UpstreamUnavailable = "common.upstream_unavailable";
}
```

`src/Ecommerce.ServiceDefaults/Api/ApiEnvelopeProblemDetailsWriter.cs`:

```csharp
using System.Diagnostics;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Ecommerce.ServiceDefaults.Api;

// Converts every ProblemDetails the framework produces into the API response envelope
public sealed class ApiEnvelopeProblemDetailsWriter : IProblemDetailsWriter
{
    public bool CanWrite(ProblemDetailsContext context) => true;

    public ValueTask WriteAsync(ProblemDetailsContext context)
    {
        var http = context.HttpContext;
        var problem = context.ProblemDetails;
        var status = problem.Status ?? http.Response.StatusCode;
        http.Response.StatusCode = status;

        var code = ResolveCode(problem, status);
        var message = ResolveMessage(problem, status, http.Request.Path);
        var details = problem is HttpValidationProblemDetails validation ? validation.Errors : null;
        var traceId = Activity.Current?.Id ?? http.TraceIdentifier;
        var envelope = new ApiResponse(false, null, new ApiError(code, message, details, traceId));

        return new ValueTask(http.Response.WriteAsJsonAsync(envelope, http.RequestAborted));
    }

    private static string ResolveCode(ProblemDetails problem, int status)
    {
        if (problem.Extensions.TryGetValue("code", out var value) && value is string code)
        {
            return code;
        }

        return status switch
        {
            StatusCodes.Status400BadRequest when problem is HttpValidationProblemDetails => CommonErrorCodes.ValidationFailed,
            StatusCodes.Status400BadRequest => CommonErrorCodes.BadRequest,
            StatusCodes.Status404NotFound => CommonErrorCodes.NotFound,
            StatusCodes.Status405MethodNotAllowed => CommonErrorCodes.MethodNotAllowed,
            StatusCodes.Status415UnsupportedMediaType => CommonErrorCodes.UnsupportedMediaType,
            StatusCodes.Status500InternalServerError => CommonErrorCodes.InternalError,
            StatusCodes.Status502BadGateway or StatusCodes.Status503ServiceUnavailable or StatusCodes.Status504GatewayTimeout => CommonErrorCodes.UpstreamUnavailable,
            _ => $"common.http_{status}",
        };
    }

    private static string ResolveMessage(ProblemDetails problem, int status, PathString path)
    {
        if (!string.IsNullOrWhiteSpace(problem.Detail))
        {
            return TrimFullStop(problem.Detail);
        }

        return status switch
        {
            StatusCodes.Status400BadRequest when problem is HttpValidationProblemDetails => "Request validation failed",
            StatusCodes.Status400BadRequest => "The request could not be read",
            StatusCodes.Status404NotFound => $"No endpoint matches [{path}]",
            StatusCodes.Status500InternalServerError => "An unexpected error occurred",
            StatusCodes.Status502BadGateway or StatusCodes.Status503ServiceUnavailable or StatusCodes.Status504GatewayTimeout => "An upstream service is unavailable",
            _ => TrimFullStop(problem.Title ?? $"Request failed with status [{status}]"),
        };
    }

    private static string TrimFullStop(string text) => text.TrimEnd('.');
}
```

`src/Ecommerce.ServiceDefaults/Api/ApiDefaultsExtensions.cs`:

```csharp
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.Hosting;
using Scalar.AspNetCore;

namespace Ecommerce.ServiceDefaults.Api;

public static class ApiDefaultsExtensions
{
    // The envelope writer must be registered before AddProblemDetails so it is asked first
    public static TBuilder AddApiErrorHandling<TBuilder>(this TBuilder builder) where TBuilder : IHostApplicationBuilder
    {
        builder.Services.TryAddEnumerable(ServiceDescriptor.Singleton<IProblemDetailsWriter, ApiEnvelopeProblemDetailsWriter>());
        builder.Services.AddProblemDetails();

        return builder;
    }

    public static TBuilder AddApiDefaults<TBuilder>(this TBuilder builder) where TBuilder : IHostApplicationBuilder
    {
        builder.AddApiErrorHandling();
        builder.Services.AddOpenApi();

        return builder;
    }

    public static WebApplication UseApiErrorHandling(this WebApplication app)
    {
        app.UseExceptionHandler(new ExceptionHandlerOptions
        {
            StatusCodeSelector = exception => exception is BadHttpRequestException badRequest
                ? badRequest.StatusCode
                : StatusCodes.Status500InternalServerError,
        });
        app.UseStatusCodePages();

        return app;
    }

    public static WebApplication UseApiDefaults(this WebApplication app)
    {
        app.UseApiErrorHandling();
        app.MapDefaultEndpoints();

        if (app.Environment.IsDevelopment())
        {
            app.MapOpenApi();
            app.MapScalarApiReference();
        }

        return app;
    }
}
```

- [ ] **Step 4: Run every test and build**

```bash
dotnet test
dotnet build
```

Expected: 26 ServiceDefaults tests and 22 Catalog tests pass, 48 in total, and the build reports `0 Warning(s)`.

### Task 2.1.2: Gateway project

**Files:**
- Modify: `Directory.Packages.props`
- Create: `src/Ecommerce.Gateway/Ecommerce.Gateway.csproj`
- Create: `src/Ecommerce.Gateway/Program.cs`
- Create: `src/Ecommerce.Gateway/appsettings.json`
- Create: `src/Ecommerce.Gateway/appsettings.Development.json`
- Create: `src/Ecommerce.Gateway/Properties/launchSettings.json`

**Interfaces:**
- Consumes: `AddServiceDefaults()`, `MapDefaultEndpoints()`, `AddApiErrorHandling()`, `UseApiErrorHandling()`.
- Produces: the `gateway` resource on `https://localhost:7100` and `http://localhost:5100` with route `catalog` (order 0) to cluster `catalog` at `https+http://catalog-api`, route `frontend` (order 1000) to cluster `frontend` at `http://frontend`, and a gateway endpoint on `/api/{**rest}` answering 404. Later phases add routes `basket` and `orders` with order 0 next to `catalog`.

- [ ] **Step 1: Add the package versions**

In `Directory.Packages.props`, add a new group directly before the `Catalog` group:

```xml
  <ItemGroup Label="Gateway">
    <PackageVersion Include="Yarp.ReverseProxy" Version="2.3.0" />
    <PackageVersion Include="Microsoft.Extensions.ServiceDiscovery.Yarp" Version="10.10.0" />
  </ItemGroup>
```

- [ ] **Step 2: Create the project files by hand**

No template is used; the five files are small. Create the folders `src/Ecommerce.Gateway` and `src/Ecommerce.Gateway/Properties`.

`src/Ecommerce.Gateway/Ecommerce.Gateway.csproj`:

```xml
<Project Sdk="Microsoft.NET.Sdk.Web">

  <ItemGroup>
    <PackageReference Include="Yarp.ReverseProxy" />
    <PackageReference Include="Microsoft.Extensions.ServiceDiscovery.Yarp" />
  </ItemGroup>

  <ItemGroup>
    <ProjectReference Include="../Ecommerce.ServiceDefaults/Ecommerce.ServiceDefaults.csproj" />
  </ItemGroup>

</Project>
```

`src/Ecommerce.Gateway/Program.cs`:

```csharp
using Ecommerce.ServiceDefaults.Api;

var builder = WebApplication.CreateBuilder(args);

builder.AddServiceDefaults();
builder.AddApiErrorHandling();
builder.Services.AddReverseProxy()
    .LoadFromConfig(builder.Configuration.GetSection("ReverseProxy"))
    .AddServiceDiscoveryDestinationResolver();

var app = builder.Build();

app.UseApiErrorHandling();
app.MapDefaultEndpoints();

// Unknown API paths get an envelope 404 instead of falling through to the frontend catch-all
app.Map("/api/{**rest}", () => TypedResults.NotFound());
app.MapReverseProxy();

app.Run();
```

`src/Ecommerce.Gateway/appsettings.json`. The catalog route has order 0 so that its more specific template beats the gateway's own `/api/{**rest}` endpoint, which also has order 0; the frontend catch-all has order 1000 so it only receives what nothing else matched. Endpoint routing compares order before template specificity, which is why these values matter.

```json
{
  "Logging": {
    "LogLevel": {
      "Default": "Information",
      "Microsoft.AspNetCore": "Warning",
      "Yarp": "Warning"
    }
  },
  "AllowedHosts": "*",
  "ReverseProxy": {
    "Routes": {
      "catalog": {
        "ClusterId": "catalog",
        "Order": 0,
        "Match": {
          "Path": "/api/catalog/{**catch-all}"
        }
      },
      "frontend": {
        "ClusterId": "frontend",
        "Order": 1000,
        "Match": {
          "Path": "/{**catch-all}"
        }
      }
    },
    "Clusters": {
      "catalog": {
        "Destinations": {
          "catalog-api": {
            "Address": "https+http://catalog-api"
          }
        }
      },
      "frontend": {
        "Destinations": {
          "frontend": {
            "Address": "http://frontend"
          }
        }
      }
    }
  }
}
```

`src/Ecommerce.Gateway/appsettings.Development.json`:

```json
{
  "Logging": {
    "LogLevel": {
      "Default": "Information",
      "Microsoft.AspNetCore": "Warning"
    }
  }
}
```

`src/Ecommerce.Gateway/Properties/launchSettings.json`:

```json
{
  "$schema": "https://json.schemastore.org/launchsettings.json",
  "profiles": {
    "https": {
      "commandName": "Project",
      "dotnetRunMessages": true,
      "launchBrowser": false,
      "applicationUrl": "https://localhost:7100;http://localhost:5100",
      "environmentVariables": {
        "ASPNETCORE_ENVIRONMENT": "Development"
      }
    },
    "http": {
      "commandName": "Project",
      "dotnetRunMessages": true,
      "launchBrowser": false,
      "applicationUrl": "http://localhost:5100",
      "environmentVariables": {
        "ASPNETCORE_ENVIRONMENT": "Development"
      }
    }
  }
}
```

- [ ] **Step 3: Add to the solution and build**

```bash
dotnet sln add src/Ecommerce.Gateway
dotnet build
```

Expected: `Build succeeded.` with `0 Warning(s)`.

- [ ] **Step 4: Smoke test the gateway standalone**

Without the AppHost no destination resolves, which is exactly what this check relies on.

```bash
dotnet run --project src/Ecommerce.Gateway --launch-profile http --no-build > /tmp/gateway-smoke.log 2>&1 &
GATEWAY_PID=$!
curl -s --retry 30 --retry-delay 1 --retry-connrefused -w ' [%{http_code}]\n' http://localhost:5100/health
curl -s -m 10 -w ' [%{http_code}]\n' http://localhost:5100/api/nope
curl -s -m 40 -w ' [%{http_code}]\n' http://localhost:5100/api/catalog/products
curl -s -m 40 -w ' [%{http_code}]\n' http://localhost:5100/
kill $GATEWAY_PID
```

Expected, in order: `Healthy [200]`; a 404 envelope with `"code":"common.not_found"` and message `No endpoint matches [/api/nope]`; a 502 envelope with `"code":"common.upstream_unavailable"` and message `An upstream service is unavailable`; the same 502 envelope for `/`. The log contains `warn: Yarp.ReverseProxy.Forwarder.HttpForwarder[48]` lines for the two failed forwards, which is YARP reporting the unreachable destinations and is expected here. Confirm with `pgrep -fl Ecommerce.Gateway` that nothing is left running.

### Task 2.1.3: AppHost wiring for the frontend and the gateway

Prerequisite: task 2.2.1 is accepted, so `src/ecommerce-frontend/package.json` exists. The lead sends this task only then.

**Files:**
- Modify: `Directory.Packages.props`
- Modify: `src/Ecommerce.AppHost/Ecommerce.AppHost.csproj`
- Modify: `src/Ecommerce.AppHost/AppHost.cs`

**Interfaces:**
- Consumes: the `catalogDb` variable and the `catalog-api` registration from phase 1.
- Produces: resources `frontend` (the Angular dev server, started by Aspire as `npm run dev -- --port <port>` with `PORT` also set, after an automatic `npm install` that shows up as the `frontend-installer` resource) and `gateway`, plus the `catalogApi` and `frontend` variables later phases reference.

- [ ] **Step 1: Add the hosting package version**

In `Directory.Packages.props`, add one line to the `Aspire hosting` group after the MongoDB line:

```xml
    <PackageVersion Include="Aspire.Hosting.JavaScript" Version="13.5.3" />
```

- [ ] **Step 2: Replace the AppHost project file**

```xml
<Project Sdk="Aspire.AppHost.Sdk/13.5.3">

  <PropertyGroup>
    <OutputType>Exe</OutputType>
    <AspireUseCliBundle>true</AspireUseCliBundle>
    <UserSecretsId>ecommerce-aspire-demo-apphost</UserSecretsId>
  </PropertyGroup>

  <ItemGroup>
    <PackageReference Include="Aspire.Hosting.PostgreSQL" />
    <PackageReference Include="Aspire.Hosting.Redis" />
    <PackageReference Include="Aspire.Hosting.RabbitMQ" />
    <PackageReference Include="Aspire.Hosting.MongoDB" />
    <PackageReference Include="Aspire.Hosting.JavaScript" />
  </ItemGroup>

  <ItemGroup>
    <ProjectReference Include="../Ecommerce.Catalog.Api/Ecommerce.Catalog.Api.csproj" />
    <ProjectReference Include="../Ecommerce.Gateway/Ecommerce.Gateway.csproj" />
  </ItemGroup>

</Project>
```

- [ ] **Step 3: Replace `AppHost.cs`**

The frontend path is relative to the AppHost project directory. The gateway waits for `catalog-api` but not for `frontend`: a dev server that is still starting simply yields a 502 envelope for a moment, and the products call retries on the page.

```csharp
var builder = DistributedApplication.CreateBuilder(args);

var postgres = builder.AddPostgres("postgres");
var catalogDb = postgres.AddDatabase("catalogdb");

var redis = builder.AddRedis("basket-cache");

var rabbitMq = builder.AddRabbitMQ("messaging")
    .WithManagementPlugin();

var mongo = builder.AddMongoDB("mongo");
var orderingDb = mongo.AddDatabase("orderingdb");

var catalogApi = builder.AddProject<Projects.Ecommerce_Catalog_Api>("catalog-api")
    .WithReference(catalogDb)
    .WaitFor(catalogDb)
    .WithHttpHealthCheck("/health");

var frontend = builder.AddViteApp("frontend", "../ecommerce-frontend");

builder.AddProject<Projects.Ecommerce_Gateway>("gateway")
    .WithReference(catalogApi)
    .WaitFor(catalogApi)
    .WithReference(frontend)
    .WithHttpHealthCheck("/health")
    .WithExternalHttpEndpoints();

builder.Build().Run();
```

- [ ] **Step 4: Build**

```bash
dotnet build
```

Expected: `Build succeeded.` with `0 Warning(s)`. Do not run the AppHost; the lead runs phase acceptance.

---

## Sub-phase 2.2 Angular workspace, theme and layout (frontend-dev)

### Task 2.2.1: Workspace and tooling

**Files:**
- Create: `src/ecommerce-frontend/` from the Angular CLI
- Create: `src/ecommerce-frontend/.nvmrc`
- Modify: `src/ecommerce-frontend/package.json` (scripts only)
- Modify by `ng add angular-eslint`: `package.json`, `angular.json`, new `eslint.config.js`
- Keep as generated: `angular.json`, `tsconfig.json`, `tsconfig.app.json`, `tsconfig.spec.json`, `.prettierrc`, `.editorconfig`, `.gitignore`, `.vscode/`, `public/favicon.ico`, `README.md`, `package-lock.json`, everything under `src/` until the next task

**Interfaces:**
- Consumes: Node 24 from nvm.
- Produces: a workspace where `npm run dev` starts the dev server, `npm run build`, `npm run lint`, `npm test`, `npm run format` and `npm run format:check` all work.

- [ ] **Step 1: Select Node 24 and generate the workspace from the repository root**

```bash
source "$HOME/.nvm/nvm.sh" && nvm use 24
npx -y @angular/cli@22 new ecommerce-frontend --directory src/ecommerce-frontend --style scss --ssr false --zoneless --ai-config none --skip-git --routing --package-manager npm --defaults
```

Expected: `CREATE` lines for the workspace files, `Installing packages (npm)...` and `Packages installed successfully.` The Angular CLI reported is 22.1.x. Generated files use the 2025 naming style (`app.ts`, `app.html`), the Vitest runner and zoneless change detection.

- [ ] **Step 2: Pin Node for the folder**

Create `src/ecommerce-frontend/.nvmrc` containing exactly:

```
24
```

- [ ] **Step 3: Add Angular Material and ESLint**

From `src/ecommerce-frontend`:

```bash
cd src/ecommerce-frontend
npm install @angular/material@22 @angular/cdk@22
npx ng add angular-eslint --skip-confirmation
```

Expected: Material and CDK 22.1.x appear under `dependencies`; `ng add` prints `CREATE eslint.config.js`, `UPDATE package.json`, `UPDATE angular.json` and `Packages installed successfully.` An `npm warn allow-scripts` notice can appear on install; it is informational. The Material `ng add` schematic is deliberately not used, because it would add Google Fonts and icon links to `index.html`; the theme is written by hand in task 2.2.2.

- [ ] **Step 4: Set the scripts**

Replace the `scripts` object in `src/ecommerce-frontend/package.json` with exactly:

```json
{
  "ng": "ng",
  "dev": "ng serve",
  "start": "ng serve",
  "build": "ng build",
  "test": "ng test --watch=false",
  "lint": "ng lint",
  "format": "prettier --write \"src/**/*.{ts,html,scss}\"",
  "format:check": "prettier --check \"src/**/*.{ts,html,scss}\""
}
```

`dev` is what Aspire runs, passing `--port` itself. `test` runs once and exits, as CI and the lead's review expect.

- [ ] **Step 5: Format the generated sources and verify every script**

```bash
npm run format
npm run build
npm run lint
npm test
npm run format:check
```

Expected: `format` rewrites whichever generated files differ from Prettier's layout, `src/main.ts` among them; `build` ends with `Application bundle generation complete`; `lint` prints `All files pass linting.`; `test` reports `Test Files  1 passed (1)` and `Tests  2 passed (2)` for the generated spec; `format:check` reports all files formatted.

### Task 2.2.2: Theme, shell layout, header and footer, test-first

**Files:**
- Modify: `src/ecommerce-frontend/src/index.html`
- Modify: `src/ecommerce-frontend/src/styles.scss`
- Modify: `src/ecommerce-frontend/src/app/app.spec.ts`
- Modify: `src/ecommerce-frontend/src/app/app.ts`
- Modify: `src/ecommerce-frontend/src/app/app.html`
- Modify: `src/ecommerce-frontend/src/app/app.scss`
- Modify: `src/ecommerce-frontend/src/app/app.config.ts`
- Keep: `src/ecommerce-frontend/src/app/app.routes.ts` (still the empty `routes` array)
- Create: `src/ecommerce-frontend/src/app/core/layout/site-header.ts`, `site-header.html`, `site-header.scss`
- Create: `src/ecommerce-frontend/src/app/core/layout/site-footer.ts`, `site-footer.html`, `site-footer.scss`

**Interfaces:**
- Consumes: Angular Material toolbar and button modules.
- Produces: `App` root component rendering `<app-site-header />`, a `main.content` with the router outlet, and `<app-site-footer />`; a Material 3 theme with the azure palette and the system font stack; `SiteHeader` with the "ECommerce Demo" brand link and a Products link; `SiteFooter` with the credit line.

- [ ] **Step 1: Write the failing spec**

Replace `src/app/app.spec.ts` with:

```typescript
import { TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';

import { App } from './app';

describe('App', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [App],
      providers: [provideRouter([])],
    }).compileComponents();
  });

  it('renders the header label and the footer credit', async () => {
    const fixture = TestBed.createComponent(App);
    await fixture.whenStable();

    const text = (fixture.nativeElement as HTMLElement).textContent ?? '';
    expect(text).toContain('ECommerce Demo');
    expect(text).toContain('Developed by Goran Todorovic 2026');
  });
});
```

- [ ] **Step 2: Run the tests and confirm they fail**

```bash
npm test
```

Expected: the run fails because `App` still renders the generated placeholder. Vitest stops at the first failing assertion, so the report names the `ECommerce Demo` expectation; the footer expectation is never reached.

- [ ] **Step 3: Write the shell**

`src/index.html`:

```html
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <title>ECommerce Demo</title>
    <base href="/" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="icon" type="image/x-icon" href="favicon.ico" />
  </head>
  <body>
    <app-root></app-root>
  </body>
</html>
```

`src/styles.scss`. Light scheme only, on purpose: a projector never surprises the presenter with a dark theme.

```scss
@use '@angular/material' as mat;

html {
  color-scheme: light;
  @include mat.theme(
    (
      color: (
        primary: mat.$azure-palette,
        tertiary: mat.$blue-palette,
      ),
      typography: (
        plain-family: system-ui,
        brand-family: system-ui,
      ),
      density: 0,
    )
  );
}

html,
body {
  height: 100%;
  margin: 0;
}

body {
  background: var(--mat-sys-surface);
  color: var(--mat-sys-on-surface);
  font: var(--mat-sys-body-medium);
}
```

`src/app/app.config.ts`. The interceptor is added in task 2.3.1; this version only registers the router and `HttpClient`.

```typescript
import { ApplicationConfig, provideBrowserGlobalErrorListeners } from '@angular/core';
import { provideHttpClient } from '@angular/common/http';
import { provideRouter } from '@angular/router';

import { routes } from './app.routes';

export const appConfig: ApplicationConfig = {
  providers: [provideBrowserGlobalErrorListeners(), provideRouter(routes), provideHttpClient()],
};
```

`src/app/app.ts`:

```typescript
import { ChangeDetectionStrategy, Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';

import { SiteFooter } from './core/layout/site-footer';
import { SiteHeader } from './core/layout/site-header';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, SiteHeader, SiteFooter],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './app.html',
  styleUrl: './app.scss',
})
export class App {}
```

`src/app/app.html`:

```html
<app-site-header />
<main class="content">
  <router-outlet />
</main>
<app-site-footer />
```

`src/app/app.scss`:

```scss
:host {
  display: flex;
  flex-direction: column;
  min-height: 100vh;
}

.content {
  flex: 1;
  width: min(1100px, 100% - 2rem);
  margin: 0 auto;
  padding-block: 1.5rem;
}
```

`src/app/core/layout/site-header.ts`:

```typescript
import { ChangeDetectionStrategy, Component } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatToolbarModule } from '@angular/material/toolbar';
import { RouterLink, RouterLinkActive } from '@angular/router';

@Component({
  selector: 'app-site-header',
  imports: [MatToolbarModule, MatButtonModule, RouterLink, RouterLinkActive],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './site-header.html',
  styleUrl: './site-header.scss',
})
export class SiteHeader {}
```

`src/app/core/layout/site-header.html`:

```html
<mat-toolbar class="header">
  <a class="brand" routerLink="/products">ECommerce Demo</a>
  <nav class="nav" aria-label="Main">
    <a mat-button routerLink="/products" routerLinkActive="active">Products</a>
  </nav>
</mat-toolbar>
```

`src/app/core/layout/site-header.scss`:

```scss
.header {
  position: sticky;
  top: 0;
  z-index: 10;
  gap: 1.5rem;
  background: var(--mat-sys-primary-container);
  color: var(--mat-sys-on-primary-container);
}

.brand {
  font: var(--mat-sys-title-large);
  color: inherit;
  text-decoration: none;
  letter-spacing: 0.02em;
}

.nav {
  margin-left: auto;
  display: flex;
  gap: 0.25rem;
}

.active {
  font-weight: 700;
}
```

`src/app/core/layout/site-footer.ts`:

```typescript
import { ChangeDetectionStrategy, Component } from '@angular/core';

@Component({
  selector: 'app-site-footer',
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './site-footer.html',
  styleUrl: './site-footer.scss',
})
export class SiteFooter {}
```

`src/app/core/layout/site-footer.html`:

```html
<footer class="footer">Developed by Goran Todorovic 2026</footer>
```

`src/app/core/layout/site-footer.scss`:

```scss
.footer {
  position: sticky;
  bottom: 0;
  padding: 0.75rem 1rem;
  text-align: center;
  font: var(--mat-sys-body-small);
  background: var(--mat-sys-surface-container);
  color: var(--mat-sys-on-surface-variant);
}
```

- [ ] **Step 4: Run the tests, then the full check**

```bash
npm test
npm run build
npm run lint
npm run format:check
```

Expected: `Tests  1 passed (1)`; build, lint and format check clean.

---

## Sub-phase 2.3 Buyer identity, interceptor and response helper (frontend-dev)

### Task 2.3.1: Buyer identity, interceptor and envelope helper, test-first

**Files:**
- Create: `src/ecommerce-frontend/src/app/core/api/api-response.spec.ts`
- Create: `src/ecommerce-frontend/src/app/core/buyer-identity.spec.ts`
- Create: `src/ecommerce-frontend/src/app/core/buyer-id-interceptor.spec.ts`
- Create: `src/ecommerce-frontend/src/app/core/api/api-response.ts`
- Create: `src/ecommerce-frontend/src/app/core/buyer-identity.ts`
- Create: `src/ecommerce-frontend/src/app/core/buyer-id-interceptor.ts`
- Modify: `src/ecommerce-frontend/src/app/app.config.ts`

**Interfaces:**
- Consumes: `HttpClient` providers.
- Produces, all under `src/app/core`:
  - `api/api-response.ts`: interfaces `ApiError` and `ApiResponse<T>` mirroring the envelope; class `ApiFailure extends Error` with `code`, `message`, `traceId`, `details`; `unwrap<T>(response: ApiResponse<T>): T` which throws `ApiFailure` on `success: false`; `toApiFailure(error: unknown): ApiFailure` which maps `HttpErrorResponse` with an envelope body, status 0 (`client.network_error`), other statuses (`common.http_<status>`) and anything else (`client.unknown_error`).
  - `buyer-identity.ts`: `BuyerIdentity` service with a readonly `id`, created with `crypto.randomUUID()` and stored under `ecommerce-demo.buyer-id`.
  - `buyer-id-interceptor.ts`: `buyerIdInterceptor: HttpInterceptorFn` adding `X-Buyer-Id` to requests whose URL starts with `/api/`.

- [ ] **Step 1: Write the three failing specs**

`src/app/core/api/api-response.spec.ts`:

```typescript
import { HttpErrorResponse } from '@angular/common/http';

import { ApiFailure, toApiFailure, unwrap } from './api-response';

describe('unwrap', () => {
  it('returns data from a success envelope', () => {
    expect(unwrap({ success: true, data: [1, 2], error: null })).toEqual([1, 2]);
  });

  it('returns null data from an empty success envelope', () => {
    expect(unwrap<null>({ success: true, data: null, error: null })).toBeNull();
  });

  it('throws an ApiFailure carrying the envelope error', () => {
    const attempt = () =>
      unwrap({
        success: false,
        data: null,
        error: {
          code: 'basket.checkout_empty',
          message: 'Basket is empty',
          details: null,
          traceId: 't1',
        },
      });

    expect(attempt).toThrowError(ApiFailure);
    expect(attempt).toThrowError('Basket is empty');
  });
});

describe('toApiFailure', () => {
  it('maps an HTTP error whose body is an envelope', () => {
    const error = new HttpErrorResponse({
      status: 404,
      error: {
        success: false,
        data: null,
        error: {
          code: 'catalog.product_not_found',
          message: 'Product [x] not found',
          details: null,
          traceId: 't2',
        },
      },
    });

    const failure = toApiFailure(error);

    expect(failure.code).toBe('catalog.product_not_found');
    expect(failure.message).toBe('Product [x] not found');
    expect(failure.traceId).toBe('t2');
  });

  it('maps a network failure to client.network_error', () => {
    const failure = toApiFailure(
      new HttpErrorResponse({ status: 0, error: new ProgressEvent('error') }),
    );

    expect(failure.code).toBe('client.network_error');
  });

  it('maps an HTTP error without an envelope to its status code', () => {
    const failure = toApiFailure(
      new HttpErrorResponse({ status: 502, statusText: 'Bad Gateway', error: '' }),
    );

    expect(failure.code).toBe('common.http_502');
  });

  it('passes an ApiFailure through unchanged', () => {
    const original = new ApiFailure('x.y', 'msg');

    expect(toApiFailure(original)).toBe(original);
  });
});
```

`src/app/core/buyer-identity.spec.ts`:

```typescript
import { BuyerIdentity } from './buyer-identity';

describe('BuyerIdentity', () => {
  beforeEach(() => localStorage.clear());

  it('creates a UUID on first use and stores it', () => {
    const identity = new BuyerIdentity();

    expect(identity.id).toMatch(/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/);
    expect(localStorage.getItem('ecommerce-demo.buyer-id')).toBe(identity.id);
  });

  it('reuses the stored id', () => {
    localStorage.setItem('ecommerce-demo.buyer-id', 'stored-id');

    expect(new BuyerIdentity().id).toBe('stored-id');
  });
});
```

`src/app/core/buyer-id-interceptor.spec.ts`:

```typescript
import { HttpClient, provideHttpClient, withInterceptors } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';

import { buyerIdInterceptor } from './buyer-id-interceptor';
import { BuyerIdentity } from './buyer-identity';

describe('buyerIdInterceptor', () => {
  let http: HttpClient;
  let controller: HttpTestingController;

  beforeEach(() => {
    localStorage.clear();
    TestBed.configureTestingModule({
      providers: [
        provideHttpClient(withInterceptors([buyerIdInterceptor])),
        provideHttpClientTesting(),
      ],
    });
    http = TestBed.inject(HttpClient);
    controller = TestBed.inject(HttpTestingController);
  });

  afterEach(() => controller.verify());

  it('adds the X-Buyer-Id header to API requests', () => {
    http.get('/api/catalog/products').subscribe();

    const request = controller.expectOne('/api/catalog/products');
    expect(request.request.headers.get('X-Buyer-Id')).toBe(TestBed.inject(BuyerIdentity).id);
    request.flush({ success: true, data: [], error: null });
  });

  it('leaves non-API requests untouched', () => {
    http.get('/assets/config.json').subscribe();

    const request = controller.expectOne('/assets/config.json');
    expect(request.request.headers.has('X-Buyer-Id')).toBe(false);
    request.flush({});
  });
});
```

- [ ] **Step 2: Run the tests and confirm they fail**

```bash
npm test
```

Expected: the run fails to resolve `./api-response`, `./buyer-identity` and `./buyer-id-interceptor`.

- [ ] **Step 3: Implement**

`src/app/core/api/api-response.ts`:

```typescript
import { HttpErrorResponse } from '@angular/common/http';

export interface ApiError {
  code: string;
  message: string;
  details: unknown;
  traceId: string | null;
}

export interface ApiResponse<T> {
  success: boolean;
  data: T | null;
  error: ApiError | null;
}

export class ApiFailure extends Error {
  constructor(
    readonly code: string,
    message: string,
    readonly traceId: string | null = null,
    readonly details: unknown = null,
  ) {
    super(message);
    this.name = 'ApiFailure';
  }
}

export function unwrap<T>(response: ApiResponse<T>): T {
  if (!response.success) {
    throw fromApiError(response.error);
  }
  return response.data as T;
}

export function toApiFailure(error: unknown): ApiFailure {
  if (error instanceof ApiFailure) {
    return error;
  }
  if (error instanceof HttpErrorResponse) {
    const body = error.error as Partial<ApiResponse<unknown>> | null;
    if (body && typeof body === 'object' && body.error) {
      return fromApiError(body.error);
    }
    if (error.status === 0) {
      return new ApiFailure('client.network_error', 'The server could not be reached');
    }
    return new ApiFailure(`common.http_${error.status}`, error.statusText || 'Request failed');
  }
  return new ApiFailure('client.unknown_error', 'Something went wrong');
}

function fromApiError(error: ApiError | null): ApiFailure {
  return new ApiFailure(
    error?.code ?? 'client.unknown_error',
    error?.message ?? 'Request failed',
    error?.traceId ?? null,
    error?.details ?? null,
  );
}
```

`src/app/core/buyer-identity.ts`:

```typescript
import { Injectable } from '@angular/core';

const storageKey = 'ecommerce-demo.buyer-id';

// One anonymous buyer id per browser, created on first use and kept in local storage
@Injectable({ providedIn: 'root' })
export class BuyerIdentity {
  readonly id: string = loadOrCreate();
}

function loadOrCreate(): string {
  try {
    const existing = localStorage.getItem(storageKey);
    if (existing) {
      return existing;
    }
    const created = crypto.randomUUID();
    localStorage.setItem(storageKey, created);
    return created;
  } catch {
    return crypto.randomUUID();
  }
}
```

`src/app/core/buyer-id-interceptor.ts`:

```typescript
import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';

import { BuyerIdentity } from './buyer-identity';

export const buyerIdInterceptor: HttpInterceptorFn = (request, next) => {
  if (!request.url.startsWith('/api/')) {
    return next(request);
  }
  const buyer = inject(BuyerIdentity);
  return next(request.clone({ setHeaders: { 'X-Buyer-Id': buyer.id } }));
};
```

`src/app/app.config.ts`, now registering the interceptor:

```typescript
import { ApplicationConfig, provideBrowserGlobalErrorListeners } from '@angular/core';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { provideRouter } from '@angular/router';

import { routes } from './app.routes';
import { buyerIdInterceptor } from './core/buyer-id-interceptor';

export const appConfig: ApplicationConfig = {
  providers: [
    provideBrowserGlobalErrorListeners(),
    provideRouter(routes),
    provideHttpClient(withInterceptors([buyerIdInterceptor])),
  ],
};
```

- [ ] **Step 4: Run the tests, then the full check**

```bash
npm test
npm run build
npm run lint
npm run format:check
```

Expected: `Test Files  4 passed (4)` and `Tests  12 passed (12)`; build, lint and format check clean.

---

## Sub-phase 2.4 Products page (frontend-dev)

### Task 2.4.1: Product model, Catalog client, placeholder image and products page, test-first

**Files:**
- Create: `src/ecommerce-frontend/src/app/shared/product-image/product-image-palette.spec.ts`
- Create: `src/ecommerce-frontend/src/app/shared/product-image/product-image-palette.ts`
- Create: `src/ecommerce-frontend/src/app/shared/product-image/product-image.ts`, `product-image.html`, `product-image.scss`
- Create: `src/ecommerce-frontend/src/app/shared/models/product.ts`
- Create: `src/ecommerce-frontend/src/app/core/api/catalog-api.ts`
- Create: `src/ecommerce-frontend/src/app/features/products/product-list.ts`, `product-list.html`, `product-list.scss`
- Modify: `src/ecommerce-frontend/src/app/app.routes.ts`

**Interfaces:**
- Consumes: `unwrap`, `toApiFailure`, `ApiResponse`.
- Produces: `Product` interface matching the Catalog `ProductResponse` fields in camelCase; `CatalogApi.listProducts()` returning an `httpResource<Product[]>` for `GET /api/catalog/products`; `ProductImage` component with required inputs `imageKey` and `name`; `ProductList` routed at `/products` with loading, error-with-retry and grid states, an add-to-basket button that is disabled for out-of-stock products and has no click handler yet (phase 3 wires it); routes redirecting `''` and unknown paths to `/products`.

- [ ] **Step 1: Write the failing spec**

`src/app/shared/product-image/product-image-palette.spec.ts`:

```typescript
import { hueFor, initialsFor } from './product-image-palette';

describe('hueFor', () => {
  it('is deterministic and within the hue range', () => {
    expect(hueFor('mug')).toBe(hueFor('mug'));
    expect(hueFor('mug')).toBeGreaterThanOrEqual(0);
    expect(hueFor('mug')).toBeLessThan(360);
  });

  it('differs for different keys', () => {
    expect(hueFor('mug')).not.toBe(hueFor('hoodie'));
  });
});

describe('initialsFor', () => {
  it('takes the first letter of the first two words', () => {
    expect(initialsFor('Aspire Ceramic Mug')).toBe('AC');
  });

  it('handles a single word', () => {
    expect(initialsFor('Poster')).toBe('P');
  });
});
```

- [ ] **Step 2: Run the tests and confirm they fail**

```bash
npm test
```

Expected: the run fails to resolve `./product-image-palette`.

- [ ] **Step 3: Implement**

`src/app/shared/product-image/product-image-palette.ts`:

```typescript
// Deterministic placeholder colors and initials so the demo needs no image files
export function hueFor(key: string): number {
  let hash = 0;
  for (const char of key) {
    hash = (hash * 31 + char.charCodeAt(0)) % 360;
  }
  return hash;
}

export function initialsFor(name: string): string {
  return name
    .split(/\s+/)
    .filter((word) => word.length > 0)
    .slice(0, 2)
    .map((word) => word[0].toUpperCase())
    .join('');
}
```

`src/app/shared/product-image/product-image.ts`:

```typescript
import { ChangeDetectionStrategy, Component, computed, input } from '@angular/core';

import { hueFor, initialsFor } from './product-image-palette';

@Component({
  selector: 'app-product-image',
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './product-image.html',
  styleUrl: './product-image.scss',
})
export class ProductImage {
  readonly imageKey = input.required<string>();
  readonly name = input.required<string>();

  protected readonly background = computed(() => `hsl(${hueFor(this.imageKey())} 45% 55%)`);
  protected readonly initials = computed(() => initialsFor(this.name()));
}
```

`src/app/shared/product-image/product-image.html`:

```html
<div class="tile" role="img" [attr.aria-label]="name()" [style.background-color]="background()">
  {{ initials() }}
</div>
```

`src/app/shared/product-image/product-image.scss`:

```scss
.tile {
  display: grid;
  place-items: center;
  aspect-ratio: 4 / 3;
  width: 100%;
  border-radius: 12px 12px 0 0;
  color: rgb(255 255 255 / 92%);
  font: var(--mat-sys-display-small);
  letter-spacing: 0.05em;
}
```

`src/app/shared/models/product.ts`:

```typescript
export interface Product {
  id: string;
  name: string;
  description: string;
  category: string;
  price: number;
  availableStock: number;
  imageKey: string;
}
```

`src/app/core/api/catalog-api.ts`. The resource is created with the service's injector so a component can call `listProducts()` from a field initializer.

```typescript
import { httpResource } from '@angular/common/http';
import { Injectable, Injector, inject } from '@angular/core';

import { Product } from '../../shared/models/product';
import { ApiResponse, unwrap } from './api-response';

@Injectable({ providedIn: 'root' })
export class CatalogApi {
  private readonly injector = inject(Injector);

  listProducts() {
    return httpResource<Product[]>(() => '/api/catalog/products', {
      injector: this.injector,
      parse: (raw) => unwrap(raw as ApiResponse<Product[]>),
    });
  }
}
```

`src/app/features/products/product-list.ts`:

```typescript
import { CurrencyPipe } from '@angular/common';
import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatProgressBarModule } from '@angular/material/progress-bar';

import { toApiFailure } from '../../core/api/api-response';
import { CatalogApi } from '../../core/api/catalog-api';
import { ProductImage } from '../../shared/product-image/product-image';

@Component({
  selector: 'app-product-list',
  imports: [CurrencyPipe, MatCardModule, MatButtonModule, MatProgressBarModule, ProductImage],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './product-list.html',
  styleUrl: './product-list.scss',
})
export class ProductList {
  private readonly catalog = inject(CatalogApi);

  protected readonly products = this.catalog.listProducts();
  protected readonly failure = computed(() => {
    const error = this.products.error();
    return error ? toApiFailure(error) : null;
  });

  protected reload(): void {
    this.products.reload();
  }
}
```

`src/app/features/products/product-list.html`:

```html
<h1 class="title">Products</h1>

@if (products.isLoading()) {
  <mat-progress-bar mode="indeterminate" aria-label="Loading products" />
}

@if (failure(); as failure) {
  <mat-card class="notice" appearance="outlined">
    <mat-card-content>
      <p>{{ failure.message }}</p>
      <p class="code">[{{ failure.code }}]</p>
    </mat-card-content>
    <mat-card-actions>
      <button mat-button (click)="reload()">Retry</button>
    </mat-card-actions>
  </mat-card>
} @else if (products.value(); as items) {
  <div class="grid">
    @for (product of items; track product.id) {
      <mat-card
        class="product"
        [class.sold-out]="product.availableStock === 0"
        appearance="outlined"
      >
        <app-product-image [imageKey]="product.imageKey" [name]="product.name" />
        <mat-card-header>
          <mat-card-title>{{ product.name }}</mat-card-title>
          <mat-card-subtitle>{{ product.category }}</mat-card-subtitle>
        </mat-card-header>
        <mat-card-content>
          <p class="description">{{ product.description }}</p>
          <p class="price">{{ product.price | currency: 'EUR' }}</p>
          @if (product.availableStock > 0) {
            <p class="stock">In stock: {{ product.availableStock }}</p>
          } @else {
            <p class="stock out">Out of stock</p>
          }
        </mat-card-content>
        <mat-card-actions align="end">
          <button mat-flat-button [disabled]="product.availableStock === 0">Add to basket</button>
        </mat-card-actions>
      </mat-card>
    } @empty {
      <p>No products available</p>
    }
  </div>
}
```

`src/app/features/products/product-list.scss`:

```scss
.title {
  font: var(--mat-sys-headline-medium);
  margin: 0 0 1rem;
}

.grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
  gap: 1rem;
}

.product {
  display: flex;
  flex-direction: column;
}

.product mat-card-content {
  flex: 1;
}

.sold-out app-product-image {
  opacity: 0.55;
}

.description {
  color: var(--mat-sys-on-surface-variant);
  min-height: 2.6em;
}

.price {
  font: var(--mat-sys-title-medium);
  margin: 0.5rem 0 0.25rem;
}

.stock {
  font: var(--mat-sys-label-large);
  color: var(--mat-sys-primary);
  margin: 0;
}

.stock.out {
  color: var(--mat-sys-error);
}

.notice .code {
  font: var(--mat-sys-label-medium);
  color: var(--mat-sys-on-surface-variant);
}
```

`src/app/app.routes.ts`:

```typescript
import { Routes } from '@angular/router';

export const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'products' },
  {
    path: 'products',
    loadComponent: () => import('./features/products/product-list').then((m) => m.ProductList),
  },
  { path: '**', redirectTo: 'products' },
];
```

- [ ] **Step 4: Run the tests, then the full check**

```bash
npm test
npm run build
npm run lint
npm run format:check
```

Expected: `Test Files  5 passed (5)` and `Tests  16 passed (16)`; the build lists a lazy chunk named `product-list`; lint and format check clean.

---

## Sub-phase 2.5 Phase acceptance

Run by the lead after every task above is reviewed and ticked.

- [ ] **Step 1: Clean build and full test runs**

```bash
dotnet build
dotnet test
cd src/ecommerce-frontend && source "$HOME/.nvm/nvm.sh" && nvm use && npm run lint && npm test && cd ../..
```

Expected: `0 Warning(s)`, 48 .NET tests, 16 frontend tests, lint clean.

- [ ] **Step 2: Start the AppHost and wait for the three application resources**

```bash
export PATH="$PATH:$HOME/.dotnet/tools"
AH=src/Ecommerce.AppHost/Ecommerce.AppHost.csproj
aspire start --apphost $AH --non-interactive --format Json
for r in catalog-api frontend gateway; do aspire wait $r --status healthy --timeout 300 --apphost $AH --non-interactive; done
aspire describe --apphost $AH --non-interactive --format Table
```

Expected: all three healthy; `describe` also lists `frontend-installer` as Finished, which is the automatic `npm install`. `aspire logs frontend --tail 12` shows `Starting process...: Cmd = .../npm, Args = ["run", "dev", "--", "--port", "<port>"]` and `Local: http://localhost:<port>/`.

- [ ] **Step 3: Exercise the gateway**

```bash
curl -s http://localhost:5100/api/catalog/products | python3 -c 'import sys,json; d=json.load(sys.stdin); print(d["success"], len(d["data"]))'
# Expected: True 12

curl -s -w ' [%{http_code}]\n' http://localhost:5100/api/catalog/products/a0000000-0000-4000-8000-0000000000ff
# Expected: envelope with "code":"catalog.product_not_found" and [404], passed through from Catalog

curl -s -w ' [%{http_code}]\n' http://localhost:5100/api/nope
# Expected: envelope with "code":"common.not_found" and [404], answered by the gateway

curl -s -o /dev/null -w '%{http_code} %{content_type}\n' http://localhost:5100/
# Expected: 200 text/html

curl -s -o /dev/null -w '%{http_code}\n' http://localhost:5100/products
# Expected: 200, the SPA fallback

curl -s http://localhost:5100/ | grep -o '<title>[^<]*</title>'
# Expected: <title>ECommerce Demo</title>

TOKEN=$(curl -s http://localhost:5100/@vite/client | grep -oE 'wsToken = "[^"]+"' | head -1 | sed 's/.*"\(.*\)"/\1/')
curl -s -m 5 -i -N --http1.1 -H "Connection: Upgrade" -H "Upgrade: websocket" -H "Sec-WebSocket-Version: 13" -H "Sec-WebSocket-Key: dGhlIHNhbXBsZSBub25jZQ==" -H "Sec-WebSocket-Protocol: vite-hmr" "http://localhost:5100/?token=$TOKEN" | head -1
# Expected: HTTP/1.1 101 Switching Protocols, proving hot reload works through the gateway
```

- [ ] **Step 4: Prove the upstream-unavailable envelope and recovery**

```bash
aspire resource catalog-api stop --apphost $AH --non-interactive
aspire wait catalog-api --status down --timeout 60 --apphost $AH --non-interactive
curl -s -m 60 -w ' [%{http_code}]\n' http://localhost:5100/api/catalog/products
# Expected: envelope with "code":"common.upstream_unavailable" and [504]

aspire resource catalog-api start --apphost $AH --non-interactive
aspire wait catalog-api --status healthy --timeout 120 --apphost $AH --non-interactive
curl -s http://localhost:5100/api/catalog/products | python3 -c 'import sys,json; d=json.load(sys.stdin); print(d["success"], len(d["data"]))'
# Expected: True 12
```

- [ ] **Step 5: Owner's browser check**

With the AppHost running, open `http://localhost:5100` (or `https://localhost:7100` once `aspire certs trust` has been approved). Expected: the header with the "ECommerce Demo" label and the Products link, a responsive grid of twelve product cards with colored initial tiles, category, description, EUR price and stock line, the Limited Edition Hoodie shown as Out of stock with a disabled button and a faded tile, and the sticky footer reading "Developed by Goran Todorovic 2026". In the dashboard, a trace for the products request starts at `gateway` and continues into `catalog-api`; the `frontend` resource shows the dev server logs.

- [ ] **Step 6: Stop and record**

```bash
aspire stop --apphost $AH --non-interactive
```

The lead ticks phase 2 in `STATUS.md`, writes the phase entry in `SUMMARY.md`, and waits for the owner's review.
