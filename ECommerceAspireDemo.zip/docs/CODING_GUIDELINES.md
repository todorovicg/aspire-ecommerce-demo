# Coding Guidelines

Status: agreed, 2026-09-12. Applies to every project in the solution. The architecture
is described in [ARCHITECTURE.md](ARCHITECTURE.md).

## 1. Principles

- As simple as possible, but not simpler. Best practices without ceremony.
- Aspire is the subject of the demo. Anything that pulls attention from it needs a reason.
- One way to do each thing. When this document names a pattern, use it everywhere.
- The build is warning-free when work is handed over, even though warnings are not errors.
- Only dependencies that are fully open source and require no license of any kind,
  personal or commercial, for any use. This applies to NuGet packages, npm packages and
  container images. Check the license before proposing a package; the current list with
  licenses is in ARCHITECTURE.md section 9, and a new dependency is added there first.

## 2. C# and .NET

### 2.1 Naming

| Element | Style | Example |
|---|---|---|
| Types, methods, properties, constants | PascalCase | `OrderProcessor`, `MaxQuantity` |
| Locals, parameters | camelCase | `buyerId` |
| Private fields | `_camelCase` | `_store` |
| Interfaces | `I` prefix | `IBasketStore` |
| Async methods | `Async` suffix, `CancellationToken` last | `GetAsync(id, cancellationToken)` |
| Request and response records | `Request` and `Response` suffix | `CheckoutRequest`, `BasketResponse` |
| Endpoint classes | `Endpoint` suffix | `CheckoutEndpoint` |
| Message handlers | `Handler` suffix | `OrderPaidHandler` |
| Options records | `Options` suffix | `OrderProcessorOptions` |

### 2.2 Language and layout

- .NET 10, C# 14, nullable reference types enabled, implicit usings on.
- `var` everywhere.
- File-scoped namespaces matching the folder: `Ecommerce.Basket.Api.Features.Checkout`.
- Usings outside the namespace, `System` namespaces first, then others, then project
  namespaces, sorted alphabetically within each group.
- Allman braces, four-space indentation, braces on every `if`, `for` and `while` body.
- Primary constructors for classes whose constructor only receives dependencies.
  Explicit constructors when there is validation or logic.
- Expression-bodied members only for one-line bodies.
- `sealed` on every class that is not designed for inheritance.
- Positional `sealed record` for contracts, requests, responses and options. Domain
  entities are classes with behavior and private setters where invariants matter.

### 2.3 Files and folders

- One file per feature named after the endpoint, for example `CheckoutEndpoint.cs`. It
  contains the static endpoint class with its `Map` method and handler, plus the request
  and response records of that feature.
- Domain types, infrastructure classes, handlers and options each get their own file.
- A file stays under roughly 200 lines. Beyond that, split the feature.
- Folder layout per service:

```
Features/<FeatureName>/<FeatureName>Endpoint.cs
Domain/                      entities, value objects, invariants
Infrastructure/              stores, clients, EF configuration, Mongo mapping
Messaging/                   Wolverine handlers and publisher wiring
Program.cs                   composition root only
```

### 2.4 Endpoints

- Minimal APIs. Each service maps one route group with its prefix, for example
  `app.MapGroup("/api/basket").WithTags("Basket")`, and each feature adds its endpoints
  to that group through a static `Map<Feature>` extension method.
- Handlers are static methods on the endpoint class with dependencies as parameters.
- Handlers return `TypedResults` with an explicit `Results<...>` union so OpenAPI
  metadata comes from the signature.
- Request models are records validated with data annotations through the .NET 10
  built-in minimal API validation.
- The buyer identity comes from the `X-Buyer-Id` header, bound into the shared
  `BuyerId` type from `Ecommerce.ApiDefaults` and rejected once per route group
  by the shared `BuyerIdFilter` when missing or malformed.
- Endpoint classes are static and do not log. `ILogger<T>` needs a non-static type, so
  logging lives in application services, message handlers and hosted services, which are
  non-static classes. An endpoint that needs to log something delegates to such a class.

### 2.5 API response envelope

Every response body from every service has the same shape. The HTTP status code keeps
its normal meaning; the envelope makes the body predictable.

```json
{ "success": true,  "data": { "orderId": "0199..." }, "error": null }
```

```json
{
  "success": false,
  "data": null,
  "error": {
    "code": "basket.product_out_of_stock",
    "message": "Product [Aspire Mug] has [0] units available",
    "details": null,
    "traceId": "00-8f3c2a...-01"
  }
}
```

Rules:

- `data` is present and `error` is `null` on success; the opposite on failure. A
  success with nothing to return, such as a delete, still returns the envelope with
  `data` set to `null`.
- `error.code` is machine-readable, `<service>.<snake_case_reason>`, for example
  `basket.product_not_found`, `catalog.product_not_found`, `orders.not_found`,
  `basket.checkout_empty`, `basket.broker_unavailable`. Framework-originated errors use
  the `common` prefix: `common.validation_failed`, `common.not_found`,
  `common.internal_error`. Codes are `const string` fields in one `ErrorCodes` class
  per service and are never built from strings at the call site.
- `error.message` is a human-readable sentence in the log line style of section 3:
  values in square brackets, no trailing full stop.
- `error.details` is an optional object for structured extras. Validation failures put
  the field errors there as `{ "fieldName": ["message", ...] }`. Out-of-stock at
  checkout puts the affected products there.
- `error.traceId` is the current W3C trace id, so an error on screen can be pasted into
  the dashboard's trace search.
- The types live in `Ecommerce.ApiDefaults` as `ApiResponse<T>`, `ApiResponse`
  and `ApiError`. `ApiResponse` has the factories `Ok(data)`, `Empty()` and
  `Fail(code, message, details)`. The static `ApiResults` helper produces the typed
  results: `Ok(data)`, `Accepted(data)`, `Empty()`, `BadRequest(code, message, details)`,
  `NotFound(code, message)`, `Conflict(code, message, details)` and
  `ServiceUnavailable(code, message)`. Framework-level codes live in `CommonErrorCodes`, including
  `common.upstream_unavailable` for 502, 503 and 504 responses produced by the gateway
  when a backend is down.
- Errors the framework generates on its own, meaning validation failures, unhandled
  exceptions and unmatched routes, are converted to the envelope by a custom
  `IProblemDetailsWriter` registered by `Ecommerce.ApiDefaults`. No response ever leaves a
  service in another shape.
- The gateway forwards bodies unchanged and adds nothing.

Status code mapping:

| Situation | Status | Code |
|---|---|---|
| Success with a body | 200 | |
| Accepted for asynchronous processing | 202 | |
| Success without a body | 200 with `data: null` | |
| Validation failure | 400 | `common.validation_failed` |
| Missing or malformed `X-Buyer-Id` | 400 | `common.buyer_id_invalid` |
| Resource not found | 404 | `<service>.<thing>_not_found` |
| Business rule violation | 409 | `<service>.<reason>` |
| Dependency unavailable after retries | 503 | `<service>.<dependency>_unavailable` |
| Unhandled exception | 500 | `common.internal_error` |

### 2.6 Errors and exceptions

- Expected outcomes such as not found, out of stock or declined are return values, never
  exceptions.
- Exceptions are for infrastructure failures and bugs. They are logged once, by the
  global exception handler, and become a `500` envelope. Do not catch and rethrow to log.
- A dependency failure that a handler can meaningfully report, such as the broker being
  down at checkout, is caught at the boundary and turned into a `503` envelope with a
  warning log line.
- Infrastructure clients translate the transport exceptions of their dependency into one
  exception type of their own, for example `CatalogUnavailableException`, so application
  services never catch `HttpRequestException` or Polly types directly.

### 2.7 Configuration

- Strongly typed options records bound with `BindConfiguration("Section")`, validated
  with data annotations and `ValidateOnStart()`, so a bad value fails at startup.
- No secrets anywhere. Aspire injects every connection string.
- Development-only values go in `appsettings.Development.json`.

### 2.8 Time and identifiers

- `TimeProvider` is injected wherever time is read. Never call `DateTime.UtcNow` or
  `DateTimeOffset.UtcNow` in application code.
- New identifiers come from `Guid.CreateVersion7()`.

### 2.9 Comments

- No XML documentation comments.
- Single-line `//` comments only, and only where the code cannot explain why something
  is done. No comments that restate what the code does.
- No em dashes in comments or anywhere else in code and messages.

### 2.10 Analyzers and warnings

- Default .NET analyzers as the SDK enables them. No style enforcement in the build, no
  third-party analyzer packages, no warnings-as-errors.
- Warnings are fixed as part of normal work. The handed-over build has none.

### 2.11 Tests

- xUnit v3. One test class per unit under test, named `<Unit>Tests`.
- Test methods are named `Method_Scenario_ExpectedOutcome`, for example
  `Checkout_WithEmptyBasket_ReturnsCheckoutEmpty`.
- Arrange, act and assert phases separated by blank lines. Plain `Assert` calls.
- Hand-written fakes over mocking libraries. A fake is a small class in the test
  project's `Fakes` folder.
- A fake `TimeProvider` drives anything time-based.
- Integration tests through `Aspire.Hosting.Testing` live only in
  `Ecommerce.IntegrationTests` and talk to the system through the gateway. They poll
  with a timeout for asynchronous outcomes and return the last observed value, so a
  failed assertion shows what the system did; they never open a database or a broker.
- Test projects reference `xunit.v3` only, set `OutputType` to `Exe`, and run on the
  Microsoft Testing Platform selected in `global.json`. Async calls in tests pass
  `TestContext.Current.CancellationToken`.
- EF Core handlers are tested against SQLite in-memory through the real provider, one
  fresh database per test, never against the EF in-memory provider.

## 3. Logging

Every log line follows one format:

```csharp
logger.LogInformation("[{Prefix}] Published OrderPlaced for order [{OrderId}] buyer [{BuyerId}]",
    nameof(CheckoutEndpoint), orderId, buyerId);
```

Rules:

- Message templates with named placeholders, never string interpolation. The rendered
  text is identical, and the dashboard keeps each value as a filterable property.
- The first placeholder is always `{Prefix}` filled with `nameof(<class>)` of the class
  the log is written from, rendered in square brackets.
- Every other value is rendered inside square brackets.
- One line per log call. No line breaks inside the message.
- No trailing full stop.
- Placeholder names are PascalCase and stable across the solution: `OrderId`,
  `BuyerId`, `ProductId`, `Quantity`, `Status`.
- Levels: `Information` for business events that happen once per operation, such as
  order placed or payment approved. `Warning` for handled anomalies, such as a stock
  shortfall or a retry scheduled. `Error` only with an exception attached. `Debug` for
  per-tick chatter such as the processor finding nothing to do.
- Never log a card number, in any form. Buyer id and order id are fine.
- A third-party warning that is a false positive by design is silenced with a logger
  category filter in that service's `appsettings.json`, never by lowering the default
  level, and the reason is recorded in ARCHITECTURE.md.

## 4. Messaging

- Wolverine handlers are static methods on a `<Message>Handler` class, with the message
  first and dependencies as further parameters:
  `public static async Task HandleAsync(OrderPaid message, CatalogDbContext db, ILogger<OrderPaidHandler> logger, CancellationToken cancellationToken)`.
- One handler class per message per service, in the `Messaging` folder.
- Every handler is idempotent. Redelivery of the same message must not change the
  outcome.
- Contracts are positional records in `Ecommerce.Contracts` and never carry behavior.
  A changed contract gets a new name; existing records are not edited once in use.
- Queue names are `<service>.<event-kebab-case>`, exchange names are
  `<event-kebab-case>`.
- A service that uses Wolverine ends `Program.cs` with
  `return await app.RunJasperFxCommands(args);` so the AppHost's JasperFx dashboard
  commands can run `check-env`, `describe` and `codegen preview` against it. Services
  without Wolverine keep `app.Run()`.
- Events are published through a durable outbox backed by a Postgres message store,
  never inline; the publisher class translates a failure to store the envelope into an
  `OutboxUnavailableException` that the caller maps to a `503`.

## 5. Data access

- Catalog: EF Core with one `CatalogDbContext`, registered with `DisableRetry = true`
  because Wolverine opens a transaction around every handler and EF Core rejects that
  under the retrying execution strategy. Mapping in `IEntityTypeConfiguration`
  classes under `Infrastructure`, never attributes on entities. Migrations live in the
  project and are applied at startup in development. Stock changes use a guarded
  `ExecuteUpdateAsync`, never read-modify-write.
- Basket: one `RedisBasketStore` behind `IBasketStore`. Baskets are serialized with
  `System.Text.Json` using the web defaults.
- Ordering: one `MongoOrderStore` behind `IOrderStore`. Claims and state changes use
  atomic `FindOneAndUpdate` and `UpdateOne` calls with filters that include the expected
  current state.
- Serialization everywhere is `System.Text.Json` with camelCase property names.

## 6. Angular

### 6.1 Structure and naming

- Angular 22 style guide as the CLI generates it: file names without type suffixes,
  so `product-list.ts` declares `ProductList`, and `basket-store.ts` declares
  `BasketStore`. Template and styles sit next to the class file.
- Folders: `core/` for the buyer id service and interceptor, API clients and layout;
  `features/<feature>/` for routed views; `shared/` for models and reusable pieces.
- Kebab-case file names, PascalCase classes, camelCase members.

### 6.2 Modern APIs only

- `inject()` instead of constructor injection.
- `input()`, `output()` and `model()` instead of decorators.
- `@if`, `@for` and `@switch` control flow.
- Signals for component state, `computed()` for derived values, `OnPush` change
  detection, zoneless as the CLI defaults it.
- `httpResource` for reads. Plain `HttpClient` for writes.

### 6.3 API access

- All calls use relative `/api/...` URLs through the gateway.
- One client per backend service in `core/api/`: `catalog-api.ts`, `basket-api.ts`,
  `orders-api.ts`.
- One `ApiResponse<T>` interface mirrors the envelope. `unwrap` returns `data` on
  success and throws `ApiFailure`, an `Error` subclass carrying `code`, `message`,
  `traceId` and `details`, on failure. `toApiFailure` turns anything a request can
  produce, including `HttpErrorResponse` with an envelope body, a network failure
  (`client.network_error`) and non-envelope statuses (`common.http_<status>`), into the
  same `ApiFailure`. Reads use `httpResource` with `parse` set to `unwrap`.
- The buyer id interceptor adds `X-Buyer-Id` to every request whose URL starts with
  `/api/`. `BuyerIdentity` generates the GUID with `crypto.randomUUID()` and stores it in
  local storage under `ecommerce-demo.buyer-id` on first use.

### 6.4 Styling

- SCSS. One Material 3 theme defined in `styles.scss` with a single accent color.
- Component styles cover layout only. No utility CSS framework, no external fonts,
  icons or images. Product images are generated tiles: a hue derived from `imageKey` and
  the product's initials.

### 6.5 Tooling and tests

- angular-eslint recommended rules and Prettier with single quotes, two-space indent
  and a 100-column width, both run through npm scripts.
- Vitest specs next to the file they test, limited to logic worth testing: the buyer id
  interceptor, the basket store, the orders polling rule and the response helper.

## 7. Repository

- `.editorconfig` at the root for C#, TypeScript, JSON and Markdown.
- `.gitignore` for .NET and Node, ready for the day a repository is initialized.
- `README.md` with the description, prerequisites and run commands.
- `Directory.Build.props` for shared build settings and `Directory.Packages.props` for
  central package versions. A package version appears in exactly one place.
