# ECommerce Aspire Demo: Architecture and Project Structure

Status: agreed design, 2026-09-12; section 3 and section 7 updated on 2026-09-14 when the
shared API code moved into its own project (phase 9). Supersedes `PROPOSAL_SOLUTION.md`.
Coding rules are in [CODING_GUIDELINES.md](CODING_GUIDELINES.md).

## 1. Purpose

A small but complete e-commerce system whose only job is to show what Aspire gives a
team building a cloud-native microservice solution: orchestration from C#, integrations
for databases and brokers, service discovery, resilience, and end-to-end observability
through the Aspire dashboard.

The system is a simulator. A visitor opens one URL, browses products, fills a basket,
checks out with a test card, and watches the order move to Paid and Shipped while the
product stock drops. Every step is real code running against real infrastructure in
containers; only the payment provider is simulated.

What it is not: a production shop. There is no authentication, no real payments, no
deployment pipeline, and no attempt at features that would pull focus from Aspire.
Within that scope the code is written the way a production team would write it: clean
boundaries, validation, idempotent messaging, health checks, tests.

### 1.1 Aspire showcase map

| Aspire capability | Where it lives here | How to show it |
|---|---|---|
| Orchestration in C#, no compose files | `Ecommerce.AppHost/AppHost.cs` | One `aspire run` starts 4 containers, 5 .NET processes and the Angular dev server |
| Hosting and client integrations | Postgres, Redis, RabbitMQ, Mongo resources and their client packages | Connection strings, health checks and telemetry appear with no config files |
| Service discovery | Gateway routes, Basket to Catalog, Ordering to Payment | Code says `https+http://catalog-api`; ports are assigned at run time |
| Resilience | Standard resilience handler from ServiceDefaults | Stop the `payment-api` resource, place an order, watch it wait, start it again |
| Distributed tracing | Every service uses ServiceDefaults; Wolverine propagates context over RabbitMQ | One checkout is one trace: gateway, basket, catalog, broker, ordering, payment, broker, catalog |
| Structured logs and metrics | Dashboard | Filter logs by resource or by trace id; HTTP and Wolverine meters |
| Health and startup ordering | `WaitFor`, `/health`, `/alive` | Resources move from Waiting to Running in dependency order |
| Polyglot apps | `AddViteApp` for Angular | Angular gets its port from Aspire and its logs in the dashboard |
| Dashboard commands | Restart, JasperFx commands on Wolverine services | Run Wolverine's environment check from a resource tile |
| Integration testing | `Ecommerce.IntegrationTests` | `dotnet test` boots the whole system and buys a product |

## 2. System overview

```
                       Browser (Angular SPA, served through the gateway)
                                         |
                                         | https://localhost:7100
                                         v
                       +-------------------------------------+
                       |  Gateway  (Ecommerce.Gateway, YARP) |
                       |  /api/catalog/*  -> catalog-api     |
                       |  /api/basket/*   -> basket-api      |
                       |  /api/orders/*   -> ordering-api    |
                       |  /*              -> frontend        |
                       +-------------------------------------+
                          |               |               |
                          v               v               v
   +---------------+   +---------------+   +----------------+   HTTP    +---------------+
   |  Catalog API  |<--|  Basket API   |   |  Ordering API  |---------->|  Payment API  |
   |  PostgreSQL   |   |  Redis        |   |  MongoDB       |           |  stateless    |
   +---------------+   +---------------+   +----------------+           +---------------+
          ^                    |                  ^     |
          | OrderPaid          | OrderPlaced      |     | OrderPaid
          |                    v                  |     v
          |            +------------------------------------+
          +------------|             RabbitMQ               |
                       +------------------------------------+
```

Synchronous calls, all through Aspire service discovery and the resilience handler:

- Browser to Gateway.
- Gateway to Catalog, Basket, Ordering, Preferences and the Angular dev server.
- Basket to Catalog, to validate products, prices and stock.
- Ordering to Payment, to authorize a payment.

Asynchronous messages, through RabbitMQ with Wolverine:

- Basket publishes `OrderPlaced` at checkout. Ordering consumes it.
- Ordering publishes `OrderPaid` when a payment is approved. Catalog consumes it and
  decrements stock.

Payment is reachable only from inside the system. The gateway does not route to it.

### 2.1 A purchase, end to end

1. The products page calls `GET /api/catalog/products` through the gateway.
2. Add to basket calls `PUT /api/basket/items`. Basket calls Catalog for the product,
   rejects unknown or out-of-stock products, caps the quantity at the available stock,
   stores the line in Redis with the current unit price.
3. Checkout calls `POST /api/basket/checkout` with buyer, address and card details.
   Basket re-reads every line from Catalog, refuses if anything is out of stock,
   publishes `OrderPlaced` inline, clears the basket, and answers `202 Accepted` with
   the order id.
4. Ordering consumes `OrderPlaced` and upserts the order in Mongo with status
   `Submitted`.
5. The order processor picks the order up, calls Payment. Approved: status `Paid`,
   `OrderPaid` published. Declined: status `PaymentFailed`. Payment unreachable: the
   order stays `Submitted` and is retried after a backoff.
6. Catalog consumes `OrderPaid` through a durable inbox and decrements stock once.
7. A few seconds after `Paid`, the processor moves the order to `Shipped`.
8. The orders page polls `GET /api/orders` while any order is still in progress, so the
   status changes appear without a refresh, and the products page shows the new stock
   on its next load.

## 3. Solution structure

```
ECommerceAspireDemo/
|-- ECommerceAspireDemo.slnx
|-- global.json                       pins the .NET 10 SDK
|-- Directory.Build.props             shared build settings for every project
|-- Directory.Packages.props          central package versions
|-- .editorconfig                     C# style and analyzer severities
|-- docs/
|   |-- ARCHITECTURE.md               this document
|   `-- PROPOSAL_SOLUTION.md          original proposal, superseded
|-- src/
|   |-- Ecommerce.AppHost/            Aspire orchestrator
|   |-- Ecommerce.ServiceDefaults/    Aspire service defaults from the template
|   |-- Ecommerce.ApiDefaults/        response envelope, problem details writer, buyer identity, OpenAPI and Scalar
|   |-- Ecommerce.Contracts/          integration message contracts (OrderPlaced, OrderPaid)
|   |-- Ecommerce.Gateway/            YARP reverse proxy with service discovery
|   |-- Ecommerce.Catalog.Api/        products and stock, PostgreSQL, EF Core
|   |-- Ecommerce.Basket.Api/         baskets, Redis
|   |-- Ecommerce.Ordering.Api/       orders, MongoDB, order processor
|   |-- Ecommerce.Payment.Api/        simulated payment provider, no storage
|   |-- Ecommerce.Preferences.Api/    per-buyer preferences (language), Redis
|   `-- ecommerce-frontend/           Angular 22 SPA (.nvmrc pins Node 24)
`-- tests/
    |-- Ecommerce.ApiDefaults.Tests/
    |-- Ecommerce.Catalog.Api.Tests/
    |-- Ecommerce.Basket.Api.Tests/
    |-- Ecommerce.Ordering.Api.Tests/
    |-- Ecommerce.Payment.Api.Tests/
    |-- Ecommerce.Preferences.Api.Tests/
    `-- Ecommerce.IntegrationTests/   Aspire.Hosting.Testing, boots the AppHost
```

Project references:

| Project | References |
|---|---|
| AppHost | all `src` projects, as Aspire project references |
| Gateway | ServiceDefaults, ApiDefaults |
| Catalog, Basket, Ordering | ServiceDefaults, ApiDefaults, Contracts |
| Payment, Preferences | ServiceDefaults, ApiDefaults |
| ApiDefaults | ServiceDefaults |
| Contracts | nothing |
| each unit test project | the project it tests |
| IntegrationTests | AppHost |

Services never reference each other. Anything two services share is either an HTTP
contract described in this document or a message record in Contracts.

### 3.1 Inside a service project

Each service is one deployable project organized by feature. Endpoints are thin,
validation is declarative, and data access lives in one place.

```
Ecommerce.Basket.Api/
|-- Program.cs                        composition root only
|-- Features/
|   |-- GetBasket/                    endpoint + response model
|   |-- UpsertItem/                   endpoint + request model + rules
|   |-- RemoveItem/
|   `-- Checkout/                     endpoint, request model, publisher call
|-- Domain/                           Basket, BasketItem, invariants
|-- Infrastructure/                   RedisBasketStore, CatalogClient
|-- appsettings.json
`-- Properties/launchSettings.json
```

Each feature folder has a static class with a `Map...` method that registers its
endpoints on a `RouteGroupBuilder`. `Program.cs` calls `AddServiceDefaults`, registers
the Aspire client integrations, Wolverine and the feature services, then maps the groups.

## 4. Services

### 4.1 Gateway (`Ecommerce.Gateway`)

Role: the single public entry point. A .NET project running YARP with the Aspire
service discovery destination resolver, so cluster destinations are resource names,
not addresses. It uses ServiceDefaults, so every trace begins at the gateway and the
gateway's own health and logs appear in the dashboard.

Routes, in match order:

| Path | Cluster | Destination | Order |
|---|---|---|---|
| `/api/catalog/{**catch-all}` | catalog | `https+http://catalog-api` | 0 |
| `/api/basket/{**catch-all}` | basket | `https+http://basket-api` | 0 |
| `/api/orders/{**catch-all}` | ordering | `https+http://ordering-api` | 0 |
| `/api/preferences/{**catch-all}` | preferences | `https+http://preferences-api` | 0 |
| `/api/{**rest}` | none, a gateway endpoint answering 404 | | 0 |
| `/{**catch-all}` | frontend | `http://frontend` | 1000 |

Paths are forwarded unchanged; each service owns its `/api/...` prefix. Endpoint
routing compares route order before template specificity, so the API routes and the
gateway's own `/api/{**rest}` endpoint share order 0 and the more specific template wins,
while the frontend catch-all sits at order 1000 and only receives what nothing else
matched. An unknown API path therefore returns the 404 envelope from the gateway instead
of the SPA's index page. The catch-all route forwards the Angular dev server, including
the WebSocket used for hot reload, which YARP proxies without extra configuration. The
`X-Buyer-Id` header passes through untouched. A backend that is down surfaces as a 504
from YARP, converted by the shared problem details writer into the envelope with code
`common.upstream_unavailable`. Routes are added to the gateway configuration in the
phase that creates their service, so a route never points at a resource the AppHost
does not yet know.

Fixed ports from `launchSettings.json`: `https://localhost:7100` and
`http://localhost:5100`. The AppHost marks these endpoints external. Which of the two
is bound depends on the launch profile the AppHost was started with, because child
projects follow it. In development the Angular dev server also forwards `/api` to the
gateway (section 4.7), so the `frontend` link in the dashboard opens a working shop as
well; the gateway stays the only entry to the APIs.

Why a project rather than Aspire's `AddYarp` container: the container integration still
ships the nightly preview YARP image, and the project variant gives the gateway
ServiceDefaults telemetry for free. Switching later is a few lines in the AppHost.

### 4.2 Catalog (`Ecommerce.Catalog.Api`)

Role: owns products and stock. PostgreSQL through EF Core and the Aspire Npgsql EF
integration. Migrations are applied and seed data inserted at startup in development,
so every run begins with a known catalog.

Model:

| Field | Type | Notes |
|---|---|---|
| Id | Guid | |
| Name | string | |
| Description | string | |
| Category | string | one of a small fixed set |
| Price | decimal | EUR |
| AvailableStock | int | never below zero |
| ImageKey | string | key for the frontend's generated placeholder image |

Translations: a `product_translations` table owned by the product (`ProductId`, `Language`,
`Name`, `Description`, `Category`, key on product and language) holds the Serbian text;
the product's own fields are English and the fallback. `Product.WithTranslation` adds or
replaces a language, `Product.Localize(language)` returns the `ProductText` for it. The
language comes from the standard `Accept-Language` header through ASP.NET Core request
localization (supported cultures `en`, `sr` and `sr-Latn`, default `en`), bound into a
`RequestLanguage` parameter whose `Code` is the two-letter language of the negotiated UI
culture. Both endpoints map through `ProductResponse.From(product, language)`, and the
list is ordered by the displayed name. The seed carries Serbian Latin text for all twelve
products and their four categories.

Endpoints:

| Method and path | Purpose | Responses |
|---|---|---|
| `GET /api/catalog/products` | list products; optional `ids` query filter for Basket | 200 |
| `GET /api/catalog/products/{id}` | one product | 200, 404 |

Message handling: consumes `OrderPaid` from queue `catalog.order-paid` through
Wolverine's durable inbox backed by a `wolverine` schema in the catalog database. The
handler runs one guarded update per line:

```sql
UPDATE products SET available_stock = available_stock - @qty
WHERE id = @productId AND available_stock >= @qty
```

If the guard matches no row the handler floors the stock at zero and logs a warning
with order id, product id and the shortfall. That is the only case where an order is
fulfilled beyond stock, and it can happen only when two orders race for the last units
between checkout validation and payment. Stock reservation is out of scope and this
behavior is documented rather than hidden.

Seed data: 12 products in 3 categories. One product is seeded with zero stock so the
disabled state is visible immediately, and one with a stock of 2 so it can sell out
during a demo.

### 4.3 Basket (`Ecommerce.Basket.Api`)

Role: one basket per buyer in Redis, through the Aspire StackExchange.Redis
integration. Key `basket:{buyerId}`, value is the basket as JSON, expiry 7 days
refreshed on every write.

Buyer identity: the `X-Buyer-Id` header, a GUID the frontend generates once and keeps
in local storage. The header is bound into a `BuyerId` value through `BindAsync`, which
never fails binding; a `BuyerIdFilter` on the route group answers `400` with
`common.buyer_id_invalid` when the value is missing or malformed, so the rule lives in
one place.

Model: `ShoppingBasket { BuyerId, Items[] { ProductId, UnitPrice, Quantity } }`
with `ItemCount` and `Total`. The aggregate is named `ShoppingBasket` because inside the
`Ecommerce.Basket.Api` namespaces the identifier `Basket` is the namespace segment. The
unit price stored at add time is what the basket page displays; checkout replaces it
with the current Catalog price in the order snapshot. `BasketService` holds the rules and
the logging; endpoints only map its results to envelopes.

Product names are not stored. Every read (get, upsert, remove) makes one batch lookup to
Catalog for all lines and takes the names from the answer, forwarding the request's
`Accept-Language` through `Microsoft.AspNetCore.HeaderPropagation`, so the basket shows
names in the buyer's current language and the order lines placed at checkout carry the
names in the language active then. A product Catalog no longer knows is shown by its id.
When Catalog cannot be reached, reads answer `503 basket.catalog_unavailable`, as the
upsert always did.

Endpoints:

| Method and path | Purpose | Responses |
|---|---|---|
| `GET /api/basket` | the buyer's basket, empty basket if none | 200 |
| `PUT /api/basket/items` | set quantity for a product (adds or updates) | 200 with the basket, the requested and applied quantity and a `capped` flag; 400, 404 product, 409 out of stock, 503 catalog unavailable |
| `DELETE /api/basket/items/{productId}` | remove a line | 200 with the updated basket, also when the line did not exist |
| `POST /api/basket/checkout` | place the order | 202, 400, 409 out of stock, 503 broker unavailable |

Rules for `PUT /api/basket/items`: quantity between 1 and 99; product must exist;
available stock must be at least 1; quantity is capped at available stock and the
response says so with the applied quantity. The Catalog is called through a typed
`HttpClient` on `https+http://catalog-api`; the client translates every transport
failure the resilience handler gives up on (`HttpRequestException`, Polly's timeout and
circuit-breaker exceptions) into one `CatalogUnavailableException`, which the service
maps to a 503 envelope with `basket.catalog_unavailable` after logging a warning. With
the standard resilience defaults that answer arrives after roughly 30 seconds of retries
with backoff, which is visible and intended in a demo.

Checkout request: buyer name, email, shipping address (street, city, postal code,
country), card number (16 digits) and card holder name. Validation uses the built-in
.NET 10 minimal API validation with data annotations. Checkout with an empty basket is
`400`.

Checkout sequence:

1. Read every basket line from Catalog in one call using the `ids` filter.
2. If any product is missing or has less stock than the requested quantity, answer `409`
   with the affected products and keep the basket unchanged, so the buyer can adjust it.
3. Build `OrderPlaced` with a new order id and the current Catalog prices.
4. Publish it through Wolverine's durable outbox. The `order-placed` exchange is a
   durable endpoint backed by a Postgres message store in the basket's own `basketdb`
   database, so `PublishAsync` persists the envelope before returning and Wolverine
   delivers it as soon as the broker is reachable. A checkout therefore succeeds while
   RabbitMQ is down and the order arrives when the broker returns. Only a failure to
   store the envelope surfaces as `503` with `basket.outbox_unavailable`, and then the
   basket is untouched.
5. Delete the basket. Answer `202 Accepted` with the order id.

The outbox replaced an earlier "send inline and fail the request" design: Wolverine's
inline sender retries briefly and then discards a message it cannot deliver, without
throwing to the caller, which would have lost orders silently. `basketdb` holds only
Wolverine's tables in the `wolverine` schema; basket data itself stays in Redis.

Wolverine warns at startup whenever a node has no message handlers, and Basket has none
by design. Its `appsettings.json` sets the `Wolverine.Configuration.HandlerDiscovery`
logger category to `Error`, so the startup log stays clean without touching the default
level.

### 4.4 Ordering (`Ecommerce.Ordering.Api`)

Role: consumes `OrderPlaced`, owns orders in MongoDB through the Aspire MongoDB driver
integration, drives each order through its lifecycle, and serves order history.

Order document (collection `orders`, `_id` is the order id):

| Field | Notes |
|---|---|
| Id, BuyerId | |
| Buyer { Name, Email } | snapshot from checkout |
| ShippingAddress { Street, City, PostalCode, Country } | snapshot |
| CardLast4 | the last four digits, kept for display |
| PaymentCardNumber | the test card number, present only until the payment step completes and then cleared; the simulator has no tokenization step |
| Lines[] { ProductId, ProductName, UnitPrice, Quantity } | snapshot |
| Total | |
| Status | Submitted, Paid, Shipped, PaymentFailed |
| CreatedAt, PaidAt, ShippedAt | |
| FailureReason | set for PaymentFailed |
| PaymentReference | id returned by Payment |
| PaymentAttempts | count of calls to Payment |
| PaidEventPublished | true once `OrderPaid` has been published successfully |
| NextAttemptAt | when the processor should look at the order next |
| LeaseUntil | set while a processor instance is working on the order |

Message handling: consumes `OrderPlaced` from queue `ordering.order-placed` with
inline processing, so the broker acknowledges the message only after the order is
stored. The handler inserts by order id and ignores a duplicate, so a redelivered
message is harmless. The card number is kept on the document only until the payment
step completes, is never logged, and is never returned by an endpoint.

Endpoints, all scoped by the `X-Buyer-Id` header:

| Method and path | Purpose | Responses |
|---|---|---|
| `GET /api/orders` | the buyer's orders, newest first | 200 |
| `GET /api/orders/{id}` | one order | 200, 404 |

### 4.5 Order lifecycle and the processor

```
              Payment approved                 after PaidToShippedDelay
  Submitted ---------------------> Paid --------------------------------> Shipped
      |
      | Payment declined
      v
  PaymentFailed

  Payment unreachable: stay Submitted, NextAttemptAt = now + PaymentRetryDelay
```

`OrderProcessor` is a `BackgroundService` in Ordering. Every `PollInterval` it asks
Mongo for orders that are due and claims each one atomically:

```
filter:  Status in (Submitted, Paid)
         and NextAttemptAt <= now
         and (LeaseUntil is null or LeaseUntil < now)
update:  set LeaseUntil = now + LeaseDuration
```

`FindOneAndUpdate` makes the claim atomic, so two instances never process the same
order, and a crashed instance's lease simply expires. State lives entirely in Mongo,
which is why the processor survives restarts without a Wolverine message store.

Per claimed order:

- `Submitted`: call Payment and increment `PaymentAttempts`. Approved: set `Paid`,
  `PaidAt`, `PaymentReference`, clear the card number and set
  `NextAttemptAt = now + PaidToShippedDelay`, persist, then publish `OrderPaid` through
  the durable outbox and set `PaidEventPublished`; if the outbox refuses the event, set
  `NextAttemptAt = now + PaymentRetryDelay` and leave the flag false. Declined: set
  `PaymentFailed` with the reason and clear the card number. Transport failure after the
  resilience handler gave up: set `NextAttemptAt = now + PaymentRetryDelay`. There is
  no attempt cap; a waiting order is visible on the orders page and in the logs, which
  is the intended way to show resilience during a demo.
- `Paid`: if `PaidEventPublished` is false, publish `OrderPaid` first and set the flag.
  Then, once `PaidToShippedDelay` has elapsed since `PaidAt`, set `Shipped` and
  `ShippedAt`.
- In every case the lease is released (`LeaseUntil = null`) in the final update.

The state update is written before `OrderPaid` is published. If the process dies
between the two, the next tick finds a `Paid` order without `PaidEventPublished` and
publishes again before shipping. Catalog's durable inbox makes a duplicate publish
harmless. `OrderPaid` goes through a Postgres-backed durable outbox in the
`orderingmessages` database, for the same reason Basket's `OrderPlaced` does: Wolverine
needs a relational message store, orders themselves stay in Mongo, and an event raised
while the broker is down must not be lost.

Configuration (`Ordering:Processor` section) with defaults:

| Setting | Default |
|---|---|
| PollInterval | 1 s |
| LeaseDuration | 30 s |
| PaidToShippedDelay | 5 s |
| PaymentRetryDelay | 5 s |

`TimeProvider` is injected everywhere time is read, so the processor and the state
transitions are unit-testable with a fake clock.

### 4.6 Payment (`Ecommerce.Payment.Api`)

Role: stands in for an external payment provider. Stateless, no database. Uses
ServiceDefaults so its traces and health show in the dashboard.

Endpoint:

| Method and path | Purpose | Responses |
|---|---|---|
| `POST /api/payments` | authorize a payment | 200 with result, 400 |

Request: `orderId`, `amount`, `currency`, `cardNumber`, `cardHolder`. Response:
`paymentId`, `status` (`Approved` or `Declined`), `reason` (`card_declined` when
declined). Ordering calls it through a typed `HttpClient` on `https+http://payment-api`
and treats any transport failure or non-success status as `PaymentUnavailableException`,
which the processor turns into a scheduled retry.

Behavior: waits `Payment:ProcessingDelay` (default 1.5 s) to feel like a real
provider, then applies the test card rule. Deterministic outcomes let the presenter
choose what happens.

| Card number | Result |
|---|---|
| Any 16-digit number ending in `0002`, for example `4000 0000 0000 0002` | Declined, reason `card_declined` |
| Any other 16-digit number, for example `4242 4242 4242 4242` | Approved |

The checkout form is prefilled with the approving number. Amount and currency are
echoed back and not otherwise checked.

Trade-off, stated: because Payment keeps no state it cannot deduplicate by order id.
Ordering's lease prevents concurrent double calls, but a crash between an approval and
the Mongo update would authorize again on retry. A real provider dedupes with an
idempotency key; this simulator does not.

### 4.7 Frontend (`ecommerce-frontend`)

Angular 22 with standalone components, signals, OnPush change detection and Angular
Material. Served in development by the Angular dev server, which Aspire starts through
`AddViteApp` and reaches through the gateway's catch-all route. The dev server's
`proxy.conf.mjs` forwards `/api` to the gateway address that the AppHost injects through
`frontend.WithReference(gateway)` (`services__gateway__http__0`), so the frontend's own
URL in the dashboard serves a working shop too; without the variable it falls back to
`http://localhost:5100` for a manual `ng serve`.

Layout: header with the text label "E-Commerce Aspire Demo" on the left, a language
menu (English, Srpski) and navigation to Products, Basket and Orders, and a basket item count. Sticky footer with
"Goran Todorovic 2026 - Master". Modern, simple, Material defaults with a single
accent color; no external images or fonts, so the demo runs offline. Product images are
generated placeholders (a colored tile derived from `ImageKey` with the product's
initials).

Views:

| Route | View | Behavior |
|---|---|---|
| `/products` | product grid | name, category, price, stock indicator, add-to-basket; out-of-stock products render disabled with an "Out of stock" label |
| `/basket` | basket | plus and minus controls, remove, per-line and basket totals, snack bar feedback; the checkout button arrives with phase 4 |
| `/checkout` | checkout form | buyer, address, card (prefilled with the approving test card); place order navigates to `/orders` |
| `/orders` | order history | status per order; polls every 3 s only while this view is open and either at least one order is `Submitted` or `Paid` or the order placed a moment ago is not listed yet (checkout is asynchronous, so the first fetch can predate the order); shows a waiting notice instead of the empty state in that case and a "Watching for status changes" hint while polling |

Structure: `core/` (buyer id service and HTTP interceptor, the language store, language
interceptor and i18n helpers, API clients, the pending order service, the
`BasketStore`, layout components), `features/` (products, basket, checkout, orders),
`shared/` (models, placeholder image component). All API calls use relative `/api/...`
URLs. The interceptor adds `X-Buyer-Id` from local storage, generating the GUID on first
use. `BasketStore` is the single source of truth for the basket in the browser: the root
component loads it once at startup, every mutation replaces it with the server's copy,
the header badge and the pages read its signals, and the products page's add action
requests the current line quantity plus one so capping is reported by the server.

Localization: Transloco with JSON dictionaries in `public/i18n/en.json` and `sr.json`,
loaded over HTTP. `LanguageStore` reads the buyer's preference from `/api/preferences` in
an app initializer, so the first render is already in the right language, applies a
choice at once (active language, `html lang`) and stores it with `PUT /api/preferences`;
a failed store is reported in a snack bar and the language stays for the visit. The
`languageInterceptor` sends `Accept-Language` (`en` or `sr-Latn`) on every API call unless
the caller set it; the products resource includes the header itself so it reloads on a
switch, and the root component reloads the basket on every language change. Prices and
dates format through `transloco-locale` (`en-US`, `sr-Latn-RS`). Order statuses map to
`status.*` keys; API error codes map to `errors.*` keys when the dictionary has them and
otherwise show the server's message; payment failure reasons likewise under `reasons.*`.
The brand and the footer credit are names and stay untranslated.

Tooling: Angular CLI as a project dependency, ESLint with angular-eslint, Prettier,
Vitest for unit specs. `package.json` has a `dev` script that runs `ng serve`; Aspire
starts it as `npm run dev -- --port <assigned port>` and also sets the `PORT` variable,
and runs `npm install` first through a companion `frontend-installer` resource.
`.nvmrc` contains `24`. Angular Material is installed as a package and themed by hand in
`styles.scss` with the system font stack, because the Material `ng add` schematic would
add external Google Fonts and icon links that an offline demo must not depend on.

### 4.8 Preferences (`Ecommerce.Preferences.Api`)

Role: the buyer's settings, today only the language. Redis through the Aspire
StackExchange.Redis integration on the same `redis` resource Basket uses, key
`preferences:{buyerId}`, JSON value, no expiry. The `X-Buyer-Id` header identifies the
buyer exactly as in Basket, through `BuyerIdFilter`.

Endpoints:

| Method | Path | Result |
|---|---|---|
| GET | `/api/preferences` | `{ language }`, `en` when nothing is stored |
| PUT | `/api/preferences` | body `{ language }`; `200` with the stored value, `400 preferences.unsupported_language` with the supported list in `details` |

`Languages.Supported` is `en` and `sr`. `PreferencesService` holds the rule and the log
line; the store is an interface with a Redis implementation and an in-memory fake for
tests. Fixed ports 7150 and 5150.

## 5. Messaging

### 5.1 Contracts (`Ecommerce.Contracts`)

Immutable records, versioned by name if they ever change.

```csharp
public sealed record OrderPlaced(
    Guid OrderId,
    Guid BuyerId,
    OrderBuyer Buyer,
    OrderAddress ShippingAddress,
    OrderCard Card,                 // Number and HolderName; consumed by Ordering, never stored
    IReadOnlyList<OrderLine> Lines, // ProductId, ProductName, UnitPrice, Quantity
    decimal Total,
    string Currency,
    DateTimeOffset PlacedAt);

public sealed record OrderPaid(
    Guid OrderId,
    IReadOnlyList<OrderPaidLine> Lines, // ProductId, Quantity
    DateTimeOffset PaidAt);
```

The card number travels inside `OrderPlaced` because the simulator has no tokenization
step. In a real system the provider tokenizes the card in the browser and the event
carries a token. This is a stated simplification; the number is a test card and no
service persists it.

### 5.2 Topology

Wolverine provisions everything at startup (`AutoProvision`).

| Exchange | Bound queue | Consumer | Listener mode |
|---|---|---|---|
| `order-placed` | `ordering.order-placed` | Ordering | inline, acknowledged after the order is stored |
| `order-paid` | `catalog.order-paid` | Catalog | durable inbox in the catalog database; the DbContext is registered with `DisableRetry = true` because EF Core forbids user transactions under the retrying execution strategy |

Basket publishes through a durable outbox; Ordering consumes with inline processing so
the broker acknowledges only after the order is stored. Failed handlers retry with
Wolverine's default policy and then move to the dead-letter queue, which is visible in
the RabbitMQ management UI linked from the dashboard. Every project that calls
`UseWolverine` references `WolverineFx.RuntimeCompilation`: Wolverine 6 compiles handler
code at first use and no longer ships the compiler in the core package, so the first
message of a handler takes a second or two longer than the rest.

Wolverine is configured from the Aspire-injected connection string with
`UseRabbitMqUsingNamedConnection("messaging")`. Its trace source and meters are added
in ServiceDefaults, so message hops appear inside the same trace as the HTTP calls
around them.

### 5.3 Delivery semantics, summarized

| Hop | Guarantee | Why it is safe |
|---|---|---|
| Basket publishes OrderPlaced | at least once | durable outbox in Postgres, delivered when the broker is reachable |
| Ordering consumes OrderPlaced | at least once | upsert by order id |
| Ordering publishes OrderPaid | at least once | durable outbox in Postgres, plus a flag on the order re-published if missing |
| Catalog consumes OrderPaid | exactly once effect | durable inbox plus guarded update, inside an EF Core transaction opened by Wolverine |

## 6. AppHost

`Ecommerce.AppHost/AppHost.cs`, the whole orchestration:

```csharp
using JasperFx.Aspire;

var builder = DistributedApplication.CreateBuilder(args);

// Infrastructure
var postgres   = builder.AddPostgres("postgres");
var catalogDb  = postgres.AddDatabase("catalogdb");
var basketDb   = postgres.AddDatabase("basketdb");
var orderingMessagesDb = postgres.AddDatabase("orderingmessages");
var redis      = builder.AddRedis("redis");
var rabbitMq   = builder.AddRabbitMQ("messaging").WithManagementPlugin();
var mongo      = builder.AddMongoDB("mongo");
var orderingDb = mongo.AddDatabase("orderingdb");

// Services
var catalogApi = builder.AddProject<Projects.Ecommerce_Catalog_Api>("catalog-api")
    .WithReference(catalogDb).WaitFor(catalogDb)
    .WithReference(rabbitMq).WaitFor(rabbitMq)
    .WithHttpHealthCheck("/health")
    .WithJasperFxCommands();

var basketApi = builder.AddProject<Projects.Ecommerce_Basket_Api>("basket-api")
    .WithReference(redis).WaitFor(redis)
    .WithReference(basketDb).WaitFor(basketDb)
    .WithReference(rabbitMq).WaitFor(rabbitMq)
    .WithReference(catalogApi).WaitFor(catalogApi)
    .WithHttpHealthCheck("/health")
    .WithJasperFxCommands();

var paymentApi = builder.AddProject<Projects.Ecommerce_Payment_Api>("payment-api")
    .WithHttpHealthCheck("/health");

var preferencesApi = builder.AddProject<Projects.Ecommerce_Preferences_Api>("preferences-api")
    .WithReference(redis).WaitFor(redis)
    .WithHttpHealthCheck("/health");

var orderingApi = builder.AddProject<Projects.Ecommerce_Ordering_Api>("ordering-api")
    .WithReference(orderingDb).WaitFor(orderingDb)
    .WithReference(orderingMessagesDb).WaitFor(orderingMessagesDb)
    .WithReference(rabbitMq).WaitFor(rabbitMq)
    .WithReference(paymentApi)
    .WithHttpHealthCheck("/health")
    .WithJasperFxCommands();

// Frontend
var frontend = builder.AddViteApp("frontend", "../ecommerce-frontend");

// Gateway, the only entry to the APIs
var gateway = builder.AddProject<Projects.Ecommerce_Gateway>("gateway")
    .WithReference(catalogApi).WaitFor(catalogApi)
    .WithReference(basketApi).WaitFor(basketApi)
    .WithReference(orderingApi).WaitFor(orderingApi)
    .WithReference(preferencesApi).WaitFor(preferencesApi)
    .WithReference(frontend)
    .WithHttpHealthCheck("/health")
    .WithExternalHttpEndpoints();

// The dev server proxies /api to the gateway, so the frontend URL in the dashboard works on its own
frontend.WithReference(gateway);

builder.Build().Run();
```

Notes:

- Containers use the default session lifetime and no data volumes, so every run starts
  from the seeded state. Persistent lifetime can be switched on later for faster
  startup if repeatable state stops mattering.
- `WaitFor` gates a service on its dependencies' health checks. Basket waits for
  Catalog so the first add-to-basket never races the seeding.
- `WithHttpHealthCheck("/health")` is what makes a project resource report health at
  all. Without it Aspire treats the process as ready the moment it starts, the dashboard
  shows no health state, and `WaitFor` on that project would not wait for its
  initialization.
- Ordering does not wait for Payment on purpose. An unavailable Payment is a runtime
  condition the processor handles, and that is the resilience demonstration.
- `WithJasperFxCommands` comes from the `JasperFx.Aspire` package and adds Wolverine's
  read-only diagnostic commands to the resource tiles: `jasperfx-check-env`,
  `jasperfx-describe` and `jasperfx-codegen-preview`. Each button runs
  `dotnet run --project <service> --no-build -- <verb>` with the resource's environment
  and streams the output into the resource's console log, which is why the three
  Wolverine services end their `Program.cs` with `RunJasperFxCommands(args)`; started
  without arguments the same executable runs the web host as before.
- `AddViteApp` installs npm packages if needed, runs the `dev` script, and passes the
  port through the `PORT` environment variable.
- Every .NET project has fixed ports in its `launchSettings.json`, which Aspire honors,
  so URLs never change between runs:

| Resource | HTTPS | HTTP |
|---|---|---|
| AppHost dashboard | 17000 | 15000 |
| gateway | 7100 | 5100 |
| catalog-api | 7110 | 5110 |
| basket-api | 7120 | 5120 |
| ordering-api | 7130 | 5130 |
| payment-api | 7140 | 5140 |
| preferences-api | 7150 | 5150 |

## 7. Cross-cutting concerns

### 7.1 ServiceDefaults

`Ecommerce.ServiceDefaults` is the standard Aspire service defaults project, generated
from the template and referenced by every .NET project. `AddServiceDefaults()` and
`MapDefaultEndpoints()` in `Extensions.cs` are what Aspire supplies:

- OpenTelemetry logging, metrics and tracing with the OTLP exporter the dashboard
  expects. Instrumentation for ASP.NET Core, HttpClient and the runtime. Aspire client
  integrations add Npgsql, Redis and MongoDB instrumentation on their own. The one
  local addition to the template's telemetry setup is the `Wolverine` trace source and
  the `Wolverine*` meters, so message hops land in the same traces as the HTTP calls.
- Health checks: `/health` runs every registered check, `/alive` only the liveness
  check. Client integrations register a check per dependency.
- Service discovery on every `HttpClient`, so `https+http://catalog-api` resolves.
- The standard resilience handler on every `HttpClient`: request timeout, retry with
  backoff, circuit breaker, total timeout. Defaults are kept, since they are what a
  new team would get.

Nothing else lives in this project. The shared API code every service also needs is
project code, not Aspire code, and has its own project, described in 7.2.

### 7.2 Shared API conventions (`Ecommerce.ApiDefaults`)

Everything in this subsection is code written for this solution. It lives in
`Ecommerce.ApiDefaults`, a small class library every web project references next to
ServiceDefaults. The library references ServiceDefaults, because `UseApiDefaults` calls
the template's `MapDefaultEndpoints`; nothing in it comes from Aspire. The conventions
every service follows when it uses that code are listed with it.

- Response envelope: every response body is `success`, `data` and `error` with `code`,
  `message`, `details` and `traceId`, as the `ApiResponse<T>`, `ApiResponse` and
  `ApiError` records. `ApiResults` builds the `IResult` for each status and
  `CommonErrorCodes` holds the `common.*` codes. The full shape and the error code
  convention are in the coding guidelines.
- Problem details writer: `ApiEnvelopeProblemDetailsWriter` is an `IProblemDetailsWriter`
  that converts every problem details the framework produces, such as validation
  failures, unhandled exceptions and bodiless status codes like `404`, into the
  envelope, so nothing leaves a service in another shape.
- Registration in two layers: `AddApiErrorHandling`/`UseApiErrorHandling` register the
  writer, the exception handler and status code pages for any web project including
  the gateway; `AddApiDefaults`/`UseApiDefaults` add OpenAPI, Scalar and the health
  endpoints from 7.1 on top for the APIs.
- Buyer identity: `BuyerId` binds from the `X-Buyer-Id` header through `BindAsync` and
  never fails binding; `BuyerIdFilter` on a route group answers `400` with
  `common.buyer_id_invalid` when the header is missing or malformed. Basket, Ordering
  and Preferences share both.
- Minimal APIs, one route group per service prefix, one static `Map...` class per
  feature.
- Request models are records validated with data annotations through the .NET 10
  built-in minimal API validation.
- OpenAPI document via `Microsoft.AspNetCore.OpenApi`, browsable with Scalar in
  development at `/scalar`. Both packages come in through `Ecommerce.ApiDefaults`. Each
  service's Scalar page is reachable from the dashboard's endpoint links.
- Money is `decimal`, currency is `EUR` everywhere; the frontend formats it.

### 7.3 Data access

- Catalog: EF Core with a `CatalogDbContext`, migrations in the project, applied at
  startup in development together with seeding. The initializer creates the migrations
  history table before calling `MigrateAsync`, because the Npgsql provider reads that
  table before creating it and logs the read as a failed command on every fresh
  database. The context comes from Aspire's Npgsql
  integration with `DisableRetry = true`, and Wolverine's EF Core integration wraps
  every handler in a transaction on it, so the inbox record and the stock update
  commit together and Aspire still provides health and telemetry.
- Basket: `IConnectionMultiplexer` from the Aspire Redis integration, `System.Text.Json`
  serialization.
- Ordering: `IMongoClient` from the Aspire MongoDB integration, one typed collection,
  an index on `BuyerId` and one on `(Status, NextAttemptAt)` created at startup.

## 8. Testing

| Project | Covers | Notes |
|---|---|---|
| `Ecommerce.ApiDefaults.Tests` | envelope records, `ApiResults`, the problem details writer, registration order, `BuyerId` binding and filter | plain `DefaultHttpContext`, no test server |
| `Ecommerce.Basket.Api.Tests` | quantity capping, out-of-stock rejection, totals, checkout validation outcomes | Catalog client and store behind small interfaces, faked in tests |
| `Ecommerce.Ordering.Api.Tests` | state transitions, processor decisions for approved, declined and unreachable payment, `OrderPlaced` handler mapping | fake clock through `TimeProvider`, fake payment client and store |
| `Ecommerce.Catalog.Api.Tests` | entity invariants, seed data, seeding, list and get handlers, `OrderPaid` handler decision logic | handlers run against SQLite in-memory through the real EF Core provider; the guarded Postgres update is covered by the integration test |
| `Ecommerce.Payment.Api.Tests` | test card rule, request validation | |
| `Ecommerce.Preferences.Api.Tests` | supported languages and the default, service and endpoints over an in-memory store | |
| `Ecommerce.IntegrationTests` | the full purchase, the dev server proxy, the preference round trip, Serbian names through the gateway and the basket | see below |
| frontend Vitest specs | buyer id and language interceptors, basket count, orders polling and the pending order, language store, language menu, translated pages | |

Integration test flow: an xUnit collection fixture, shared by every test class so the
AppHost boots once per run, builds the AppHost with `DistributedApplicationTestingBuilder`,
starts it, waits for `gateway`, `payment-api` and `frontend` to be healthy and creates an
`HttpClient` for the gateway's http endpoint and one for the frontend's. The tests
talk only through that client: read a product's stock, add it to a basket under a fresh
buyer id, check out with the approving card, poll the order until `Shipped` (a `404`
right after checkout only means the asynchronous `OrderPlaced` has not arrived yet),
then poll the product until its stock has dropped by the ordered quantity. A second test
checks out with the declining card and asserts `PaymentFailed` with `card_declined` and
unchanged stock. Polling returns the last observed value when the timeout passes, so a
failed assertion shows what the system actually did. The whole run takes about forty
seconds including the container starts and leaves nothing behind.

xUnit v3 on the Microsoft Testing Platform for all .NET tests, selected through
`global.json`. No mocking framework unless a test genuinely needs one; small hand-written
fakes are preferred.

## 9. Dependencies and licenses

Rule for this project: every dependency is open source under a license that requires
no personal or commercial license key. Versions are the current ones as of
2026-09-12 and are managed centrally in `Directory.Packages.props`.

| Package | Version | License | Used by |
|---|---|---|---|
| Aspire.Hosting.AppHost | 13.5.3 | MIT | AppHost |
| Aspire.Hosting.PostgreSQL, Redis, RabbitMQ, MongoDB | 13.5.3 | MIT | AppHost |
| Aspire.Hosting.JavaScript | 13.5.3 | MIT | AppHost |
| Aspire.Hosting.Testing | 13.5.3 | MIT | IntegrationTests |
| JasperFx.Aspire | 2.68.0 | MIT | AppHost |
| Aspire.Npgsql.EntityFrameworkCore.PostgreSQL | 13.5.3 | MIT | Catalog |
| Aspire.StackExchange.Redis | 13.5.3 | MIT | Basket, Preferences |
| Microsoft.AspNetCore.HeaderPropagation | 10.0.12 | MIT | Basket |
| Aspire.MongoDB.Driver | 13.5.3 | MIT | Ordering |
| Microsoft.Extensions.ServiceDiscovery, .Http.Resilience | 10.10.0 | MIT | ServiceDefaults |
| OpenTelemetry.* | 1.18.0 | Apache 2.0 | ServiceDefaults |
| Yarp.ReverseProxy | 2.3.0 | MIT | Gateway |
| Microsoft.Extensions.ServiceDiscovery.Yarp | 10.10.0 | MIT | Gateway |
| WolverineFx | 6.36.0 | MIT | Catalog, Basket, Ordering |
| WolverineFx.RabbitMQ | 6.36.0 | MIT | Catalog, Basket, Ordering |
| WolverineFx.RuntimeCompilation | 6.36.0 | MIT | every project calling UseWolverine |
| WolverineFx.Postgresql | 6.36.0 | MIT | Basket (outbox), Catalog (inbox) |
| WolverineFx.EntityFrameworkCore | 6.36.0 | MIT | Catalog |
| Microsoft.Extensions.TimeProvider.Testing | 10.10.0 | MIT | tests only |
| Microsoft.EntityFrameworkCore.* | 10.0.12 | MIT | Catalog |
| Microsoft.EntityFrameworkCore.Design | 10.0.12 | MIT | Catalog, build time only |
| Microsoft.EntityFrameworkCore.Sqlite | 10.0.12 | MIT | Catalog tests only |
| Npgsql.EntityFrameworkCore.PostgreSQL | 10.0.x | PostgreSQL | Catalog, transitive |
| dotnet-ef (global tool) | 10.x | MIT | developer machine |
| MongoDB.Driver | 3.x | Apache 2.0 | Ordering |
| Microsoft.AspNetCore.OpenApi | 10.0.12 | MIT | ApiDefaults |
| Scalar.AspNetCore | 2.17.3 | MIT | ApiDefaults |
| xunit.v3 | 4.0.0 | Apache 2.0 | tests, the only test package needed on .NET 10 |
| Angular, Angular Material, Angular CLI | 22.x | MIT | frontend |
| @jsverse/transloco, @jsverse/transloco-locale | 8.4.0 | MIT | frontend |
| angular-eslint, ESLint, Prettier, Vitest | current | MIT | frontend |

Deliberately excluded because they now require a commercial license: MassTransit v9,
MediatR, AutoMapper. None is needed.

Container images: `postgres`, `redis`, `rabbitmq` with management, `mongo`, all pulled
by the Aspire hosting integrations under their upstream open source licenses.

## 10. Conventions baseline

The full rules are in [CODING_GUIDELINES.md](CODING_GUIDELINES.md). The headline
decisions:

- .NET 10, C# 14, `global.json` pinned to the installed SDK.
- `Directory.Build.props`: nullable enabled, implicit usings, default analyzers only,
  warnings allowed but fixed before hand-over.
- File-scoped namespaces, records for contracts and request/response models, primary
  constructors where they read well, `//` comments only and only where needed.
- One feature per folder, one static endpoint class per feature, no MediatR-style
  dispatch, no generic repositories, no mapping libraries.
- Uniform API response envelope with machine-readable error codes.
- Logging through `ILogger` message templates in the format
  `[{Prefix}] message with values in [brackets]`, no trailing full stop.
- Time through `TimeProvider`, GUIDs through `Guid.CreateVersion7()`.
- Angular: strict TypeScript, standalone components, signals and `OnPush`, ESLint and
  Prettier enforced.

## 11. Local setup and running

Prerequisites on this machine:

| Tool | Requirement | Status on 2026-09-12 |
|---|---|---|
| .NET SDK | 10.0.x | 10.0.201 installed |
| Aspire CLI | `dotnet tool install -g Aspire.Cli` | 13.5.3 installed |
| Docker | running daemon | 28.1.1 installed |
| Node | 24.x through nvm | 24.18.0 installed, default is 22 |

First run:

```bash
dotnet tool install -g Aspire.Cli
cd src/ecommerce-frontend && nvm use && npm ci && cd ../..
source "$HOME/.nvm/nvm.sh" && nvm use 24
aspire run --apphost src/Ecommerce.AppHost/Ecommerce.AppHost.csproj
```

`aspire run` starts the AppHost and prints the dashboard URL; Node must be on the PATH
of that shell because Aspire launches the Angular dev server from it. `dotnet run
--project src/Ecommerce.AppHost` does the same without the CLI. The demo itself is at
`https://localhost:7100`. Tests run with `dotnet test` from the solution root; the
integration tests need Docker, and Node on the PATH lets the frontend start but the
tests do not depend on it.

Known risk and fallback: hot reload for Angular runs over a WebSocket proxied by the
gateway. If it misbehaves on a given machine, the frontend can be opened on its own
Aspire-assigned port for development, with the gateway still serving `/api`.

## 12. Out of scope

Authentication and authorization, real payment integration, stock reservation at
checkout, categories navigation and search, a product detail page, SignalR or other
push channels, chaos or fault injection, load generation, deployment manifests and
pipelines, CORS configuration (unnecessary with a single origin).

## 13. Decision log

| Decision | Alternatives considered | Reason |
|---|---|---|
| Wolverine for messaging | MassTransit, Rebus, raw RabbitMQ client | MassTransit v9 is commercial and v8 support ends in 2026; Wolverine is MIT with an explicit open core commitment, has native Aspire support and OpenTelemetry built in |
| Gateway as a .NET YARP project | Aspire `AddYarp` container | container integration still uses the nightly preview image; the project gets ServiceDefaults telemetry |
| Persisted order processor | Wolverine scheduled messages | scheduled messages are durable only with a relational message store, which Ordering has no other reason to own |
| Durable inbox only in Catalog | application-level idempotency table | the inbox is the standard Wolverine practice and costs a few lines; Catalog already owns Postgres |
| Durable outboxes in Basket and Ordering | inline publish that fails the request | Wolverine's inline sender discards an undeliverable message without throwing, which lost an order during the broker outage check; a small Postgres message store per publisher keeps the event until the broker returns |
| Card number kept on the order until payment completes | never persist it | a retry after a Payment outage needs something to charge; the number is cleared when the payment step ends and is never logged or returned |
| `DisableRetry` on the Catalog DbContext | keep the retrying strategy and drop Wolverine's transaction | EF Core refuses user transactions under the retrying strategy, and the inbox record and the stock update must commit together |
| History table created before `MigrateAsync` | accept the failed read in the log | the Npgsql provider reads the history table before creating it and logs the read as a failed command on every fresh database |
| Logger category filter for Wolverine handler discovery in Basket | leave the warning | Wolverine warns whenever a node has no handlers, which is Basket's design; the filter says so in configuration instead of noise on every start |
| JasperFx commands on the Wolverine services | none | three read-only dashboard buttons for one package and a one-line change per `Program.cs` |
| Integration tests through the gateway only | direct database assertions | the test sees what a user sees and stays independent of the storage choices |
| Polling on the orders page | SignalR | a hub, event subscription and reconnection logic for a status that arrives in seconds; polling is limited to in-progress orders to keep traces clean |
| Test card numbers | random payment outcome | the presenter can trigger a decline on demand |
| Buyer id header | login | no auth in scope; per-browser identity is enough for baskets and history |
| Single origin through the gateway | Angular dev proxy to APIs | mirrors production topology and removes CORS entirely |
| Built-in minimal API validation | FluentValidation | ships with .NET 10, no extra dependency |
| Response envelope on every API | problem details as the error shape | one predictable body for success and failure; framework errors are converted by a problem details writer so nothing escapes the shape |
| Shared API code in its own `Ecommerce.ApiDefaults` project | keep it inside the ServiceDefaults assembly under `Api/`, where it first lived | ServiceDefaults stays what the template generates, so nobody reads the envelope or the buyer identity as Aspire features; the price is one more project reference per service |
| Default analyzers, warnings allowed | latest-recommended analysis with warnings as errors | demo project; strict analysis is a production concern, the build is still kept warning-free |
