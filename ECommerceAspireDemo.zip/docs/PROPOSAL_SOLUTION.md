> **Superseded.** This was the initial proposal. The agreed design is in [ARCHITECTURE.md](ARCHITECTURE.md).

# Technical Specification & Project Structure: Cloud-Native eCommerce (.NET Aspire)

This document provides a detailed overview of the architecture, directory structure, and configuration steps for the practical implementation of the master's thesis titled **"Development of Cloud-Native Microservices Architecture Using the .NET Aspire Framework"**.

---

## 🏗️ 1. System Architecture Overview

The system is designed as a distributed ecosystem composed of autonomous microservices that communicate both synchronously (via HTTP/REST) and asynchronously (via a message broker).

```text
                                  +-----------------------------------+

                                  |         Angular Frontend          |
                                  |     (Local Port: Dynamic)         |
                                  +-----------------------------------+
                                            /               \
                                    (HTTP) /                 \ (HTTP)
                                          v                   v
+------------------------------------------+                 +------------------------------------------+

|             Catalog Web API              |                 |              Basket Web API              |
|  - Technology: .NET Minimal API          |                 |  - Technology: .NET Minimal API          |
|  - Storage: PostgreSQL                   |                 |  - Storage: Redis Cache                  |
+------------------------------------------+                 +------------------------------------------+
                                          \                   /
                                           \                 /
                                     (Event: Order Placed)
                                             \             /
                                              v           v
                                 +-------------------------------------+

                                 |           RabbitMQ Broker           |
                                 |            (Message Bus)            |
                                 +-------------------------------------+
                                                    |
                                                    | (Asynchronous Read)
                                                    v
                                 +-------------------------------------+

                                 |      Ordering Background Worker     |
                                 |  - Technology: .NET Worker Service  |
                                 |  - Storage: MongoDB                 |
                                 +-------------------------------------+
```

---

## 📂 2. Directory Structure (Solution Architecture)

Inside the root solution folder (`EcommerceAspireSolution`), create the following directory and project structure:

```text
📁 EcommerceAspireSolution/
│
├── 📁 src/
│   │
│   ├── 📁 Ecommerce.AppHost/              <-- Central .NET Aspire Orchestrator (C#)
│   │   ├── Program.cs
│   │   └── Ecommerce.AppHost.csproj
│   │
│   ├── 📁 Ecommerce.ServiceDefaults/      <-- Shared Telemetry, Health Checks & Polly Policies
│   │   ├── Extensions.cs
│   │   └── Ecommerce.ServiceDefaults.csproj
│   │
│   ├── 📁 Ecommerce.Catalog.Api/          <-- Product Catalog Service (Minimal API)
│   │   ├── Program.cs
│   │   └── Ecommerce.Catalog.Api.csproj
│   │
│   ├── 📁 Ecommerce.Basket.Api/           <-- Shopping Cart Service (Minimal API)
│   │   ├── Program.cs
│   │   └── Ecommerce.Basket.Api.csproj
│   │
│   ├── 📁 Ecommerce.Ordering.Worker/      <-- Background Order Processing (Worker Service)
│   │   ├── Worker.cs
│   │   └── Ecommerce.Ordering.Worker.csproj
│   │
│   └── 📁 ecommerce-frontend/             <-- Angular SPA Client (TypeScript / Node.js)
│       ├── package.json
│       ├── angular.json
│       └── 📁 src/
│
└── EcommerceAspireSolution.sln            <-- Global Visual Studio Solution File
```

---

## 🛠️ 3. Detailed Component Breakdown

### 3.1. Ecommerce.AppHost (Orchestration Project)
* **Role:** The central entry point of the application. It replaces the need for external `docker-compose.yml` files by managing the lifecycle of containers, databases, and applications directly from C# code.
* **Key NuGet Packages:**
  * `Aspire.Hosting.AppHost`
  * `Aspire.Hosting.PostgreSQL`
  * `Aspire.Hosting.Redis`
  * `Aspire.Hosting.RabbitMQ`
  * `Aspire.Hosting.MongoDB`
  * `Aspire.Hosting.NodeJs` (Required to run Angular via NPM)

### 3.2. Ecommerce.ServiceDefaults (Infrastructure Project)
* **Role:** Automatically configures cross-cutting concerns for all .NET projects within the system.
* **Key Features:**
  * **OpenTelemetry:** Configures metrics, logging, and distributed tracing.
  * **Health Checks:** Exposes `/health` and `/alive` endpoints for orchestrators.
  * **Polly Resiliency:** Configures standard HTTP clients with automated retry and circuit breaker strategies.

### 3.3. Ecommerce.Catalog.Api (Product Catalog Microservice)
* **Role:** Manages products, categories, inventories, and pricing.
* **Database:** **PostgreSQL**.
* **Technical Details:** Uses *Entity Framework Core* for data mapping and migrations. Exposes RESTful endpoints (e.g., `GET /api/catalog/products`).

### 3.4. Ecommerce.Basket.Api (Temporary Shopping Cart Microservice)
* **Role:** Stores, updates, and deletes items that users add to their shopping carts before checkout.
* **Database:** **Redis** (In-memory cache).
* **Technical Details:** Requires ultra-low latency and high performance. When a user submits an order, this service publishes an event to RabbitMQ and clears the cache.

### 3.5. Ecommerce.Ordering.Worker (Background Order Processor)
* **Role:** Consumes order placement messages from the RabbitMQ queue, handles final verification, and stores invoices.
* **Database:** **MongoDB** (Document-based).
* **Technical Details:** Extends the `.NET BackgroundService`. It utilizes MongoDB because the order acts as a point-in-time snapshot, nesting cart and user data into a single, immutable JSON document.

### 3.6. ecommerce-frontend (User Interface)
* **Role:** Single Page Application (SPA) built using the **Angular** framework.
* **Technical Details:** Communicates purely via asynchronous HTTP requests to `Catalog.Api` and `Basket.Api`. The base URLs and ports of these API endpoints are dynamically injected into Angular via environment variables managed by the .NET Aspire AppHost.

---

## 🚀 4. Master Configuration Blueprint (`AppHost/Program.cs`)

When implementing the orchestrator, the code inside the central `Program.cs` file must follow this declarative blueprint:

```csharp
var builder = DistributedApplication.CreateBuilder(args);

// 1. Define External Resources (Containers & Databases)
var postgres = builder.AddPostgres("postgres").WithPgAdmin();
var catalogDb = postgres.AddDatabase("CatalogDb");

var redis = builder.AddRedis("basket-cache");
var rabbitMq = builder.AddRabbitMQ("messaging");
var mongo = builder.AddMongoDB("ordering-db");

// 2. Register & Interconnect .NET Microservices
var catalogApi = builder.AddProject<Projects.Ecommerce_Catalog_Api>("catalog-api")
    .WithReference(catalogDb);

var basketApi = builder.AddProject<Projects.Ecommerce_Basket_Api>("basket-api")
    .WithReference(redis);

builder.AddProject<Projects.Ecommerce_Ordering_Worker>("ordering-worker")
    .WithReference(rabbitMq)
    .WithReference(mongo);

// 3. Integrate the Angular SPA Client
builder.AddNpmApp("angular-frontend", "../ecommerce-frontend", "start")
    .WithReference(catalogApi)
    .WithReference(basketApi)
    .WithHttpEndpoint(env: "PORT")
    .PublishAsDockerFile();

builder.Build().Run();
```

---

## 📋 5. Step-by-Step Implementation Roadmap

1.  **Initialization:** Create an empty .NET Aspire project using the default Visual Studio template or via the CLI command: `dotnet new aspire`.
2.  **Create APIs:** Add two `Web API` projects (`Catalog` and `Basket`) and reference `ServiceDefaults` in both.
3.  **Create Worker:** Add a `.NET Worker Service` project for the `Ordering` module.
4.  **Initialize Angular:** Inside the `src` folder, execute the command: `ng new ecommerce-frontend`.
5.  **Wire Up AppHost:** Modify `Program.cs` in the AppHost project to match the configuration shown in Section 4.
6.  **Run the System:** Boot up the `Ecommerce.AppHost` project. The **.NET Aspire Dashboard** will automatically open in your browser, revealing all active services, live container logs, databases, and OpenTelemetry metric dashboards.

