# ECommerce Aspire Demo

A small e-commerce shop built to show what Aspire gives a team building a cloud-native
microservice system: orchestration from C#, integrations for databases and brokers,
service discovery, resilience and end-to-end observability. It behaves like a
production system in miniature: no chaos switches, no fault injection, no test-only
code paths. Resilience is shown by stopping real resources from the dashboard.

The design is in [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md), the coding rules in
[docs/CODING_GUIDELINES.md](docs/CODING_GUIDELINES.md) and the execution plans with
their decision log in [docs/plans](docs/plans/README.md).

## What is in it

| Resource | Technology | Role |
|---|---|---|
| `gateway` | YARP with Aspire service discovery | single entry point, serves the frontend and routes `/api/*` |
| `catalog-api` | EF Core on PostgreSQL, Wolverine durable inbox | products and stock |
| `basket-api` | Redis, Wolverine durable outbox on PostgreSQL | baskets and checkout |
| `ordering-api` | MongoDB, Wolverine durable outbox on PostgreSQL | orders and the order lifecycle |
| `payment-api` | stateless minimal API | stands in for a payment provider |
| `preferences-api` | Redis | each buyer's language, read before the shop's first render |
| `frontend` | Angular with Material, served by the Vite dev server | the shop |
| `postgres`, `redis`, `messaging`, `mongo` | containers | PostgreSQL, Redis, RabbitMQ with the management plugin, MongoDB |

A purchase flows through all of it: the basket checks stock with Catalog, publishes
`OrderPlaced` through its outbox, Ordering stores the order, charges it through
Payment, publishes `OrderPaid` through its outbox, Catalog consumes it through its inbox
and decrements stock, and Ordering ships the order five seconds after payment.

The shop speaks English and Serbian. The language menu in the header switches every text,
the product names, descriptions and categories (Catalog keeps the translations), the
basket line names and the price and date formats, and the choice is stored per buyer in
Redis so it survives a refresh.

## Prerequisites

| Tool | Version |
|---|---|
| .NET SDK | 10.0.x |
| Aspire CLI | 13.5.3, `dotnet tool install -g Aspire.Cli` |
| Docker | running daemon |
| Node | 24 through nvm, for the frontend |

## Run

Node must be on the PATH of the shell that starts the AppHost, because Aspire launches
the Angular dev server from it:

```bash
source "$HOME/.nvm/nvm.sh" && nvm use 24
aspire run --apphost src/Ecommerce.AppHost/Ecommerce.AppHost.csproj
```

An IDE started from the Dock does not see the PATH your shell builds, so either load nvm
from `~/.zprofile` and make 24 the default (`nvm alias default 24`) or put the node
directory on `PATH` in the AppHost run configuration.

The command prints the dashboard URL. Open the shop from the dashboard: the `frontend`
link opens the Angular dev server, which forwards `/api` calls to the gateway, and the
`gateway` link serves the same shop through YARP. Child projects follow the launch
profile the AppHost was started with: under `https` the gateway is at
`https://localhost:7100`, under `http` at `http://localhost:5100`. The dashboard is at
`https://localhost:17000`. Every project has a fixed port, so the URLs never change
between runs:

| Resource | HTTPS | HTTP |
|---|---|---|
| gateway | 7100 | 5100 |
| catalog-api | 7110 | 5110 |
| basket-api | 7120 | 5120 |
| ordering-api | 7130 | 5130 |
| payment-api | 7140 | 5140 |
| preferences-api | 7150 | 5150 |

Each API publishes an OpenAPI document and a Scalar reference page at `/scalar`, linked
from its resource in the dashboard.

## Walk through the demo

1. Open the shop, add a few products to the basket and check out. The card field is
   prefilled with the approving test card.
2. Open the orders page. The order appears as Submitted, turns Paid within a few
   seconds and Shipped five seconds later. Back on the products page the stock has
   dropped.
3. In the dashboard, open Traces and pick the checkout request. One trace spans the
   gateway, Basket, Catalog, the broker, Ordering, Payment, the broker again and
   Catalog.
4. Check out again with the declining card and watch the order end in PaymentFailed.
5. Switch the language to Srpski in the header menu: navigation, products, basket,
   checkout and order statuses turn Serbian, prices and dates follow, and a refresh keeps
   the choice because it lives in Redis under your buyer id.

Test cards:

| Number | Result |
|---|---|
| `4242 4242 4242 4242` | approved |
| `4000 0000 0000 0002` | declined with `card_declined` |

## Show resilience

Stop resources from the dashboard, or with the CLI, and watch the system cope:

| Stop | What happens |
|---|---|
| `payment-api` | orders stay Submitted and the processor retries; they complete when Payment is back |
| `messaging` | checkout still succeeds; the outbox delivers `OrderPlaced` when the broker returns |
| `catalog-api` | checkout answers `503` with `basket.catalog_unavailable`; a pending `OrderPaid` waits in the queue and stock is corrected when Catalog is back |

```bash
AH=src/Ecommerce.AppHost/Ecommerce.AppHost.csproj
aspire resource payment-api stop --apphost $AH
aspire resource payment-api start --apphost $AH
```

## The Aspire CLI as a demo tool

Everything the dashboard shows is also on the command line, which is handy on stage:

```bash
AH=src/Ecommerce.AppHost/Ecommerce.AppHost.csproj
aspire start --apphost $AH                          # run in the background
aspire wait gateway --status healthy --apphost $AH  # block until the system is up
aspire describe --apphost $AH                       # resources, endpoints, health
aspire logs ordering-api --search OrderProcessor --apphost $AH
aspire otel traces basket-api --apphost $AH         # traces through the dashboard telemetry API
aspire stop --apphost $AH
```

The three Wolverine services carry JasperFx commands on their dashboard tiles: check
the environment, describe the messaging configuration and preview the generated code.
They run the service's own command line against the running configuration and stream
the output into the resource logs.

## Test

```bash
dotnet test
```

Unit tests run in seconds. `Ecommerce.IntegrationTests` boots the whole AppHost through
`Aspire.Hosting.Testing`, buys a product through the gateway, waits for the order to
ship and the stock to drop, checks the declining card, and calls the API through the
frontend's own dev server to prove the `/api` proxy, stores a language preference and
reads a product and a basket line in Serbian. It needs Docker and Node on the
PATH and takes about a minute.

The frontend has its own checks:

```bash
cd src/ecommerce-frontend && nvm use && npm test && npm run lint
```

## Dependencies

Everything is open source under MIT, Apache 2.0 or the BSD license, with no personal or
commercial license requirement; the full table is in the architecture document.

Goran Todorovic 2026 - Master.
